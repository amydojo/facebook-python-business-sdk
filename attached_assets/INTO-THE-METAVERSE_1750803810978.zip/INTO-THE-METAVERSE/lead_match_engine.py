"""
Meta ↔ Airtable Lead Match Engine
Real ROAS & ROI calculation with authentic revenue tracking
"""
import pandas as pd
import streamlit as st
import numpy as np
from datetime import datetime
import re

class LeadMatchEngine:
    """Advanced lead matching and revenue attribution system"""
    
    def __init__(self):
        # Exact Airtable field mappings from your API documentation
        self.field_mapping = {
            'email': 'fldAnzFEtflKfcrcB',  # Email
            'phone': 'fld8xTYVdZPis6HDZ',  # Phone
            'contact_source': 'fldBUfZjdVhhJpRRA',  # Contact Source
            'brand': 'flddGiLa7lQ0nodBz',  # Brand
            'service': 'fldkOezyuypk702fU',  # Service
            'consult_status': 'fldSKhUarguxwbUHy',  # Consult Status
            'overall_status': 'fldsMq5UysgZe3rin',  # Overall Status
            'scheduled_location': 'fldzZY4vUX0nNBKL1',  # Scheduled Location
            'original_location': 'fldYy4VbsGAZBdaWy',  # Original Location
            'inbound_date': 'fldatlCCIFOSP4Gox',  # Inbound
            'lead_id': 'fldZBmUMcgnBJFfYW'  # ID
        }
        
        self.transaction_fields = {
            'amount': 'fldUIvamoBDCIayd3',  # Amount
            'lead_link': 'fldP2jAWtabHOpFhQ',  # ID (link to Leads)
            'status': 'fld67faZjBYC5QmUN',  # Status
            'patient': 'fldFvLb6TBxbOieWZ',  # Patient
            'date': 'fldsTSGtw52nGLBgf',  # Date
            'payment_type': 'fldm4QvADomcUlcfB'  # Payment Type
        }
        
        # Exact Meta source values from your Contact Source field
        self.meta_sources = ['Facebook AD', 'Instagram AD', 'Facebook AD Sign Up']
        
        # Exact status values from your Airtable fields
        self.booked_statuses = ['Arrived', 'Scheduled']
        self.converted_statuses = ['Closed', 'Deposit Paid', 'Installment Plan']
        self.paid_statuses = ['Paid in Full', 'Installment Payment']
        
        # Only Smooth MD brand filter
        self.target_brand = 'Smooth M.D.'
    
    def match_leads_to_meta(self, leads_df, meta_campaigns_df=None):
        """
        Step 1: Match leads from Airtable to Meta campaigns
        Priority: Email → Phone → Source filtering
        """
        if leads_df.empty:
            return pd.DataFrame()
        
        st.info("🔍 **Step 1: Matching Leads to Meta Sources**")
        
        # Filter for Meta leads only
        meta_leads = self._filter_meta_leads(leads_df)
        
        if meta_leads.empty:
            st.warning("No Meta leads found in your data")
            return pd.DataFrame()
        
        # Add matching metadata
        meta_leads = meta_leads.copy()
        meta_leads['match_method'] = 'source_filter'
        meta_leads['is_meta_lead'] = True
        
        st.success(f"✅ Found {len(meta_leads)} leads from Meta sources")
        
        # Show breakdown by source
        if self.field_mapping['contact_source'] in meta_leads.columns:
            source_breakdown = meta_leads[self.field_mapping['contact_source']].value_counts()
            st.write("**Source breakdown:**")
            for source, count in source_breakdown.head(5).items():
                st.write(f"• {source}: {count} leads")
        
        return meta_leads
    
    def calculate_booking_conversion_status(self, matched_leads):
        """
        Step 2: Determine booking and conversion status for each lead
        """
        if matched_leads.empty:
            return matched_leads
        
        st.info("📊 **Step 2: Calculating Booking & Conversion Status**")
        
        leads_with_status = matched_leads.copy()
        
        # Check consult status for bookings
        consult_col = self.field_mapping['consult_status']
        if consult_col in leads_with_status.columns:
            leads_with_status['is_booked'] = leads_with_status[consult_col].apply(
                lambda x: self._check_status(x, self.booked_statuses)
            )
        else:
            # Try alternate column names
            possible_consult_cols = [col for col in leads_with_status.columns 
                                   if 'consult' in col.lower() or 'appointment' in col.lower()]
            if possible_consult_cols:
                leads_with_status['is_booked'] = leads_with_status[possible_consult_cols[0]].apply(
                    lambda x: self._check_status(x, self.booked_statuses)
                )
                st.info(f"Using '{possible_consult_cols[0]}' for booking status")
            else:
                leads_with_status['is_booked'] = False
                st.warning("No consult status column found - using default booking status")
        
        # Check overall status for conversions
        overall_col = self.field_mapping['overall_status']
        if overall_col in leads_with_status.columns:
            leads_with_status['is_converted'] = leads_with_status[overall_col].apply(
                lambda x: self._check_status(x, self.converted_statuses)
            )
        else:
            # Try alternate column names
            possible_status_cols = [col for col in leads_with_status.columns 
                                  if 'status' in col.lower() and 'consult' not in col.lower()]
            if possible_status_cols:
                leads_with_status['is_converted'] = leads_with_status[possible_status_cols[0]].apply(
                    lambda x: self._check_status(x, self.converted_statuses)
                )
                st.info(f"Using '{possible_status_cols[0]}' for conversion status")
            else:
                leads_with_status['is_converted'] = False
                st.warning("No overall status column found - using default conversion status")
        
        # Calculate metrics
        total_leads = len(leads_with_status)
        booked_count = leads_with_status['is_booked'].sum()
        converted_count = leads_with_status['is_converted'].sum()
        
        booking_rate = (booked_count / total_leads * 100) if total_leads > 0 else 0
        conversion_rate = (converted_count / total_leads * 100) if total_leads > 0 else 0
        
        st.success(f"""
        ✅ **Booking & Conversion Analysis:**
        • Total Meta Leads: {total_leads:,}
        • Booked Leads: {booked_count:,} ({booking_rate:.1f}%)
        • Converted Leads: {converted_count:,} ({conversion_rate:.1f}%)
        """)
        
        return leads_with_status
    
    def link_transactions_and_revenue(self, leads_with_status, transactions_df):
        """
        Step 3: Link transactions to leads and calculate actual revenue
        """
        if leads_with_status.empty or transactions_df.empty:
            st.warning("Missing leads or transactions data for revenue calculation")
            return leads_with_status
        
        st.info("💰 **Step 3: Linking Transactions & Calculating Revenue**")
        
        leads_with_revenue = leads_with_status.copy()
        leads_with_revenue['transaction_amount'] = 0.0
        leads_with_revenue['transaction_count'] = 0
        leads_with_revenue['transaction_status'] = ""
        
        # Try to match transactions by lead ID or email
        matched_transactions = 0
        total_revenue = 0.0
        
        for idx, lead in leads_with_revenue.iterrows():
            lead_transactions = self._find_lead_transactions(lead, transactions_df)
            
            if not lead_transactions.empty:
                # Sum transaction amounts for this lead
                amount_col = self.transaction_fields['amount']
                if amount_col in lead_transactions.columns:
                    lead_revenue = lead_transactions[amount_col].apply(
                        lambda x: self._parse_amount(x)
                    ).sum()
                    
                    leads_with_revenue.at[idx, 'transaction_amount'] = lead_revenue
                    leads_with_revenue.at[idx, 'transaction_count'] = len(lead_transactions)
                    
                    # Get transaction status
                    if 'Status' in lead_transactions.columns:
                        statuses = lead_transactions['Status'].dropna().unique()
                        leads_with_revenue.at[idx, 'transaction_status'] = ', '.join(str(s) for s in statuses)
                    
                    matched_transactions += 1
                    total_revenue += lead_revenue
        
        # Calculate summary metrics
        leads_with_revenue_count = (leads_with_revenue['transaction_amount'] > 0).sum()
        avg_transaction_value = total_revenue / leads_with_revenue_count if leads_with_revenue_count > 0 else 0
        
        st.success(f"""
        ✅ **Revenue Analysis:**
        • Transactions Matched: {matched_transactions:,}
        • Leads with Revenue: {leads_with_revenue_count:,}
        • Total Revenue: ${total_revenue:,.2f}
        • Average Transaction: ${avg_transaction_value:,.2f}
        """)
        
        return leads_with_revenue
    
    def calculate_real_roas_roi(self, leads_with_revenue, meta_spend):
        """
        Step 4: Calculate authentic ROAS and ROI metrics
        """
        if leads_with_revenue.empty:
            return {}, leads_with_revenue
        
        st.info("📈 **Step 4: Computing Real ROAS & ROI**")
        
        # Calculate key metrics
        total_leads = len(leads_with_revenue)
        booked_leads = leads_with_revenue['is_booked'].sum()
        converted_leads = leads_with_revenue['is_converted'].sum()
        total_revenue = leads_with_revenue['transaction_amount'].sum()
        leads_with_revenue_count = (leads_with_revenue['transaction_amount'] > 0).sum()
        
        # Calculate rates
        booking_rate = (booked_leads / total_leads * 100) if total_leads > 0 else 0
        conversion_rate = (converted_leads / total_leads * 100) if total_leads > 0 else 0
        revenue_rate = (leads_with_revenue_count / total_leads * 100) if total_leads > 0 else 0
        
        # Calculate financial metrics
        roas = total_revenue / meta_spend if meta_spend > 0 else 0
        roi = ((total_revenue - meta_spend) / meta_spend * 100) if meta_spend > 0 else 0
        cost_per_lead = meta_spend / total_leads if total_leads > 0 else 0
        cost_per_conversion = meta_spend / converted_leads if converted_leads > 0 else 0
        revenue_per_lead = total_revenue / total_leads if total_leads > 0 else 0
        
        metrics = {
            'total_leads': total_leads,
            'booked_leads': booked_leads,
            'converted_leads': converted_leads,
            'leads_with_revenue': leads_with_revenue_count,
            'total_revenue': total_revenue,
            'meta_spend': meta_spend,
            'booking_rate': booking_rate,
            'conversion_rate': conversion_rate,
            'revenue_rate': revenue_rate,
            'roas': roas,
            'roi': roi,
            'cost_per_lead': cost_per_lead,
            'cost_per_conversion': cost_per_conversion,
            'revenue_per_lead': revenue_per_lead
        }
        
        # Display beautiful metrics
        st.success("✅ **Final ROAS & ROI Analysis:**")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                "💰 Real ROAS", 
                f"{roas:.2f}x",
                delta=f"${total_revenue:,.0f} revenue" if total_revenue > 0 else None
            )
        
        with col2:
            st.metric(
                "📊 ROI", 
                f"{roi:.1f}%",
                delta=f"${total_revenue - meta_spend:,.0f} profit" if total_revenue > meta_spend else None
            )
        
        with col3:
            st.metric(
                "🎯 Conversion Rate", 
                f"{conversion_rate:.1f}%",
                delta=f"{converted_leads}/{total_leads} leads"
            )
        
        with col4:
            st.metric(
                "💵 Revenue/Lead", 
                f"${revenue_per_lead:.0f}",
                delta=f"{leads_with_revenue_count} paid" if leads_with_revenue_count > 0 else None
            )
        
        return metrics, leads_with_revenue
    
    def create_brand_location_breakdown(self, leads_with_revenue):
        """
        Smart filters and brand-level breakdown analysis
        """
        if leads_with_revenue.empty:
            return {}
        
        st.info("🏢 **Brand & Location Performance Breakdown**")
        
        breakdowns = {}
        
        # Brand breakdown
        brand_col = self.field_mapping['brand']
        if brand_col in leads_with_revenue.columns:
            brand_breakdown = leads_with_revenue.groupby(brand_col).agg({
                'is_booked': 'sum',
                'is_converted': 'sum', 
                'transaction_amount': 'sum'
            }).reset_index()
            brand_breakdown.columns = ['Brand', 'Booked', 'Converted', 'Revenue']
            breakdowns['brand'] = brand_breakdown
            
            st.write("**Performance by Brand:**")
            st.dataframe(brand_breakdown, use_container_width=True)
        
        # Location breakdown
        location_col = self.field_mapping['scheduled_location']
        if location_col in leads_with_revenue.columns:
            location_breakdown = leads_with_revenue.groupby(location_col).agg({
                'is_booked': 'sum',
                'is_converted': 'sum',
                'transaction_amount': 'sum'
            }).reset_index()
            location_breakdown.columns = ['Location', 'Booked', 'Converted', 'Revenue']
            breakdowns['location'] = location_breakdown
            
            st.write("**Performance by Location:**")
            st.dataframe(location_breakdown, use_container_width=True)
        
        # Service breakdown
        service_col = self.field_mapping['service']
        if service_col in leads_with_revenue.columns:
            service_breakdown = leads_with_revenue.groupby(service_col).agg({
                'is_booked': 'sum',
                'is_converted': 'sum',
                'transaction_amount': 'sum'
            }).reset_index()
            service_breakdown.columns = ['Service', 'Booked', 'Converted', 'Revenue']
            breakdowns['service'] = service_breakdown
            
            st.write("**Performance by Service:**")
            st.dataframe(service_breakdown, use_container_width=True)
        
        return breakdowns
    
    def _filter_meta_leads(self, leads_df):
        """Filter leads from Meta sources for Smooth MD only"""
        # First filter for Smooth MD brand
        brand_col = self.field_mapping['brand']
        source_col = self.field_mapping['contact_source']
        
        if brand_col not in leads_df.columns:
            st.warning(f"Brand column '{brand_col}' not found in data")
            return pd.DataFrame()
        
        if source_col not in leads_df.columns:
            st.warning(f"Contact Source column '{source_col}' not found in data")
            return pd.DataFrame()
        
        # Filter for Smooth MD brand only
        smooth_md_filter = leads_df[brand_col] == self.target_brand
        
        # Filter for Meta sources (exact matches)
        meta_source_filter = leads_df[source_col].isin(self.meta_sources)
        
        # Combine filters
        combined_filter = smooth_md_filter & meta_source_filter
        
        filtered_leads = leads_df[combined_filter].copy()
        
        st.info(f"Found {len(filtered_leads)} Smooth MD leads from Meta sources out of {len(leads_df)} total leads")
        
        return filtered_leads
    
    def _check_status(self, status_value, target_statuses):
        """Check if status matches any target statuses"""
        if pd.isna(status_value):
            return False
        
        status_str = str(status_value).lower()
        return any(target.lower() in status_str for target in target_statuses)
    
    def _find_lead_transactions(self, lead, transactions_df):
        """Find transactions linked to a specific lead using exact Airtable structure"""
        matches = pd.DataFrame()
        
        # Try matching by lead ID link (this is the primary link field)
        link_col = self.transaction_fields['lead_link']  # fldP2jAWtabHOpFhQ
        
        if link_col in transactions_df.columns:
            # Get the record ID from the lead (Airtable record ID)
            if hasattr(lead, 'name') and lead.name:  # lead.name contains the record ID when iterating
                lead_record_id = lead.name
                # Match where the link field contains this record ID
                id_matches = transactions_df[
                    transactions_df[link_col].astype(str).str.contains(str(lead_record_id), na=False)
                ]
                if not id_matches.empty:
                    matches = pd.concat([matches, id_matches])
        
        # Fallback: Try matching by email using lookup field
        email_lookup_col = 'fld2TcRIN6jsulo4k'  # Email lookup field in transactions
        if email_lookup_col in transactions_df.columns:
            lead_email = lead.get(self.field_mapping['email'])
            if pd.notna(lead_email):
                email_matches = transactions_df[
                    transactions_df[email_lookup_col].astype(str).str.contains(str(lead_email), na=False, case=False)
                ]
                if not email_matches.empty:
                    matches = pd.concat([matches, email_matches])
        
        # Fallback: Try matching by phone using lookup field  
        phone_lookup_col = 'fldtZJkmnhmIqIiYH'  # Phone lookup field in transactions
        if phone_lookup_col in transactions_df.columns and matches.empty:
            lead_phone = lead.get(self.field_mapping['phone'])
            if pd.notna(lead_phone):
                phone_matches = transactions_df[
                    transactions_df[phone_lookup_col].astype(str).str.contains(str(lead_phone), na=False)
                ]
                if not phone_matches.empty:
                    matches = pd.concat([matches, phone_matches])
        
        return matches.drop_duplicates()
    
    def _parse_amount(self, amount_value):
        """Parse amount from various formats"""
        if pd.isna(amount_value):
            return 0.0
        
        # Convert to string and clean
        amount_str = str(amount_value).replace('$', '').replace(',', '').strip()
        
        try:
            return float(amount_str)
        except (ValueError, TypeError):
            return 0.0