"""
Deep Dive Airtable Connection Diagnostic Tool
Comprehensive testing of Airtable API connection issues
"""
import os
import json
import requests
import pandas as pd
import streamlit as st
from pyairtable import Api
from datetime import datetime

def diagnose_airtable_connection():
    """Comprehensive Airtable connection diagnosis"""
    st.title("🔍 Airtable Connection Deep Dive Diagnosis")
    
    # Get credentials from session state
    api_key = st.session_state.get('api_key', '')
    base_id = st.session_state.get('base_id', 'appri2CgCoIiuZWq3')
    table_name = st.session_state.get('leads_table_name', 'Leads')
    
    st.info(f"Testing connection to Base: {base_id}, Table: {table_name}")
    
    # Test 1: API Key Validation
    st.subheader("🔑 Step 1: API Key Validation")
    
    if not api_key:
        st.error("❌ No API key found in session state!")
        st.info("Please check your settings and ensure the API key is saved.")
        return
    
    if api_key.startswith('pat'):
        st.success("✅ API key format appears correct (Personal Access Token)")
    elif api_key.startswith('key'):
        st.warning("⚠️ Using legacy API key format - consider upgrading to Personal Access Token")
    else:
        st.error("❌ API key format doesn't match expected patterns")
    
    # Test 2: Direct HTTP API Test
    st.subheader("🌐 Step 2: Direct HTTP API Test")
    
    try:
        # Test basic API access with direct HTTP request
        url = f"https://api.airtable.com/v0/{base_id}/{table_name}"
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        
        with st.spinner("Testing direct HTTP connection..."):
            response = requests.get(url, headers=headers, params={'maxRecords': 1})
        
        st.write(f"Response Status: {response.status_code}")
        
        if response.status_code == 200:
            st.success("✅ Direct HTTP API connection successful!")
            data = response.json()
            st.write(f"Records found: {len(data.get('records', []))}")
            
            # Show sample record structure
            if data.get('records'):
                st.write("Sample record structure:")
                st.json(data['records'][0])
        
        elif response.status_code == 401:
            st.error("❌ Authentication failed - Invalid API key")
            st.info("Please verify your API key in Airtable account settings")
        
        elif response.status_code == 403:
            st.error("❌ Permission denied - API key lacks required permissions")
            st.info("Ensure your API key has read access to this base and table")
        
        elif response.status_code == 404:
            st.error("❌ Not found - Base ID or table name incorrect")
            st.info("Please verify your Base ID and table name")
        
        else:
            st.error(f"❌ Unexpected error: {response.status_code}")
            st.write("Response:", response.text)
    
    except Exception as e:
        st.error(f"❌ HTTP request failed: {str(e)}")
    
    # Test 3: PyAirtable Library Test
    st.subheader("📚 Step 3: PyAirtable Library Test")
    
    try:
        with st.spinner("Testing PyAirtable library connection..."):
            api = Api(api_key)
            table = api.table(base_id, table_name)
            
            # Try to get just one record
            records = table.all(max_records=1)
        
        st.success("✅ PyAirtable library connection successful!")
        st.write(f"Records retrieved: {len(records)}")
        
        if records:
            st.write("Sample record:")
            st.json(records[0])
    
    except Exception as e:
        st.error(f"❌ PyAirtable library failed: {str(e)}")
        st.write("Error type:", type(e).__name__)
        
        # Specific error handling
        if "401" in str(e):
            st.info("🔧 Fix: Check your API key permissions")
        elif "404" in str(e):
            st.info("🔧 Fix: Verify Base ID and table name")
        elif "timeout" in str(e).lower():
            st.info("🔧 Fix: Network timeout - try again")
    
    # Test 4: Table Schema Analysis
    st.subheader("📋 Step 4: Table Schema Analysis")
    
    try:
        # Get table schema
        schema_url = f"https://api.airtable.com/v0/meta/bases/{base_id}/tables"
        headers = {'Authorization': f'Bearer {api_key}'}
        
        response = requests.get(schema_url, headers=headers)
        
        if response.status_code == 200:
            schema_data = response.json()
            
            # Find our table
            target_table = None
            available_tables = []
            
            for table in schema_data.get('tables', []):
                available_tables.append(table['name'])
                if table['name'] == table_name:
                    target_table = table
                    break
            
            if target_table:
                st.success(f"✅ Table '{table_name}' found!")
                st.write(f"Table ID: {target_table['id']}")
                
                # Show field information
                st.write("Available fields:")
                fields_df = pd.DataFrame([
                    {
                        'Field Name': field['name'],
                        'Field Type': field['type'],
                        'Description': field.get('description', 'No description')
                    }
                    for field in target_table.get('fields', [])
                ])
                st.dataframe(fields_df)
            
            else:
                st.error(f"❌ Table '{table_name}' not found!")
                st.write("Available tables in this base:")
                for table in available_tables:
                    st.write(f"• {table}")
        
        else:
            st.warning("⚠️ Could not retrieve table schema")
    
    except Exception as e:
        st.warning(f"⚠️ Schema analysis failed: {str(e)}")
    
    # Test 5: Environment and Dependencies Check
    st.subheader("🔧 Step 5: Environment Check")
    
    # Check Python packages
    try:
        import pyairtable
        st.success(f"✅ PyAirtable version: {pyairtable.__version__}")
    except Exception as e:
        st.error(f"❌ PyAirtable import failed: {str(e)}")
    
    # Check environment variables
    env_api_key = os.environ.get("AIRTABLE_API_KEY")
    if env_api_key:
        st.info("📝 AIRTABLE_API_KEY environment variable is set")
        if env_api_key == api_key:
            st.success("✅ Session API key matches environment variable")
        else:
            st.warning("⚠️ Session API key differs from environment variable")
    else:
        st.info("📝 No AIRTABLE_API_KEY environment variable found")
    
    # Test 6: Rate Limiting Check
    st.subheader("⏱️ Step 6: Rate Limiting Test")
    
    try:
        start_time = datetime.now()
        
        # Make multiple rapid requests to test rate limiting
        for i in range(3):
            response = requests.get(
                f"https://api.airtable.com/v0/{base_id}/{table_name}",
                headers={'Authorization': f'Bearer {api_key}'},
                params={'maxRecords': 1}
            )
            
            if response.status_code == 429:
                st.warning(f"⚠️ Rate limit hit on request {i+1}")
                break
            elif response.status_code != 200:
                st.error(f"❌ Request {i+1} failed: {response.status_code}")
                break
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        st.success(f"✅ Rate limiting test completed in {duration:.2f} seconds")
    
    except Exception as e:
        st.error(f"❌ Rate limiting test failed: {str(e)}")
    
    # Test 7: Data Type Analysis
    st.subheader("🔍 Step 7: Data Quality Analysis")
    
    try:
        # Get a larger sample for analysis
        url = f"https://api.airtable.com/v0/{base_id}/{table_name}"
        headers = {'Authorization': f'Bearer {api_key}'}
        response = requests.get(url, headers=headers, params={'maxRecords': 10})
        
        if response.status_code == 200:
            data = response.json()
            records = data.get('records', [])
            
            if records:
                # Analyze field types and content
                field_analysis = {}
                
                for record in records:
                    fields = record.get('fields', {})
                    for field_name, value in fields.items():
                        if field_name not in field_analysis:
                            field_analysis[field_name] = {
                                'types': set(),
                                'sample_values': [],
                                'null_count': 0
                            }
                        
                        if value is None:
                            field_analysis[field_name]['null_count'] += 1
                        else:
                            field_analysis[field_name]['types'].add(type(value).__name__)
                            if len(field_analysis[field_name]['sample_values']) < 3:
                                field_analysis[field_name]['sample_values'].append(str(value)[:50])
                
                st.write("Field analysis:")
                analysis_df = pd.DataFrame([
                    {
                        'Field': field_name,
                        'Data Types': ', '.join(info['types']),
                        'Null Count': info['null_count'],
                        'Sample Values': ' | '.join(info['sample_values'])
                    }
                    for field_name, info in field_analysis.items()
                ])
                st.dataframe(analysis_df)
        
    except Exception as e:
        st.warning(f"⚠️ Data quality analysis failed: {str(e)}")
    
    # Summary and Recommendations
    st.subheader("📊 Summary & Recommendations")
    
    st.info("""
    **Common Airtable Connection Issues & Solutions:**
    
    1. **Invalid API Key** → Generate new Personal Access Token in Airtable
    2. **Wrong Base ID** → Check URL when viewing your base: `airtable.com/appXXXXXXXXXXXX/`
    3. **Incorrect Table Name** → Use exact name as shown in Airtable (case-sensitive)
    4. **Permission Issues** → Ensure API key has read access to base and table
    5. **Rate Limiting** → Airtable limits to 5 requests/second
    6. **Network Issues** → Check internet connection and firewall settings
    """)

if __name__ == "__main__":
    diagnose_airtable_connection()