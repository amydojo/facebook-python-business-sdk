"""
Production Dashboard V2
Rebuilt with reliable data connector and centralized configuration management
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta, date
import logging
from reliable_data_connector import ReliableDataConnector
from config_manager import get_config

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Smooth MD Meta Attribution Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

def apply_professional_styling():
    """Apply professional dashboard styling"""
    st.markdown("""
    <style>
    .stApp {
        background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    }
    
    .main .block-container {
        padding: 1rem;
        max-width: 100%;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 20px;
        backdrop-filter: blur(20px);
        margin-top: 1rem;
    }
    
    .dashboard-header {
        text-align: center;
        padding: 2rem 0;
        background: linear-gradient(135deg, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0.05) 100%);
        border-radius: 20px;
        margin-bottom: 2rem;
        border: 1px solid rgba(255,255,255,0.1);
    }
    
    .metric-card {
        background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 100%);
        padding: 1.5rem;
        border-radius: 15px;
        border: 1px solid rgba(255,255,255,0.1);
        margin-bottom: 1rem;
        backdrop-filter: blur(10px);
    }
    
    .metric-title {
        color: rgba(255,255,255,0.8);
        font-size: 0.9rem;
        font-weight: 500;
        margin-bottom: 0.5rem;
    }
    
    .metric-value {
        color: white;
        font-size: 2rem;
        font-weight: 700;
        margin-bottom: 0.25rem;
    }
    
    .metric-subtitle {
        color: rgba(255,255,255,0.6);
        font-size: 0.8rem;
    }
    
    .status-success { color: #10b981; font-weight: 600; }
    .status-error { color: #ef4444; font-weight: 600; }
    .status-warning { color: #f59e0b; font-weight: 600; }
    
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
        background: rgba(255,255,255,0.05);
        border-radius: 10px;
        padding: 4px;
    }
    
    .stTabs [data-baseweb="tab"] {
        background: transparent;
        border-radius: 8px;
        color: rgba(255,255,255,0.7);
        border: none;
        padding: 0.5rem 1rem;
    }
    
    .stTabs [aria-selected="true"] {
        background: rgba(255,255,255,0.15);
        color: white !important;
    }
    </style>
    """, unsafe_allow_html=True)

def display_connection_status(connector):
    """Display connection status with detailed diagnostics"""
    st.markdown("### Connection Status & Data Validation")
    
    status = connector.get_connection_status()
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Airtable Configuration**")
        
        if status['airtable_status'] == 'Configured':
            st.markdown('<span class="status-success">✓ Configured</span>', unsafe_allow_html=True)
        else:
            st.markdown('<span class="status-error">✗ Missing credentials</span>', unsafe_allow_html=True)
        
        st.markdown(f"**Base ID:** `{status['base_id']}`")
        st.markdown(f"**Transactions Table:** `{status['tables']['transactions']}`")
        st.markdown(f"**Leads Table:** `{status['tables']['leads']}`")
        
        if 'airtable_test' in status:
            if 'successful' in status['airtable_test']:
                st.markdown('<span class="status-success">✓ Connection Test Passed</span>', unsafe_allow_html=True)
            else:
                st.markdown(f'<span class="status-error">✗ {status["airtable_test"]}</span>', unsafe_allow_html=True)
    
    with col2:
        st.markdown("**Meta API Configuration**")
        
        if status['meta_status'] == 'Configured':
            st.markdown('<span class="status-success">✓ Configured</span>', unsafe_allow_html=True)
        else:
            st.markdown('<span class="status-error">✗ Missing credentials</span>', unsafe_allow_html=True)
        
        if 'meta_test' in status:
            if 'successful' in status['meta_test']:
                st.markdown('<span class="status-success">✓ Connection Test Passed</span>', unsafe_allow_html=True)
            else:
                st.markdown(f'<span class="status-error">✗ {status["meta_test"]}</span>', unsafe_allow_html=True)

def create_date_range_selector():
    """Create enhanced date range selector"""
    st.markdown("### Custom Date Range Analysis")
    
    tab1, tab2 = st.tabs(["Custom Range", "Quick Select"])
    
    with tab1:
        col1, col2, col3 = st.columns(3)
        
        with col1:
            start_date = st.date_input(
                "Start Date", 
                value=date.today() - timedelta(days=30),
                help="Select the beginning of your analysis period"
            )
        
        with col2:
            end_date = st.date_input(
                "End Date", 
                value=date.today(),
                help="Select the end of your analysis period"
            )
        
        with col3:
            st.markdown("<br>", unsafe_allow_html=True)
            compare_periods = st.checkbox(
                "Compare with Previous Period", 
                help="Compare metrics with the equivalent previous time period"
            )
    
    with tab2:
        col1, col2 = st.columns(2)
        
        with col1:
            period_options = {
                "Last 7 Days": 7,
                "Last 14 Days": 14,
                "Last 30 Days": 30,
                "Last 60 Days": 60,
                "Last 90 Days": 90
            }
            
            selected_period = st.selectbox("Choose Period", list(period_options.keys()), index=2)
            
            if selected_period:
                days_back = period_options[selected_period]
                end_date = date.today()
                start_date = end_date - timedelta(days=days_back)
        
        with col2:
            if st.button("This Month"):
                start_date = date.today().replace(day=1)
                end_date = date.today()
            
            if st.button("Last Month"):
                today = date.today()
                first = today.replace(day=1)
                end_date = first - timedelta(days=1)
                start_date = end_date.replace(day=1)
            
            compare_periods = st.checkbox("Enable Period Comparison", key="quick_compare")
    
    return start_date, end_date, compare_periods

def display_main_metrics(transactions_data, leads_data, meta_data):
    """Display main performance metrics"""
    revenue = transactions_data.get('total_revenue', 0)
    transaction_count = transactions_data.get('transaction_count', 0)
    spend = meta_data.get('spend', 0)
    impressions = meta_data.get('impressions', 0)
    clicks = meta_data.get('clicks', 0)
    total_leads = leads_data.get('total_leads', 0)
    converted_leads = leads_data.get('converted_leads', 0)
    
    roas = revenue / spend if spend > 0 else 0
    conversion_rate = (converted_leads / total_leads * 100) if total_leads > 0 else 0
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Total Revenue</div>
            <div class="metric-value">${revenue:,.2f}</div>
            <div class="metric-subtitle">{transaction_count} transactions</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Meta Ad Spend</div>
            <div class="metric-value">${spend:,.2f}</div>
            <div class="metric-subtitle">{impressions:,} impressions</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">ROAS</div>
            <div class="metric-value">{roas:.2f}x</div>
            <div class="metric-subtitle">{clicks:,} clicks</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Conversion Rate</div>
            <div class="metric-value">{conversion_rate:.1f}%</div>
            <div class="metric-subtitle">{total_leads} total leads</div>
        </div>
        """, unsafe_allow_html=True)

def display_data_validation(transactions_data, leads_data, start_date, end_date):
    """Display data validation and freshness information"""
    st.markdown("### Data Validation & Freshness")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Transaction Data (Revenue)**")
        
        if transactions_data.get('error'):
            st.error(f"Transaction data error: {transactions_data['error']}")
        else:
            trans_metrics = {
                'Status': '✓ Connected' if transactions_data.get('success') else '✗ Error',
                'Date Range': f"{start_date} to {end_date}",
                'Total Transactions': transactions_data.get('transaction_count', 0),
                'Total Revenue': f"${transactions_data.get('total_revenue', 0):,.2f}",
                'Data Source': 'Airtable Base: appH4MePHS6qLsk5z'
            }
            
            for metric, value in trans_metrics.items():
                st.markdown(f"**{metric}:** {value}")
            
            # Show latest transaction
            transactions = transactions_data.get('transactions', [])
            if transactions:
                latest_trans = max(transactions, key=lambda x: x['date'])
                st.markdown(f"**Latest Transaction:** {latest_trans['date']} - ${latest_trans['amount']}")
    
    with col2:
        st.markdown("**Lead Data (Funnel)**")
        
        if leads_data.get('error'):
            st.error(f"Lead data error: {leads_data['error']}")
        else:
            lead_metrics = {
                'Status': '✓ Connected' if leads_data.get('success') else '✗ Error',
                'Date Range': f"{start_date} to {end_date}",
                'Total Leads': leads_data.get('total_leads', 0),
                'Booked Leads': leads_data.get('booked_leads', 0),
                'Converted Leads': leads_data.get('converted_leads', 0),
                'Data Source': 'Airtable Base: appH4MePHS6qLsk5z'
            }
            
            for metric, value in lead_metrics.items():
                st.markdown(f"**{metric}:** {value}")
            
            # Show conversion rate
            total_leads = leads_data.get('total_leads', 0)
            converted_leads = leads_data.get('converted_leads', 0)
            if total_leads > 0:
                conversion_rate = (converted_leads / total_leads * 100)
                st.markdown(f"**Conversion Rate:** {conversion_rate:.1f}%")

def display_campaign_breakdown(breakdown_data):
    """Display detailed campaign breakdown"""
    st.markdown("### Detailed Ad Performance Breakdown")
    
    if breakdown_data.get('error'):
        st.warning(f"Campaign breakdown unavailable: {breakdown_data['error']}")
        st.info("To see detailed ad performance, ensure your Meta API credentials are properly configured")
        return
    
    breakdown = breakdown_data.get('breakdown_data', {})
    
    tab1, tab2, tab3 = st.tabs(["Campaigns", "Ad Sets", "Ad Creatives"])
    
    with tab1:
        campaigns = breakdown.get('campaigns', [])
        if campaigns:
            st.markdown("**Campaign Performance Overview**")
            
            campaigns_df = pd.DataFrame(campaigns)
            campaigns_df['spend'] = campaigns_df['spend'].astype(float)
            campaigns_df['impressions'] = campaigns_df['impressions'].astype(int)
            campaigns_df['clicks'] = campaigns_df['clicks'].astype(int)
            campaigns_df['ctr'] = campaigns_df['ctr'].astype(float)
            campaigns_df = campaigns_df.sort_values('spend', ascending=False)
            
            col1, col2 = st.columns(2)
            
            with col1:
                fig = px.bar(
                    campaigns_df.head(10), 
                    x='campaign_name', 
                    y='spend',
                    title="Campaign Spend Distribution"
                )
                fig.update_layout(
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)',
                    font_color='white',
                    title_font_color='white'
                )
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                st.markdown("**Top Performing Campaigns:**")
                display_df = campaigns_df[['campaign_name', 'spend', 'impressions', 'clicks', 'ctr']].head(5)
                display_df.columns = ['Campaign', 'Spend ($)', 'Impressions', 'Clicks', 'CTR (%)']
                st.dataframe(display_df, use_container_width=True)
        else:
            st.info("No campaign data available for the selected period")
    
    with tab2:
        adsets = breakdown.get('adsets', [])
        if adsets:
            st.markdown("**Ad Set Performance Analysis**")
            
            adsets_df = pd.DataFrame(adsets)
            adsets_df['spend'] = adsets_df['spend'].astype(float)
            adsets_df['ctr'] = adsets_df['ctr'].astype(float)
            adsets_df['impressions'] = adsets_df['impressions'].astype(int)
            
            col1, col2 = st.columns(2)
            
            with col1:
                fig = px.scatter(
                    adsets_df, 
                    x='spend', 
                    y='ctr',
                    size='impressions',
                    hover_data=['adset_name', 'campaign_name'],
                    title="Ad Set Efficiency: CTR vs Spend"
                )
                fig.update_layout(
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)',
                    font_color='white',
                    title_font_color='white'
                )
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                st.markdown("**Top Ad Sets by Performance:**")
                display_df = adsets_df[['adset_name', 'campaign_name', 'spend', 'ctr']].head(5)
                display_df.columns = ['Ad Set', 'Campaign', 'Spend ($)', 'CTR (%)']
                st.dataframe(display_df, use_container_width=True)
        else:
            st.info("No ad set data available for the selected period")
    
    with tab3:
        ads = breakdown.get('ads', [])
        if ads:
            st.markdown("**Individual Ad Creative Performance**")
            
            ads_df = pd.DataFrame(ads)
            ads_df['spend'] = ads_df['spend'].astype(float)
            ads_df['ctr'] = ads_df['ctr'].astype(float)
            ads_df['clicks'] = ads_df['clicks'].astype(int)
            ads_df = ads_df.sort_values('spend', ascending=False)
            
            col1, col2 = st.columns(2)
            
            with col1:
                top_ads = ads_df.head(10)
                fig = px.bar(
                    top_ads, 
                    x='ad_name', 
                    y='spend',
                    color='ctr',
                    title="Top Ad Creatives by Spend & CTR"
                )
                fig.update_layout(
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)',
                    font_color='white',
                    title_font_color='white'
                )
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                st.markdown("**Best Performing Ad Creatives:**")
                
                ads_df['cpc'] = ads_df['spend'] / ads_df['clicks']
                ads_df['cpc'] = ads_df['cpc'].replace([float('inf')], 0)
                
                display_df = ads_df[['ad_name', 'campaign_name', 'spend', 'clicks', 'ctr', 'cpc']].head(8)
                display_df.columns = ['Ad Creative', 'Campaign', 'Spend ($)', 'Clicks', 'CTR (%)', 'CPC ($)']
                st.dataframe(display_df, use_container_width=True)
        else:
            st.info("No individual ad data available for the selected period")

def display_service_breakdown(transactions_data):
    """Display service performance breakdown"""
    transactions = transactions_data.get('transactions', [])
    if not transactions:
        return
    
    st.markdown("### Service Performance Analysis")
    
    df = pd.DataFrame(transactions)
    service_revenue = df.groupby('service')['amount'].agg(['sum', 'count']).reset_index()
    service_revenue.columns = ['Service', 'Revenue', 'Count']
    service_revenue = service_revenue.sort_values('Revenue', ascending=False)
    
    col1, col2 = st.columns(2)
    
    with col1:
        fig = px.pie(
            service_revenue, 
            values='Revenue', 
            names='Service',
            title="Revenue by Service"
        )
        fig.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='white',
            title_font_color='white'
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("**Service Performance Details:**")
        for _, row in service_revenue.iterrows():
            avg_value = row['Revenue'] / row['Count'] if row['Count'] > 0 else 0
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">{row['Service']}</div>
                <div class="metric-value">${row['Revenue']:,.2f}</div>
                <div class="metric-subtitle">{row['Count']} transactions • Avg: ${avg_value:.2f}</div>
            </div>
            """, unsafe_allow_html=True)

def main():
    """Main dashboard application"""
    apply_professional_styling()
    
    # Dashboard Header
    st.markdown("""
    <div class="dashboard-header">
        <h1 style="color: white; font-size: 2.5rem; margin: 0;">Smooth MD Meta Attribution Dashboard</h1>
        <p style="color: rgba(255,255,255,0.8); font-size: 1.1rem; margin: 0.5rem 0 0 0;">
            Authentic Data Integration & Performance Analysis
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize reliable data connector
    connector = ReliableDataConnector()
    
    # Display connection status
    display_connection_status(connector)
    
    # Date range selection
    start_date, end_date, compare_periods = create_date_range_selector()
    
    # Convert dates to strings
    start_str = start_date.strftime('%Y-%m-%d')
    end_str = end_date.strftime('%Y-%m-%d')
    
    # Display period information
    st.markdown(f"""
    **Analysis Period:** {start_date.strftime('%B %d, %Y')} to {end_date.strftime('%B %d, %Y')} 
    ({(end_date - start_date).days + 1} days)
    """)
    
    # Load all data
    with st.spinner("Loading comprehensive data from authentic sources..."):
        transactions_data = connector.load_transaction_data(start_str, end_str)
        leads_data = connector.load_leads_data(start_str, end_str)
        meta_data = connector.load_meta_insights(start_str, end_str)
        breakdown_data = connector.load_campaign_breakdown(start_str, end_str)
    
    # Display main metrics
    if not transactions_data.get('error') and not leads_data.get('error'):
        display_main_metrics(transactions_data, leads_data, meta_data)
    
    # Display data validation
    display_data_validation(transactions_data, leads_data, start_date, end_date)
    
    # Display campaign breakdown
    display_campaign_breakdown(breakdown_data)
    
    # Display service breakdown
    display_service_breakdown(transactions_data)

if __name__ == "__main__":
    main()