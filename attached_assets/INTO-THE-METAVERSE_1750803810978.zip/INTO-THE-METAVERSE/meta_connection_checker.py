
import os
import requests
import json
import streamlit as st

def check_meta_api_connection():
    st.set_page_config(page_title="Meta API Connection Checker", layout="wide")
    st.title("🔍 Meta API Connection Checker")
    
    # Get credentials from environment/secrets
    access_token = st.secrets.get("META_ACCESS_TOKEN", os.environ.get("META_ACCESS_TOKEN", ""))
    account_id = st.secrets.get("META_AD_ACCOUNT_ID", os.environ.get("META_AD_ACCOUNT_ID", ""))
    
    if not access_token:
        access_token = st.text_input("Meta Access Token", type="password")
    
    if not account_id:
        account_id = st.text_input("Meta Ad Account ID (with or without 'act_' prefix)")
    
    # Add act_ prefix if missing
    if account_id and not account_id.startswith('act_'):
        account_id = f"act_{account_id}"
    
    if st.button("Test Connection"):
        if not access_token or not account_id:
            st.error("❌ Missing credentials. Please provide both Meta Access Token and Ad Account ID.")
            return
        
        st.info("🔄 Testing Meta API connection...")
        
        # Test account info endpoint
        api_version = "v22.0"
        base_url = f"https://graph.facebook.com/{api_version}"
        account_url = f"{base_url}/{account_id}"
        
        params = {
            "access_token": access_token,
            "fields": "id,name,account_status,currency,timezone_name,business_country_code"
        }
        
        try:
            response = requests.get(account_url, params=params)
            
            if response.status_code == 200:
                account_info = response.json()
                
                st.success(f"✅ Connection successful! Account: {account_info.get('name')}")
                
                # Display account information
                st.subheader("Account Information")
                cols = st.columns(3)
                cols[0].metric("Account ID", account_info.get('id', 'N/A'))
                cols[1].metric("Currency", account_info.get('currency', 'N/A'))
                cols[2].metric("Status", "Active" if account_info.get('account_status') == 1 else "Inactive")
                
                # Test campaigns endpoint
                st.subheader("Testing Campaign Access")
                campaign_url = f"{base_url}/{account_id}/campaigns"
                campaign_params = {
                    "access_token": access_token,
                    "fields": "id,name,status",
                    "limit": 5
                }
                
                try:
                    campaign_response = requests.get(campaign_url, params=campaign_params)
                    
                    if campaign_response.status_code == 200:
                        campaign_data = campaign_response.json()
                        campaigns = campaign_data.get('data', [])
                        
                        if campaigns:
                            st.success(f"✅ Successfully retrieved {len(campaigns)} campaigns")
                            st.dataframe([{
                                "Campaign ID": c.get('id'),
                                "Campaign Name": c.get('name'),
                                "Status": c.get('status')
                            } for c in campaigns])
                        else:
                            st.warning("⚠️ No campaigns found in this account")
                    else:
                        st.error(f"❌ Campaign access failed: {campaign_response.status_code}")
                        st.code(campaign_response.text)
                except Exception as e:
                    st.error(f"❌ Campaign access error: {str(e)}")
                
                # Test insights endpoint
                st.subheader("Testing Insights Access")
                insights_url = f"{base_url}/{account_id}/insights"
                
                time_range = json.dumps({
                    "since": "2024-01-01",
                    "until": "2024-12-31"
                })
                
                insights_params = {
                    "access_token": access_token,
                    "time_range": time_range,
                    "fields": "spend,impressions,clicks",
                    "level": "account",
                    "limit": 5
                }
                
                try:
                    insights_response = requests.get(insights_url, params=insights_params)
                    
                    if insights_response.status_code == 200:
                        insights_data = insights_response.json()
                        insights = insights_data.get('data', [])
                        
                        if insights:
                            st.success(f"✅ Successfully retrieved {len(insights)} insights records")
                            st.dataframe(insights)
                        else:
                            st.warning("⚠️ No insights data found for this period")
                    else:
                        st.error(f"❌ Insights access failed: {insights_response.status_code}")
                        st.code(insights_response.text)
                except Exception as e:
                    st.error(f"❌ Insights access error: {str(e)}")
                
            else:
                st.error(f"❌ Connection failed with status code {response.status_code}")
                error_details = response.json() if response.text else {"error": "No response details"}
                st.json(error_details)
                
                # Common error troubleshooting
                if response.status_code == 400:
                    st.warning("⚠️ This might be an invalid access token or account ID. Check your credentials.")
                elif response.status_code == 401:
                    st.warning("⚠️ Unauthorized access. Your access token may have expired.")
                elif response.status_code == 403:
                    st.warning("⚠️ Permission denied. Make sure your app has the proper permissions.")
                elif response.status_code == 404:
                    st.warning("⚠️ Account not found. Check your account ID.")
                
        except Exception as e:
            st.error(f"❌ Connection test failed: {str(e)}")
            st.info("Ensure you have a valid internet connection and that your credentials are correct.")

if __name__ == "__main__":
    check_meta_api_connection()
