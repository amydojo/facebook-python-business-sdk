#!/usr/bin/env python3
"""
Emergency Table Discovery System
Attempts multiple methods to discover accessible tables and validate permissions
"""

import os
import json
from pyairtable import Api, Table
import requests
import time

def test_direct_api_access():
    """Test direct API access with raw HTTP requests"""
    
    api_key = os.getenv('AIRTABLE_API_KEY')
    base_id = os.getenv('AIRTABLE_BASE_ID')
    
    if not api_key or not base_id:
        return False, "Missing credentials"
    
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json'
    }
    
    # Test base metadata endpoint
    try:
        url = f"https://api.airtable.com/v0/meta/bases/{base_id}/tables"
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            tables_data = response.json()
            table_names = [table['name'] for table in tables_data.get('tables', [])]
            return True, table_names
        else:
            return False, f"HTTP {response.status_code}: {response.text}"
            
    except Exception as e:
        return False, str(e)

def test_pyairtable_access():
    """Test pyairtable library access with various table names"""
    
    api_key = os.getenv('AIRTABLE_API_KEY')
    base_id = os.getenv('AIRTABLE_BASE_ID')
    
    if not api_key or not base_id:
        return {}
    
    api = Api(api_key)
    accessible_tables = {}
    
    # Extended list of possible table names
    possible_names = [
        'Leads', 'Lead', 'Prospects', 'Customers', 'Contacts', 'People',
        'Transactions', 'Social Media', 'Sales', 'Revenue', 'Payments', 'Orders',
        'Bookings', 'Appointments', 'Clients', 'Users', 'Records', 'Data',
        'Table 1', 'Table 2', 'Table 3', 'Main', 'Primary', 'Import'
    ]
    
    for table_name in possible_names:
        try:
            # Method 1: New API style
            table = api.table(base_id, table_name)
            records = table.all(max_records=1)
            
            accessible_tables[table_name] = {
                'method': 'api.table',
                'accessible': True,
                'record_count': len(records),
                'fields': list(records[0]['fields'].keys()) if records else []
            }
            
            print(f"✓ Found table: {table_name}")
            
        except Exception as e1:
            try:
                # Method 2: Direct Table class (legacy)
                table = Table(api_key, base_id, table_name)
                records = table.all(max_records=1)
                
                accessible_tables[table_name] = {
                    'method': 'Table',
                    'accessible': True,
                    'record_count': len(records),
                    'fields': list(records[0]['fields'].keys()) if records else []
                }
                
                print(f"✓ Found table (legacy): {table_name}")
                
            except Exception as e2:
                # Both methods failed
                if "NOT_FOUND" not in str(e1) and "404" not in str(e1):
                    print(f"✗ {table_name}: {e1}")
    
    return accessible_tables

def categorize_tables(accessible_tables):
    """Categorize tables based on field names"""
    
    categorized = {
        'transactions': [],
        'leads': [],
        'unknown': []
    }
    
    for table_name, info in accessible_tables.items():
        if not info.get('accessible'):
            continue
            
        fields = [f.lower() for f in info.get('fields', [])]
        field_string = ' '.join(fields)
        
        # Transaction indicators
        transaction_keywords = ['amount', 'revenue', 'payment', 'transaction', 'price', 'cost', 'total', 'value']
        if any(keyword in field_string for keyword in transaction_keywords):
            categorized['transactions'].append(table_name)
        # Lead indicators  
        elif any(keyword in field_string for keyword in ['email', 'phone', 'contact', 'lead', 'name', 'first', 'last', 'customer']):
            categorized['leads'].append(table_name)
        else:
            categorized['unknown'].append(table_name)
    
    return categorized

def update_connector_configuration(categorized_tables):
    """Update the unified connector with discovered tables"""
    
    config_updates = {}
    
    if categorized_tables['transactions']:
        config_updates['transactions'] = categorized_tables['transactions'][0]  # Use first match
        
    if categorized_tables['leads']:
        config_updates['leads'] = categorized_tables['leads'][0]  # Use first match
    
    # Write temporary config
    with open('discovered_tables.json', 'w') as f:
        json.dump({
            'discovered': categorized_tables,
            'recommended': config_updates,
            'timestamp': time.time()
        }, f, indent=2)
    
    return config_updates

def main():
    """Main diagnostic routine"""
    
    print("=== EMERGENCY TABLE DISCOVERY ===")
    
    # Test 1: Direct API access
    print("\n1. Testing direct API access...")
    api_success, api_result = test_direct_api_access()
    
    if api_success:
        print(f"✓ Direct API success: {api_result}")
        tables_from_api = api_result
    else:
        print(f"✗ Direct API failed: {api_result}")
        tables_from_api = []
    
    # Test 2: PyAirtable library access
    print("\n2. Testing pyairtable access...")
    accessible_tables = test_pyairtable_access()
    
    if accessible_tables:
        print(f"✓ Found {len(accessible_tables)} accessible tables via pyairtable")
        
        # Categorize tables
        categorized = categorize_tables(accessible_tables)
        
        print(f"\nCategorization results:")
        print(f"  Transaction tables: {categorized['transactions']}")
        print(f"  Lead tables: {categorized['leads']}")
        print(f"  Unknown tables: {categorized['unknown']}")
        
        # Update configuration
        config = update_connector_configuration(categorized)
        
        if config:
            print(f"\nRecommended configuration:")
            for data_type, table_name in config.items():
                print(f"  {data_type}: {table_name}")
            
            return True, config
        else:
            print("\nNo suitable tables found for required data types")
            return False, "No matching tables"
    
    else:
        print("✗ No tables accessible via any method")
        
        # Final diagnostic
        print("\n=== DIAGNOSTIC SUMMARY ===")
        print("Possible issues:")
        print("- API key lacks read permissions for this base")
        print("- Base ID is incorrect or changed")
        print("- Tables have been renamed or deleted")
        print("- Network connectivity issues")
        
        return False, "Complete access failure"

if __name__ == "__main__":
    success, result = main()
    
    if success:
        print(f"\n✓ Emergency discovery successful: {result}")
    else:
        print(f"\n✗ Emergency discovery failed: {result}")