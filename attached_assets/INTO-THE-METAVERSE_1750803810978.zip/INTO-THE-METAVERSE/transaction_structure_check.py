import streamlit as st
import os
from pyairtable import Api

def check_transaction_structure():
    """Check the actual structure of transaction records"""
    st.title("Transaction Data Structure Analysis")
    
    try:
        api_key = os.environ.get('AIRTABLE_API_KEY')
        base_id = os.environ.get('AIRTABLE_BASE_ID')
        
        if not api_key or not base_id:
            st.error("Missing Airtable credentials")
            return
            
        api = Api(api_key)
        table = api.table(base_id, 'Transactions')
        
        # Get first few records to analyze structure
        records = table.all(max_records=5)
        
        st.subheader("Sample Transaction Records")
        
        for i, record in enumerate(records):
            st.write(f"**Transaction {i+1}:**")
            st.write(f"Record ID: {record['id']}")
            
            fields = record['fields']
            st.write("Fields:")
            for field_name, field_value in fields.items():
                if field_name.lower() in ['lead', 'lead id', 'lead_id', 'customer', 'patient']:
                    st.write(f"  🔗 **{field_name}**: {field_value}")
                else:
                    st.write(f"  {field_name}: {field_value}")
            st.write("---")
            
        # Show all available field names
        st.subheader("All Available Fields")
        all_fields = set()
        for record in records:
            all_fields.update(record['fields'].keys())
            
        for field in sorted(all_fields):
            if 'lead' in field.lower() or 'customer' in field.lower() or 'patient' in field.lower():
                st.write(f"🔗 **{field}**")
            else:
                st.write(field)
                
    except Exception as e:
        st.error(f"Error: {str(e)}")

if __name__ == "__main__":
    check_transaction_structure()