"""
Final Meta Marketing Dashboard
Complete attribution tracking without dependency conflicts
"""

import streamlit as st
import os
import requests
import json
from datetime import datetime, timedelta
from pyairtable import Api, Table
from pyairtable.formulas import match, AND, OR, EQ, GTE, LTE, Field

# Configure page
st.set_page_config(
    page_title="Meta Marketing Dashboard", 
    page_icon="🎯",
    layout="wide"
)

# Direct credential access function
def get_credentials():
    """Get all required credentials with proper error handling"""
    creds = {
        'meta_token': os.environ.get('META_ACCESS_TOKEN'),
        'meta_account': os.environ.get('META_AD_ACCOUNT_ID'),
        'airtable_key': 'patRpwfhYlGferLE8.17a89cf5c31e4ef29041a67a4b28ca4058bb443779beb0dd4352ad999b186cdd',
        'airtable_base': 'appH4MePHS6qLsk5z'
    }
    return creds

def get_meta_advertising_data(start_date: str, end_date: str):
    """Get Meta advertising data from API"""
    try:
        creds = get_credentials()
        access_token = creds['meta_token']
        ad_account_id = creds['meta_account']
        
        if not access_token or not ad_account_id:
            st.error(f"Missing Meta credentials - Token: {bool(access_token)}, Account: {bool(ad_account_id)}")
            return None
        
        if not ad_account_id.startswith('act_'):
            ad_account_id = f"act_{ad_account_id}"
            
        url = f"https://graph.facebook.com/v18.0/{ad_account_id}/insights"
        params = {
            'access_token': access_token,
            'time_range': f'{{"since":"{start_date}","until":"{end_date}"}}',
            'fields': 'campaign_name,spend,impressions,clicks,ctr,cpm,reach,frequency',
            'level': 'campaign',
            'limit': 100
        }
        
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            campaigns = data.get('data', [])
            if campaigns:
                return {
                    'success': True,
                    'campaigns': campaigns,
                    'total_spend': sum(float(c.get('spend', 0)) for c in campaigns),
                    'total_impressions': sum(int(c.get('impressions', 0)) for c in campaigns),
                    'total_clicks': sum(int(c.get('clicks', 0)) for c in campaigns)
                }
        return None
            
    except Exception as e:
        st.error(f"Meta API Error: {str(e)}")
        return None

def get_detailed_ad_performance(start_date: str, end_date: str):
    """Get detailed ad set and individual ad performance"""
    try:
        creds = get_credentials()
        access_token = creds['meta_token']
        ad_account_id = creds['meta_account']
        
        if not access_token or not ad_account_id:
            return {'success': False, 'adsets': [], 'ads': []}
        
        if not ad_account_id.startswith('act_'):
            ad_account_id = f"act_{ad_account_id}"
            
        detailed_performance = {'success': True, 'adsets': [], 'ads': []}
        
        # Get ad set level data
        url = f"https://graph.facebook.com/v18.0/{ad_account_id}/insights"
        params = {
            'access_token': access_token,
            'time_range': f'{{"since":"{start_date}","until":"{end_date}"}}',
            'fields': 'campaign_name,adset_name,spend,impressions,clicks,ctr,cpc,cpm',
            'level': 'adset',
            'limit': 100
        }
        
        response = requests.get(url, params=params)
        if response.status_code == 200:
            data = response.json()
            detailed_performance['adsets'] = data.get('data', [])
        
        # Get individual ad level data
        params['level'] = 'ad'
        params['fields'] = 'campaign_name,adset_name,ad_name,spend,impressions,clicks,ctr,cpc,cpm'
        params['limit'] = 200
        
        response = requests.get(url, params=params)
        if response.status_code == 200:
            data = response.json()
            detailed_performance['ads'] = data.get('data', [])
        
        return detailed_performance
        
    except Exception as e:
        st.error(f"Detailed performance error: {e}")
        return {'success': False, 'adsets': [], 'ads': []}

def test_airtable_permissions():
    """Test Airtable API permissions and provide detailed diagnostics"""
    creds = get_credentials()
    api_key = creds['airtable_key']
    base_id = creds['airtable_base']
    
    if not api_key or not base_id:
        return False, "Missing Airtable credentials"
    
    try:
        # Test basic API access
        import requests
        headers = {'Authorization': f'Bearer {api_key}'}
        
        # Test 1: Check if API key is valid by trying to access base metadata
        meta_url = f"https://api.airtable.com/v0/meta/bases/{base_id}/tables"
        response = requests.get(meta_url, headers=headers)
        
        if response.status_code == 403:
            return False, "API key lacks required permissions for this base"
        elif response.status_code == 404:
            return False, f"Base {base_id} not found or not accessible"
        elif response.status_code == 401:
            return False, "Invalid API key"
        elif response.status_code == 200:
            # Base is accessible via metadata API
            tables_data = response.json()
            table_names = [table['name'] for table in tables_data.get('tables', [])]
            return True, f"Base accessible. Tables found: {', '.join(table_names)}"
        else:
            # Fallback: try direct table access
            api = Api(api_key)
            common_tables = ['Leads', 'Transactions', 'Social Media', 'Contacts', 'Revenue', 'Sales']
            
            for table_name in common_tables:
                try:
                    table = api.table(base_id, table_name)
                    records = table.all(max_records=1)
                    return True, f"Connected to table '{table_name}'"
                except Exception:
                    continue
            
            return False, "No accessible tables found"
            
    except Exception as e:
        return False, f"Connection test failed: {str(e)}"

def load_airtable_leads(start_date=None, end_date=None):
    """Load lead data from Airtable with date range filtering"""
    try:
        # Test permissions first
        permission_ok, permission_msg = test_airtable_permissions()
        
        if not permission_ok:
            st.error(f"**Airtable Access Issue:** {permission_msg}")
            return []
        
        st.success(f"Airtable connection verified: {permission_msg}")
        
        creds = get_credentials()
        api_key = creds['airtable_key']
        base_id = creds['airtable_base']
        
        if not api_key or not base_id:
            st.error("Airtable credentials are missing")
            return []
        
        # Use official PyAirtable API class (non-deprecated pattern)
        api = Api(api_key)
        leads_table = api.table(base_id, 'Leads')
        
        # Use string-based formula which is more reliable
        if start_date and end_date:
            # Filter by source, brand, and date range using string formula
            formula = f"AND(OR({{Contact Source}}='Facebook AD', {{Contact Source}}='Instagram AD', {{Contact Source}}='Facebook AD Sign Up'), {{Brand}}='Smooth M.D.', {{Inbound}}>='{str(start_date)}', {{Inbound}}<='{str(end_date)}')"
            records = leads_table.all(
                formula=formula,
                fields=["ID", "Phone", "Email", "Contact Source", "Inbound", "Brand", "Overall Status", 
                       "Original Location", "Scheduled Location", "Consult", "Consult Status", "Scheduled by:"],
                sort=["Inbound"]
            )
        else:
            # Filter by source and brand for all-time data
            formula = "AND(OR({Contact Source}='Facebook AD', {Contact Source}='Instagram AD', {Contact Source}='Facebook AD Sign Up'), {Brand}='Smooth M.D.')"
            records = leads_table.all(
                formula=formula,
                fields=["ID", "Phone", "Email", "Contact Source", "Inbound", "Brand", "Overall Status",
                       "Original Location", "Scheduled Location", "Consult", "Consult Status", "Scheduled by:"],
                sort=["Inbound"]
            )
        
        leads_data = []
        for record in records:
            fields = record.get('fields', {})
            
            # Validate essential fields exist
            if not fields.get('Contact Source'):
                continue
                
            leads_data.append({
                'id': record['id'],
                'lead_id': fields.get('ID', ''),
                'phone': str(fields.get('Phone', '')).strip(),
                'email': str(fields.get('Email', '')).strip().lower(),
                'contact_source': fields.get('Contact Source', ''),
                'brand': fields.get('Brand', ''),
                'inbound_date': fields.get('Inbound', ''),
                'overall_status': fields.get('Overall Status', ''),
                'original_location': fields.get('Original Location', ''),
                'scheduled_location': fields.get('Scheduled Location', ''),
                'consult': fields.get('Consult', ''),
                'consult_status': fields.get('Consult Status', ''),
                'scheduled_by': fields.get('Scheduled by:', '')
            })
        
        date_info = f" (filtered {start_date} to {end_date})" if start_date and end_date else " (all time)"
        st.success(f"Loaded {len(leads_data)} Meta leads{date_info}")
        return leads_data
        
    except Exception as e:
        st.error(f"Airtable error: {str(e)}")
        return []

def load_airtable_transactions(start_date=None, end_date=None):
    """Load transaction/revenue data from Airtable with date range filtering"""
    try:
        # Test permissions first
        permission_ok, permission_msg = test_airtable_permissions()
        
        if not permission_ok:
            st.warning("Airtable transaction data unavailable - using Meta data only for analysis")
            return []
        
        creds = get_credentials()
        api_key = creds['airtable_key']
        base_id = creds['airtable_base']
        
        if not api_key or not base_id:
            return []
        
        api = Api(api_key)
        table = api.table(base_id, 'Transactions')
        records = table.all()
        
        transactions_data = []
        for record in records:
            fields = record['fields']
            amount = 0
            
            # Get amount from the Amount field
            if 'Amount' in fields:
                try:
                    amount = float(fields['Amount'])
                except (ValueError, TypeError):
                    amount = 0
            
            # Apply date filtering if dates provided
            transaction_date_str = fields.get('Date', '')
            include_transaction = True
            
            if start_date and end_date and transaction_date_str:
                try:
                    transaction_date = datetime.strptime(transaction_date_str, '%Y-%m-%d').date()
                    if not (start_date <= transaction_date <= end_date):
                        include_transaction = False
                except ValueError:
                    # Exclude transactions with invalid dates when filtering
                    if start_date and end_date:
                        include_transaction = False
            
            if include_transaction and amount > 0:  # Only include transactions with valid amounts
                # Check if Patient field contains link to leads table
                patient_field = fields.get('Patient', '')
                if isinstance(patient_field, list) and len(patient_field) > 0:
                    # Patient field is a linked record - extract the ID
                    patient_info = patient_field[0] if isinstance(patient_field[0], str) else str(patient_field[0])
                else:
                    patient_info = str(patient_field) if patient_field else ''
                
                transactions_data.append({
                    'id': record['id'],
                    'patient': patient_info,
                    'date': fields.get('Date', ''),
                    'amount': amount,
                    'payment_type': fields.get('Payment Type', ''),
                    'status': fields.get('Status', 'Completed'),
                    'patient_type': fields.get('Patient Type', ''),
                    'revenue_type': fields.get('Revenue Type', ''),
                    'services_purchased': fields.get('Services Purchased', ''),
                    'initial_purchase_month': fields.get('Initial Purchase Month', ''),
                    'initial_purchase_year': fields.get('Initial Purchase Year', ''),
                    'raw_patient_field': fields.get('Patient', '')  # Keep raw field for debugging
                })
        
        date_info = f" (filtered {start_date} to {end_date})" if start_date and end_date else " (all time)"
        total_revenue = sum(t['amount'] for t in transactions_data)
        st.success(f"Loaded {len(transactions_data)} transactions{date_info} - Total: ${total_revenue:,.2f}")
        return transactions_data
        
    except Exception as e:
        st.warning("Airtable transaction access limited - continuing with Meta advertising data")
        return []

def calculate_funnel_metrics(leads_data):
    """Calculate lead funnel conversion metrics using actual Airtable field structure"""
    if not leads_data:
        return {}
    
    total_leads = len(leads_data)
    
    # Count leads at each funnel stage using your actual fields
    # Handle fields that might be strings, dicts, or None
    def safe_get_string(lead, field):
        value = lead.get(field, '')
        if isinstance(value, str):
            return value.strip()
        elif isinstance(value, dict):
            return ''  # Skip error fields
        else:
            return str(value).strip() if value else ''
    
    scheduled_leads = sum(1 for lead in leads_data if safe_get_string(lead, 'scheduled_location') and safe_get_string(lead, 'scheduled_location') != 'Pending')
    consulted_leads = sum(1 for lead in leads_data if 'completed' in safe_get_string(lead, 'consult_status').lower() or 'done' in safe_get_string(lead, 'consult_status').lower())
    
    # Use actual status data for better metrics
    pending_consults = sum(1 for lead in leads_data if 'pending' in safe_get_string(lead, 'consult_status').lower())
    
    # Count actual conversions from Overall Status field
    closed_leads = sum(1 for lead in leads_data if 'closed' in safe_get_string(lead, 'overall_status').lower() or 'converted' in safe_get_string(lead, 'overall_status').lower() or 'treatment' in safe_get_string(lead, 'overall_status').lower())
    
    # Calculate conversion rates
    scheduling_rate = (scheduled_leads / total_leads * 100) if total_leads > 0 else 0
    consult_rate = (consulted_leads / scheduled_leads * 100) if scheduled_leads > 0 else 0
    close_rate = (closed_leads / consulted_leads * 100) if consulted_leads > 0 else 0
    
    return {
        'total_leads': total_leads,
        'scheduled_leads': scheduled_leads,
        'consulted_leads': consulted_leads,
        'closed_leads': closed_leads,
        'pending_consults': pending_consults,
        'scheduling_rate': scheduling_rate,
        'consult_rate': consult_rate,
        'close_rate': close_rate,
        'overall_conversion_rate': (closed_leads / total_leads * 100) if total_leads > 0 else 0
    }

def match_leads_to_revenue(leads_data, transactions_data):
    """
    Advanced lead-to-revenue attribution using validated PyAirtable data
    Eliminates duplicate "Unknown" entries through proper matching logic
    """
    if not leads_data:
        return [], 0
    
    if not transactions_data:
        # Return validated leads with zero revenue
        return [create_zero_revenue_lead(lead) for lead in leads_data], 0
    
    # Phase 1: Direct matching with comprehensive validation
    attributed_leads = []
    total_attributed_revenue = 0
    used_transaction_ids = set()
    
    for lead in leads_data:
        # Clean and validate lead data
        lead_phone = clean_phone_number(lead.get('phone', ''))
        lead_email = clean_email_address(lead.get('email', ''))
        
        matched_transactions = []
        lead_revenue = 0
        
        # Attempt direct matching using multiple patterns
        for transaction in transactions_data:
            if transaction['id'] in used_transaction_ids:
                continue
                
            if is_transaction_match(lead.get('lead_id', ''), lead_phone, lead_email, transaction):
                matched_transactions.append(transaction)
                lead_revenue += transaction['amount']
                used_transaction_ids.add(transaction['id'])
        
        # Create attributed lead record
        attributed_lead = create_attributed_lead(
            lead, lead_revenue, matched_transactions, 
            'direct_match' if matched_transactions else 'no_direct_match'
        )
        attributed_leads.append(attributed_lead)
        total_attributed_revenue += lead_revenue
    
    # Phase 2: Skip proportional distribution - only show direct matches
    # This eliminates confusing "proportional distribution" revenue attribution
    
    return attributed_leads, total_attributed_revenue

def clean_phone_number(phone):
    """Clean phone number for matching"""
    if not phone:
        return ""
    return str(phone).strip().replace('(', '').replace(')', '').replace('-', '').replace(' ', '').replace('+1', '')

def clean_email_address(email):
    """Clean email address for matching"""
    if not email:
        return ""
    return str(email).strip().lower()

def is_transaction_match(lead_id, lead_phone, lead_email, transaction):
    """Determine if transaction matches lead using direct ID matching and fallback patterns"""
    patient_reference = transaction.get('patient', '')
    
    # Pattern 1: Direct Lead ID matching (primary method)
    if lead_id and patient_reference:
        # Check if patient field contains the lead ID directly
        if str(lead_id).upper() in str(patient_reference).upper():
            return True
    
    # Pattern 2: Fallback to phone/email matching for cases where direct linking isn't available
    patient_name = str(patient_reference).lower().strip()
    
    # Skip if patient field is clearly a record ID (contains numbers and letters)
    if len(patient_name) > 6 and any(c.isdigit() for c in patient_name) and any(c.isalpha() for c in patient_name):
        # This looks like a record ID, not a name - skip phone/email matching
        return False
    
    # Phone matching (only if patient field looks like a name)
    if lead_phone and len(lead_phone) >= 4 and patient_name and not any(c.isdigit() for c in patient_name[:3]):
        clean_patient = patient_name.replace('(', '').replace(')', '').replace('-', '').replace(' ', '').replace('.', '').replace('+', '')
        clean_lead_phone = lead_phone.replace('(', '').replace(')', '').replace('-', '').replace(' ', '').replace('.', '').replace('+', '')
        
        if len(clean_lead_phone) >= 4:
            phone_variants = [clean_lead_phone[-10:], clean_lead_phone[-4:]]
            for variant in phone_variants:
                if variant and len(variant) >= 3 and variant in clean_patient:
                    return True
    
    # Email matching (only if patient field looks like a name)
    if lead_email and '@' in lead_email and patient_name and not any(c.isdigit() for c in patient_name[:3]):
        email_prefix = lead_email.split('@')[0].lower()
        if len(email_prefix) >= 3 and email_prefix in patient_name:
            return True
    
    return False

def create_zero_revenue_lead(lead):
    """Create lead record with zero revenue"""
    result = lead.copy()
    result.update({
        'revenue': 0,
        'transaction_count': 0,
        'matched_transactions': [],
        'attribution_method': 'no_transactions'
    })
    return result

def create_attributed_lead(lead, revenue, transactions, method):
    """Create properly attributed lead record"""
    result = lead.copy()
    result.update({
        'revenue': revenue,
        'transaction_count': len(transactions),
        'matched_transactions': transactions,
        'attribution_method': method
    })
    return result

def main():
    st.title("🎯 Comprehensive Meta Marketing Dashboard")
    st.markdown("**Complete Attribution: Ad Spend → Leads → Revenue**")
    
    # Credential validation display
    creds = get_credentials()
    with st.expander("🔧 Credential Status", expanded=False):
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.write(f"Meta Token: {'✅' if creds['meta_token'] else '❌'}")
        with col2:
            st.write(f"Meta Account: {'✅' if creds['meta_account'] else '❌'}")
        with col3:
            st.write(f"Airtable Key: {'✅' if creds['airtable_key'] else '❌'}")
        with col4:
            st.write(f"Airtable Base: {'✅' if creds['airtable_base'] else '❌'}")
    
    # Date range selection with better defaults
    from datetime import date
    today = date.today()
    thirty_days_ago = today - timedelta(days=30)
    
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Start Date", thirty_days_ago)
    with col2:
        end_date = st.date_input("End Date", today)
    
    # Data availability info
    st.info(f"**Suggested ranges:** Last 30 days (2 Meta leads, 4 transactions) | Last 90 days (6 Meta leads, 16 transactions)")
    
    start_str = start_date.strftime('%Y-%m-%d')
    end_str = end_date.strftime('%Y-%m-%d')
    
    # Load all data sources with date filtering
    with st.spinner("Loading comprehensive attribution data..."):
        meta_data = get_meta_advertising_data(start_str, end_str)
        detailed_performance = get_detailed_ad_performance(start_str, end_str)
        leads_data = load_airtable_leads(start_date, end_date)
        transactions_data = load_airtable_transactions(start_date, end_date)
    
    # Data Quality Validation
    st.header("📊 Complete Attribution Analysis")
    
    # Validation metrics display
    with st.expander("📋 Data Validation Summary", expanded=False):
        col1, col2, col3 = st.columns(3)
        with col1:
            st.write(f"**Date Range:** {start_date} to {end_date}")
            st.write(f"**Meta Campaigns:** {len(meta_data.get('campaigns', [])) if meta_data else 0}")
        with col2:
            st.write(f"**Airtable Leads:** {len(leads_data)}")
            st.write(f"**Transactions:** {len(transactions_data)}")
        with col3:
            total_transaction_revenue = sum(t.get('amount', 0) for t in transactions_data)
            st.write(f"**Transaction Revenue:** ${total_transaction_revenue:,.2f}")
            st.write(f"**Revenue Period:** {start_date} to {end_date}")
    
    if meta_data and meta_data.get('campaigns'):
        # Calculate attribution metrics with validation
        leads_with_revenue, attributed_revenue = match_leads_to_revenue(leads_data, transactions_data)
        funnel_metrics = calculate_funnel_metrics(leads_data)
        
        total_spend = meta_data['total_spend']
        total_impressions = meta_data['total_impressions']
        total_clicks = meta_data['total_clicks']
        
        # Calculate ROAS and efficiency metrics
        roas = (attributed_revenue / total_spend) if total_spend > 0 else 0
        net_profit = attributed_revenue - total_spend
        
        # Use actual conversion data when available
        actual_conversions = funnel_metrics.get('closed_leads', 0)
        cost_per_conversion = (total_spend / actual_conversions) if actual_conversions > 0 else 0
        
        # Display data source status
        if leads_data and transactions_data:
            st.success(f"✅ Complete data integration: Meta API + Airtable ({len(leads_data)} leads, {len(transactions_data)} transactions)")
        elif leads_data:
            st.info(f"✅ Meta API + Airtable leads ({len(leads_data)} leads) - No transactions in date range")
        else:
            st.warning("⚠️ Meta API only - No Airtable data in selected date range")
        
        # Essential KPIs Dashboard
        st.header("📊 Essential KPIs & Performance Metrics")
        
        # Top Row - Revenue & ROAS Metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Ad Spend", f"${total_spend:,.2f}")
        with col2:
            st.metric("Attributed Revenue", f"${attributed_revenue:,.2f}")
        with col3:
            roas_delta = roas - 3.0  # Assuming 3x ROAS target
            roas_color = "normal" if roas >= 3.0 else "inverse"
            st.metric("ROAS", f"{roas:.2f}x", delta=f"{roas_delta:+.2f}x vs target")
        with col4:
            profit_margin = (net_profit / attributed_revenue * 100) if attributed_revenue > 0 else 0
            st.metric("Net Profit", f"${net_profit:,.2f}", delta=f"{profit_margin:.1f}% margin")
        
        # Second Row - Lead Generation Metrics
        col1, col2, col3, col4 = st.columns(4)
        total_leads = funnel_metrics.get('total_leads', 0)
        closed_leads = funnel_metrics.get('closed_leads', 0)
        
        with col1:
            cost_per_lead = total_spend / total_leads if total_leads > 0 else 0
            st.metric("Meta Leads", f"{total_leads:,}", delta=f"${cost_per_lead:.2f} CPL")
        with col2:
            st.metric("Conversions", f"{closed_leads:,}")
        with col3:
            conversion_rate = funnel_metrics.get('overall_conversion_rate', 0)
            st.metric("Conversion Rate", f"{conversion_rate:.1f}%")
        with col4:
            st.metric("Cost per Conversion", f"${cost_per_conversion:,.2f}")
        
        # Third Row - Advanced Performance Metrics
        col1, col2, col3, col4 = st.columns(4)
        leads_with_revenue_count = len([l for l in leads_with_revenue if l.get('revenue', 0) > 0])
        attribution_rate = (leads_with_revenue_count / total_leads * 100) if total_leads > 0 else 0
        avg_revenue_per_lead = attributed_revenue / total_leads if total_leads > 0 else 0
        avg_revenue_per_conversion = attributed_revenue / closed_leads if closed_leads > 0 else 0
        
        with col1:
            st.metric("Attribution Rate", f"{attribution_rate:.1f}%", help="% of leads with matched revenue")
        with col2:
            st.metric("Revenue per Lead", f"${avg_revenue_per_lead:,.2f}")
        with col3:
            st.metric("Revenue per Conversion", f"${avg_revenue_per_conversion:,.2f}")
        with col4:
            unmatched_transactions = [t for t in transactions_data if t['id'] not in 
                                    [trans['id'] for lead in leads_with_revenue for trans in lead.get('matched_transactions', [])]]
            unmatched_revenue = sum(t['amount'] for t in unmatched_transactions)
            st.metric("Unmatched Revenue", f"${unmatched_revenue:,.2f}", help="Revenue not attributed to Meta leads")
        
        # Comprehensive Lead Conversion Funnel
        st.header("🔄 Complete Lead Conversion Funnel")
        
        # Calculate comprehensive funnel stages based on actual Airtable status fields
        contacted_leads = 0
        scheduled_leads = 0
        consulted_leads = 0
        transactions_leads = 0
        returning_leads = 0
        
        # Add leads with revenue to transaction count
        leads_with_transactions = [l for l in leads_with_revenue if l.get('revenue', 0) > 0]
        transactions_leads = len(leads_with_transactions)
        
        for lead in leads_data:
            status = str(lead.get('overall_status', '')).lower()
            consult_status = str(lead.get('consult_status', '')).lower()
            
            # Count contacted leads (anyone beyond initial lead)
            if any(term in status for term in ['follow up', 'contacted', 'reached', 'spoke', 'called']):
                contacted_leads += 1
            
            # Count scheduled/booked appointments
            if any(term in status for term in ['scheduled', 'appointment', 'consult', 'booked']) or \
               any(term in consult_status for term in ['scheduled', 'booked', 'confirmed']):
                scheduled_leads += 1
            
            # Count completed consultations
            if any(term in status for term in ['treatment', 'consultation completed', 'consulted']) or \
               any(term in consult_status for term in ['completed', 'done', 'finished']):
                consulted_leads += 1
            
            # Count returning customers
            if any(term in status for term in ['returning', 'repeat', 'follow-up treatment', 'additional']):
                returning_leads += 1
        
        # Create comprehensive funnel using plotly
        import plotly.graph_objects as go
        
        funnel_stages = [
            'Leads Generated',
            'Contacted/Reached',
            'Scheduled/Booked',
            'Consulted/Treated',
            'Paid/Transaction',
            'Returning Customer'
        ]
        
        funnel_values = [
            total_leads,
            contacted_leads,
            scheduled_leads,
            consulted_leads, 
            transactions_leads,
            returning_leads
        ]
        
        funnel_colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b']
        
        fig = go.Figure(go.Funnel(
            y=funnel_stages,
            x=funnel_values,
            textinfo="value+percent initial",
            marker=dict(color=funnel_colors),
            connector=dict(line=dict(color="lightgray", dash="solid", width=2))
        ))
        
        fig.update_layout(
            title="Complete Meta Lead Journey Funnel",
            height=500,
            showlegend=False
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Comprehensive Funnel Performance Analysis
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📈 Stage Conversion Rates")
            
            # Calculate conversion rates between stages
            contact_rate = (contacted_leads / total_leads * 100) if total_leads > 0 else 0
            schedule_rate = (scheduled_leads / contacted_leads * 100) if contacted_leads > 0 else 0
            consult_rate = (consulted_leads / scheduled_leads * 100) if scheduled_leads > 0 else 0
            transaction_rate = (transactions_leads / consulted_leads * 100) if consulted_leads > 0 else 0
            return_rate = (returning_leads / transactions_leads * 100) if transactions_leads > 0 else 0
            
            st.write(f"**Lead to Contact Rate:** {contact_rate:.1f}%")
            st.write(f"**Contact to Schedule Rate:** {schedule_rate:.1f}%")
            st.write(f"**Schedule to Consult Rate:** {consult_rate:.1f}%")
            st.write(f"**Consult to Transaction Rate:** {transaction_rate:.1f}%")
            st.write(f"**Transaction to Return Rate:** {return_rate:.1f}%")
            
        with col2:
            st.subheader("💰 Stage Economics")
            
            # Calculate cost per stage
            cost_per_contact = total_spend / contacted_leads if contacted_leads > 0 else 0
            cost_per_schedule = total_spend / scheduled_leads if scheduled_leads > 0 else 0
            cost_per_consult = total_spend / consulted_leads if consulted_leads > 0 else 0
            cost_per_transaction = total_spend / transactions_leads if transactions_leads > 0 else 0
            
            st.write(f"**Cost per Contact:** ${cost_per_contact:.2f}")
            st.write(f"**Cost per Schedule:** ${cost_per_schedule:.2f}")
            st.write(f"**Cost per Consult:** ${cost_per_consult:.2f}")
            st.write(f"**Cost per Transaction:** ${cost_per_transaction:.2f}")
            
            # Overall efficiency
            overall_conversion = (transactions_leads / total_leads * 100) if total_leads > 0 else 0
            st.write(f"**Overall Lead to Sale:** {overall_conversion:.1f}%")
        
        # Campaign Performance Analysis
        st.header("🎯 Campaign Performance Insights")
        
        # Build comprehensive campaign performance data with smart attribution
        campaigns = meta_data.get('campaigns', [])
        campaign_performance = []
        total_revenue_available = sum(lead.get('revenue', 0) for lead in leads_with_revenue)
        
        # Calculate spend proportions for smart attribution
        total_spend = sum(float(campaign.get('spend', 0)) for campaign in campaigns)
        
        for campaign in campaigns:
            spend = float(campaign.get('spend', 0))
            impressions = int(campaign.get('impressions', 0))
            clicks = int(campaign.get('clicks', 0))
            campaign_name = campaign.get('campaign_name', 'Unknown')
            
            # Calculate key metrics
            ctr = (clicks / impressions * 100) if impressions > 0 else 0
            cpc = (spend / clicks) if clicks > 0 else 0
            cpm = (spend / impressions * 1000) if impressions > 0 else 0
            
            # Smart attribution based on campaign characteristics
            estimated_conversions = 0
            campaign_revenue = 0
            
            if total_revenue_available > 0 and total_spend > 0:
                # Base attribution on spend proportion
                spend_weight = spend / total_spend if total_spend > 0 else 0
                
                # Adjust weight based on campaign performance indicators
                performance_multiplier = 1.0
                
                # Higher CTR campaigns get more attribution
                if ctr > 1.5:
                    performance_multiplier += 0.3
                elif ctr > 1.0:
                    performance_multiplier += 0.1
                
                # Form campaigns typically convert better
                if 'form' in campaign_name.lower():
                    performance_multiplier += 0.2
                
                # Lead campaigns are conversion-focused
                if 'lead' in campaign_name.lower():
                    performance_multiplier += 0.15
                
                # Apply attribution
                attribution_weight = spend_weight * performance_multiplier
                campaign_revenue = total_revenue_available * attribution_weight
                estimated_conversions = max(1, int(len(leads_with_revenue) * attribution_weight))
            
            roas = (campaign_revenue / spend) if spend > 0 else 0
            
            campaign_performance.append({
                'name': campaign_name,
                'spend': spend,
                'impressions': impressions,
                'clicks': clicks,
                'ctr': ctr,
                'cpc': cpc,
                'cpm': cpm,
                'conversions': estimated_conversions,
                'revenue': campaign_revenue,
                'roas': roas,
                'efficiency_score': (ctr * 0.3 + (100/cpc if cpc > 0 else 0) * 0.3 + roas * 0.4),
                'attribution_method': 'Smart Proportional'
            })
        
        if campaign_performance:
            # Detailed debugging for revenue attribution
            total_revenue_available = sum(lead.get('revenue', 0) for lead in leads_with_revenue)
            
            # Production attribution summary
            attributed_revenue = sum(c['revenue'] for c in campaign_performance)
            if attributed_revenue > 0:
                st.info(f"**Attribution Summary:** ${attributed_revenue:,.2f} total revenue attributed across {len(campaign_performance)} campaigns using performance-weighted allocation.")
            
            # Sort by efficiency score
            campaign_performance.sort(key=lambda x: x['efficiency_score'], reverse=True)
            
            # Create comprehensive performance comparison chart
            fig = go.Figure()
            
            campaign_names = [c['name'][:20] + '...' if len(c['name']) > 20 else c['name'] for c in campaign_performance]
            
            # Add ROAS bars with better scaling
            roas_values = [max(c['roas'], 0.1) for c in campaign_performance]  # Ensure minimum visibility
            fig.add_trace(go.Bar(
                name='ROAS',
                x=campaign_names,
                y=roas_values,
                marker_color='#2E8B57',
                yaxis='y',
                text=[f"{c['roas']:.2f}x" if c['roas'] > 0 else "0.0x" for c in campaign_performance],
                textposition='outside',
                hovertemplate='<b>%{x}</b><br>ROAS: %{text}<br>Revenue: $%{customdata}<extra></extra>',
                customdata=[c['revenue'] for c in campaign_performance]
            ))
            
            # Add CTR line with better visibility
            fig.add_trace(go.Scatter(
                name='CTR (%)',
                x=campaign_names,
                y=[c['ctr'] for c in campaign_performance],
                mode='lines+markers',
                line=dict(color='#FF6B35', width=4),
                marker=dict(size=10, color='#FF6B35', line=dict(width=2, color='white')),
                yaxis='y2',
                hovertemplate='<b>%{x}</b><br>CTR: %{y:.2f}%<br>Clicks: %{customdata}<extra></extra>',
                customdata=[c['clicks'] for c in campaign_performance]
            ))
            
            # Add efficiency score line for correlation insight
            fig.add_trace(go.Scatter(
                name='Efficiency Score',
                x=campaign_names,
                y=[c['efficiency_score'] for c in campaign_performance],
                mode='lines+markers',
                line=dict(color='#9400D3', width=3, dash='dot'),
                marker=dict(size=8, color='#9400D3'),
                yaxis='y3',
                hovertemplate='<b>%{x}</b><br>Efficiency: %{y:.1f}<extra></extra>'
            ))
            
            fig.update_layout(
                title='Campaign Performance: Multi-Metric Analysis',
                xaxis=dict(
                    title='Campaigns (Ranked by Performance)',
                    tickangle=45
                ),
                yaxis=dict(
                    title='ROAS (Return on Ad Spend)',
                    side='left',
                    color='#2E8B57',
                    showgrid=True,
                    gridcolor='lightgray'
                ),
                yaxis2=dict(
                    title='CTR (%)',
                    side='right',
                    overlaying='y',
                    color='#FF6B35'
                ),
                yaxis3=dict(
                    title='Efficiency Score',
                    anchor='free',
                    overlaying='y',
                    side='right',
                    position=0.95,
                    color='#9400D3'
                ),
                height=600,
                margin=dict(l=80, r=120, t=80, b=140),
                hovermode='x unified',
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=-0.3,
                    xanchor="center",
                    x=0.5,
                    bgcolor="rgba(255,255,255,0.8)",
                    bordercolor="gray",
                    borderwidth=1
                )
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Performance insights table
            st.subheader("📊 Campaign Performance Breakdown")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**Top Performing Campaigns**")
                for i, campaign in enumerate(campaign_performance[:3]):
                    efficiency_badge = "🟢" if campaign['efficiency_score'] > 5 else "🟡" if campaign['efficiency_score'] > 2 else "🔴"
                    st.write(f"{efficiency_badge} **{campaign['name'][:35]}**")
                    st.write(f"   • ROAS: {campaign['roas']:.1f}x | CTR: {campaign['ctr']:.2f}% | Spend: ${campaign['spend']:.0f}")
                    st.write(f"   • Revenue: ${campaign['revenue']:.0f} | Conversions: {campaign['conversions']}")
            
            with col2:
                st.markdown("**Optimization Opportunities**")
                low_performers = [c for c in campaign_performance if c['efficiency_score'] < 2]
                if low_performers:
                    for campaign in low_performers[:3]:
                        st.write(f"🔴 **{campaign['name'][:35]}**")
                        if campaign['ctr'] < 1:
                            st.write(f"   • Low CTR ({campaign['ctr']:.2f}%) - Test new creative")
                        if campaign['cpc'] > 5:
                            st.write(f"   • High CPC (${campaign['cpc']:.2f}) - Refine targeting")
                        if campaign['roas'] < 1:
                            st.write(f"   • Poor ROAS ({campaign['roas']:.1f}x) - Check conversion tracking")
                else:
                    st.write("✅ All campaigns performing well!")
        else:
            st.info("No campaign performance data available for the selected date range.")
        
        # Status Breakdown Chart
        st.header("📊 Lead Status Distribution")
        
        status_counts = {}
        for lead in leads_data:
            status = lead.get('overall_status', 'Unknown')
            status_counts[status] = status_counts.get(status, 0) + 1
        
        if status_counts:
            fig = go.Figure(data=[go.Pie(
                labels=list(status_counts.keys()),
                values=list(status_counts.values()),
                textposition='inside',
                textinfo='percent+label'
            )])
            fig.update_layout(title="Lead Status Distribution")
            st.plotly_chart(fig, use_container_width=True)
        
        # Campaign Performance
        st.header("📱 Live Campaign Performance")
        
        for campaign in meta_data['campaigns']:
            with st.expander(f"Campaign: {campaign.get('campaign_name', 'Unknown')}"):
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Spend", f"${float(campaign.get('spend', 0)):,.2f}")
                with col2:
                    st.metric("Impressions", f"{int(campaign.get('impressions', 0)):,}")
                with col3:
                    st.metric("Clicks", f"{int(campaign.get('clicks', 0)):,}")
                with col4:
                    st.metric("CTR", f"{float(campaign.get('ctr', 0)):.2f}%")
        
        # Ad Set Performance
        if detailed_performance.get('adsets'):
            st.header("🎯 Ad Set Performance Breakdown")
            
            for i, adset in enumerate(detailed_performance['adsets'][:10]):  # Top 10
                with st.expander(f"Ad Set #{i+1}: {adset.get('adset_name', 'Unknown')[:50]}..."):
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("Spend", f"${float(adset.get('spend', 0)):,.2f}")
                    with col2:
                        st.metric("Impressions", f"{int(adset.get('impressions', 0)):,}")
                    with col3:
                        st.metric("CTR", f"{float(adset.get('ctr', 0)):.2f}%")
                    with col4:
                        st.metric("CPC", f"${float(adset.get('cpc', 0)):,.2f}")
        
        # Individual Ad Performance
        if detailed_performance.get('ads'):
            st.header("🎭 Individual Ad Creative Performance")
            
            # Sort ads by spend
            ads_sorted = sorted(detailed_performance['ads'], key=lambda x: float(x.get('spend', 0)), reverse=True)
            
            for i, ad in enumerate(ads_sorted[:15]):  # Top 15
                spend = float(ad.get('spend', 0))
                impressions = int(ad.get('impressions', 0))
                ctr = float(ad.get('ctr', 0))
                cpc = float(ad.get('cpc', 0))
                
                # Calculate performance score
                max_impressions = max(int(a.get('impressions', 0)) for a in ads_sorted)
                ctr_score = ctr * 0.4
                cpc_efficiency = (1 / (cpc + 0.01)) * 0.3 if cpc > 0 else 0
                volume_score = (impressions / max_impressions) * 0.3 if max_impressions > 0 else 0
                performance_score = (ctr_score + cpc_efficiency + volume_score) * 100
                
                with st.expander(f"Ad #{i+1}: {ad.get('ad_name', 'Unknown')[:40]}... - Score: {performance_score:.1f}"):
                    col1, col2, col3, col4, col5 = st.columns(5)
                    with col1:
                        st.metric("Spend", f"${spend:,.2f}")
                    with col2:
                        st.metric("Impressions", f"{impressions:,}")
                    with col3:
                        st.metric("CTR", f"{ctr:.2f}%")
                    with col4:
                        st.metric("CPC", f"${cpc:.2f}")
                    with col5:
                        st.metric("Score", f"{performance_score:.1f}")
        
        # Revenue Attribution Details
        if leads_with_revenue:
            st.header("💰 Revenue Attribution Details")
            
            for i, lead in enumerate(leads_with_revenue):
                lead_name = lead.get('lead_id', f"Lead {i+1}")
                revenue = lead.get('revenue', 0)
                transaction_count = lead.get('transaction_count', 0)
                contact_source = lead.get('contact_source', 'Unknown')
                
                with st.expander(f"Lead: {lead_name} ({contact_source}) - ${revenue:,.2f}"):
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.write(f"**Phone:** {lead.get('phone', 'N/A')}")
                        st.write(f"**Email:** {lead.get('email', 'N/A')}")
                    with col2:
                        st.write(f"**Source:** {contact_source}")
                        st.write(f"**Brand:** {lead.get('brand', 'N/A')}")
                    with col3:
                        st.write(f"**Revenue:** ${revenue:,.2f}")
                        st.write(f"**Transactions:** {transaction_count}")
                    
                    # Show matched transactions if any
                    matched_transactions = lead.get('matched_transactions', [])
                    if matched_transactions:
                        st.write("**Matched Transactions:**")
                        for trans in matched_transactions:
                            # Use proper display format - transaction ID should be shown as reference
                            patient_info = trans.get('patient', 'Unknown Patient')
                            transaction_id = trans.get('id', 'Unknown ID')
                            amount = trans.get('amount', 0)
                            date = trans.get('date', 'Unknown date')
                            
                            # If patient field contains transaction ID, show it properly
                            if patient_info and len(patient_info) > 8 and any(c.isdigit() for c in patient_info):
                                st.write(f"- Transaction {transaction_id[-8:]}: ${amount:,.2f} on {date}")
                            else:
                                st.write(f"- {patient_info}: ${amount:,.2f} on {date}")
                    elif revenue > 0:
                        st.write("**Attribution:** Direct transaction matching")
                    with col3:
                        st.write(f"**Status:** {lead.get('overall_status', 'Unknown')}")
            
            st.success(f"Successfully attributed ${attributed_revenue:,.2f} in revenue to {len(leads_with_revenue)} Meta leads")
        else:
            st.info("No revenue attribution matches found. Check lead/transaction data alignment.")
    
    else:
        st.error("Meta API connection failed. Please check your credentials.")

if __name__ == "__main__":
    main()