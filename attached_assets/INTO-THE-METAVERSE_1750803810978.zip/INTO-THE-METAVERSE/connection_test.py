"""
Comprehensive Airtable Connection Test
Verify authentic data connection for the ultra-premium dashboard
"""

import streamlit as st
import pandas as pd
from pyairtable import Api
import os

# Get API key
try:
    AIRTABLE_KEY = st.secrets["AIRTABLE_API_KEY"]
except:
    AIRTABLE_KEY = os.getenv("AIRTABLE_API_KEY", "")

st.set_page_config(page_title="Connection Test", layout="wide")

st.title("🔍 Authentic Data Connection Test")
st.write("Testing your real Airtable data connection...")

if AIRTABLE_KEY:
    st.success("✅ API Key Found")
    
    try:
        api = Api(AIRTABLE_KEY)
        st.success("✅ API Client Created")
        
        # Test leads connection
        st.subheader("📊 Testing Leads Data")
        leads_table = api.table("appri2CgCoIiuZWq3", "Leads")
        leads_records = leads_table.all(max_records=5)
        
        if leads_records:
            st.success(f"✅ Connected! Found {len(leads_records)} sample leads")
            
            # Show sample data structure
            if leads_records:
                sample_fields = leads_records[0].get('fields', {})
                st.write("**Available Fields:**")
                for field in sample_fields.keys():
                    st.write(f"- {field}")
        else:
            st.warning("⚠️ No leads data found")
            
        # Test transactions connection
        st.subheader("💰 Testing Transactions Data")
        try:
            trans_table = api.table("appri2CgCoIiuZWq3", "Transactions")
            trans_records = trans_table.all(max_records=5)
            
            if trans_records:
                st.success(f"✅ Connected! Found {len(trans_records)} sample transactions")
                
                # Show sample transaction fields
                if trans_records:
                    sample_fields = trans_records[0].get('fields', {})
                    st.write("**Available Transaction Fields:**")
                    for field in sample_fields.keys():
                        st.write(f"- {field}")
            else:
                st.warning("⚠️ No transactions data found")
                
        except Exception as e:
            st.error(f"❌ Transactions connection failed: {str(e)}")
            
    except Exception as e:
        st.error(f"❌ Connection failed: {str(e)}")
        st.info("Please verify your API key and base permissions.")
        
else:
    st.error("❌ No API key found")
    st.info("Please provide your Airtable API key.")

st.divider()
st.write("Return to your ultra-premium dashboard once connection is verified!")