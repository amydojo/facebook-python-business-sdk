"""
API Performance Audit and Data Accuracy Monitor
Real-time monitoring of Meta API and Airtable performance with data validation
"""
import time
import pandas as pd
import streamlit as st
from datetime import datetime, timedelta
from data_storage import storage, validator
import requests
from pyairtable import Api

class APIAuditor:
    """Enhanced API performance monitoring and data validation"""
    
    def __init__(self):
        self.meta_api_base = "https://graph.facebook.com/v22.0"
        self.performance_thresholds = {
            'response_time_warning': 5.0,  # seconds
            'response_time_critical': 10.0,
            'success_rate_warning': 95.0,  # percentage
            'success_rate_critical': 90.0
        }
    
    def audit_airtable_connection(self, api_key: str, base_id: str, table_name: str) -> dict:
        """Comprehensive Airtable API audit"""
        audit_result = {
            'source': 'airtable',
            'status': 'unknown',
            'response_time': 0,
            'record_count': 0,
            'validation': {},
            'recommendations': [],
            'timestamp': datetime.now().isoformat()
        }
        
        start_time = time.time()
        
        try:
            # Test connection and measure performance
            api = Api(api_key)
            table = api.table(base_id, table_name)
            
            # Get first page to test connection
            records = table.all(max_records=100)
            
            response_time = time.time() - start_time
            audit_result['response_time'] = response_time
            audit_result['record_count'] = len(records)
            
            if records:
                # Convert to DataFrame for validation
                data = [dict(r['fields'], id=r['id']) for r in records]
                df = pd.DataFrame(data)
                
                # Validate data quality
                validation = validator.validate_dataframe(df, 'airtable_leads')
                audit_result['validation'] = validation
                audit_result['status'] = 'success'
                
                # Performance recommendations
                if response_time > self.performance_thresholds['response_time_warning']:
                    audit_result['recommendations'].append(
                        f"Slow response time: {response_time:.2f}s - Consider implementing caching"
                    )
                
                if validation['stats']['missing_values'] > 0:
                    audit_result['recommendations'].append(
                        f"Data quality issue: {validation['stats']['missing_values']} missing values found"
                    )
                
                # Log performance
                storage.log_api_performance(
                    'airtable', response_time, 'success', len(records)
                )
                
            else:
                audit_result['status'] = 'warning'
                audit_result['recommendations'].append("No records found in table")
                
        except Exception as e:
            audit_result['status'] = 'error'
            audit_result['error'] = str(e)
            audit_result['recommendations'].append(f"Connection failed: {str(e)}")
            
            # Log error
            storage.log_api_performance(
                'airtable', time.time() - start_time, 'error', 0, str(e)
            )
        
        return audit_result
    
    def audit_meta_api_connection(self, access_token: str, ad_account_id: str) -> dict:
        """Comprehensive Meta API audit"""
        audit_result = {
            'source': 'meta_api',
            'status': 'unknown',
            'response_time': 0,
            'endpoints_tested': {},
            'validation': {},
            'recommendations': [],
            'timestamp': datetime.now().isoformat()
        }
        
        # Add 'act_' prefix if missing
        if not ad_account_id.startswith('act_'):
            ad_account_id = f"act_{ad_account_id}"
        
        # Test multiple endpoints
        endpoints_to_test = [
            {
                'name': 'account_info',
                'url': f"{self.meta_api_base}/{ad_account_id}",
                'params': {'fields': 'id,name,account_status,currency'}
            },
            {
                'name': 'campaigns',
                'url': f"{self.meta_api_base}/{ad_account_id}/campaigns",
                'params': {'fields': 'id,name,status', 'limit': 5}
            },
            {
                'name': 'insights',
                'url': f"{self.meta_api_base}/{ad_account_id}/insights",
                'params': {
                    'fields': 'spend,impressions,clicks',
                    'time_range': '{"since":"2024-01-01","until":"2024-01-07"}',
                    'limit': 5
                }
            }
        ]
        
        total_start_time = time.time()
        all_successful = True
        
        for endpoint in endpoints_to_test:
            start_time = time.time()
            endpoint_result = {
                'status': 'unknown',
                'response_time': 0,
                'record_count': 0,
                'error': None
            }
            
            try:
                params = endpoint['params'].copy()
                params['access_token'] = access_token
                
                response = requests.get(endpoint['url'], params=params)
                response_time = time.time() - start_time
                endpoint_result['response_time'] = response_time
                
                if response.status_code == 200:
                    data = response.json()
                    endpoint_result['status'] = 'success'
                    
                    # Count records
                    if 'data' in data:
                        endpoint_result['record_count'] = len(data['data'])
                    elif isinstance(data, dict):
                        endpoint_result['record_count'] = 1
                    
                    # Validate specific endpoint data
                    if endpoint['name'] == 'campaigns' and 'data' in data:
                        validation = validator.validate_api_response(data['data'], 'meta_campaigns')
                        audit_result['validation'][endpoint['name']] = validation
                    
                    # Log success
                    storage.log_api_performance(
                        f"meta_{endpoint['name']}", response_time, 'success', 
                        endpoint_result['record_count']
                    )
                    
                else:
                    endpoint_result['status'] = 'error'
                    endpoint_result['error'] = f"HTTP {response.status_code}: {response.text}"
                    all_successful = False
                    
                    # Log error
                    storage.log_api_performance(
                        f"meta_{endpoint['name']}", response_time, 'error', 0, 
                        endpoint_result['error']
                    )
                    
            except Exception as e:
                endpoint_result['status'] = 'error'
                endpoint_result['error'] = str(e)
                endpoint_result['response_time'] = time.time() - start_time
                all_successful = False
                
                # Log error
                storage.log_api_performance(
                    f"meta_{endpoint['name']}", endpoint_result['response_time'], 
                    'error', 0, str(e)
                )
            
            audit_result['endpoints_tested'][endpoint['name']] = endpoint_result
        
        audit_result['response_time'] = time.time() - total_start_time
        audit_result['status'] = 'success' if all_successful else 'partial' if any(
            ep['status'] == 'success' for ep in audit_result['endpoints_tested'].values()
        ) else 'error'
        
        # Generate recommendations
        self._generate_meta_recommendations(audit_result)
        
        return audit_result
    
    def _generate_meta_recommendations(self, audit_result: dict):
        """Generate Meta API performance recommendations"""
        endpoints = audit_result['endpoints_tested']
        
        # Check response times
        slow_endpoints = [
            name for name, data in endpoints.items() 
            if data['response_time'] > self.performance_thresholds['response_time_warning']
        ]
        
        if slow_endpoints:
            audit_result['recommendations'].append(
                f"Slow endpoints detected: {', '.join(slow_endpoints)} - Consider rate limiting"
            )
        
        # Check for errors
        failed_endpoints = [
            name for name, data in endpoints.items() 
            if data['status'] == 'error'
        ]
        
        if failed_endpoints:
            audit_result['recommendations'].append(
                f"Failed endpoints: {', '.join(failed_endpoints)} - Check API permissions"
            )
        
        # Check data availability
        empty_endpoints = [
            name for name, data in endpoints.items()
            if data['status'] == 'success' and data['record_count'] == 0
        ]
        
        if empty_endpoints:
            audit_result['recommendations'].append(
                f"Empty data from: {', '.join(empty_endpoints)} - Check date ranges or account activity"
            )
    
    def generate_performance_report(self) -> dict:
        """Generate comprehensive performance report"""
        stats = storage.get_api_performance_stats(24)  # Last 24 hours
        
        report = {
            'summary': {
                'total_apis_monitored': len(stats),
                'overall_health': 'good',
                'issues_detected': 0,
                'recommendations_count': 0
            },
            'api_performance': stats,
            'alerts': [],
            'recommendations': [],
            'timestamp': datetime.now().isoformat()
        }
        
        # Analyze performance for alerts
        issues = 0
        for api_name, data in stats.items():
            # Check success rate
            if data['success_rate'] < self.performance_thresholds['success_rate_critical']:
                report['alerts'].append({
                    'level': 'critical',
                    'api': api_name,
                    'message': f"Low success rate: {data['success_rate']:.1f}%"
                })
                issues += 1
            elif data['success_rate'] < self.performance_thresholds['success_rate_warning']:
                report['alerts'].append({
                    'level': 'warning',
                    'api': api_name,
                    'message': f"Degraded success rate: {data['success_rate']:.1f}%"
                })
                issues += 1
            
            # Check response time
            if data['avg_response_time'] > self.performance_thresholds['response_time_critical']:
                report['alerts'].append({
                    'level': 'critical',
                    'api': api_name,
                    'message': f"Slow response time: {data['avg_response_time']:.2f}s"
                })
                issues += 1
            elif data['avg_response_time'] > self.performance_thresholds['response_time_warning']:
                report['alerts'].append({
                    'level': 'warning',
                    'api': api_name,
                    'message': f"Elevated response time: {data['avg_response_time']:.2f}s"
                })
                issues += 1
            
            # Add recommendations
            if data['error_count'] > 0:
                report['recommendations'].append(
                    f"{api_name}: {data['error_count']} errors detected - Review API credentials and permissions"
                )
        
        # Set overall health
        report['summary']['issues_detected'] = issues
        report['summary']['recommendations_count'] = len(report['recommendations'])
        
        if issues >= 3:
            report['summary']['overall_health'] = 'poor'
        elif issues >= 1:
            report['summary']['overall_health'] = 'warning'
        
        return report

# Initialize global auditor
auditor = APIAuditor()