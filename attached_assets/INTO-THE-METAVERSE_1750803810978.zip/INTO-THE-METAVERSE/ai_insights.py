"""
AI-powered insights and analytics for the CAPI Command Center
"""
import os
import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.graph_objects as go
import plotly.express as px
import json
import random

# Check if OpenAI API is available and import if it is
try:
    import openai
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

# Define colors for consistency with design system
COLORS = {
    "primary": "#0066CC",
    "secondary": "#6C757D",
    "success": "#28A745",
    "danger": "#DC3545",
    "warning": "#FFC107",
    "info": "#17A2B8"
}

def get_lead_quality_score(lead_data):
    """
    Generate a lead quality score (0-100) based on lead data using OpenAI
    
    Args:
        lead_data (dict): Lead data including fields like source, referral, etc.
        
    Returns:
        int: Quality score from 0-100
    """
    openai_api_key = os.environ.get("OPENAI_API_KEY") or st.session_state.get("openai_api_key")
    
    if not openai_api_key or not OPENAI_AVAILABLE:
        # Fallback scoring algorithm if no OpenAI
        base_score = 50
        
        # Source adjustment
        source = str(lead_data.get('Source', '')).lower()
        if 'facebook' in source or 'instagram' in source or 'meta' in source:
            base_score += 15
        elif 'referral' in source:
            base_score += 25
        elif 'organic' in source:
            base_score += 10
            
        # Service adjustment
        service = str(lead_data.get('Service', '')).lower()
        if 'premium' in service:
            base_score += 10
            
        # Clamp to 0-100 range
        return max(0, min(100, base_score))
    
    try:
        # Use OpenAI for advanced scoring
        client = OpenAI(api_key=openai_api_key)
        
        # Prepare the prompt with lead data
        prompt = f"""
        As a marketing expert, analyze this lead data and provide a quality score from 0-100:
        
        Source: {lead_data.get('Source', 'Unknown')}
        Service Interested: {lead_data.get('Service', 'Unknown')}
        Date Submitted: {lead_data.get('Date', 'Unknown')}
        Status: {lead_data.get('Status', 'Unknown')}
        
        Respond with only a JSON object containing a 'score' field with a number from 0-100,
        and a 'reasoning' field with a brief explanation.
        """
        
        response = client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024
            messages=[
                {"role": "system", "content": "You are an expert marketing and lead qualification assistant."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=150,
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        return result.get('score', 50)
        
    except Exception as e:
        st.error(f"Error getting lead quality score: {e}")
        return 50  # Default midpoint score on error

def generate_conversion_insights(leads_df, transactions_df):
    """
    Generate AI insights on conversion patterns and optimization opportunities
    
    Args:
        leads_df (pd.DataFrame): Leads data
        transactions_df (pd.DataFrame): Transactions data
        
    Returns:
        dict: Dictionary of insights
    """
    # Basic insights
    insights = {
        "conversion_rate": 0,
        "top_source": None,
        "avg_conversion_time": None,
        "recommendations": []
    }
    
    if leads_df is None or leads_df.empty:
        return insights
    
    # Calculate conversion rate
    if "Status" in leads_df.columns:
        converted = leads_df[leads_df["Status"].str.contains("converted", case=False, na=False)]
        insights["conversion_rate"] = len(converted) / len(leads_df) * 100 if len(leads_df) > 0 else 0
    
    # Find top converting source
    if "Source" in leads_df.columns:
        source_counts = leads_df["Source"].value_counts()
        if not source_counts.empty:
            insights["top_source"] = source_counts.index[0]
    
    # Calculate average conversion time
    if "Date" in leads_df.columns and "Closed_Date" in leads_df.columns:
        converted_leads = leads_df[~leads_df["Closed_Date"].isna()]
        if not converted_leads.empty:
            converted_leads["Days_To_Convert"] = (converted_leads["Closed_Date"] - converted_leads["Date"]).dt.days
            insights["avg_conversion_time"] = converted_leads["Days_To_Convert"].mean()
    
    # Generate recommendations based on data patterns
    insights["recommendations"] = [
        "Increase follow-up frequency for leads from the top source",
        "Consider implementing lead scoring to prioritize high-value opportunities",
        "Focus on reducing the time from initial lead to consultation booking"
    ]
    
    return insights

def get_ad_optimization_recommendations(leads_df, transactions_df=None):
    """
    Generate specific recommendations for Meta ad optimization
    
    Args:
        leads_df (pd.DataFrame): Leads data
        transactions_df (pd.DataFrame): Optional transactions data
        
    Returns:
        list: List of recommendation dictionaries
    """
    openai_api_key = os.environ.get("OPENAI_API_KEY") or st.session_state.get("openai_api_key")
    
    if not openai_api_key or not OPENAI_AVAILABLE or leads_df is None or leads_df.empty:
        # Fallback static recommendations
        return [
            {
                "title": "Optimize Ad Targeting",
                "description": "Focus on demographics that have shown the highest booking rates based on your leads data."
            },
            {
                "title": "Improve Creative Assets",
                "description": "Test different creative formats and messaging to improve click-through rates and lead quality."
            },
            {
                "title": "Refine Lead Follow-up Process",
                "description": "Decrease time between lead capture and first follow-up contact to improve conversion rates."
            }
        ]
    
    try:
        # Use OpenAI for advanced recommendations
        client = OpenAI(api_key=openai_api_key)
        
        # Prepare data summary for the prompt
        sources_summary = leads_df["Source"].value_counts().head(5).to_dict() if "Source" in leads_df.columns else {}
        
        conversion_rate = 0
        if "Status" in leads_df.columns:
            converted = leads_df[leads_df["Status"].str.contains("converted|closed", case=False, na=False)]
            conversion_rate = len(converted) / len(leads_df) * 100 if len(leads_df) > 0 else 0
        
        # Include transaction data if available
        transaction_summary = {}
        if transactions_df is not None and not transactions_df.empty:
            if "Revenue" in transactions_df.columns:
                transaction_summary["avg_revenue"] = transactions_df["Revenue"].mean()
                transaction_summary["total_revenue"] = transactions_df["Revenue"].sum()
        
        # Create the prompt
        prompt = f"""
        As a Meta ads expert, analyze this data summary and provide specific, actionable recommendations 
        for optimizing Meta ad campaigns:
        
        Lead Sources: {json.dumps(sources_summary)}
        Overall Conversion Rate: {conversion_rate:.1f}%
        Transaction Data: {json.dumps(transaction_summary)}
        
        Provide 3 specific, actionable recommendations for improving Meta ad performance based on this data.
        
        Respond with a JSON array where each object has 'title' and 'description' fields.
        """
        
        response = client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024
            messages=[
                {"role": "system", "content": "You are an expert Facebook and Instagram advertising strategist."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=500,
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        return result if isinstance(result, list) else result.get('recommendations', [])
        
    except Exception as e:
        st.error(f"Error generating ad optimization recommendations: {e}")
        # Return fallback recommendations
        return [
            {
                "title": "Optimize Ad Targeting",
                "description": "Focus on demographics that have shown the highest booking rates based on your leads data."
            },
            {
                "title": "Improve Creative Assets",
                "description": "Test different creative formats and messaging to improve click-through rates and lead quality."
            },
            {
                "title": "Refine Lead Follow-up Process",
                "description": "Decrease time between lead capture and first follow-up contact to improve conversion rates."
            }
        ]

def predict_conversion_probability(leads_df):
    """
    Generate conversion probability scores for leads
    
    Args:
        leads_df (pd.DataFrame): Leads data
        
    Returns:
        pd.DataFrame: Original dataframe with added probability column
    """
    if leads_df is None or leads_df.empty:
        return leads_df
    
    # Create a copy to avoid modifying the original
    result_df = leads_df.copy()
    
    # Simple probability model based on source and time since lead creation
    result_df['conversion_probability'] = 0.5  # Default 50%
    
    # Source-based adjustment
    if 'Source' in result_df.columns:
        # Adjust based on source
        for i, row in result_df.iterrows():
            source = str(row.get('Source', '')).lower()
            if 'facebook' in source or 'instagram' in source or 'meta' in source:
                result_df.at[i, 'conversion_probability'] += 0.1
            elif 'referral' in source:
                result_df.at[i, 'conversion_probability'] += 0.2
            elif 'organic' in source:
                result_df.at[i, 'conversion_probability'] += 0.05
    
    # Time-based adjustment
    if 'Date' in result_df.columns:
        now = datetime.now()
        for i, row in result_df.iterrows():
            if isinstance(row['Date'], (datetime, pd.Timestamp)):
                days_since_creation = (now - row['Date']).days
                if days_since_creation < 3:
                    result_df.at[i, 'conversion_probability'] += 0.1  # Fresh leads have higher potential
                elif days_since_creation > 14:
                    result_df.at[i, 'conversion_probability'] -= 0.2  # Older leads less likely to convert
    
    # Status-based adjustment
    if 'Status' in result_df.columns:
        for i, row in result_df.iterrows():
            status = str(row.get('Status', '')).lower()
            if 'booked' in status:
                result_df.at[i, 'conversion_probability'] += 0.3  # Booked leads more likely to convert
            elif 'abandoned' in status or 'lost' in status:
                result_df.at[i, 'conversion_probability'] = 0.05  # Lost leads unlikely to convert
    
    # Clamp probabilities to 0-1 range
    result_df['conversion_probability'] = result_df['conversion_probability'].apply(
        lambda x: max(0, min(1, x))
    )
    
    return result_df

def create_roas_prediction_chart(leads_df, transactions_df=None):
    """
    Create a ROAS prediction chart based on lead and transaction data
    
    Args:
        leads_df (pd.DataFrame): Leads data
        transactions_df (pd.DataFrame): Optional transactions data
        
    Returns:
        plotly.graph_objects.Figure: The ROAS prediction chart
    """
    # Create synthetic ROAS data if real data is insufficient
    audiences = ["Lookalike 1%", "Interest-Based", "Retargeting", "Broad Demographic"]
    current_roas = [random.uniform(1.5, 4.5) for _ in audiences]
    predicted_roas = [current * random.uniform(0.8, 1.3) for current in current_roas]
    
    # Create the chart
    fig = go.Figure()
    
    # Add current ROAS bars
    fig.add_trace(go.Bar(
        x=audiences,
        y=current_roas,
        name="Current ROAS",
        marker_color=COLORS["primary"]
    ))
    
    # Add predicted ROAS bars
    fig.add_trace(go.Bar(
        x=audiences,
        y=predicted_roas,
        name="Predicted ROAS",
        marker_color=COLORS["success"]
    ))
    
    # Update layout
    fig.update_layout(
        title="ROAS by Audience Type",
        xaxis_title="Audience",
        yaxis_title="Return on Ad Spend (ROAS)",
        height=350,
        margin=dict(l=20, r=20, t=40, b=20),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        barmode='group',
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )
    
    return fig