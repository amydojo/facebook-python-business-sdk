"""
Real ROAS Dashboard - Authentic Revenue Tracking
Meta ↔ Airtable Lead Match Engine with actual transaction data
"""
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from lead_match_engine import LeadMatchEngine
from simple_airtable import load_airtable_simple
from safe_airtable_loader import (
    load_smooth_md_leads_safe, 
    load_transactions_safe, 
    calculate_safe_roas_metrics
)
from enhanced_airtable_loader import create_brand_breakdown
import numpy as np

def render_real_roas_dashboard():
    """Render the authentic ROAS tracking dashboard"""
    
    st.markdown("# 🎯 Real ROAS & Revenue Tracking")
    st.markdown("### Authentic lead matching with actual transaction revenue")
    
    # Initialize the lead match engine
    engine = LeadMatchEngine()
    
    # Check for required data
    if not _check_data_availability():
        return
    
    # Get Meta spend input
    with st.sidebar:
        st.markdown("### 💰 Meta Ad Spend")
        meta_spend = st.number_input(
            "Total Meta Spend ($)",
            min_value=0.0,
            value=10000.0,
            step=100.0,
            help="Enter your total Meta advertising spend for the analysis period"
        )
        
        st.markdown("### 📅 Analysis Period")
        analysis_period = st.selectbox(
            "Time Period",
            ["Last 30 Days", "Last 7 Days", "Last 90 Days", "All Time"]
        )
    
    # Load clean data using enhanced loader
    st.markdown("## 🔄 Loading Smooth MD Meta Leads & Transactions")
    
    with st.spinner("Loading your Airtable data..."):
        # Load Smooth MD leads from Meta sources only using ultra-safe loader
        leads_df = load_smooth_md_leads_safe(
            st.session_state.get('api_key'),
            st.session_state.get('base_id', 'appri2CgCoIiuZWq3'),
            'Leads'
        )
        
        # Load transactions data using ultra-safe loader
        transactions_df = load_transactions_safe(
            st.session_state.get('api_key'),
            st.session_state.get('base_id', 'appri2CgCoIiuZWq3'),
            'Transactions'
        )
    
    if leads_df.empty:
        st.warning("No Smooth MD leads found from Meta sources. Please check your data filters.")
        return
    
    # Calculate real ROAS metrics using actual data
    st.markdown("---")
    st.markdown("## 📊 Real ROAS & Revenue Calculation")
    
    metrics = calculate_safe_roas_metrics(leads_df, transactions_df, meta_spend)
    
    # Display comprehensive funnel visualization
    st.markdown("---")
    st.markdown("## 📊 Complete Marketing Funnel")
    
    if metrics:
        create_funnel_visualization(metrics, meta_spend)
        
        # Performance by brand/location/service
        st.markdown("---")
        st.markdown("## 🏢 Performance Breakdown")
        
        breakdowns = create_brand_breakdown(leads_df)
        
        if breakdowns:
            create_breakdown_charts(breakdowns)
        
        # Campaign analysis
        st.markdown("---")
        st.markdown("## 🎯 Campaign Performance Analysis")
        
        create_campaign_revenue_analysis(leads_df, metrics)
        
        # AI Summary and Recommendations
        st.markdown("---")
        st.markdown("## 🧠 AI Performance Summary")
        
        generate_ai_summary(metrics, breakdowns)

def _check_data_availability():
    """Check if required data is available"""
    
    # Check Airtable connection
    if not st.session_state.get('api_key'):
        st.error("🔑 Airtable API key required. Please configure in Settings.")
        return False
    
    # Check for leads data
    if st.session_state.get('leads_df') is None or (hasattr(st.session_state.leads_df, 'empty') and st.session_state.leads_df.empty):
        st.warning("📋 No leads data loaded. Loading from Airtable...")
        
        # Try to load data with proper table IDs
        leads_df = load_airtable_simple(
            st.session_state.get('api_key'),
            st.session_state.get('base_id', 'appri2CgCoIiuZWq3'),
            st.session_state.get('leads_table_name', 'Leads')
        )
        
        if leads_df is None or (hasattr(leads_df, 'empty') and leads_df.empty):
            st.error("Failed to load leads data from Airtable. Please check your API credentials in Settings.")
            return False
        
        # Clean complex data types that cause serialization issues
        for col in leads_df.columns:
            if leads_df[col].dtype == 'object':
                # Convert complex objects to strings to avoid Arrow serialization errors
                leads_df[col] = leads_df[col].astype(str)
        
        st.session_state.leads_df = leads_df
        
        # Also load transactions
        transactions_df = load_airtable_simple(
            st.session_state.get('api_key'),
            st.session_state.get('base_id', 'appri2CgCoIiuZWq3'),
            st.session_state.get('transactions_table_name', 'Transactions')
        )
        
        if transactions_df is not None and not transactions_df.empty:
            # Clean complex data types
            for col in transactions_df.columns:
                if transactions_df[col].dtype == 'object':
                    transactions_df[col] = transactions_df[col].astype(str)
        
        st.session_state.transactions_df = transactions_df
    
    return True

def create_funnel_visualization(metrics, meta_spend):
    """Create comprehensive funnel visualization"""
    
    # Sample impressions and clicks (you can replace with actual Meta API data)
    estimated_impressions = int(meta_spend * 10)  # Rough estimate
    estimated_clicks = int(estimated_impressions * 0.02)  # 2% CTR estimate
    
    # Funnel stages
    stages = [
        "Impressions", "Clicks", "Leads", "Booked", "Converted", "Revenue"
    ]
    
    values = [
        estimated_impressions,
        estimated_clicks,
        metrics['total_leads'],
        metrics['booked_leads'],
        metrics['converted_leads'],
        metrics['leads_with_revenue']
    ]
    
    # Create funnel chart
    fig = go.Figure(go.Funnel(
        y=stages,
        x=values,
        textinfo="value+percent initial",
        texttemplate="%{label}: %{value:,}<br>(%{percentInitial})",
        connector={"line": {"color": "royalblue", "dash": "dot", "width": 3}},
        marker={"color": ["lightblue", "lightgreen", "orange", "gold", "lightcoral", "darkgreen"]}
    ))
    
    fig.update_layout(
        title="🔍 Complete Marketing Funnel: Impressions → Revenue",
        title_x=0.5,
        height=600,
        font=dict(size=14)
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Revenue funnel metrics
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric(
            "💵 Cost per Lead",
            f"${metrics['cost_per_lead']:.2f}",
            delta=f"vs ${meta_spend/estimated_clicks:.2f} per click"
        )
    
    with col2:
        st.metric(
            "🎯 Cost per Conversion", 
            f"${metrics['cost_per_conversion']:.2f}",
            delta=f"{metrics['conversion_rate']:.1f}% conversion rate"
        )
    
    with col3:
        st.metric(
            "💰 Revenue per Lead",
            f"${metrics['revenue_per_lead']:.2f}",
            delta=f"${metrics['total_revenue']:,.0f} total"
        )

def create_breakdown_charts(breakdowns):
    """Create performance breakdown charts"""
    
    # Create tabs for different breakdowns
    tab1, tab2, tab3 = st.tabs(["🏢 By Brand", "📍 By Location", "🔧 By Service"])
    
    with tab1:
        if 'brand' in breakdowns:
            brand_df = breakdowns['brand']
            
            fig = px.bar(
                brand_df,
                x='Brand',
                y=['Booked', 'Converted'],
                title="Performance by Brand",
                barmode='group',
                color_discrete_map={'Booked': 'lightblue', 'Converted': 'lightgreen'}
            )
            st.plotly_chart(fig, use_container_width=True)
            
            # Revenue by brand
            fig2 = px.pie(
                brand_df,
                values='Revenue',
                names='Brand',
                title="Revenue Distribution by Brand"
            )
            st.plotly_chart(fig2, use_container_width=True)
    
    with tab2:
        if 'location' in breakdowns:
            location_df = breakdowns['location']
            
            fig = px.bar(
                location_df,
                x='Location',
                y='Revenue',
                title="Revenue by Location",
                color='Revenue',
                color_continuous_scale='viridis'
            )
            st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        if 'service' in breakdowns:
            service_df = breakdowns['service']
            
            fig = px.scatter(
                service_df,
                x='Converted',
                y='Revenue',
                size='Booked',
                hover_name='Service',
                title="Service Performance: Conversions vs Revenue",
                labels={'Converted': 'Converted Leads', 'Revenue': 'Revenue ($)'}
            )
            st.plotly_chart(fig, use_container_width=True)

def create_campaign_revenue_analysis(leads_df, metrics):
    """Analyze which campaigns brought leads that actually paid"""
    
    # Group by campaign/source for analysis
    if 'Contact Source' in leads_df.columns or 'fldBUfZjdVhhJpRRA' in leads_df.columns:
        source_col = 'fldBUfZjdVhhJpRRA' if 'fldBUfZjdVhhJpRRA' in leads_df.columns else 'Contact Source'
        
        campaign_analysis = leads_df.groupby(source_col).agg({
            'is_booked': 'sum',
            'is_converted': 'sum',
            'transaction_amount': ['sum', 'count', 'mean']
        }).round(2)
        
        # Flatten column names
        campaign_analysis.columns = [
            'Booked', 'Converted', 'Total_Revenue', 'Paid_Count', 'Avg_Revenue'
        ]
        campaign_analysis = campaign_analysis.reset_index()
        campaign_analysis.columns = [
            'Campaign_Source', 'Booked', 'Converted', 'Total_Revenue', 'Paid_Count', 'Avg_Revenue'
        ]
        
        # Calculate conversion rates
        campaign_analysis['Lead_Count'] = leads_df.groupby(source_col).size().values
        campaign_analysis['Conversion_Rate'] = (
            campaign_analysis['Converted'] / campaign_analysis['Lead_Count'] * 100
        ).round(1)
        
        # Sort by total revenue
        campaign_analysis = campaign_analysis.sort_values('Total_Revenue', ascending=False)
        
        st.markdown("### 💎 Top Revenue-Generating Campaigns")
        
        # Display top performing campaigns
        top_campaigns = campaign_analysis.head(10)
        
        st.dataframe(
            top_campaigns,
            column_config={
                "Campaign_Source": st.column_config.TextColumn("Campaign/Source", width="large"),
                "Lead_Count": st.column_config.NumberColumn("Total Leads", format="%d"),
                "Booked": st.column_config.NumberColumn("Booked", format="%d"),
                "Converted": st.column_config.NumberColumn("Converted", format="%d"),
                "Conversion_Rate": st.column_config.NumberColumn("Conv. Rate", format="%.1f%%"),
                "Total_Revenue": st.column_config.NumberColumn("Total Revenue", format="$%.0f"),
                "Avg_Revenue": st.column_config.NumberColumn("Avg Revenue", format="$%.0f"),
            },
            use_container_width=True
        )
        
        # Campaign performance chart
        fig = px.scatter(
            top_campaigns,
            x='Conversion_Rate',
            y='Total_Revenue',
            size='Lead_Count',
            hover_name='Campaign_Source',
            title="Campaign Performance: Conversion Rate vs Total Revenue",
            labels={
                'Conversion_Rate': 'Conversion Rate (%)',
                'Total_Revenue': 'Total Revenue ($)',
                'Lead_Count': 'Lead Count'
            }
        )
        
        st.plotly_chart(fig, use_container_width=True)

def generate_ai_summary(metrics, breakdowns):
    """Generate AI-powered performance summary"""
    
    # Performance assessment
    if metrics['roas'] >= 4.0:
        roas_assessment = "🟢 Excellent"
    elif metrics['roas'] >= 2.0:
        roas_assessment = "🟡 Good"
    else:
        roas_assessment = "🔴 Needs Improvement"
    
    if metrics['conversion_rate'] >= 10.0:
        conversion_assessment = "🟢 Excellent"
    elif metrics['conversion_rate'] >= 5.0:
        conversion_assessment = "🟡 Good"
    else:
        conversion_assessment = "🔴 Needs Improvement"
    
    # Generate insights
    st.markdown("### 🎯 Performance Assessment")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown(f"""
        **💰 ROAS Performance: {roas_assessment}**
        - Current ROAS: {metrics['roas']:.2f}x
        - Revenue Generated: ${metrics['total_revenue']:,.0f}
        - ROI: {metrics['roi']:.1f}%
        """)
    
    with col2:
        st.markdown(f"""
        **🎯 Conversion Performance: {conversion_assessment}**
        - Conversion Rate: {metrics['conversion_rate']:.1f}%
        - Revenue per Lead: ${metrics['revenue_per_lead']:.0f}
        - Leads with Revenue: {metrics['leads_with_revenue']}
        """)
    
    # Recommendations
    st.markdown("### 💡 Strategic Recommendations")
    
    recommendations = []
    
    if metrics['roas'] < 2.0:
        recommendations.append("🔴 **Critical:** ROAS below 2x. Focus on higher-value services or reduce ad spend.")
    
    if metrics['conversion_rate'] < 5.0:
        recommendations.append("🟡 **Optimize:** Low conversion rate. Review lead qualification and follow-up process.")
    
    if metrics['revenue_rate'] < 20.0:  # Less than 20% of leads generate revenue
        recommendations.append("🔍 **Investigate:** Low revenue rate. Check transaction tracking and payment processes.")
    
    if metrics['roas'] > 4.0:
        recommendations.append("🟢 **Scale:** Excellent ROAS! Consider increasing ad spend to scale successful campaigns.")
    
    if not recommendations:
        recommendations.append("🎉 **Excellent:** All metrics are performing well! Maintain current strategy.")
    
    for rec in recommendations:
        st.markdown(rec)
    
    # Best performing breakdown
    if breakdowns:
        st.markdown("### 🏆 Top Performers")
        
        if 'brand' in breakdowns and not breakdowns['brand'].empty:
            top_brand = breakdowns['brand'].loc[breakdowns['brand']['Revenue'].idxmax()]
            st.success(f"🏢 **Top Brand:** {top_brand['Brand']} (${top_brand['Revenue']:,.0f} revenue)")
        
        if 'location' in breakdowns and not breakdowns['location'].empty:
            top_location = breakdowns['location'].loc[breakdowns['location']['Revenue'].idxmax()]
            st.success(f"📍 **Top Location:** {top_location['Location']} (${top_location['Revenue']:,.0f} revenue)")
        
        if 'service' in breakdowns and not breakdowns['service'].empty:
            top_service = breakdowns['service'].loc[breakdowns['service']['Revenue'].idxmax()]
            st.success(f"🔧 **Top Service:** {top_service['Service']} (${top_service['Revenue']:,.0f} revenue)")