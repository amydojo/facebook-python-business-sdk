"""
Accurate Meta Attribution Dashboard
Uses Social Media view for precise revenue tracking with proper field mapping
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import os
import requests
from datetime import datetime, timedelta
from pyairtable import Api
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Meta Attribution Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

def apply_professional_styling():
    """Professional dashboard styling"""
    st.markdown("""
    <style>
    .stApp {
        background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    }
    
    .main .block-container {
        padding: 1rem;
        max-width: 100%;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 20px;
        backdrop-filter: blur(20px);
        margin-top: 1rem;
    }
    
    .dashboard-header {
        text-align: center;
        padding: 2rem 0;
        background: linear-gradient(135deg, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0.05) 100%);
        border-radius: 20px;
        margin-bottom: 2rem;
        backdrop-filter: blur(10px);
    }
    
    .metric-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
        margin: 2rem 0;
    }
    
    .metric-card {
        background: rgba(255, 255, 255, 0.12);
        backdrop-filter: blur(20px);
        border-radius: 16px;
        padding: 1.5rem;
        border: 1px solid rgba(255, 255, 255, 0.2);
        transition: all 0.3s ease;
    }
    
    .metric-card:hover {
        transform: translateY(-2px);
        background: rgba(255, 255, 255, 0.18);
        box-shadow: 0 8px 32px rgba(0,0,0,0.2);
    }
    
    .metric-title {
        font-size: 0.9rem;
        color: rgba(255,255,255,0.8);
        font-weight: 500;
        margin-bottom: 0.5rem;
    }
    
    .metric-value {
        font-size: 2rem;
        font-weight: 700;
        color: white;
        margin-bottom: 0.5rem;
    }
    
    .metric-subtitle {
        font-size: 0.85rem;
        color: rgba(255,255,255,0.7);
    }
    
    .roas-hero {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        border-radius: 24px;
        padding: 3rem 2rem;
        text-align: center;
        margin: 2rem 0;
        box-shadow: 0 20px 60px rgba(17, 153, 142, 0.3);
        position: relative;
        overflow: hidden;
    }
    
    .roas-value {
        font-size: 3.5rem;
        font-weight: 800;
        color: white;
        margin: 0;
        text-shadow: 0 4px 20px rgba(0,0,0,0.2);
    }
    
    .section-container {
        background: rgba(255, 255, 255, 0.08);
        border-radius: 16px;
        padding: 2rem;
        margin: 2rem 0;
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .section-title {
        color: white;
        font-size: 1.4rem;
        font-weight: 600;
        margin-bottom: 1rem;
        border-bottom: 2px solid rgba(255,255,255,0.2);
        padding-bottom: 0.5rem;
    }
    
    .status-success { color: #4CAF50; }
    .status-error { color: #F44336; }
    .status-warning { color: #FF9800; }
    
    #MainMenu, footer, header, .stDeployButton {
        visibility: hidden;
    }
    </style>
    """, unsafe_allow_html=True)

class MetaRevenueAnalyzer:
    """Analyzes Meta revenue using Social Media view with accurate field mapping"""
    
    def __init__(self):
        self.base_id = 'appri2CgCoIiuZWq3'
        self.meta_spend = 0
        self.meta_revenue = 0
        self.smooth_md_revenue = 0
        self.social_media_transactions = []
        self.meta_insights = {}
    
    def load_meta_advertising_data(self):
        """Load Meta advertising spend and performance data"""
        try:
            access_token = os.getenv('META_ACCESS_TOKEN')
            ad_account_id = os.getenv('META_AD_ACCOUNT_ID')
            
            if not access_token or not ad_account_id:
                return False, "Meta API credentials missing"
            
            url = f"https://graph.facebook.com/v18.0/act_{ad_account_id}/insights"
            params = {
                'access_token': access_token,
                'fields': 'spend,impressions,clicks,actions,cpm,cpc,ctr,reach',
                'date_preset': 'last_30d',
                'limit': 50
            }
            
            response = requests.get(url, params=params, timeout=15)
            
            if response.status_code == 200:
                data = response.json()
                insights = data.get('data', [])
                
                if insights:
                    self.meta_spend = sum(float(insight.get('spend', 0)) for insight in insights)
                    impressions = sum(int(insight.get('impressions', 0)) for insight in insights)
                    clicks = sum(int(insight.get('clicks', 0)) for insight in insights)
                    reach = sum(int(insight.get('reach', 0)) for insight in insights)
                    
                    # Extract leads from actions
                    leads = 0
                    for insight in insights:
                        actions = insight.get('actions', [])
                        for action in actions:
                            if action.get('action_type') == 'lead':
                                leads += int(action.get('value', 0))
                    
                    self.meta_insights = {
                        'spend': self.meta_spend,
                        'impressions': impressions,
                        'clicks': clicks,
                        'reach': reach,
                        'leads': leads,
                        'cpm': sum(float(insight.get('cpm', 0)) for insight in insights) / len(insights),
                        'cpc': sum(float(insight.get('cpc', 0)) for insight in insights) / len(insights),
                        'ctr': sum(float(insight.get('ctr', 0)) for insight in insights) / len(insights)
                    }
                    
                    return True, f"Meta data loaded: ${self.meta_spend:,.2f} spend, {impressions:,} impressions"
                else:
                    return False, "No Meta insights available"
            else:
                return False, f"Meta API error: {response.status_code}"
                
        except Exception as e:
            return False, f"Meta API failed: {str(e)}"
    
    def load_social_media_revenue(self):
        """Load revenue from Social Media view transactions"""
        try:
            airtable_key = os.getenv('AIRTABLE_API_KEY')
            if not airtable_key:
                return False, "Airtable API key missing"
            
            api = Api(airtable_key)
            trans_table = api.table(self.base_id, 'Transactions')
            
            # Load all transactions from Social Media view
            social_records = trans_table.all(view='Social Media')
            
            total_revenue = 0
            smooth_md_revenue = 0
            valid_transactions = 0
            
            for record in social_records:
                fields = record.get('fields', {})
                
                # Extract amount from available fields
                amount = fields.get('Amount', 0)
                if not amount:
                    amount = fields.get('Purchased', 0)
                if not amount:
                    amount = fields.get('Remaining', 0)
                
                # Ensure numeric amount
                if isinstance(amount, (int, float)) and amount > 0:
                    # Get brand information
                    brand_data = fields.get('Brand (from ID)', [])
                    brand = brand_data[0] if isinstance(brand_data, list) and brand_data else str(brand_data)
                    
                    # Get contact source
                    source_data = fields.get('Contact Source (from ID)', [])
                    contact_source = source_data[0] if isinstance(source_data, list) and source_data else str(source_data)
                    
                    # Get services and other details
                    services = fields.get('Services Purchased', '')
                    status = fields.get('Status', '')
                    date = fields.get('Date', '')
                    patient = fields.get('Patient', '')
                    
                    # Check if Smooth MD
                    is_smooth_md = 'smooth' in brand.lower() and 'md' in brand.lower()
                    
                    # Store transaction data
                    transaction_info = {
                        'amount': amount,
                        'brand': brand,
                        'contact_source': contact_source,
                        'services': services,
                        'status': status,
                        'date': date,
                        'patient': patient,
                        'is_smooth_md': is_smooth_md
                    }
                    
                    self.social_media_transactions.append(transaction_info)
                    total_revenue += amount
                    valid_transactions += 1
                    
                    if is_smooth_md:
                        smooth_md_revenue += amount
            
            self.meta_revenue = total_revenue
            self.smooth_md_revenue = smooth_md_revenue
            
            return True, f"Social Media transactions: {valid_transactions} records, ${total_revenue:,.2f} total revenue"
            
        except Exception as e:
            return False, f"Social Media view failed: {str(e)}"
    
    def calculate_performance_metrics(self):
        """Calculate comprehensive performance metrics"""
        if not self.meta_spend or not self.meta_revenue:
            return {}
        
        # Basic ROAS calculations
        roas = self.meta_revenue / self.meta_spend
        smooth_md_roas = self.smooth_md_revenue / self.meta_spend
        
        # Transaction analysis
        total_transactions = len(self.social_media_transactions)
        smooth_md_transactions = len([t for t in self.social_media_transactions if t['is_smooth_md']])
        
        # Average values
        avg_transaction_value = self.meta_revenue / total_transactions if total_transactions > 0 else 0
        avg_smooth_md_value = self.smooth_md_revenue / smooth_md_transactions if smooth_md_transactions > 0 else 0
        
        # Cost metrics
        cost_per_transaction = self.meta_spend / total_transactions if total_transactions > 0 else 0
        
        # Performance ratios
        profit = self.meta_revenue - self.meta_spend
        profit_margin = (profit / self.meta_revenue) * 100 if self.meta_revenue > 0 else 0
        
        return {
            'roas': roas,
            'smooth_md_roas': smooth_md_roas,
            'total_revenue': self.meta_revenue,
            'smooth_md_revenue': self.smooth_md_revenue,
            'total_spend': self.meta_spend,
            'profit': profit,
            'profit_margin': profit_margin,
            'total_transactions': total_transactions,
            'smooth_md_transactions': smooth_md_transactions,
            'avg_transaction_value': avg_transaction_value,
            'avg_smooth_md_value': avg_smooth_md_value,
            'cost_per_transaction': cost_per_transaction,
            'revenue_per_dollar': self.meta_revenue / self.meta_spend if self.meta_spend > 0 else 0
        }
    
    def get_services_analysis(self):
        """Analyze revenue by service type"""
        services_data = {}
        
        for transaction in self.social_media_transactions:
            service = transaction['services']
            if service not in services_data:
                services_data[service] = {'revenue': 0, 'count': 0}
            
            services_data[service]['revenue'] += transaction['amount']
            services_data[service]['count'] += 1
        
        # Sort by revenue
        return sorted(services_data.items(), key=lambda x: x[1]['revenue'], reverse=True)
    
    def get_brand_analysis(self):
        """Analyze revenue by brand"""
        brand_data = {}
        
        for transaction in self.social_media_transactions:
            brand = transaction['brand']
            if brand not in brand_data:
                brand_data[brand] = {'revenue': 0, 'count': 0}
            
            brand_data[brand]['revenue'] += transaction['amount']
            brand_data[brand]['count'] += 1
        
        # Sort by revenue
        return sorted(brand_data.items(), key=lambda x: x[1]['revenue'], reverse=True)

def create_roas_gauge_chart(roas_value, title="ROAS"):
    """Create ROAS gauge visualization"""
    fig = go.Figure(go.Indicator(
        mode = "gauge+number",
        value = roas_value,
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': title, 'font': {'size': 20, 'color': 'white'}},
        gauge = {
            'axis': {'range': [None, 8], 'tickcolor': 'white'},
            'bar': {'color': "#11998e"},
            'steps': [
                {'range': [0, 2], 'color': "rgba(255, 99, 99, 0.3)"},
                {'range': [2, 4], 'color': "rgba(255, 206, 84, 0.3)"},
                {'range': [4, 8], 'color': "rgba(75, 192, 192, 0.3)"}
            ],
            'threshold': {
                'line': {'color': "white", 'width': 4},
                'thickness': 0.75,
                'value': 3.0
            }
        }
    ))
    
    fig.update_layout(
        height=350,
        font={'color': 'white'},
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    
    return fig

def create_revenue_breakdown_chart(services_data):
    """Create revenue breakdown by services"""
    if not services_data:
        return None
    
    services = [item[0] for item in services_data[:8]]
    revenues = [item[1]['revenue'] for item in services_data[:8]]
    
    fig = px.pie(
        values=revenues,
        names=services,
        title="Revenue Distribution by Service",
        color_discrete_sequence=px.colors.qualitative.Set3
    )
    
    fig.update_layout(
        height=400,
        font={'color': 'white'},
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        title_font_color='white'
    )
    
    return fig

def main():
    """Main dashboard application"""
    
    apply_professional_styling()
    
    # Header
    st.markdown("""
    <div class="dashboard-header">
        <h1 style="color: white; font-size: 2.5rem; margin: 0;">📊 Meta Attribution Dashboard</h1>
        <p style="color: rgba(255,255,255,0.8); font-size: 1.1rem; margin: 0.5rem 0 0 0;">
            Accurate revenue tracking using Social Media view
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize analyzer
    analyzer = MetaRevenueAnalyzer()
    
    # Load data
    with st.spinner("Loading Meta advertising data and Social Media transactions..."):
        meta_success, meta_message = analyzer.load_meta_advertising_data()
        revenue_success, revenue_message = analyzer.load_social_media_revenue()
    
    # Connection status
    col1, col2 = st.columns(2)
    
    with col1:
        status_class = "status-success" if meta_success else "status-error"
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Meta Advertising API</div>
            <div class="metric-value {status_class}">
                {'✅ Connected' if meta_success else '❌ Error'}
            </div>
            <div class="metric-subtitle">{meta_message}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        status_class = "status-success" if revenue_success else "status-error"
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Social Media Revenue</div>
            <div class="metric-value {status_class}">
                {'✅ Connected' if revenue_success else '❌ Error'}
            </div>
            <div class="metric-subtitle">{revenue_message}</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Main analytics
    if meta_success and revenue_success:
        metrics = analyzer.calculate_performance_metrics()
        
        # ROAS Hero Section
        roas = metrics.get('roas', 0)
        st.markdown(f"""
        <div class="roas-hero">
            <h2 class="roas-value">{roas:.2f}x</h2>
            <h3 style="color: white; margin: 0.5rem 0; font-size: 1.4rem;">Meta ROAS</h3>
            <p style="color: rgba(255,255,255,0.8); margin: 0;">
                ${metrics.get('total_revenue', 0):,.2f} revenue ÷ ${metrics.get('total_spend', 0):,.2f} spend
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        # Key Performance Metrics
        st.markdown('<div class="metric-container">', unsafe_allow_html=True)
        
        # Total Revenue
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Total Meta Revenue</div>
            <div class="metric-value">${metrics.get('total_revenue', 0):,.2f}</div>
            <div class="metric-subtitle">From {metrics.get('total_transactions', 0)} transactions</div>
        </div>
        """, unsafe_allow_html=True)
        
        # Smooth MD Revenue
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Smooth MD Revenue</div>
            <div class="metric-value">${metrics.get('smooth_md_revenue', 0):,.2f}</div>
            <div class="metric-subtitle">From {metrics.get('smooth_md_transactions', 0)} transactions</div>
        </div>
        """, unsafe_allow_html=True)
        
        # Profit
        profit = metrics.get('profit', 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Total Profit</div>
            <div class="metric-value">${profit:,.2f}</div>
            <div class="metric-subtitle">{metrics.get('profit_margin', 0):.1f}% margin</div>
        </div>
        """, unsafe_allow_html=True)
        
        # Average Transaction Value
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Avg Transaction Value</div>
            <div class="metric-value">${metrics.get('avg_transaction_value', 0):,.2f}</div>
            <div class="metric-subtitle">Cost per transaction: ${metrics.get('cost_per_transaction', 0):,.2f}</div>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        # ROAS Analysis Section
        st.markdown('<div class="section-container">', unsafe_allow_html=True)
        st.markdown('<h2 class="section-title">📈 ROAS Analysis</h2>', unsafe_allow_html=True)
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            roas_chart = create_roas_gauge_chart(roas, "Overall ROAS")
            st.plotly_chart(roas_chart, use_container_width=True)
        
        with col2:
            smooth_md_roas = metrics.get('smooth_md_roas', 0)
            st.markdown(f"""
            <div style="padding: 2rem 0;">
                <h3 style="color: white; margin-bottom: 1rem;">Brand Performance</h3>
                <div style="background: rgba(255,255,255,0.1); padding: 1rem; border-radius: 12px; margin: 1rem 0;">
                    <div style="color: rgba(255,255,255,0.8); font-size: 0.9rem;">Smooth MD ROAS</div>
                    <div style="color: white; font-size: 1.8rem; font-weight: 700;">{smooth_md_roas:.2f}x</div>
                </div>
                <div style="background: rgba(255,255,255,0.1); padding: 1rem; border-radius: 12px; margin: 1rem 0;">
                    <div style="color: rgba(255,255,255,0.8); font-size: 0.9rem;">Revenue per Dollar</div>
                    <div style="color: white; font-size: 1.8rem; font-weight: 700;">${metrics.get('revenue_per_dollar', 0):.2f}</div>
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Services Revenue Analysis
        services_data = analyzer.get_services_analysis()
        if services_data:
            st.markdown('<div class="section-container">', unsafe_allow_html=True)
            st.markdown('<h2 class="section-title">🛍️ Revenue by Service</h2>', unsafe_allow_html=True)
            
            col1, col2 = st.columns([1, 1])
            
            with col1:
                revenue_chart = create_revenue_breakdown_chart(services_data)
                if revenue_chart:
                    st.plotly_chart(revenue_chart, use_container_width=True)
            
            with col2:
                st.markdown('<h3 style="color: white; margin-bottom: 1rem;">Top Services</h3>', unsafe_allow_html=True)
                for i, (service, data) in enumerate(services_data[:6]):
                    st.markdown(f"""
                    <div style="background: rgba(255,255,255,0.1); padding: 1rem; border-radius: 8px; margin: 0.5rem 0;">
                        <div style="color: white; font-weight: 600;">{service}</div>
                        <div style="color: rgba(255,255,255,0.8); font-size: 0.9rem;">
                            ${data['revenue']:,.2f} • {data['count']} transactions
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
            
            st.markdown('</div>', unsafe_allow_html=True)
        
        # Brand Performance
        brand_data = analyzer.get_brand_analysis()
        if brand_data:
            st.markdown('<div class="section-container">', unsafe_allow_html=True)
            st.markdown('<h2 class="section-title">🏢 Brand Performance</h2>', unsafe_allow_html=True)
            
            col1, col2, col3 = st.columns(3)
            
            for i, (brand, data) in enumerate(brand_data[:3]):
                with [col1, col2, col3][i]:
                    st.markdown(f"""
                    <div class="metric-card">
                        <div class="metric-title">{brand}</div>
                        <div class="metric-value">${data['revenue']:,.2f}</div>
                        <div class="metric-subtitle">{data['count']} transactions</div>
                    </div>
                    """, unsafe_allow_html=True)
            
            st.markdown('</div>', unsafe_allow_html=True)
        
    else:
        st.error("Data loading failed. Check API connections and view access.")
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <p style="color: rgba(255,255,255,0.6); text-align: center;">
        Revenue attribution based on Social Media view transactions with Meta advertising spend
    </p>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()