"""
Development Compliance Audit
Comprehensive analysis of adherence to current development guidelines
"""

import streamlit as st
import os
import sys
import ast
import re
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px

class DevelopmentComplianceAuditor:
    """Audit system compliance with current development guidelines"""
    
    def __init__(self):
        self.audit_results = {}
        self.compliance_score = 0
        self.violations = []
        self.recommendations = []
        
    def run_compliance_audit(self) -> Dict:
        """Execute comprehensive compliance audit"""
        
        st.title("📋 Development Compliance Audit")
        st.markdown("Analyzing adherence to current development guidelines")
        st.markdown("---")
        
        # Performance tracking
        start_time = time.time()
        
        # Run audit sections
        audit_sections = [
            ("Code Quality Standards", self._audit_code_quality),
            ("Architecture Compliance", self._audit_architecture),
            ("Performance Standards", self._audit_performance),
            ("Security Guidelines", self._audit_security),
            ("Data Handling Standards", self._audit_data_handling),
            ("Error Handling Patterns", self._audit_error_handling),
            ("Documentation Standards", self._audit_documentation),
            ("Testing Guidelines", self._audit_testing),
            ("Deployment Readiness", self._audit_deployment)
        ]
        
        progress_bar = st.progress(0)
        
        for i, (section_name, audit_func) in enumerate(audit_sections):
            st.subheader(f"🔍 {section_name}")
            
            try:
                section_results = audit_func()
                self.audit_results[section_name] = section_results
                
                # Display section summary
                self._display_section_summary(section_name, section_results)
                
            except Exception as e:
                st.error(f"Audit error in {section_name}: {e}")
                self.audit_results[section_name] = {'error': str(e)}
            
            progress_bar.progress((i + 1) / len(audit_sections))
        
        # Calculate overall compliance score
        self.compliance_score = self._calculate_compliance_score()
        
        # Display comprehensive results
        self._display_compliance_dashboard()
        
        audit_duration = time.time() - start_time
        
        return {
            'compliance_score': self.compliance_score,
            'audit_results': self.audit_results,
            'violations': self.violations,
            'recommendations': self.recommendations,
            'audit_duration': audit_duration,
            'timestamp': datetime.now().isoformat()
        }
    
    def _audit_code_quality(self) -> Dict:
        """Audit code quality standards compliance"""
        
        quality_metrics = {
            'type_hints_usage': 0,
            'docstring_coverage': 0,
            'function_complexity': 0,
            'naming_conventions': 0,
            'import_organization': 0
        }
        
        python_files = [f for f in os.listdir('.') if f.endswith('.py') and not f.startswith('test_')]
        
        if not python_files:
            return {'error': 'No Python files found'}
        
        total_files = len(python_files)
        
        for file_path in python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Parse AST
                try:
                    tree = ast.parse(content)
                except SyntaxError:
                    self.violations.append(f"Syntax error in {file_path}")
                    continue
                
                # Check type hints
                has_type_hints = 'from typing import' in content or ': str' in content or '-> ' in content
                if has_type_hints:
                    quality_metrics['type_hints_usage'] += 1
                
                # Check docstrings
                has_docstrings = '"""' in content or "'''" in content
                if has_docstrings:
                    quality_metrics['docstring_coverage'] += 1
                
                # Check function complexity (basic heuristic)
                function_count = content.count('def ')
                nested_blocks = content.count('    if ') + content.count('    for ') + content.count('    while ')
                if function_count > 0:
                    avg_complexity = nested_blocks / function_count
                    if avg_complexity < 3:  # Low complexity threshold
                        quality_metrics['function_complexity'] += 1
                
                # Check naming conventions
                snake_case_functions = len(re.findall(r'def [a-z_][a-z0-9_]*\(', content))
                camel_case_classes = len(re.findall(r'class [A-Z][a-zA-Z0-9]*\(', content))
                total_definitions = snake_case_functions + camel_case_classes
                
                if total_definitions > 0:
                    quality_metrics['naming_conventions'] += 1
                
                # Check import organization
                lines = content.split('\n')
                import_lines = [i for i, line in enumerate(lines) if line.strip().startswith(('import ', 'from '))]
                
                if import_lines:
                    # Check if imports are at the top (after docstring/comments)
                    first_code_line = next((i for i, line in enumerate(lines) if line.strip() and not line.strip().startswith('#') and not line.strip().startswith('"""')), 0)
                    if import_lines[0] <= first_code_line + 10:  # Allow some flexibility
                        quality_metrics['import_organization'] += 1
                
            except Exception as e:
                self.violations.append(f"Error analyzing {file_path}: {e}")
        
        # Convert to percentages
        for metric in quality_metrics:
            quality_metrics[metric] = (quality_metrics[metric] / total_files) * 100
        
        # Display metrics
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            st.metric("Type Hints", f"{quality_metrics['type_hints_usage']:.0f}%")
        with col2:
            st.metric("Docstrings", f"{quality_metrics['docstring_coverage']:.0f}%")
        with col3:
            st.metric("Low Complexity", f"{quality_metrics['function_complexity']:.0f}%")
        with col4:
            st.metric("Naming Standards", f"{quality_metrics['naming_conventions']:.0f}%")
        with col5:
            st.metric("Import Organization", f"{quality_metrics['import_organization']:.0f}%")
        
        # Identify violations
        if quality_metrics['type_hints_usage'] < 80:
            self.violations.append("Type hints usage below 80%")
            self.recommendations.append("Add type hints to function parameters and return values")
        
        if quality_metrics['docstring_coverage'] < 70:
            self.violations.append("Docstring coverage below 70%")
            self.recommendations.append("Add comprehensive docstrings to modules, classes, and functions")
        
        return quality_metrics
    
    def _audit_architecture(self) -> Dict:
        """Audit architectural compliance"""
        
        arch_metrics = {
            'separation_of_concerns': 0,
            'dependency_management': 0,
            'configuration_management': 0,
            'modular_design': 0
        }
        
        # Check separation of concerns
        specialized_files = [
            'config_manager.py',
            'reliable_data_connector.py',
            'robust_error_handler.py'
        ]
        
        existing_specialized = sum(1 for f in specialized_files if os.path.exists(f))
        arch_metrics['separation_of_concerns'] = (existing_specialized / len(specialized_files)) * 100
        
        # Check dependency management
        if os.path.exists('pyproject.toml'):
            arch_metrics['dependency_management'] = 100
        elif os.path.exists('requirements.txt'):
            arch_metrics['dependency_management'] = 75
        else:
            arch_metrics['dependency_management'] = 0
            self.violations.append("No dependency management file found")
        
        # Check configuration management
        config_indicators = [
            os.path.exists('.streamlit/config.toml'),
            os.path.exists('config_manager.py'),
            any('os.getenv' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py'))
        ]
        arch_metrics['configuration_management'] = (sum(config_indicators) / len(config_indicators)) * 100
        
        # Check modular design
        python_files = [f for f in os.listdir('.') if f.endswith('.py')]
        if len(python_files) > 5:  # Multiple modules indicate modular design
            arch_metrics['modular_design'] = min(100, len(python_files) * 10)
        else:
            arch_metrics['modular_design'] = 50
        
        # Display architecture metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Separation of Concerns", f"{arch_metrics['separation_of_concerns']:.0f}%")
        with col2:
            st.metric("Dependency Mgmt", f"{arch_metrics['dependency_management']:.0f}%")
        with col3:
            st.metric("Configuration Mgmt", f"{arch_metrics['configuration_management']:.0f}%")
        with col4:
            st.metric("Modular Design", f"{arch_metrics['modular_design']:.0f}%")
        
        return arch_metrics
    
    def _audit_performance(self) -> Dict:
        """Audit performance standards compliance"""
        
        perf_metrics = {
            'caching_implementation': 0,
            'async_patterns': 0,
            'memory_efficiency': 0,
            'response_time_optimization': 0
        }
        
        # Check caching implementation
        cache_indicators = [
            os.path.exists('data_cache'),
            any('cache' in open(f, 'r').read().lower() for f in os.listdir('.') if f.endswith('.py')),
            any('@st.cache' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py'))
        ]
        perf_metrics['caching_implementation'] = (sum(cache_indicators) / len(cache_indicators)) * 100
        
        # Check async patterns (basic check)
        async_indicators = [
            any('async def' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py')),
            any('await ' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py'))
        ]
        perf_metrics['async_patterns'] = (sum(async_indicators) / max(len(async_indicators), 1)) * 100
        
        # Check memory efficiency patterns
        memory_patterns = [
            any('del ' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py')),
            any('gc.collect' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py')),
            not any('global ' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py'))  # Avoid globals
        ]
        perf_metrics['memory_efficiency'] = (sum(memory_patterns) / len(memory_patterns)) * 100
        
        # Check response time optimization
        optimization_patterns = [
            any('batch' in open(f, 'r').read().lower() for f in os.listdir('.') if f.endswith('.py')),
            any('pagination' in open(f, 'r').read().lower() for f in os.listdir('.') if f.endswith('.py')),
            any('lazy' in open(f, 'r').read().lower() for f in os.listdir('.') if f.endswith('.py'))
        ]
        perf_metrics['response_time_optimization'] = (sum(optimization_patterns) / len(optimization_patterns)) * 100
        
        # Display performance metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Caching", f"{perf_metrics['caching_implementation']:.0f}%")
        with col2:
            st.metric("Async Patterns", f"{perf_metrics['async_patterns']:.0f}%")
        with col3:
            st.metric("Memory Efficiency", f"{perf_metrics['memory_efficiency']:.0f}%")
        with col4:
            st.metric("Response Optimization", f"{perf_metrics['response_time_optimization']:.0f}%")
        
        return perf_metrics
    
    def _audit_security(self) -> Dict:
        """Audit security standards compliance"""
        
        security_metrics = {
            'environment_variables': 0,
            'input_validation': 0,
            'secret_management': 0,
            'secure_configurations': 0
        }
        
        # Check environment variable usage
        env_usage = any('os.getenv' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py'))
        security_metrics['environment_variables'] = 100 if env_usage else 0
        
        # Check input validation patterns
        validation_patterns = [
            any('validate' in open(f, 'r').read().lower() for f in os.listdir('.') if f.endswith('.py')),
            any('isinstance(' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py')),
            any('try:' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py'))
        ]
        security_metrics['input_validation'] = (sum(validation_patterns) / len(validation_patterns)) * 100
        
        # Check secret management
        secret_indicators = [
            not any('api_key =' in open(f, 'r').read().lower() for f in os.listdir('.') if f.endswith('.py')),  # No hardcoded keys
            not any('token =' in open(f, 'r').read().lower() for f in os.listdir('.') if f.endswith('.py')),  # No hardcoded tokens
            os.path.exists('.gitignore')
        ]
        security_metrics['secret_management'] = (sum(secret_indicators) / len(secret_indicators)) * 100
        
        # Check secure configurations
        secure_config = [
            os.path.exists('.streamlit/config.toml'),
            os.path.exists('.gitignore'),
            not any('debug=True' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py'))
        ]
        security_metrics['secure_configurations'] = (sum(secure_config) / len(secure_config)) * 100
        
        # Display security metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Environment Vars", f"{security_metrics['environment_variables']:.0f}%")
        with col2:
            st.metric("Input Validation", f"{security_metrics['input_validation']:.0f}%")
        with col3:
            st.metric("Secret Management", f"{security_metrics['secret_management']:.0f}%")
        with col4:
            st.metric("Secure Config", f"{security_metrics['secure_configurations']:.0f}%")
        
        return security_metrics
    
    def _audit_data_handling(self) -> Dict:
        """Audit data handling standards"""
        
        data_metrics = {
            'authentic_data_usage': 0,
            'error_handling': 0,
            'data_validation': 0,
            'caching_strategy': 0
        }
        
        # Check for authentic data usage (no mock data)
        mock_indicators = [
            any('mock' in open(f, 'r').read().lower() for f in os.listdir('.') if f.endswith('.py')),
            any('fake' in open(f, 'r').read().lower() for f in os.listdir('.') if f.endswith('.py')),
            any('dummy' in open(f, 'r').read().lower() for f in os.listdir('.') if f.endswith('.py'))
        ]
        
        # Authentic data usage is high if no mock indicators
        data_metrics['authentic_data_usage'] = 0 if any(mock_indicators) else 100
        
        # Check error handling in data operations
        error_handling = [
            any('try:' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py')),
            any('except' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py')),
            any('raise' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py'))
        ]
        data_metrics['error_handling'] = (sum(error_handling) / len(error_handling)) * 100
        
        # Check data validation
        validation_indicators = [
            any('validate' in open(f, 'r').read().lower() for f in os.listdir('.') if f.endswith('.py')),
            any('isinstance' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py')),
            any('assert' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py'))
        ]
        data_metrics['data_validation'] = (sum(validation_indicators) / len(validation_indicators)) * 100
        
        # Check caching strategy
        data_metrics['caching_strategy'] = 100 if os.path.exists('data_cache') else 0
        
        # Display data handling metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Authentic Data", f"{data_metrics['authentic_data_usage']:.0f}%")
        with col2:
            st.metric("Error Handling", f"{data_metrics['error_handling']:.0f}%")
        with col3:
            st.metric("Data Validation", f"{data_metrics['data_validation']:.0f}%")
        with col4:
            st.metric("Caching Strategy", f"{data_metrics['caching_strategy']:.0f}%")
        
        if data_metrics['authentic_data_usage'] < 100:
            self.violations.append("Mock or dummy data detected in codebase")
            self.recommendations.append("Remove all mock data and use authentic data sources only")
        
        return data_metrics
    
    def _audit_error_handling(self) -> Dict:
        """Audit error handling patterns"""
        
        error_metrics = {
            'exception_coverage': 0,
            'logging_implementation': 0,
            'user_friendly_errors': 0,
            'recovery_mechanisms': 0
        }
        
        python_files = [f for f in os.listdir('.') if f.endswith('.py')]
        
        for file_path in python_files:
            try:
                with open(file_path, 'r') as f:
                    content = f.read()
                
                # Check exception coverage
                has_try_except = 'try:' in content and 'except' in content
                if has_try_except:
                    error_metrics['exception_coverage'] += 1
                
                # Check logging implementation
                has_logging = 'logging' in content or 'logger' in content
                if has_logging:
                    error_metrics['logging_implementation'] += 1
                
                # Check user-friendly errors
                has_user_errors = 'st.error' in content or 'st.warning' in content
                if has_user_errors:
                    error_metrics['user_friendly_errors'] += 1
                
                # Check recovery mechanisms
                has_recovery = 'retry' in content.lower() or 'fallback' in content.lower()
                if has_recovery:
                    error_metrics['recovery_mechanisms'] += 1
                    
            except Exception:
                continue
        
        # Convert to percentages
        total_files = len(python_files)
        for metric in error_metrics:
            error_metrics[metric] = (error_metrics[metric] / total_files) * 100 if total_files > 0 else 0
        
        # Display error handling metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Exception Coverage", f"{error_metrics['exception_coverage']:.0f}%")
        with col2:
            st.metric("Logging", f"{error_metrics['logging_implementation']:.0f}%")
        with col3:
            st.metric("User-Friendly Errors", f"{error_metrics['user_friendly_errors']:.0f}%")
        with col4:
            st.metric("Recovery Mechanisms", f"{error_metrics['recovery_mechanisms']:.0f}%")
        
        return error_metrics
    
    def _audit_documentation(self) -> Dict:
        """Audit documentation standards"""
        
        doc_metrics = {
            'readme_present': 0,
            'code_comments': 0,
            'api_documentation': 0,
            'inline_documentation': 0
        }
        
        # Check for README
        readme_files = ['README.md', 'README.txt', 'README.rst']
        doc_metrics['readme_present'] = 100 if any(os.path.exists(f) for f in readme_files) else 0
        
        # Check code comments
        python_files = [f for f in os.listdir('.') if f.endswith('.py')]
        files_with_comments = 0
        
        for file_path in python_files:
            try:
                with open(file_path, 'r') as f:
                    content = f.read()
                
                comment_lines = len([line for line in content.split('\n') if line.strip().startswith('#')])
                total_lines = len(content.split('\n'))
                
                if comment_lines / total_lines > 0.1:  # At least 10% comments
                    files_with_comments += 1
                    
            except Exception:
                continue
        
        doc_metrics['code_comments'] = (files_with_comments / len(python_files)) * 100 if python_files else 0
        
        # Check API documentation (docstrings)
        files_with_docstrings = sum(1 for f in python_files if '"""' in open(f, 'r').read())
        doc_metrics['api_documentation'] = (files_with_docstrings / len(python_files)) * 100 if python_files else 0
        
        # Check inline documentation
        files_with_inline_docs = sum(1 for f in python_files if '# ' in open(f, 'r').read())
        doc_metrics['inline_documentation'] = (files_with_inline_docs / len(python_files)) * 100 if python_files else 0
        
        # Display documentation metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("README Present", f"{doc_metrics['readme_present']:.0f}%")
        with col2:
            st.metric("Code Comments", f"{doc_metrics['code_comments']:.0f}%")
        with col3:
            st.metric("API Documentation", f"{doc_metrics['api_documentation']:.0f}%")
        with col4:
            st.metric("Inline Documentation", f"{doc_metrics['inline_documentation']:.0f}%")
        
        return doc_metrics
    
    def _audit_testing(self) -> Dict:
        """Audit testing guidelines compliance"""
        
        test_metrics = {
            'test_files_present': 0,
            'test_coverage': 0,
            'unit_tests': 0,
            'integration_tests': 0
        }
        
        # Check for test files
        test_files = [f for f in os.listdir('.') if f.startswith('test_') or f.endswith('_test.py')]
        test_metrics['test_files_present'] = 100 if test_files else 0
        
        # Basic test coverage estimation
        python_files = [f for f in os.listdir('.') if f.endswith('.py') and not f.startswith('test_')]
        test_metrics['test_coverage'] = min(100, len(test_files) / len(python_files) * 100) if python_files else 0
        
        # Check for unit tests
        unit_test_indicators = any('unittest' in open(f, 'r').read() or 'pytest' in open(f, 'r').read() for f in test_files) if test_files else False
        test_metrics['unit_tests'] = 100 if unit_test_indicators else 0
        
        # Check for integration tests
        integration_indicators = any('integration' in f.lower() or 'end_to_end' in f.lower() for f in test_files)
        test_metrics['integration_tests'] = 100 if integration_indicators else 0
        
        # Display testing metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Test Files Present", f"{test_metrics['test_files_present']:.0f}%")
        with col2:
            st.metric("Test Coverage", f"{test_metrics['test_coverage']:.0f}%")
        with col3:
            st.metric("Unit Tests", f"{test_metrics['unit_tests']:.0f}%")
        with col4:
            st.metric("Integration Tests", f"{test_metrics['integration_tests']:.0f}%")
        
        if test_metrics['test_files_present'] == 0:
            self.violations.append("No test files found")
            self.recommendations.append("Implement comprehensive test suite with unit and integration tests")
        
        return test_metrics
    
    def _audit_deployment(self) -> Dict:
        """Audit deployment readiness"""
        
        deploy_metrics = {
            'configuration_management': 0,
            'dependency_specification': 0,
            'environment_setup': 0,
            'production_readiness': 0
        }
        
        # Check configuration management
        config_files = ['.streamlit/config.toml', 'config_manager.py']
        deploy_metrics['configuration_management'] = (sum(os.path.exists(f) for f in config_files) / len(config_files)) * 100
        
        # Check dependency specification
        dep_files = ['pyproject.toml', 'requirements.txt']
        deploy_metrics['dependency_specification'] = 100 if any(os.path.exists(f) for f in dep_files) else 0
        
        # Check environment setup
        env_indicators = [
            os.path.exists('.gitignore'),
            any('os.getenv' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py')),
            os.path.exists('.streamlit/config.toml')
        ]
        deploy_metrics['environment_setup'] = (sum(env_indicators) / len(env_indicators)) * 100
        
        # Check production readiness
        prod_indicators = [
            not any('debug=True' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py')),
            any('logging' in open(f, 'r').read() for f in os.listdir('.') if f.endswith('.py')),
            os.path.exists('data_cache')
        ]
        deploy_metrics['production_readiness'] = (sum(prod_indicators) / len(prod_indicators)) * 100
        
        # Display deployment metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Configuration", f"{deploy_metrics['configuration_management']:.0f}%")
        with col2:
            st.metric("Dependencies", f"{deploy_metrics['dependency_specification']:.0f}%")
        with col3:
            st.metric("Environment", f"{deploy_metrics['environment_setup']:.0f}%")
        with col4:
            st.metric("Production Ready", f"{deploy_metrics['production_readiness']:.0f}%")
        
        return deploy_metrics
    
    def _display_section_summary(self, section_name: str, results: Dict):
        """Display section summary with compliance status"""
        
        if 'error' in results:
            st.error(f"Audit error: {results['error']}")
            return
        
        # Calculate section average
        scores = [v for v in results.values() if isinstance(v, (int, float))]
        avg_score = sum(scores) / len(scores) if scores else 0
        
        if avg_score >= 80:
            status_color = "green"
            status_text = "✅ Compliant"
        elif avg_score >= 60:
            status_color = "orange"
            status_text = "⚠️ Needs Improvement"
        else:
            status_color = "red"
            status_text = "❌ Non-Compliant"
        
        st.markdown(f"""
        <div style="background: {status_color}; color: white; padding: 0.5rem; border-radius: 0.25rem; margin: 0.5rem 0;">
            <strong>{section_name}: {avg_score:.0f}% - {status_text}</strong>
        </div>
        """, unsafe_allow_html=True)
    
    def _calculate_compliance_score(self) -> float:
        """Calculate overall compliance score"""
        
        all_scores = []
        
        for section_results in self.audit_results.values():
            if isinstance(section_results, dict) and 'error' not in section_results:
                scores = [v for v in section_results.values() if isinstance(v, (int, float))]
                if scores:
                    all_scores.extend(scores)
        
        return sum(all_scores) / len(all_scores) if all_scores else 0
    
    def _display_compliance_dashboard(self):
        """Display comprehensive compliance dashboard"""
        
        st.markdown("---")
        st.subheader("📊 Compliance Dashboard")
        
        # Overall compliance score
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            if self.compliance_score >= 80:
                score_color = "green"
                score_status = "Excellent"
            elif self.compliance_score >= 60:
                score_color = "orange"
                score_status = "Good"
            else:
                score_color = "red"
                score_status = "Needs Work"
            
            st.markdown(f"""
            <div style="background: {score_color}; color: white; padding: 1rem; border-radius: 0.5rem; text-align: center;">
                <h3>Overall Compliance</h3>
                <h1>{self.compliance_score:.0f}%</h1>
                <p>{score_status}</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.metric("Total Violations", len(self.violations))
        
        with col3:
            st.metric("Recommendations", len(self.recommendations))
        
        with col4:
            sections_audited = len([r for r in self.audit_results.values() if 'error' not in r])
            st.metric("Sections Audited", sections_audited)
        
        # Violations and recommendations
        if self.violations:
            st.error("🚨 Compliance Violations")
            for violation in self.violations:
                st.write(f"• {violation}")
        
        if self.recommendations:
            st.info("💡 Improvement Recommendations")
            for recommendation in self.recommendations:
                st.write(f"• {recommendation}")
        
        # Compliance trends chart
        section_scores = {}
        for section, results in self.audit_results.items():
            if isinstance(results, dict) and 'error' not in results:
                scores = [v for v in results.values() if isinstance(v, (int, float))]
                section_scores[section] = sum(scores) / len(scores) if scores else 0
        
        if section_scores:
            fig = go.Figure()
            fig.add_trace(go.Bar(
                x=list(section_scores.keys()),
                y=list(section_scores.values()),
                marker_color=['green' if score >= 80 else 'orange' if score >= 60 else 'red' for score in section_scores.values()]
            ))
            
            fig.update_layout(
                title="Compliance Scores by Section",
                xaxis_title="Audit Sections",
                yaxis_title="Compliance Score (%)",
                height=400
            )
            
            st.plotly_chart(fig, use_container_width=True)

def main():
    """Run development compliance audit"""
    st.set_page_config(
        page_title="Development Compliance Audit",
        page_icon="📋",
        layout="wide"
    )
    
    auditor = DevelopmentComplianceAuditor()
    results = auditor.run_compliance_audit()
    
    # Export results
    if st.sidebar.button("📊 Export Compliance Report"):
        report_data = json.dumps(results, indent=2, default=str)
        st.sidebar.download_button(
            label="Download Report",
            data=report_data,
            file_name=f"compliance_audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            mime="application/json"
        )

if __name__ == "__main__":
    main()