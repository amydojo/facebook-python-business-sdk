"""
Unit tests for reliable data connector
"""

import pytest
import unittest.mock as mock
from reliable_data_connector import ReliableDataConnector

class TestReliableDataConnector:
    """Test suite for ReliableDataConnector"""
    
    @pytest.fixture
    def connector(self):
        """Create test connector instance"""
        return ReliableDataConnector()
    
    def test_initialization(self, connector):
        """Test connector initialization"""
        assert connector is not None
        assert hasattr(connector, 'config')
        assert hasattr(connector, 'cache_dir')
    
    @mock.patch('reliable_data_connector.Api')
    def test_load_transaction_data_success(self, mock_api, connector):
        """Test successful transaction data loading"""
        # Mock API response
        mock_table = mock_api.return_value.table.return_value
        mock_table.all.return_value = [
            {
                'id': 'test_id',
                'fields': {
                    'Date': '2025-01-01',
                    'Amount': 100.0,
                    'Brand': 'Smooth MD',
                    'Source': 'Meta'
                }
            }
        ]
        
        result = connector.load_transaction_data('2025-01-01', '2025-01-31')
        
        assert result['success'] is True
        assert len(result['transactions']) > 0
    
    def test_cache_key_generation(self, connector):
        """Test cache key generation"""
        params = {'start_date': '2025-01-01', 'end_date': '2025-01-31'}
        key = connector._get_cache_key('test_operation', params)
        
        assert isinstance(key, str)
        assert len(key) == 32  # MD5 hash length
    
    def test_validation_rules(self, connector):
        """Test data validation rules"""
        assert 'min_transaction_amount' in connector.validation_rules
        assert 'required_fields' in connector.validation_rules
        assert 'transaction' in connector.validation_rules['required_fields']
