# MetaPulse Command Center

Enterprise-grade marketing analytics platform with advanced Meta attribution tracking and comprehensive performance monitoring.

## Features

- **Real-time Meta Attribution**: Advanced tracking of Meta ad performance with accurate revenue attribution
- **Comprehensive Analytics**: Deep insights into campaign performance, lead quality, and ROI
- **Enterprise Security**: Advanced error handling, circuit breakers, and secure configuration management
- **Performance Optimization**: Intelligent caching, retry mechanisms, and response time optimization
- **Quality Assurance**: Comprehensive audit systems and compliance monitoring

## Architecture

### Core Components

- **Data Connector (`reliable_data_connector.py`)**: Robust data integration with Airtable and Meta APIs
- **Configuration Manager (`config_manager.py`)**: Centralized configuration with environment variable management
- **Error Recovery (`enhanced_error_recovery.py`)**: Advanced error handling with circuit breakers
- **Quality Control (`production_quality_control.py`)**: Real-time system monitoring and compliance

### Dashboards

- **Main Dashboard (Port 5000)**: Primary analytics interface
- **Advanced Audit (Port 5001)**: System diagnostics and performance monitoring
- **Meta Lead Validation (Port 5002)**: Lead quality analysis and validation
- **Quality Audit (Port 5003)**: Comprehensive system inspection
- **Production Quality Control (Port 5004)**: Real-time monitoring
- **Compliance Audit (Port 5005)**: Development guideline adherence

## Setup

### Prerequisites

- Python 3.11+
- Access to Meta Marketing API
- Airtable account with configured base

### Environment Variables

```bash
AIRTABLE_API_KEY=your_airtable_api_key
META_ACCESS_TOKEN=your_meta_access_token
META_AD_ACCOUNT_ID=your_ad_account_id
META_PIXEL_ID=your_pixel_id
```

### Installation

```bash
# Install dependencies
pip install -r requirements.txt

# Run main dashboard
streamlit run app.py
```

## Security

- All sensitive data is managed through environment variables
- Comprehensive input validation and error handling
- Circuit breaker patterns for API resilience
- Regular security audits and compliance monitoring

## Performance

- Advanced caching with TTL management
- Retry mechanisms with exponential backoff
- Real-time performance monitoring
- Automated optimization recommendations

## Quality Assurance

- Comprehensive test coverage
- Real-time system health monitoring
- Automated compliance auditing
- Performance benchmarking

## Support

For technical support or questions, refer to the system monitoring dashboards for real-time status and diagnostic information.
