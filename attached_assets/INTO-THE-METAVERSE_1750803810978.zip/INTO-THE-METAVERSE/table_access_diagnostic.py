#!/usr/bin/env python3
"""
Table Access Diagnostic Tool
Identifies accessible tables in the Airtable base and validates API credentials
"""

import os
from pyairtable import Api
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def diagnose_table_access():
    """Comprehensive table access diagnostic"""
    
    # Get credentials
    api_key = os.getenv('AIRTABLE_API_KEY')
    base_id = os.getenv('AIRTABLE_BASE_ID')
    
    print("=== AIRTABLE ACCESS DIAGNOSTIC ===")
    print(f"API Key present: {'Yes' if api_key else 'No'}")
    print(f"Base ID present: {'Yes' if base_id else 'No'}")
    
    if not api_key or not base_id:
        print("ERROR: Missing API credentials")
        return
    
    print(f"Base ID: {base_id}")
    print(f"API Key: {api_key[:10]}...")
    
    # Initialize API
    try:
        api = Api(api_key)
        print("✓ API initialized successfully")
    except Exception as e:
        print(f"✗ API initialization failed: {e}")
        return
    
    # Test common table names
    table_candidates = [
        'Transactions',
        'Social Media',
        'Sales',
        'Revenue',
        'Leads',
        'Lead',
        'Prospects',
        'Customers',
        'Contacts'
    ]
    
    accessible_tables = {}
    
    print("\n=== TESTING TABLE ACCESS ===")
    
    for table_name in table_candidates:
        try:
            table = api.table(base_id, table_name)
            test_records = table.all(max_records=1)
            
            field_names = []
            if test_records:
                field_names = list(test_records[0]['fields'].keys())
            
            accessible_tables[table_name] = {
                'accessible': True,
                'record_count': len(test_records),
                'sample_fields': field_names[:10]  # First 10 fields
            }
            
            print(f"✓ {table_name}: {len(test_records)} records, {len(field_names)} fields")
            
        except Exception as e:
            print(f"✗ {table_name}: {str(e)}")
            accessible_tables[table_name] = {
                'accessible': False,
                'error': str(e)
            }
    
    print("\n=== ACCESSIBLE TABLES SUMMARY ===")
    
    successful_tables = [name for name, info in accessible_tables.items() if info['accessible']]
    
    if successful_tables:
        print(f"Found {len(successful_tables)} accessible tables:")
        
        for table_name in successful_tables:
            info = accessible_tables[table_name]
            print(f"\n** {table_name} **")
            print(f"   Records found: {info['record_count']}")
            print(f"   Sample fields: {', '.join(info['sample_fields'][:5])}")
            
            # Categorize table by field patterns
            fields = [f.lower() for f in info['sample_fields']]
            
            if any(keyword in ' '.join(fields) for keyword in ['amount', 'revenue', 'payment', 'transaction']):
                print(f"   → LIKELY TRANSACTION TABLE")
            elif any(keyword in ' '.join(fields) for keyword in ['email', 'phone', 'lead', 'contact']):
                print(f"   → LIKELY LEADS TABLE")
            else:
                print(f"   → PURPOSE UNCLEAR")
    else:
        print("ERROR: No accessible tables found!")
        print("Possible issues:")
        print("- API key lacks permissions")
        print("- Base ID is incorrect")
        print("- Table names don't match expected patterns")
    
    return accessible_tables

if __name__ == "__main__":
    diagnose_table_access()