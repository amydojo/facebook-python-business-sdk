"""
Dashboard module for CAPI Command Center
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import time

# Utility functions for metrics calculation
def safe_metric_value(value):
    """Ensures metric values are properly formatted and never None"""
    if pd.isna(value) or value is None:
        return 0
    try:
        return float(value)
    except (ValueError, TypeError):
        return 0

def filter_smooth_md_data(df):
    """Filter data to only include Smooth M.D. brand"""
    if df is None or df.empty:
        return pd.DataFrame()
    
    # Create a copy to avoid modifying the original
    result_df = df.copy()
    
    # If Brand column exists, filter by it
    if 'Brand' in df.columns:
        # Convert to lowercase strings for consistent comparison
        brands = df['Brand'].fillna('').astype(str).str.lower()
        
        # Create a mask for Smooth MD with multiple potential variations
        mask = (
            (brands == 'smooth m.d.') | 
            (brands == 'smooth md') | 
            (brands == 'smoothmd') | 
            brands.str.contains('smooth', na=False)
        )
        
        result_df = df[mask]
    
    # Debug output to verify filter results
    print(f"Smooth MD filter: Found {len(result_df)} records from {len(df)} total")
    
    return result_df

def filter_meta_source_data(df):
    """Filter data to only include Meta (Facebook/Instagram) ad sources"""
    if df is None or df.empty:
        return pd.DataFrame()
    
    # Focusing specifically on Facebook and Instagram as requested
    meta_sources = ['facebook', 'instagram', 'fb', 'ig', 'meta']
    result_df = pd.DataFrame()
    
    # Check both Source and Contact Source columns
    if 'Source' in df.columns:
        source_mask = df['Source'].astype(str).str.lower().apply(
            lambda x: any(source in x for source in meta_sources)
        )
        result_df = df[source_mask]
    
    # If we still don't have results, try Contact Source column
    if result_df.empty and 'Contact Source' in df.columns:
        contact_mask = df['Contact Source'].astype(str).str.lower().apply(
            lambda x: any(source in x for source in meta_sources)
        )
        result_df = df[contact_mask]
    
    # Debug output to verify filter results
    print(f"Meta source filter: Found {len(result_df)} records from {len(df)} total")
    
    return result_df

def filter_smooth_md_services(df):
    """Filter transactions to only include Smooth M.D. specific services"""
    if df is None or df.empty or 'Service' not in df.columns:
        return pd.DataFrame()
    
    # Define Smooth M.D. services (case-insensitive)
    smooth_md_services = [
        'laser hair removal', 'lhr', 
        'botox', 'filler', 'dermal filler',
        'facial', 'hydrafacial', 'microneedling',
        'cool sculpting', 'coolsculpting', 'skin tightening',
        'prp', 'peptide', 'weight loss', 'iv therapy'
    ]
    
    # Create mask for any service containing a Smooth M.D. service name
    mask = df['Service'].astype(str).str.lower().apply(
        lambda x: any(service in x for service in smooth_md_services)
    )
    
    return df[mask]
    
def filter_current_month_data(df, date_column='Date'):
    """Filter data to only include entries from the current month"""
    if df is None or df.empty or date_column not in df.columns:
        return pd.DataFrame()
    
    # Ensure date column is datetime
    if not pd.api.types.is_datetime64_any_dtype(df[date_column]):
        df[date_column] = pd.to_datetime(df[date_column], errors='coerce')
    
    # Get current month and year
    now = datetime.now()
    current_month = now.month
    current_year = now.year
    
    # Filter for current month
    return df[(df[date_column].dt.month == current_month) & 
              (df[date_column].dt.year == current_year)]

def create_date_filter(df, date_col='Date', default_days=30):
    """Create date filter for dataframe"""
    if df is None or df.empty or date_col not in df.columns:
        return pd.DataFrame()
        
    # Ensure date column is datetime
    if not pd.api.types.is_datetime64_any_dtype(df[date_col]):
        df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
    
    # Get min and max dates    
    min_date = df[date_col].min()
    max_date = df[date_col].max()
    
    if pd.isna(min_date) or pd.isna(max_date):
        return df
    
    # Default to last 30 days
    default_start = max_date - timedelta(days=default_days)
    default_start = max(default_start, min_date)
    
    # Create date filters in sidebar
    with st.sidebar:
        st.write("### Date Filters")
        date_filter_type = st.radio(
            "Select date range",
            ["Last 30 days", "Last 7 days", "Last 90 days", "All time", "Custom range"]
        )
        
        if date_filter_type == "Custom range":
            start_date = st.date_input("Start date", value=default_start)
            end_date = st.date_input("End date", value=max_date)
            
            start_date = pd.Timestamp(start_date)
            end_date = pd.Timestamp(end_date) + timedelta(days=1) - timedelta(seconds=1)
        else:
            end_date = max_date
            if date_filter_type == "Last 7 days":
                start_date = end_date - timedelta(days=7)
            elif date_filter_type == "Last 30 days":
                start_date = end_date - timedelta(days=30)
            elif date_filter_type == "Last 90 days":
                start_date = end_date - timedelta(days=90)
            else:  # All time
                start_date = min_date
    
    # Filter data by date range
    return df[(df[date_col] >= start_date) & (df[date_col] <= end_date)]

def count_leads_by_status(df, status_column, target_values):
    """Count leads by status"""
    if df is None or df.empty or status_column not in df.columns:
        return 0
        
    # Convert all values to lowercase for case-insensitive matching
    count = 0
    
    for idx, row in df.iterrows():
        status_value = row[status_column]
        
        # Handle lists
        if isinstance(status_value, list):
            status_values = [str(x).lower() for x in status_value if x is not None]
            if any(target in ' '.join(status_values) for target in target_values):
                count += 1
        # Handle strings
        elif isinstance(status_value, str):
            if any(target in status_value.lower() for target in target_values):
                count += 1
                
    return count

# Dashboard metrics functions
def calculate_core_metrics(leads_df, transactions_df, ad_spend=0.0):
    """Calculate core metrics for dashboard"""
    metrics = {}
    
    # Print column names to help with debugging
    if leads_df is not None and not leads_df.empty:
        print("Leads DataFrame Columns:", leads_df.columns)
    
    if transactions_df is not None and not transactions_df.empty:
        print("Transactions DataFrame Columns:", transactions_df.columns)
    
    # Apply all necessary filters
    # 1. First filter for Smooth M.D. brand
    smooth_leads_df = filter_smooth_md_data(leads_df)
    
    # 2. Then filter for Meta sources within Smooth M.D. data
    meta_leads_df = filter_meta_source_data(smooth_leads_df)
    
    # 3. Filter transactions to only include Smooth M.D. brand and services
    if transactions_df is not None and not transactions_df.empty:
        smooth_transactions_df = filter_smooth_md_data(transactions_df)
        smooth_transactions_df = filter_smooth_md_services(smooth_transactions_df)
    else:
        smooth_transactions_df = pd.DataFrame()
    
    # Store filtered dataframes for other dashboard functions
    if 'filtered_meta_leads' not in st.session_state:
        st.session_state.filtered_meta_leads = meta_leads_df
    
    if 'filtered_transactions' not in st.session_state:
        st.session_state.filtered_transactions = smooth_transactions_df
    
    # Total Meta Leads (all time)
    total_leads = len(meta_leads_df) if not meta_leads_df.empty else 0
    metrics['Total Leads'] = total_leads
    
    # Total Meta Leads (current month only)
    current_month_leads_df = filter_current_month_data(meta_leads_df, 'Date')
    current_month_leads = len(current_month_leads_df) if not current_month_leads_df.empty else 0
    metrics['Current Month Leads'] = current_month_leads
    
    # Booked Meta leads - where 'Consult Status' = 'Scheduled'
    booked_leads = count_leads_by_status(meta_leads_df, 'Consult Status', ['scheduled'])
    metrics['Booked Leads'] = booked_leads
    
    # Booked percentage
    booked_percentage = (booked_leads / total_leads * 100) if total_leads > 0 else 0
    metrics['Booked %'] = booked_percentage
    
    # Converted Meta leads - where 'Closed' is not empty
    converted_leads = 0
    if not meta_leads_df.empty and 'Closed' in meta_leads_df.columns:
        converted_leads = meta_leads_df['Closed'].notna().sum()
        
        # Additional check for converted status 
        # Some leads might have 'Closed' date but weren't actually converted
        if 'Overall Status' in meta_leads_df.columns:
            converted_status = meta_leads_df[
                (meta_leads_df['Closed'].notna()) & 
                (meta_leads_df['Overall Status'].astype(str).str.lower().str.contains('converted|closed', na=False))
            ]
            if not converted_status.empty:
                converted_leads = len(converted_status)
    
    metrics['Converted Leads'] = converted_leads
    
    # Conversion percentage
    conversion_percentage = (converted_leads / total_leads * 100) if total_leads > 0 else 0
    metrics['Conversion %'] = conversion_percentage
    
    # Abandoned leads - where 'Overall Status' includes specific values
    abandoned_status_values = ['cancelled', 'dnc', 'no longer interested', 'needs to be rescheduled', 'no show']
    abandoned_leads = count_leads_by_status(meta_leads_df, 'Overall Status', abandoned_status_values)
    metrics['Abandoned Leads'] = abandoned_leads
    
    # Abandoned percentage
    abandoned_percentage = (abandoned_leads / total_leads * 100) if total_leads > 0 else 0
    metrics['Abandoned %'] = abandoned_percentage
    
    # Link transactions to Meta leads
    meta_transactions_df = pd.DataFrame()
    
    if not meta_leads_df.empty and not smooth_transactions_df.empty:
        # Try to match transactions with leads
        # First check if there's a direct Lead_ID reference
        if 'Lead_ID' in smooth_transactions_df.columns and 'record_id' in meta_leads_df.columns:
            meta_transactions_df = smooth_transactions_df[
                smooth_transactions_df['Lead_ID'].isin(meta_leads_df['record_id'])
            ]
        
        # If no transactions found by ID, try email matching
        if meta_transactions_df.empty and 'Email' in meta_leads_df.columns and 'Email' in smooth_transactions_df.columns:
            meta_leads_emails = meta_leads_df['Email'].dropna().str.lower().tolist()
            meta_transactions_df = smooth_transactions_df[
                smooth_transactions_df['Email'].astype(str).str.lower().isin(meta_leads_emails)
            ]
            
        # If still no transactions, try phone matching
        if meta_transactions_df.empty and 'Phone' in meta_leads_df.columns and 'Phone' in smooth_transactions_df.columns:
            # Clean phone numbers
            meta_leads_phones = meta_leads_df['Phone'].astype(str).apply(
                lambda x: ''.join(filter(str.isdigit, x))
            ).dropna().tolist()
            
            # Filter transactions by cleaned phone
            meta_transactions_df = smooth_transactions_df[
                smooth_transactions_df['Phone'].astype(str).apply(
                    lambda x: ''.join(filter(str.isdigit, x))
                ).isin(meta_leads_phones)
            ]
    
    # Total Revenue from Meta leads
    total_revenue = 0
    if not meta_transactions_df.empty and 'Amount' in meta_transactions_df.columns:
        # Convert Amount to numeric, handling any non-numeric values
        meta_transactions_df['Amount'] = pd.to_numeric(meta_transactions_df['Amount'], errors='coerce').fillna(0)
        total_revenue = meta_transactions_df['Amount'].sum()
        
        # Store for other dashboard functions
        st.session_state.meta_transactions = meta_transactions_df
    
    metrics['Total Revenue'] = total_revenue
    
    # Revenue per Lead (RPL)
    rpl = total_revenue / total_leads if total_leads > 0 else 0
    metrics['Revenue per Lead'] = rpl
    
    # Revenue per Booked Lead
    revenue_per_booked = total_revenue / booked_leads if booked_leads > 0 else 0
    metrics['Revenue per Booked Lead'] = revenue_per_booked
    
    # Revenue per Converted Lead
    revenue_per_converted = total_revenue / converted_leads if converted_leads > 0 else 0
    metrics['Revenue per Converted Lead'] = revenue_per_converted
    
    # ROAS (Return on Ad Spend)
    roas = total_revenue / ad_spend if ad_spend > 0 else 0
    metrics['ROAS'] = roas
    
    # Calculate CAC (Customer Acquisition Cost)
    cac = ad_spend / converted_leads if converted_leads > 0 else 0
    metrics['CAC'] = cac
    
    # Calculate CLV (Customer Lifetime Value)
    # For simplicity, using avg revenue per converted lead as a proxy
    metrics['CLV'] = revenue_per_converted
    
    # Calculate CLV:CAC ratio (important marketing efficiency metric)
    clv_cac_ratio = revenue_per_converted / cac if cac > 0 else 0
    metrics['CLV:CAC Ratio'] = clv_cac_ratio
    
    return metrics

def calculate_strategic_metrics(leads_df, transactions_df, previous_leads_df=None, ad_spend=5000):
    """Calculate strategic marketing science metrics with advanced insights"""
    metrics = {}
    insights = []
    
    # Use filtered data if available in session state
    if 'filtered_meta_leads' in st.session_state and not st.session_state.filtered_meta_leads.empty:
        meta_leads_df = st.session_state.filtered_meta_leads
    else:
        # Apply all necessary filters
        smooth_leads_df = filter_smooth_md_data(leads_df)
        meta_leads_df = filter_meta_source_data(smooth_leads_df)
    
    # Use filtered transaction data if available
    if 'meta_transactions' in st.session_state and not st.session_state.meta_transactions.empty:
        meta_transactions_df = st.session_state.meta_transactions
    elif 'filtered_transactions' in st.session_state and not st.session_state.filtered_transactions.empty:
        transactions_df = st.session_state.filtered_transactions
        meta_transactions_df = transactions_df  # Already filtered in core metrics
    else:
        if transactions_df is not None and not transactions_df.empty:
            smooth_transactions_df = filter_smooth_md_data(transactions_df)
            meta_transactions_df = filter_smooth_md_services(smooth_transactions_df)
        else:
            meta_transactions_df = pd.DataFrame()
    
    # Filter previous leads data if provided
    if previous_leads_df is not None:
        smooth_prev_leads_df = filter_smooth_md_data(previous_leads_df)
        prev_meta_leads_df = filter_meta_source_data(smooth_prev_leads_df)
    else:
        # If no previous data provided, calculate from current dataset using date filtering
        prev_meta_leads_df = pd.DataFrame()
        if not meta_leads_df.empty and 'Date' in meta_leads_df.columns:
            # Convert to datetime if needed
            if meta_leads_df['Date'].dtype != 'datetime64[ns]':
                meta_leads_df['Date'] = pd.to_datetime(meta_leads_df['Date'], errors='coerce')
            
            # Get today and 30 days ago
            today = datetime.now()
            one_month_ago = today - timedelta(days=30)
            two_months_ago = today - timedelta(days=60)
            
            # Filter for previous period (30-60 days ago)
            prev_meta_leads_df = meta_leads_df[
                (meta_leads_df['Date'] >= two_months_ago) & 
                (meta_leads_df['Date'] < one_month_ago)
            ]

    # 1. LEAD ACQUISITION METRICS
    # --- Lead Velocity Rate (LVR) ---
    current_period_leads = len(meta_leads_df) if not meta_leads_df.empty else 0
    previous_period_leads = len(prev_meta_leads_df) if not prev_meta_leads_df.empty else 0
    
    lvr = 0
    if previous_period_leads > 0:
        lvr = (current_period_leads - previous_period_leads) / previous_period_leads * 100
    metrics['Lead Velocity Rate'] = lvr
    
    # Add insight for LVR
    if lvr > 20:
        insights.append("✅ Strong lead growth rate of {:.1f}% indicates effective Meta campaigns".format(lvr))
    elif lvr > 0:
        insights.append("✅ Positive lead velocity rate of {:.1f}% - continue scaling successful campaigns".format(lvr))
    elif lvr < 0:
        insights.append("⚠️ Negative lead velocity rate of {:.1f}% - review ad creative and targeting".format(lvr))
    
    # 2. CONVERSION METRICS
    # --- Speed to Value (STV) - Average time from Date to Closed ---
    stv = 0
    if not meta_leads_df.empty and 'Date' in meta_leads_df.columns and 'Closed' in meta_leads_df.columns:
        # Get only leads that have been closed
        closed_leads = meta_leads_df[meta_leads_df['Closed'].notna()]
        
        if not closed_leads.empty:
            # Convert dates to datetime if needed
            if closed_leads['Date'].dtype != 'datetime64[ns]':
                closed_leads['Date'] = pd.to_datetime(closed_leads['Date'], errors='coerce')
            if closed_leads['Closed'].dtype != 'datetime64[ns]':
                closed_leads['Closed'] = pd.to_datetime(closed_leads['Closed'], errors='coerce')
            
            # Filter out invalid date pairs
            valid_dates = closed_leads[closed_leads['Date'].notna() & closed_leads['Closed'].notna()]
            
            if not valid_dates.empty:
                # Calculate time difference in days
                valid_dates['Days_to_Close'] = (valid_dates['Closed'] - valid_dates['Date']).dt.total_seconds() / (60*60*24)
                
                # Remove negative or extreme values
                valid_dates = valid_dates[(valid_dates['Days_to_Close'] >= 0) & (valid_dates['Days_to_Close'] <= 180)]
                
                if not valid_dates.empty:
                    # Calculate average time to close
                    stv = valid_dates['Days_to_Close'].mean()
    
    metrics['Speed to Value (days)'] = stv
    
    # Add insight for STV
    if 0 < stv <= 14:
        insights.append("✅ Excellent speed-to-value of {:.1f} days from lead to conversion".format(stv))
    elif 14 < stv <= 30:
        insights.append("✅ Good speed-to-value of {:.1f} days - further optimization possible".format(stv))
    elif stv > 30:
        insights.append("⚠️ Slow conversion cycle of {:.1f} days - review lead nurturing process".format(stv))
    
    # --- High-Intent Lead % - Leads who booked within 48 hours of Date ---
    high_intent_percent = 0
    high_intent_leads = 0
    total_booked = 0
    
    if not meta_leads_df.empty:
        # Check if required columns exist
        if all(col in meta_leads_df.columns for col in ['Date', 'Consult Status']):
            # Handle case where column might be missing
            consult_status_col = meta_leads_df['Consult Status']
            if not isinstance(consult_status_col, pd.Series):
                consult_status_col = pd.Series([''] * len(meta_leads_df))
            
            # Get booked leads (case-insensitive match)
            booked_leads = meta_leads_df[consult_status_col.astype(str).str.lower() == 'scheduled']
            
            if not booked_leads.empty and 'Consult Date' in booked_leads.columns:
                # Convert dates to datetime if needed
                if booked_leads['Date'].dtype != 'datetime64[ns]':
                    booked_leads['Date'] = pd.to_datetime(booked_leads['Date'], errors='coerce')
                if booked_leads['Consult Date'].dtype != 'datetime64[ns]':
                    booked_leads['Consult Date'] = pd.to_datetime(booked_leads['Consult Date'], errors='coerce')
                
                # Filter out invalid date pairs
                valid_dates = booked_leads[booked_leads['Date'].notna() & booked_leads['Consult Date'].notna()]
                
                if not valid_dates.empty:
                    # Calculate days to book
                    valid_dates['Days_to_Book'] = (valid_dates['Consult Date'] - valid_dates['Date']).dt.total_seconds() / (60*60*24)
                    
                    # Remove negative or extreme values
                    valid_dates = valid_dates[(valid_dates['Days_to_Book'] >= 0) & (valid_dates['Days_to_Book'] <= 30)]
                    
                    if not valid_dates.empty:
                        # Count high-intent leads (booked within 48 hours)
                        high_intent_leads = len(valid_dates[valid_dates['Days_to_Book'] <= 2])
                        total_booked = len(valid_dates)
                        
                        # Calculate percentage
                        if total_booked > 0:
                            high_intent_percent = (high_intent_leads / total_booked) * 100
    
    metrics['High-Intent Lead %'] = high_intent_percent
    metrics['High-Intent Leads'] = high_intent_leads
    metrics['Total Booked'] = total_booked
    
    # Add insight for high-intent leads
    if high_intent_percent >= 50:
        insights.append("✅ {:.1f}% high-intent leads (booking within 48hrs) indicates strong ad-to-offer alignment".format(high_intent_percent))
    elif high_intent_percent >= 25:
        insights.append("✅ {:.1f}% high-intent leads - good ad relevance and landing page effectiveness".format(high_intent_percent))
    elif high_intent_percent > 0:
        insights.append("⚠️ Only {:.1f}% high-intent leads - consider improving ad targeting specificity".format(high_intent_percent))
    
    # --- Silent Drop-Off Rate - Booked leads who became "No Show", "DNC", or "Cancelled" ---
    sdr = 0
    drop_offs = 0
    
    if not meta_leads_df.empty:
        # Handle case where column might be missing
        if 'Consult Status' in meta_leads_df.columns:
            consult_status_col = meta_leads_df['Consult Status']
            if not isinstance(consult_status_col, pd.Series):
                consult_status_col = pd.Series([''] * len(meta_leads_df))
            
            # Get booked leads (case-insensitive match)
            booked_leads = meta_leads_df[consult_status_col.astype(str).str.lower() == 'scheduled']
            
            if not booked_leads.empty and 'Overall Status' in booked_leads.columns:
                # Count drop-offs with expanded status list
                drop_off_statuses = ['no show', 'dnc', 'cancelled', 'no longer interested', 'needs to be rescheduled']
                drop_offs = count_leads_by_status(booked_leads, 'Overall Status', drop_off_statuses)
                
                # Calculate rate
                total_booked = len(booked_leads)
                if total_booked > 0:
                    sdr = (drop_offs / total_booked) * 100
    
    metrics['Silent Drop-Off Rate'] = sdr
    metrics['Drop-Offs'] = drop_offs
    
    # Add insight for silent drop-off rate
    if sdr <= 15:
        insights.append("✅ Low silent drop-off rate of {:.1f}% indicates effective lead nurturing".format(sdr))
    elif sdr <= 30:
        insights.append("⚠️ Moderate drop-off rate of {:.1f}% - implement reminder sequences".format(sdr))
    elif sdr > 30:
        insights.append("⚠️ High drop-off rate of {:.1f}% - review consultation booking process urgently".format(sdr))
    
    # --- CAC and CLV Metrics ---
    # Calculate Customer Acquisition Cost (CAC)
    converted_leads = 0
    if not meta_leads_df.empty and 'Closed' in meta_leads_df.columns:
        converted_mask = meta_leads_df['Closed'].notna()
        if 'Overall Status' in meta_leads_df.columns:
            converted_mask = converted_mask & (
                meta_leads_df['Overall Status'].astype(str).str.lower().str.contains('converted|closed', na=False)
            )
        converted_leads = converted_mask.sum()
    
    # Calculate CAC
    cac = ad_spend / converted_leads if converted_leads > 0 else 0
    metrics['CAC'] = cac
    
    # Calculate revenue metrics
    total_revenue = 0
    if not meta_transactions_df.empty and 'Amount' in meta_transactions_df.columns:
        meta_transactions_df['Amount'] = pd.to_numeric(meta_transactions_df['Amount'], errors='coerce').fillna(0)
        total_revenue = meta_transactions_df['Amount'].sum()
    
    # Calculate Customer Lifetime Value (CLV)
    clv = 0
    avg_purchase_value = 0
    repeat_purchase_rate = 0
    
    if not meta_transactions_df.empty and total_revenue > 0:
        # Calculate average purchase value
        avg_purchase_value = total_revenue / len(meta_transactions_df)
        
        # Calculate repeat purchase rate if customer identifier exists
        if 'Email' in meta_transactions_df.columns:
            # Count customers with more than one purchase
            purchase_counts = meta_transactions_df.groupby('Email').size()
            repeat_customers = (purchase_counts > 1).sum()
            total_customers = len(purchase_counts)
            repeat_purchase_rate = repeat_customers / total_customers if total_customers > 0 else 0
            
            # Estimate average purchases per customer
            avg_purchases_per_customer = purchase_counts.mean() if not purchase_counts.empty else 1
            
            # Calculate basic CLV
            clv = avg_purchase_value * avg_purchases_per_customer
        else:
            # If no customer identifier, use a conservative multiplier
            clv = avg_purchase_value * 1.5
    else:
        # If no transaction data, estimate from industry averages
        # For aesthetic services, average client has 3-4 treatments
        if converted_leads > 0 and cac > 0:
            estimated_avg_value = cac * 2.5  # Conservative estimate based on industry margins
            clv = estimated_avg_value * 3  # Assume 3 purchases per customer
    
    metrics['CLV'] = clv
    metrics['Repeat Purchase Rate'] = repeat_purchase_rate * 100
    
    # Calculate CLV:CAC ratio
    clv_cac_ratio = clv / cac if cac > 0 else 0
    metrics['CLV:CAC Ratio'] = clv_cac_ratio
    
    # Add insight for CLV:CAC
    if clv_cac_ratio >= 3:
        insights.append("✅ Strong CLV:CAC ratio of {:.1f}:1 indicates excellent marketing efficiency".format(clv_cac_ratio))
    elif clv_cac_ratio >= 1:
        insights.append("✅ Positive CLV:CAC ratio of {:.1f}:1 - focus on improving retention".format(clv_cac_ratio))
    elif clv_cac_ratio > 0:
        insights.append("⚠️ Concerning CLV:CAC ratio of {:.1f}:1 - review pricing and lead quality".format(clv_cac_ratio))
    
    # --- Revenue Consistency Score (RCS) ---
    rcs = 0
    if not meta_transactions_df.empty:
        if 'Transaction_Date' in meta_transactions_df.columns and 'Amount' in meta_transactions_df.columns:
            # Convert to datetime if needed
            if meta_transactions_df['Transaction_Date'].dtype != 'datetime64[ns]':
                meta_transactions_df['Transaction_Date'] = pd.to_datetime(meta_transactions_df['Transaction_Date'], errors='coerce')
            
            # Group by date and sum revenue
            valid_transactions = meta_transactions_df[meta_transactions_df['Transaction_Date'].notna()]
            
            if not valid_transactions.empty:
                daily_revenue = valid_transactions.groupby(valid_transactions['Transaction_Date'].dt.date)['Amount'].sum()
                
                # Calculate coefficient of variation (lower is more consistent)
                if len(daily_revenue) > 1:
                    std_dev = daily_revenue.std()
                    mean = daily_revenue.mean()
                    if mean > 0:
                        rcs = 1 - min(1, (std_dev / mean) / 2)  # Normalize to 0-1 where higher is better
    
    metrics['Revenue Consistency Score'] = rcs
    
    # Add insight for revenue consistency
    if rcs >= 0.7:
        insights.append("✅ Strong revenue consistency score of {:.2f} indicates reliable cash flow".format(rcs))
    elif rcs >= 0.5:
        insights.append("✅ Moderate revenue consistency of {:.2f} - some day-to-day variability".format(rcs))
    elif rcs > 0:
        insights.append("⚠️ Low revenue consistency score of {:.2f} - revenue stream is unpredictable".format(rcs))
    
    # --- Ad Channel Diversity Score ---
    # Calculate how diverse the sources are within Meta
    channel_diversity = 0
    if not meta_leads_df.empty and 'Contact Source' in meta_leads_df.columns:
        # Count unique sources and their distribution
        source_counts = meta_leads_df['Contact Source'].astype(str).value_counts()
        total_sources = len(source_counts)
        
        if total_sources > 0:
            # Calculate source entropy (diversity measure)
            source_props = source_counts / source_counts.sum()
            entropy = -sum(p * np.log2(p) for p in source_props if p > 0)
            max_entropy = np.log2(total_sources) if total_sources > 1 else 1
            
            # Normalize to 0-1 scale
            channel_diversity = entropy / max_entropy if max_entropy > 0 else 0
    
    metrics['Ad Channel Diversity'] = channel_diversity
    
    # Add insight for channel diversity
    if channel_diversity >= 0.7:
        insights.append("✅ Excellent ad channel diversity of {:.2f} reduces platform dependency risk".format(channel_diversity))
    elif channel_diversity >= 0.4:
        insights.append("✅ Moderate channel diversity of {:.2f} - good balance across Meta platforms".format(channel_diversity))
    elif channel_diversity > 0:
        insights.append("⚠️ Low channel diversity of {:.2f} - over-reliance on single traffic source".format(channel_diversity))
    
    # Store insights for display
    metrics['insights'] = insights
    
    return metrics
    
    return metrics

# Dashboard visualization functions
def create_funnel_chart(leads_df):
    """Create lead funnel visualization"""
    # Filter for Smooth M.D. brand
    leads_df = filter_smooth_md_data(leads_df)
    
    if leads_df is None or leads_df.empty:
        # Return empty figure with message
        fig = go.Figure()
        fig.add_annotation(
            text="No data available for funnel chart",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False
        )
        return fig
    
    # Calculate funnel stages
    total_leads = len(leads_df)
    
    # Booked - Consult Status = 'Scheduled'
    booked_leads = count_leads_by_status(leads_df, 'Consult Status', ['scheduled'])
    
    # Converted - Closed field is not empty
    converted_leads = 0
    if 'Closed' in leads_df.columns:
        converted_leads = leads_df['Closed'].notna().sum()
    
    # Create funnel data
    funnel_data = {
        'New Leads': total_leads,
        'Booked': booked_leads,
        'Converted': converted_leads
    }
    
    # Create funnel chart
    fig = go.Figure(go.Funnel(
        y=list(funnel_data.keys()),
        x=list(funnel_data.values()),
        textinfo="value+percent initial",
        marker={"color": ["#1E88E5", "#42A5F5", "#64B5F6"]}
    ))
    
    # Update layout
    fig.update_layout(
        title="Lead Funnel",
        margin=dict(l=20, r=20, t=60, b=20),
        height=400
    )
    
    return fig

def create_source_breakdown(leads_df):
    """Create a source breakdown chart"""
    # Filter for Smooth M.D. brand
    leads_df = filter_smooth_md_data(leads_df)
    
    if leads_df is None or leads_df.empty or 'Contact Source' not in leads_df.columns:
        # Return empty figure with message
        fig = go.Figure()
        fig.add_annotation(
            text="No source data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False
        )
        return fig
    
    # Process source data - handle lists/null values
    def process_source(source):
        if isinstance(source, list):
            return source[0] if source else "Unknown"
        elif pd.isna(source):
            return "Unknown"
        else:
            return source
    
    # Process sources
    leads_df['Processed_Source'] = leads_df['Contact Source'].apply(process_source)
    
    # Group by source and count
    source_counts = leads_df['Processed_Source'].value_counts().reset_index()
    source_counts.columns = ['Source', 'Count']
    
    # Create the pie chart
    fig = px.pie(
        source_counts, 
        names='Source', 
        values='Count',
        title="Leads by Source",
        hole=0.4
    )
    
    # Update layout
    fig.update_layout(
        margin=dict(l=20, r=20, t=60, b=20),
        height=400
    )
    
    return fig

def create_services_revenue_chart(transactions_df=None):
    """Create chart showing top services by revenue"""
    # If no transactions df provided, use the one from session state
    if transactions_df is None or transactions_df.empty:
        if 'meta_transactions' in st.session_state and not st.session_state.meta_transactions.empty:
            transactions_df = st.session_state.meta_transactions
        elif 'filtered_transactions' in st.session_state and not st.session_state.filtered_transactions.empty:
            transactions_df = st.session_state.filtered_transactions
    
    # Apply both brand and service filters to ensure only Smooth M.D. specific services
    if transactions_df is not None and not transactions_df.empty:
        transactions_df = filter_smooth_md_data(transactions_df)
        transactions_df = filter_smooth_md_services(transactions_df)
    
    if transactions_df is None or transactions_df.empty or 'Service' not in transactions_df.columns or 'Amount' not in transactions_df.columns:
        # Return empty figure with message
        fig = go.Figure()
        fig.add_annotation(
            text="No service revenue data available for Smooth M.D. Meta leads",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False,
            font=dict(size=14, color="crimson")
        )
        fig.update_layout(
            title="Top Services by Revenue (No Data)",
            height=400,
            plot_bgcolor='rgba(240, 240, 240, 0.8)'
        )
        return fig
    
    # Process services - handle lists/null values
    def process_service(service):
        if isinstance(service, list):
            return service[0] if service else "Unknown"
        elif pd.isna(service) or service == "" or service == "None" or service is None:
            return "Unknown"
        elif isinstance(service, str) and "[object Object]" in service:
            return "Unknown"
        else:
            # Clean up service name - capitalize and remove extraneous content
            service_str = str(service).strip()
            service_str = service_str.replace('_', ' ').title()
            return service_str
    
    # Convert Amount to numeric
    transactions_df['Amount'] = pd.to_numeric(transactions_df['Amount'], errors='coerce').fillna(0)
    
    # Process services
    transactions_df['Processed_Service'] = transactions_df['Service'].apply(process_service)
    
    # Filter out Unknown services if we have other data
    processed_df = transactions_df[transactions_df['Processed_Service'] != "Unknown"]
    if processed_df.empty:
        processed_df = transactions_df  # Use original if all are Unknown
    
    # Group by service and sum revenue
    service_revenue = processed_df.groupby('Processed_Service')['Amount'].sum().reset_index()
    
    # Sort by revenue and take top 10
    service_revenue = service_revenue.sort_values('Amount', ascending=False).head(10)
    
    # If service_revenue is empty, we know this is all "Unknown" services, 
    # so create a single value chart showing total
    if service_revenue.empty or (len(service_revenue) == 1 and service_revenue['Processed_Service'].iloc[0] == 'Unknown'):
        # Create a pie chart for unknown data
        total_revenue = transactions_df['Amount'].sum()
        
        fig = go.Figure(go.Pie(
            labels=['Unknown Service'],
            values=[total_revenue],
            hole=0.4,
            marker_colors=['#63c1e8']
        ))
        
        fig.update_layout(
            title="Revenue by Service (Unspecified Services)",
            annotations=[dict(text=f"${total_revenue:,.2f}", x=0.5, y=0.5, font_size=18, showarrow=False)]
        )
    else:
        # Format revenue values with $ sign 
        service_revenue['Formatted_Revenue'] = service_revenue['Amount'].apply(lambda x: f"${x:,.2f}")
        
        # Create the bar chart with improved colors
        fig = px.bar(
            service_revenue,
            x='Processed_Service',
            y='Amount',
            title="Top Services by Revenue",
            labels={"Processed_Service": "Service", "Amount": "Revenue ($)"},
            text='Formatted_Revenue',
            color='Amount',
            color_continuous_scale=px.colors.sequential.Blues
        )
        
        # Add value labels inside bars
        fig.update_traces(
            textposition='inside',
            textfont=dict(color='white'),
            hovertemplate='%{x}<br>Revenue: %{text}'
        )
    
    # Update layout
    fig.update_layout(
        margin=dict(l=20, r=20, t=60, b=20),
        height=400,
        xaxis_title="Service",
        yaxis_title="Revenue ($)",
        plot_bgcolor='rgba(240, 240, 240, 0.3)',
        font=dict(family="Arial, sans-serif")
    )
    
    # Show dollar signs on y-axis
    fig.update_yaxes(tickprefix="$", tickformat=",")
    
    return fig

def create_conversion_lag_histogram(leads_df):
    """Create histogram of days from Date to Closed"""
    # Filter for Smooth M.D. brand
    leads_df = filter_smooth_md_data(leads_df)
    
    if leads_df is None or leads_df.empty or 'Date' not in leads_df.columns or 'Closed' not in leads_df.columns:
        # Return empty figure with message
        fig = go.Figure()
        fig.add_annotation(
            text="No conversion lag data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False
        )
        return fig
    
    # Get only leads that have been closed
    closed_leads = leads_df[leads_df['Closed'].notna()]
    
    if closed_leads.empty:
        # Return empty figure with message
        fig = go.Figure()
        fig.add_annotation(
            text="No closed leads data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False
        )
        return fig
    
    # Convert dates to datetime
    closed_leads['Date'] = pd.to_datetime(closed_leads['Date'], errors='coerce')
    closed_leads['Closed'] = pd.to_datetime(closed_leads['Closed'], errors='coerce')
    
    # Calculate days to conversion
    closed_leads['Days_to_Conversion'] = (closed_leads['Closed'] - closed_leads['Date']).dt.total_seconds() / (60*60*24)
    
    # Filter out negative or excessive values (due to data errors)
    closed_leads = closed_leads[(closed_leads['Days_to_Conversion'] >= 0) & (closed_leads['Days_to_Conversion'] <= 180)]
    
    # Create the histogram
    fig = px.histogram(
        closed_leads,
        x='Days_to_Conversion',
        nbins=30,
        title="Click-to-Conversion Lag",
        labels={"Days_to_Conversion": "Days from Lead to Conversion"}
    )
    
    # Update layout
    fig.update_layout(
        margin=dict(l=20, r=20, t=60, b=20),
        height=400,
        xaxis_title="Days to Conversion",
        yaxis_title="Number of Leads"
    )
    
    return fig