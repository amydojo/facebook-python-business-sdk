#!/usr/bin/env python3
"""
Force correct table configuration with updated API key
"""

import os
import sys
sys.path.append('.')

# Set environment variables
os.environ['AIRTABLE_API_KEY'] = 'patRpwfhYlGferLE8.17a89cf5c31e4ef29041a67a4b28ca4058bb443779beb0dd4352ad999b186cdd'
os.environ['AIRTABLE_BASE_ID'] = 'appH4MePHS6qLsk5z'

# Import after setting environment
from pyairtable import Api
import time

# Create new API instance
api = Api(os.environ['AIRTABLE_API_KEY'])
base_id = os.environ['AIRTABLE_BASE_ID']

print("Testing direct table access...")

# Test both confirmed tables
tables_to_test = {
    'leads': 'Leads',
    'transactions': 'Transactions'
}

working_tables = {}

for data_type, table_name in tables_to_test.items():
    try:
        table = api.table(base_id, table_name)
        test_records = table.all(max_records=2)
        
        working_tables[data_type] = {
            'name': table_name,
            'accessible': True,
            'last_tested': time.time(),
            'sample_fields': list(test_records[0]['fields'].keys()) if test_records else [],
            'record_count': len(test_records)
        }
        
        print(f"✓ {data_type} -> {table_name}: {len(test_records)} records")
        if test_records:
            fields = list(test_records[0]['fields'].keys())
            print(f"  Fields: {', '.join(fields[:8])}")
        
    except Exception as e:
        print(f"✗ {data_type} -> {table_name}: {e}")

# Now patch the unified connector
if len(working_tables) == 2:
    print("\nPatching unified connector...")
    
    # Import and modify the connector
    from unified_production_connector import unified_connector
    
    # Override table_info directly
    unified_connector.table_info = working_tables
    unified_connector.health_status['tables_validated'] = True
    unified_connector.health_status['api_connected'] = True
    
    # Force new API instance
    unified_connector.api = api
    unified_connector.api_key = os.environ['AIRTABLE_API_KEY']
    
    print("✓ Connector patched with working table configuration")
    
    # Test the patched connector
    print("\nTesting patched connector...")
    
    tx_result = unified_connector.load_transactions('2025-06-01', '2025-06-17')
    lead_result = unified_connector.load_leads('2025-06-01', '2025-06-17')
    
    print(f"Transactions: success={tx_result.success}, count={tx_result.count}")
    print(f"Leads: success={lead_result.success}, count={lead_result.count}")
    
    if tx_result.success and lead_result.success:
        print("\n🎉 CONNECTION RESTORED!")
        
        # Test full pipeline
        from advanced_lead_matcher import advanced_lead_matcher
        
        meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data or [])
        matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
            meta_leads, tx_result.data or []
        )
        
        matched_count = len([l for l in matched_leads if l['matched_transactions']])
        revenue = matching_stats.get('total_matched_revenue', 0)
        
        print(f"Meta leads: {len(meta_leads)}")
        print(f"Matched leads: {matched_count}")
        print(f"Revenue: ${revenue:,.2f}")
        print("\nDashboard is ready!")
        
else:
    print(f"\n✗ Only {len(working_tables)} tables accessible - need both Leads and Transactions")