#!/usr/bin/env python3
"""
Test Lead Matching Fix
Verify the corrected attribution logic eliminates duplicate "Unknown" entries
"""

import requests
from datetime import datetime, timedelta

def test_lead_matching_logic():
    api_key = 'patRpwfhYlGferLE8.17a89cf5c31e4ef29041a67a4b28ca4058bb443779beb0dd4352ad999b186cdd'
    base_id = 'appH4MePHS6qLsk5z'
    headers = {'Authorization': f'Bearer {api_key}'}
    
    print("=== TESTING FIXED LEAD MATCHING LOGIC ===\n")
    
    # Get last 30 days data
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=30)
    
    print(f"Testing period: {start_date} to {end_date}")
    
    # Load Meta leads
    leads_response = requests.get(f'https://api.airtable.com/v0/{base_id}/Leads', headers=headers)
    meta_leads = []
    
    if leads_response.status_code == 200:
        all_leads = leads_response.json().get('records', [])
        
        for record in all_leads:
            fields = record['fields']
            contact_source = fields.get('Contact Source', '')
            inbound_date_str = fields.get('Inbound', '')
            
            if contact_source in ['Facebook AD', 'Facebook AD Sign Up', 'Instagram AD']:
                if inbound_date_str:
                    try:
                        inbound_date = datetime.strptime(inbound_date_str, '%Y-%m-%d').date()
                        if start_date <= inbound_date <= end_date:
                            meta_leads.append({
                                'id': record['id'],
                                'lead_id': fields.get('ID', ''),
                                'phone': fields.get('Phone', ''),
                                'email': fields.get('Email', ''),
                                'contact_source': contact_source,
                                'inbound_date': inbound_date_str
                            })
                    except ValueError:
                        pass
    
    print(f"Meta leads found: {len(meta_leads)}")
    for lead in meta_leads:
        print(f"  - {lead['lead_id']}: {lead['phone']}, {lead['contact_source']}")
    
    # Load transactions
    trans_response = requests.get(f'https://api.airtable.com/v0/{base_id}/Transactions', headers=headers)
    transactions = []
    
    if trans_response.status_code == 200:
        all_transactions = trans_response.json().get('records', [])
        
        for record in all_transactions:
            fields = record['fields']
            trans_date_str = fields.get('Date', '')
            amount = fields.get('Amount', 0)
            
            if trans_date_str:
                try:
                    trans_date = datetime.strptime(trans_date_str, '%Y-%m-%d').date()
                    if start_date <= trans_date <= end_date and isinstance(amount, (int, float)) and amount > 0:
                        transactions.append({
                            'id': record['id'],
                            'patient': fields.get('Patient', ''),
                            'date': trans_date_str,
                            'amount': amount
                        })
                except ValueError:
                    pass
    
    print(f"\nTransactions found: {len(transactions)}")
    total_revenue = sum(t['amount'] for t in transactions)
    print(f"Total revenue: ${total_revenue:,.2f}")
    
    for trans in transactions:
        print(f"  - {trans['patient']}: ${trans['amount']} on {trans['date']}")
    
    # Test the fixed matching logic
    print(f"\n=== TESTING ATTRIBUTION LOGIC ===")
    
    if not meta_leads:
        print("No Meta leads to attribute revenue to")
        return
    
    if not transactions:
        print("No transactions to attribute")
        return
    
    # Apply the fixed matching logic
    leads_with_revenue = []
    total_attributed_revenue = 0
    used_transaction_ids = set()
    
    # Try exact matching first
    for lead in meta_leads:
        lead_phone = str(lead.get('phone', '')).strip().replace('(', '').replace(')', '').replace('-', '').replace(' ', '')
        lead_email = str(lead.get('email', '')).strip().lower()
        
        matched_transactions = []
        lead_revenue = 0
        
        for transaction in transactions:
            if transaction['id'] in used_transaction_ids:
                continue
                
            trans_patient = str(transaction.get('patient', '')).lower()
            trans_amount = transaction.get('amount', 0)
            
            # Check if phone appears in patient name
            if lead_phone and len(lead_phone) >= 10:
                if lead_phone[-10:] in trans_patient.replace('(', '').replace(')', '').replace('-', '').replace(' ', ''):
                    matched_transactions.append(transaction)
                    lead_revenue += trans_amount
                    used_transaction_ids.add(transaction['id'])
                    continue
            
            # Check if email prefix matches patient name
            if lead_email and '@' in lead_email:
                email_prefix = lead_email.split('@')[0].lower()
                if email_prefix in trans_patient and len(email_prefix) > 3:
                    matched_transactions.append(transaction)
                    lead_revenue += trans_amount
                    used_transaction_ids.add(transaction['id'])
                    continue
        
        lead_copy = lead.copy()
        lead_copy['revenue'] = lead_revenue
        lead_copy['transaction_count'] = len(matched_transactions)
        lead_copy['matched_transactions'] = matched_transactions
        leads_with_revenue.append(lead_copy)
        total_attributed_revenue += lead_revenue
    
    # If no direct matches, distribute proportionally
    if total_attributed_revenue == 0 and total_revenue > 0:
        avg_revenue_per_lead = total_revenue / len(meta_leads)
        
        for lead in leads_with_revenue:
            lead['revenue'] = avg_revenue_per_lead
            lead['transaction_count'] = 1
            lead['attribution_method'] = 'proportional'
        
        total_attributed_revenue = total_revenue
    
    # Results
    print(f"\nATTRIBUTION RESULTS:")
    print(f"Total Meta leads: {len(leads_with_revenue)}")
    print(f"Total attributed revenue: ${total_attributed_revenue:,.2f}")
    print(f"Direct matches: {sum(1 for lead in leads_with_revenue if lead.get('matched_transactions'))}")
    print(f"Proportional attribution: {sum(1 for lead in leads_with_revenue if lead.get('attribution_method') == 'proportional')}")
    
    print(f"\nPER-LEAD ATTRIBUTION:")
    for lead in leads_with_revenue:
        print(f"  Lead {lead['lead_id']}: ${lead['revenue']:,.2f} ({lead['transaction_count']} transactions)")
        if lead.get('matched_transactions'):
            for trans in lead['matched_transactions']:
                print(f"    - Matched: {trans['patient']} ${trans['amount']}")
        elif lead.get('attribution_method') == 'proportional':
            print(f"    - Proportional share of total revenue")
    
    # Verify no duplicate "Unknown" entries
    unknown_count = sum(1 for lead in leads_with_revenue if 'Unknown' in lead.get('lead_id', ''))
    print(f"\nDUPLICATE CHECK:")
    print(f"'Unknown' lead entries: {unknown_count} (should be 0)")
    
    if unknown_count == 0:
        print("✅ SUCCESS: No duplicate 'Unknown' entries created")
    else:
        print("❌ ISSUE: Still creating 'Unknown' entries")
    
    return leads_with_revenue, total_attributed_revenue

if __name__ == "__main__":
    test_lead_matching_logic()