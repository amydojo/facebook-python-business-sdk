"""
Complete Analytics Dashboard with Authentic Data Integration
Real Meta spend + Airtable transaction revenue = Accurate ROAS
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import os
import requests
from datetime import datetime, timedelta
from pyairtable import Api
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Smooth MD Analytics",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

def apply_ios_styling():
    """Apple iOS inspired styling for mobile optimization"""
    st.markdown("""
    <style>
    .stApp {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    }
    
    .main .block-container {
        padding: 1rem;
        max-width: 100%;
    }
    
    @media (min-width: 768px) {
        .main .block-container {
            padding: 2rem;
            max-width: 1400px;
        }
    }
    
    .metric-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(20px);
        border-radius: 16px;
        padding: 20px;
        margin: 12px 0;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        border: 0.5px solid rgba(0, 0, 0, 0.05);
    }
    
    .kpi-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 16px;
        padding: 24px;
        margin: 8px 0;
        text-align: center;
        box-shadow: 0 8px 32px rgba(102, 126, 234, 0.3);
    }
    
    .roas-card {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        color: white;
        border-radius: 16px;
        padding: 32px;
        margin: 16px 0;
        text-align: center;
        box-shadow: 0 12px 48px rgba(17, 153, 142, 0.4);
    }
    
    .status-success { border-left: 4px solid #34c759; }
    .status-error { border-left: 4px solid #ff3b30; }
    .status-warning { border-left: 4px solid #ff9500; }
    
    #MainMenu, footer, header, .stDeployButton {
        visibility: hidden;
    }
    </style>
    """, unsafe_allow_html=True)

class AuthenticDataManager:
    """Manages authentic data from Meta API and Airtable"""
    
    def __init__(self):
        self.meta_data = {}
        self.airtable_data = {}
        self.connection_status = {}
        
        # Use the working base ID
        self.base_id = 'appri2CgCoIiuZWq3'
    
    def load_meta_insights(self):
        """Load authentic Meta campaign data"""
        try:
            access_token = os.getenv('META_ACCESS_TOKEN')
            ad_account_id = os.getenv('META_AD_ACCOUNT_ID')
            
            if not access_token or not ad_account_id:
                self.connection_status['meta'] = "Credentials required"
                return False
            
            url = f"https://graph.facebook.com/v18.0/act_{ad_account_id}/insights"
            params = {
                'access_token': access_token,
                'fields': 'spend,impressions,clicks,actions,cost_per_action_type,cpm,cpc,ctr,reach,frequency',
                'date_preset': 'last_30d',
                'limit': 50
            }
            
            response = requests.get(url, params=params, timeout=15)
            
            if response.status_code == 200:
                data = response.json()
                insights = data.get('data', [])
                
                if insights:
                    # Calculate comprehensive metrics from authentic data
                    total_spend = sum(float(insight.get('spend', 0)) for insight in insights)
                    total_impressions = sum(int(insight.get('impressions', 0)) for insight in insights)
                    total_clicks = sum(int(insight.get('clicks', 0)) for insight in insights)
                    total_reach = sum(int(insight.get('reach', 0)) for insight in insights)
                    
                    # Calculate leads from actions if available
                    total_leads = 0
                    for insight in insights:
                        actions = insight.get('actions', [])
                        for action in actions:
                            if action.get('action_type') == 'lead':
                                total_leads += int(action.get('value', 0))
                    
                    self.meta_data = {
                        'total_spend': total_spend,
                        'total_impressions': total_impressions,
                        'total_clicks': total_clicks,
                        'total_reach': total_reach,
                        'total_leads': total_leads,
                        'avg_cpm': sum(float(insight.get('cpm', 0)) for insight in insights) / len(insights) if insights else 0,
                        'avg_cpc': sum(float(insight.get('cpc', 0)) for insight in insights) / len(insights) if insights else 0,
                        'avg_ctr': sum(float(insight.get('ctr', 0)) for insight in insights) / len(insights) if insights else 0,
                        'cost_per_lead': total_spend / total_leads if total_leads > 0 else 0,
                        'insights_count': len(insights),
                        'raw_insights': insights
                    }
                    
                    self.connection_status['meta'] = "Connected - Real data loaded"
                    logger.info(f"Meta data loaded: ${total_spend:,.2f} spend, {total_impressions:,} impressions, {total_leads} leads")
                    return True
                else:
                    self.connection_status['meta'] = "No insights available"
                    return False
            else:
                self.connection_status['meta'] = f"API Error: {response.status_code}"
                return False
                
        except Exception as e:
            self.connection_status['meta'] = f"Connection failed: {str(e)}"
            logger.error(f"Meta API error: {e}")
            return False
    
    def load_airtable_data(self):
        """Load authentic transaction and lead data from Airtable"""
        try:
            airtable_key = os.getenv('AIRTABLE_API_KEY')
            if not airtable_key:
                self.connection_status['airtable'] = "API key required"
                return False
            
            api = Api(airtable_key)
            
            # Load leads data
            leads_table = api.table(self.base_id, 'Leads')
            leads_records = leads_table.all()
            
            # Load transactions data
            trans_table = api.table(self.base_id, 'Transactions')
            trans_records = trans_table.all()
            
            # Process leads data
            leads_data = []
            for record in leads_records:
                fields = record.get('fields', {})
                leads_data.append({
                    'record_id': record.get('id'),
                    'contact_source': fields.get('Contact Source', ''),
                    'brand': fields.get('Brand', ''),
                    'created_time': fields.get('Created Time', ''),
                    'status': fields.get('Status', ''),
                    'email': fields.get('Email', ''),
                    'phone': fields.get('Phone number', ''),
                    'heard_about': fields.get('Heard About Us From:', '')
                })
            
            # Process transactions data
            trans_data = []
            total_revenue = 0
            for record in trans_records:
                fields = record.get('fields', {})
                amount = fields.get('Amount', 0)
                if isinstance(amount, (int, float)) and amount > 0:
                    total_revenue += amount
                    trans_data.append({
                        'record_id': record.get('id'),
                        'patient': fields.get('Patient', ''),
                        'amount': amount,
                        'payment_type': fields.get('Payment Type', ''),
                        'status': fields.get('Status', ''),
                        'services': fields.get('Services Purchased', ''),
                        'date': fields.get('Date', ''),
                        'revenue_type': fields.get('Revenue Type', '')
                    })
            
            # Filter Meta leads
            meta_leads = [lead for lead in leads_data if 'meta' in lead.get('contact_source', '').lower() or 'facebook' in lead.get('contact_source', '').lower() or 'instagram' in lead.get('contact_source', '').lower()]
            
            self.airtable_data = {
                'leads_count': len(leads_data),
                'meta_leads_count': len(meta_leads),
                'transactions_count': len(trans_data),
                'total_revenue': total_revenue,
                'avg_transaction_value': total_revenue / len(trans_data) if trans_data else 0,
                'leads_data': leads_data,
                'meta_leads_data': meta_leads,
                'transactions_data': trans_data
            }
            
            self.connection_status['airtable'] = "Connected - Transaction data loaded"
            logger.info(f"Airtable data loaded: {len(leads_data)} leads, ${total_revenue:,.2f} revenue")
            return True
            
        except Exception as e:
            self.connection_status['airtable'] = f"Connection failed: {str(e)}"
            logger.error(f"Airtable error: {e}")
            return False
    
    def calculate_authentic_roas(self):
        """Calculate ROAS using authentic Meta spend and Airtable revenue"""
        if not self.meta_data or not self.airtable_data:
            return 0, 0, 0
        
        spend = self.meta_data.get('total_spend', 0)
        revenue = self.airtable_data.get('total_revenue', 0)
        
        if spend > 0:
            roas = revenue / spend
            return roas, revenue, spend
        
        return 0, revenue, spend

def create_roas_visualization(roas, revenue, spend):
    """Create ROAS visualization with authentic data"""
    fig = go.Figure()
    
    # Create gauge chart for ROAS
    fig.add_trace(go.Indicator(
        mode = "gauge+number+delta",
        value = roas,
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': "Return on Ad Spend (ROAS)", 'font': {'size': 24}},
        delta = {'reference': 4.0},  # Industry benchmark
        gauge = {
            'axis': {'range': [None, 10]},
            'bar': {'color': "#11998e"},
            'steps': [
                {'range': [0, 2], 'color': "#ff6b6b"},
                {'range': [2, 4], 'color': "#ffd93d"},
                {'range': [4, 10], 'color': "#6bcf7f"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 4.0
            }
        }
    ))
    
    fig.update_layout(
        height=400,
        font=dict(family='-apple-system, BlinkMacSystemFont, sans-serif'),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    
    return fig

def create_funnel_chart(meta_data, airtable_data):
    """Create conversion funnel with authentic data"""
    impressions = meta_data.get('total_impressions', 0)
    clicks = meta_data.get('total_clicks', 0)
    leads = meta_data.get('total_leads', 0) or airtable_data.get('meta_leads_count', 0)
    transactions = airtable_data.get('transactions_count', 0)
    
    stages = ['Impressions', 'Clicks', 'Leads', 'Transactions']
    values = [impressions, clicks, leads, transactions]
    
    fig = go.Figure(go.Funnel(
        y = stages,
        x = values,
        textinfo = "value+percent initial",
        marker = dict(
            color = ["#667eea", "#764ba2", "#11998e", "#38ef7d"],
            line = dict(width = 2, color = "white")
        ),
        connector = {"line": {"color": "#a8b2d1", "dash": "dot", "width": 2}}
    ))
    
    fig.update_layout(
        title="Conversion Funnel - Authentic Data",
        font=dict(family='-apple-system, BlinkMacSystemFont, sans-serif'),
        height=500,
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    
    return fig

def main():
    """Main application with complete authentic data integration"""
    
    apply_ios_styling()
    
    # Header
    st.title("📊 Smooth MD Campaign Analytics")
    st.markdown("**Real-time performance with authentic Meta + Airtable data**")
    
    # Initialize data manager
    data_manager = AuthenticDataManager()
    
    # Load authentic data
    with st.spinner("Loading authentic campaign and revenue data..."):
        meta_success = data_manager.load_meta_insights()
        airtable_success = data_manager.load_airtable_data()
    
    # Connection status
    st.subheader("🔗 Data Connections")
    
    col1, col2 = st.columns(2)
    
    with col1:
        meta_status = data_manager.connection_status.get('meta', 'Unknown')
        status_class = 'status-success' if 'Connected' in meta_status else 'status-error'
        st.markdown(f'<div class="metric-card {status_class}"><strong>Meta API:</strong> {meta_status}</div>', 
                   unsafe_allow_html=True)
    
    with col2:
        airtable_status = data_manager.connection_status.get('airtable', 'Unknown')
        status_class = 'status-success' if 'Connected' in airtable_status else 'status-error'
        st.markdown(f'<div class="metric-card {status_class}"><strong>Airtable:</strong> {airtable_status}</div>', 
                   unsafe_allow_html=True)
    
    # Display complete analytics if both sources are connected
    if meta_success and airtable_success:
        
        # Calculate authentic ROAS
        roas, revenue, spend = data_manager.calculate_authentic_roas()
        
        # Hero ROAS metric
        st.markdown(f"""
        <div class="roas-card">
            <h2 style="margin: 0; font-size: 2.5rem;">{roas:.2f}x</h2>
            <h3 style="margin: 0; opacity: 0.9;">Return on Ad Spend</h3>
            <p style="margin: 0; opacity: 0.8;">${revenue:,.2f} revenue ÷ ${spend:,.2f} spend</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Key performance metrics
        st.subheader("📈 Campaign Performance")
        
        col1, col2, col3, col4 = st.columns(4)
        
        meta_data = data_manager.meta_data
        airtable_data = data_manager.airtable_data
        
        with col1:
            st.markdown(f"""
            <div class="kpi-card">
                <h3>${meta_data['total_spend']:,.2f}</h3>
                <p>Total Spend</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown(f"""
            <div class="kpi-card">
                <h3>${airtable_data['total_revenue']:,.2f}</h3>
                <p>Total Revenue</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            st.markdown(f"""
            <div class="kpi-card">
                <h3>{airtable_data['meta_leads_count']}</h3>
                <p>Meta Leads</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col4:
            st.markdown(f"""
            <div class="kpi-card">
                <h3>{airtable_data['transactions_count']}</h3>
                <p>Transactions</p>
            </div>
            """, unsafe_allow_html=True)
        
        # ROAS visualization
        st.subheader("📊 ROAS Analysis")
        roas_chart = create_roas_visualization(roas, revenue, spend)
        st.plotly_chart(roas_chart, use_container_width=True)
        
        # Conversion funnel
        st.subheader("🔄 Conversion Funnel")
        funnel_chart = create_funnel_chart(meta_data, airtable_data)
        st.plotly_chart(funnel_chart, use_container_width=True)
        
        # Detailed metrics
        st.subheader("💰 Campaign Metrics")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Impressions", f"{meta_data['total_impressions']:,}")
        
        with col2:
            st.metric("Clicks", f"{meta_data['total_clicks']:,}")
        
        with col3:
            st.metric("Avg CPM", f"${meta_data['avg_cpm']:.2f}")
        
        with col4:
            st.metric("Avg CPC", f"${meta_data['avg_cpc']:.2f}")
        
        # Transaction analysis
        if airtable_data['transactions_data']:
            st.subheader("💵 Transaction Analysis")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.metric("Avg Transaction Value", f"${airtable_data['avg_transaction_value']:,.2f}")
            
            with col2:
                conversion_rate = (airtable_data['transactions_count'] / airtable_data['meta_leads_count']) * 100 if airtable_data['meta_leads_count'] > 0 else 0
                st.metric("Lead to Sale Conversion", f"{conversion_rate:.1f}%")
        
        # Success message
        st.success("Dashboard displaying 100% authentic data from your Meta campaigns and Airtable transactions.")
        
    elif meta_success:
        st.warning("Meta API connected successfully. Airtable connection needed for revenue calculations.")
        
        # Show Meta metrics only
        meta_data = data_manager.meta_data
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Total Spend", f"${meta_data['total_spend']:,.2f}")
        
        with col2:
            st.metric("Impressions", f"{meta_data['total_impressions']:,}")
        
        with col3:
            st.metric("Clicks", f"{meta_data['total_clicks']:,}")
    
    else:
        st.error("API connections required to display authentic campaign data.")
    
    # Data integrity notice
    st.markdown("---")
    st.markdown("**Data Integrity:** This dashboard displays only authentic data from your Meta API and Airtable. No synthetic or placeholder data is used.")

if __name__ == "__main__":
    main()