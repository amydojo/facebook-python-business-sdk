"""
ROI and Conversions tab for the Ad Command Center
"""
import os
import json
import streamlit as st
import pandas as pd
import numpy as np
import requests
from datetime import datetime, timedelta
import plotly.graph_objects as go

def render_roi_tab():
    """Render the ROI & Conversions tab content with precise metric calculations"""
    st.markdown('<p class="section-title">ROI & ROAS Analysis</p>', unsafe_allow_html=True)
    
    # ROI Calculator settings
    with st.expander("ROI Calculation Settings"):
        col1, col2 = st.columns(2)
        
        with col1:
            avg_transaction = st.number_input("Average Transaction Value ($):", min_value=0, value=2500, step=100)
            booking_multiplier = st.number_input("Booking Value Multiplier (%):", min_value=0, max_value=100, value=20, step=5) / 100
        
        with col2:
            lead_value = st.number_input("Lead Value ($):", min_value=0, value=50, step=10)
            booked_to_close = st.slider("Booking to Closed Rate (%):", min_value=0, max_value=100, value=65, step=5) / 100
    
    # Use data directly from session state (cached from load_meta_campaign_data)
    campaigns = st.session_state.get('meta_campaigns', [])
    insights = st.session_state.get('meta_insights', [])
    
    # Display data source information
    st.markdown("### Data Source Information")
    col1, col2 = st.columns(2)
    
    with col1:
        if campaigns:
            st.success(f"✅ Using {len(campaigns)} real campaigns from Meta")
        else:
            st.error("❌ No campaign data loaded from Meta API")
            
        if insights:
            st.success(f"✅ Using insights data for {len(insights)} campaigns from Meta")
        else:
            st.error("❌ No campaign insights loaded from Meta API")
            
    with col2:
        leads_df = st.session_state.get('filtered_leads_df')
        if leads_df is not None and not leads_df.empty:
            st.success(f"✅ Using {len(leads_df)} leads from Airtable")
            
            if 'is_converted' in leads_df.columns:
                converted_count = leads_df['is_converted'].sum()
                conversion_rate = (converted_count / len(leads_df)) * 100 if len(leads_df) > 0 else 0
                st.info(f"Found {converted_count} converted leads ({conversion_rate:.1f}%)")
        else:
            st.error("❌ No lead data available from Airtable")
    
    # Process campaign data
    if not campaigns:
        st.warning("No Meta campaign data available. Please check your API credentials in Settings tab.")
        
        # Show settings prompt
        if st.button("Go to Settings"):
            st.session_state.navigation = "⚙️ Settings"
            st.rerun()
            
        # Add manual refresh button
        if st.button("🔄 Refresh Data Now"):
            st.session_state.force_refresh = True
            st.rerun()
        return
    
    # Create campaign data structure for analysis
    campaign_data = []
    
    # Map campaign spend from insights
    campaign_spend = {}
    total_clicks = 0
    total_impressions = 0
    
    # Process insights data
    for insight in insights or []:
        if "campaign_name" in insight and "spend" in insight:
            name = insight["campaign_name"]
            if name not in campaign_spend:
                campaign_spend[name] = {
                    "spend": 0,
                    "clicks": 0,
                    "impressions": 0,
                    "ctr": 0
                }
            
            # Add spend data
            campaign_spend[name]["spend"] += float(insight.get("spend", 0))
            
            # Add click data
            clicks = int(insight.get("clicks", 0))
            campaign_spend[name]["clicks"] += clicks
            total_clicks += clicks
            
            # Add impression data
            impressions = int(insight.get("impressions", 0))
            campaign_spend[name]["impressions"] += impressions
            total_impressions += impressions
            
            # Calculate CTR
            if impressions > 0:
                campaign_spend[name]["ctr"] = (campaign_spend[name]["clicks"] / campaign_spend[name]["impressions"]) * 100
    
    # Get total leads from session state
    total_leads = 0
    leads_df = st.session_state.get('filtered_leads_df')
    if leads_df is not None and not leads_df.empty:
        total_leads = len(leads_df)
    
    # Create analysis data for each campaign
    for campaign in campaigns:
        if "name" in campaign:
            name = campaign["name"]
            status = campaign.get("status", "UNKNOWN")
            
            # Get spend and metrics from insights
            spend = campaign_spend.get(name, {}).get("spend", 0)
            clicks = campaign_spend.get(name, {}).get("clicks", 0)
            impressions = campaign_spend.get(name, {}).get("impressions", 0)
            ctr = campaign_spend.get(name, {}).get("ctr", 0)
            
            # Calculate cost metrics consistently
            # For CPC, calculate from raw data to ensure consistency
            cpc = spend / clicks if clicks > 0 else 0
                
            # For CPM, calculate from raw data to ensure consistency
            cpm = (spend / impressions) * 1000 if impressions > 0 else 0
                
            # Use enhanced attribution method for lead allocation
            # First check if we can match leads directly to campaigns
            matched_leads = 0
            if leads_df is not None and not leads_df.empty and "Source" in leads_df.columns:
                # Try to find direct matches between campaign name and lead source
                campaign_name_lower = name.lower()
                matched_leads = leads_df[leads_df["Source"].str.lower().str.contains(campaign_name_lower, na=False)].shape[0]
                
            # If we found direct matches, use them
            if matched_leads > 0:
                estimated_leads = matched_leads
            else:
                # Fall back to spend-based allocation
                total_spend = sum(data.get("spend", 0) for data in campaign_spend.values())
                campaign_weight = spend / total_spend if total_spend > 0 else 0
                estimated_leads = total_leads * campaign_weight
            
            # Get conversion rate from leads data
            conversion_rate = 0
            if leads_df is not None and not leads_df.empty and 'is_converted' in leads_df.columns:
                conversion_rate = leads_df['is_converted'].sum() / len(leads_df) if len(leads_df) > 0 else 0
            
            # Estimate conversions
            estimated_conversions = estimated_leads * conversion_rate
            
            # Calculate revenue
            estimated_revenue = estimated_conversions * avg_transaction
            
            # Calculate ROAS
            roas = estimated_revenue / spend if spend > 0 else 0
            
            # Add to campaign data
            campaign_data.append({
                "Campaign": name,
                "Status": status,
                "Spend": spend,
                "Clicks": clicks,
                "Impressions": impressions,
                "CTR": ctr,
                "CPC": cpc,
                "CPM": cpm,
                "Estimated Leads": estimated_leads,
                "Estimated Revenue": estimated_revenue,
                "ROAS": roas,
                "Estimated Conversions": estimated_conversions
            })
    
    # Display ROI Summary
    st.markdown("### Return on Ad Spend (ROAS) Summary")
    
    # Create summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    # Calculate totals
    total_spend = sum(c["Spend"] for c in campaign_data)
    total_est_revenue = sum(c["Estimated Revenue"] for c in campaign_data)
    total_est_conversions = sum(c["Estimated Conversions"] for c in campaign_data)
    overall_roas = total_est_revenue / total_spend if total_spend > 0 else 0
    
    with col1:
        st.metric(
            "Total Ad Spend", 
            f"${total_spend:,.2f}",
            delta=None
        )
    
    with col2:
        st.metric(
            "Estimated Revenue", 
            f"${total_est_revenue:,.2f}", 
            delta=f"${total_est_revenue - total_spend:,.2f}" if total_spend > 0 else None
        )
    
    with col3:
        st.metric(
            "Est. Conversions",
            f"{total_est_conversions:.1f}",
            delta=None
        )
    
    with col4:
        st.metric(
            "Overall ROAS",
            f"{overall_roas:.2f}x",
            delta=None
        )
    
    # Create DataFrame for display
    if campaign_data:
        # Display campaign performance table
        st.markdown("### Campaign Performance Metrics")
        campaign_df = pd.DataFrame(campaign_data)
        
        # Format display dataframe
        display_df = campaign_df.copy()
        display_df["Spend"] = display_df["Spend"].apply(lambda x: f"${x:.2f}")
        display_df["CPC"] = display_df["CPC"].apply(lambda x: f"${x:.2f}")
        display_df["CPM"] = display_df["CPM"].apply(lambda x: f"${x:.2f}")
        display_df["CTR"] = display_df["CTR"].apply(lambda x: f"{x:.2f}%")
        display_df["Estimated Revenue"] = display_df["Estimated Revenue"].apply(lambda x: f"${x:.2f}")
        display_df["ROAS"] = display_df["ROAS"].apply(lambda x: f"{x:.2f}x")
        display_df["Estimated Leads"] = display_df["Estimated Leads"].apply(lambda x: f"{x:.1f}")
        display_df["Estimated Conversions"] = display_df["Estimated Conversions"].apply(lambda x: f"{x:.1f}")
        
        # Select columns for display
        display_columns = ["Campaign", "Status", "Spend", "CTR", "CPC", "Estimated Leads", "Estimated Conversions", "ROAS"]
        
        # Display table
        st.dataframe(
            display_df[display_columns],
            use_container_width=True
        )
        
        # Create ROAS chart
        st.markdown("### Campaign Performance Visualization")
        
        # Allow user to choose sort order
        sort_by = st.selectbox(
            "Sort campaigns by:",
            options=["ROAS (High to Low)", "Spend (High to Low)", "Estimated Revenue (High to Low)"]
        )
        
        # Sort dataframe based on selection
        if sort_by == "ROAS (High to Low)":
            sorted_df = campaign_df.sort_values("ROAS", ascending=False)
        elif sort_by == "Spend (High to Low)":
            sorted_df = campaign_df.sort_values("Spend", ascending=False)
        else:  # Revenue
            sorted_df = campaign_df.sort_values("Estimated Revenue", ascending=False)
        
        # Create visualization
        fig = go.Figure()
        
        # Add spend bars
        fig.add_trace(go.Bar(
            x=sorted_df["Campaign"],
            y=sorted_df["Spend"],
            name="Ad Spend",
            marker_color="rgba(58, 71, 80, 0.6)"
        ))
        
        # Add revenue bars
        fig.add_trace(go.Bar(
            x=sorted_df["Campaign"],
            y=sorted_df["Estimated Revenue"],
            name="Estimated Revenue",
            marker_color="rgba(16, 185, 129, 0.6)"
        ))
        
        # Add ROAS line
        fig.add_trace(go.Scatter(
            x=sorted_df["Campaign"],
            y=sorted_df["ROAS"],
            name="ROAS",
            mode="lines+markers",
            marker=dict(size=8, color="#1E3A8A"),
            line=dict(width=2, color="#1E3A8A"),
            yaxis="y2"
        ))
        
        # Update layout
        fig.update_layout(
            title="Campaign Performance: Spend vs Estimated Revenue & ROAS",
            xaxis=dict(
                title="Campaign",
                tickangle=45,
                tickfont=dict(size=10)
            ),
            yaxis=dict(title="Amount ($)"),
            yaxis2=dict(
                title="ROAS (x)",
                overlaying="y",
                side="right",
                rangemode="tozero"
            ),
            barmode="group",
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
            height=500,
            margin=dict(l=20, r=20, t=60, b=120),
            plot_bgcolor="rgba(0,0,0,0)"
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Campaign opportunities
        st.markdown("### Optimization Opportunities")
        
        # Calculate opportunities
        opportunities = []
        for campaign in campaign_data:
            name = campaign["Campaign"]
            roas = campaign["ROAS"] if isinstance(campaign["ROAS"], float) else 0
            status = campaign["Status"]
            spend = campaign["Spend"] if isinstance(campaign["Spend"], float) else 0
            
            if roas < 1 and status == "ACTIVE" and spend > 100:
                opportunities.append({
                    "Campaign": name,
                    "Opportunity": "Consider pausing this underperforming campaign (ROAS < 1)",
                    "Priority": "High",
                    "Expected Impact": "Reduce wasted ad spend"
                })
            elif roas > 3:
                opportunities.append({
                    "Campaign": name,
                    "Opportunity": "Consider increasing budget for this high-performing campaign",
                    "Priority": "Medium",
                    "Expected Impact": "Increase lead volume while maintaining ROAS"
                })
            elif status == "ACTIVE" and spend > 0 and roas > 0 and roas < 2:
                opportunities.append({
                    "Campaign": name,
                    "Opportunity": "Optimize targeting and creative to improve performance",
                    "Priority": "Medium",
                    "Expected Impact": "Increase ROAS by improving conversion rates"
                })
        
        if opportunities:
            opportunities_df = pd.DataFrame(opportunities)
            st.dataframe(
                opportunities_df,
                column_config={
                    "Campaign": st.column_config.TextColumn("Campaign"),
                    "Opportunity": st.column_config.TextColumn("Opportunity"),
                    "Priority": st.column_config.TextColumn("Priority"),
                    "Expected Impact": st.column_config.TextColumn("Expected Impact")
                },
                use_container_width=True
            )
        else:
            st.info("No specific optimization opportunities identified at this time.")
    
    # Add refresh button
    col1, col2 = st.columns([3, 1])
    with col2:
        if st.button("🔄 Refresh Data", use_container_width=True):
            st.session_state.force_refresh = True
            st.rerun()