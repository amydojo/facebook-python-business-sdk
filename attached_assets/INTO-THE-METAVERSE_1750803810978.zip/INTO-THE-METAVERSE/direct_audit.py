"""
Direct API and Data Logic Audit
Identifies and fixes exact issues with Smooth MD data processing
"""

import os
import pandas as pd
import requests
from pyairtable import Api
import json

def run_direct_audit():
    """Run comprehensive audit and return detailed findings"""
    print("🔍 Starting Direct API & Data Audit...")
    
    results = {
        'env_vars': {},
        'airtable': {},
        'meta': {},
        'data_analysis': {},
        'optimizations': []
    }
    
    # 1. Environment Variables Check
    print("\n🔐 Checking Environment Variables...")
    env_vars = ['AIRTABLE_API_KEY', 'META_ACCESS_TOKEN', 'META_AD_ACCOUNT_ID', 'META_PIXEL_ID']
    
    for var in env_vars:
        value = os.getenv(var)
        status = {
            'exists': value is not None,
            'length': len(value) if value else 0,
            'valid': bool(value and len(value) > 10) if value else False
        }
        results['env_vars'][var] = status
        print(f"{'✅' if status['valid'] else '❌'} {var}: {'Valid' if status['valid'] else 'Invalid/Missing'}")
    
    # 2. Test Airtable Connection
    print("\n📊 Testing Airtable Connection...")
    try:
        airtable_key = os.getenv('AIRTABLE_API_KEY')
        if not airtable_key:
            print("❌ AIRTABLE_API_KEY missing")
            results['airtable']['status'] = 'missing_key'
            return results
            
        api = Api(airtable_key)
        
        # Test leads table
        leads_table = api.table('appwPsfAb2ZmWqhJD', 'tblhU4gONxgdA5jTF')
        sample_leads = leads_table.all(max_records=5)
        
        if sample_leads:
            leads_df = pd.DataFrame([record['fields'] for record in sample_leads])
            results['airtable']['leads'] = {
                'status': 'success',
                'count': len(leads_df),
                'columns': list(leads_df.columns),
                'sample': dict(leads_df.iloc[0]) if len(leads_df) > 0 else {}
            }
            print(f"✅ Leads: {len(leads_df)} records, {len(leads_df.columns)} columns")
            print(f"   Columns: {', '.join(leads_df.columns[:5])}...")
        
        # Test transactions table
        trans_table = api.table('appwPsfAb2ZmWqhJD', 'tbl364vtt5U8DxmT3')
        sample_trans = trans_table.all(max_records=5)
        
        if sample_trans:
            trans_df = pd.DataFrame([record['fields'] for record in sample_trans])
            results['airtable']['transactions'] = {
                'status': 'success',
                'count': len(trans_df),
                'columns': list(trans_df.columns),
                'sample': dict(trans_df.iloc[0]) if len(trans_df) > 0 else {}
            }
            print(f"✅ Transactions: {len(trans_df)} records, {len(trans_df.columns)} columns")
            print(f"   Columns: {', '.join(trans_df.columns[:5])}...")
            
            # Check for Amount column specifically
            if 'Amount' in trans_df.columns:
                amounts = pd.to_numeric(trans_df['Amount'], errors='coerce').dropna()
                total_revenue = amounts.sum()
                print(f"💰 Revenue Analysis: ${total_revenue:,.2f} from {len(amounts)} valid amounts")
                results['airtable']['revenue_check'] = {
                    'total_revenue': float(total_revenue),
                    'valid_amounts': len(amounts),
                    'avg_amount': float(amounts.mean()) if len(amounts) > 0 else 0
                }
        
    except Exception as e:
        print(f"❌ Airtable Error: {e}")
        results['airtable']['status'] = 'error'
        results['airtable']['error'] = str(e)
    
    # 3. Test Meta API Connection
    print("\n📈 Testing Meta API Connection...")
    try:
        access_token = os.getenv('META_ACCESS_TOKEN')
        ad_account_id = os.getenv('META_AD_ACCOUNT_ID')
        
        if not access_token or not ad_account_id:
            print("❌ Meta API credentials missing")
            results['meta']['status'] = 'missing_credentials'
            return results
        
        url = f"https://graph.facebook.com/v18.0/act_{ad_account_id}/insights"
        params = {
            'access_token': access_token,
            'fields': 'spend,impressions,clicks',
            'date_preset': 'last_7d',
            'limit': 3
        }
        
        response = requests.get(url, params=params, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            insights = data.get('data', [])
            total_spend = sum(float(insight.get('spend', 0)) for insight in insights)
            
            results['meta'] = {
                'status': 'success',
                'insights_count': len(insights),
                'total_spend': total_spend,
                'sample_insight': insights[0] if insights else {}
            }
            print(f"✅ Meta API: {len(insights)} insights, ${total_spend:,.2f} spend")
        else:
            print(f"❌ Meta API Error: HTTP {response.status_code}")
            results['meta']['status'] = 'api_error'
            results['meta']['http_code'] = response.status_code
            
    except Exception as e:
        print(f"❌ Meta API Exception: {e}")
        results['meta']['status'] = 'exception'
        results['meta']['error'] = str(e)
    
    # 4. Data Analysis (if Airtable works)
    if results['airtable'].get('leads', {}).get('status') == 'success':
        print("\n🎯 Analyzing Data Logic...")
        
        try:
            # Load full datasets for analysis
            leads_table = api.table('appwPsfAb2ZmWqhJD', 'tblhU4gONxgdA5jTF')
            all_leads = leads_table.all()
            leads_df = pd.DataFrame([record['fields'] for record in all_leads])
            
            trans_table = api.table('appwPsfAb2ZmWqhJD', 'tbl364vtt5U8DxmT3')
            all_trans = trans_table.all()
            trans_df = pd.DataFrame([record['fields'] for record in all_trans])
            
            print(f"📊 Full Dataset: {len(leads_df)} leads, {len(trans_df)} transactions")
            
            # Filtering Analysis
            original_count = len(leads_df)
            
            # Brand filtering
            brand_filtered = 0
            if 'Brand' in leads_df.columns:
                brand_mask = leads_df['Brand'].astype(str).str.contains('Smooth MD', case=False, na=False)
                brand_filtered = brand_mask.sum()
                print(f"🏷️  Brand Filter: {brand_filtered} Smooth MD leads")
            
            # Source filtering
            source_filtered = 0
            if 'Contact Source' in leads_df.columns:
                source_mask = leads_df['Contact Source'].astype(str).str.contains(
                    'Facebook|Instagram|Meta', case=False, na=False
                )
                source_filtered = source_mask.sum()
                print(f"📱 Source Filter: {source_filtered} Meta leads")
            
            # Combined filtering
            filtered_df = leads_df.copy()
            if 'Brand' in leads_df.columns:
                filtered_df = filtered_df[filtered_df['Brand'].astype(str).str.contains('Smooth MD', case=False, na=False)]
            if 'Contact Source' in filtered_df.columns:
                filtered_df = filtered_df[filtered_df['Contact Source'].astype(str).str.contains(
                    'Facebook|Instagram|Meta', case=False, na=False
                )]
            
            final_count = len(filtered_df)
            efficiency = (final_count / original_count) * 100 if original_count > 0 else 0
            
            print(f"🎯 Final Filter: {original_count} → {final_count} leads ({efficiency:.1f}% efficiency)")
            
            # Revenue matching analysis
            revenue_found = 0
            if 'Amount' in trans_df.columns:
                amounts = pd.to_numeric(trans_df['Amount'], errors='coerce').dropna()
                revenue_found = amounts.sum()
                print(f"💰 Total Revenue Available: ${revenue_found:,.2f}")
            
            results['data_analysis'] = {
                'original_leads': original_count,
                'brand_filtered': brand_filtered,
                'source_filtered': source_filtered,
                'final_filtered': final_count,
                'efficiency_percent': efficiency,
                'total_revenue': float(revenue_found)
            }
            
            # Generate optimizations
            if efficiency < 5:
                results['optimizations'].append("⚠️ Low filtering efficiency - review criteria")
            if revenue_found == 0:
                results['optimizations'].append("❌ No revenue found - check Amount column")
            if final_count == 0:
                results['optimizations'].append("🚨 No leads after filtering - criteria too strict")
            
        except Exception as e:
            print(f"❌ Data Analysis Error: {e}")
            results['data_analysis']['error'] = str(e)
    
    # 5. Summary
    print("\n📋 Audit Summary:")
    print(f"🔐 Environment: {'✅' if all(v['valid'] for v in results['env_vars'].values()) else '❌'}")
    print(f"📊 Airtable: {'✅' if results['airtable'].get('leads', {}).get('status') == 'success' else '❌'}")
    print(f"📈 Meta API: {'✅' if results['meta'].get('status') == 'success' else '❌'}")
    
    if results['optimizations']:
        print("\n🚀 Optimizations Needed:")
        for opt in results['optimizations']:
            print(f"   {opt}")
    else:
        print("\n✅ All systems optimal!")
    
    return results

if __name__ == "__main__":
    audit_results = run_direct_audit()
    
    # Save results to file for reference
    with open('audit_results.json', 'w') as f:
        json.dump(audit_results, f, indent=2, default=str)
    
    print(f"\n💾 Results saved to audit_results.json")