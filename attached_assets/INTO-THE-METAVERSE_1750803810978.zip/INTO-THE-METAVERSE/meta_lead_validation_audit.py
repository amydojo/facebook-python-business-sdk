"""
Meta Lead Validation & Attribution Audit System
Comprehensive validation that transactions truly come from Meta ad leads
Traces complete customer journey: Meta Ad → Lead → Booking → Purchase → Payment
"""

import streamlit as st
import pandas as pd
import os
from pyairtable import Api
from datetime import datetime, timedelta
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

def apply_validation_styling():
    """Apply styling for validation dashboard"""
    st.markdown("""
    <style>
    .validation-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 15px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }
    
    .journey-step {
        background: white;
        border: 2px solid #e1e5e9;
        border-radius: 10px;
        padding: 1rem;
        margin: 0.5rem 0;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .step-verified {
        border-color: #28a745;
        background: #f8fff9;
    }
    
    .step-warning {
        border-color: #ffc107;
        background: #fffdf0;
    }
    
    .step-error {
        border-color: #dc3545;
        background: #fff5f5;
    }
    
    .metric-card {
        background: white;
        border-radius: 12px;
        padding: 1.5rem;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        border-left: 4px solid #667eea;
    }
    </style>
    """, unsafe_allow_html=True)

class MetaLeadValidator:
    """Validates Meta lead attribution through complete customer journey"""
    
    def __init__(self):
        self.api_key = os.environ.get('AIRTABLE_API_KEY')
        if not self.api_key:
            st.error("Missing Airtable API key for validation")
            return
            
        self.base_id = 'appri2CgCoIiuZWq3'
        self.api = Api(self.api_key)
        
    def load_complete_dataset(self):
        """Load all required data for validation"""
        try:
            # Load leads data
            leads_table = self.api.table(self.base_id, 'Leads')
            leads_records = leads_table.all()
            
            # Load transactions from Social Media view
            trans_table = self.api.table(self.base_id, 'Transactions')
            trans_records = trans_table.all(view='Social Media')
            
            return leads_records, trans_records
        except Exception as e:
            st.error(f"Failed to load data: {e}")
            return [], []
    
    def extract_meta_leads(self, leads_records):
        """Extract and validate Meta leads with detailed attribution"""
        meta_leads = []
        meta_indicators = ['instagram', 'facebook', 'meta', 'fb', 'ig', 'instagram dm']
        
        for lead in leads_records:
            fields = lead.get('fields', {})
            lead_id = lead.get('id', '')
            
            # Get lead details
            contact_source = str(fields.get('Contact Source', '')).lower()
            brand = str(fields.get('Brand', '')).lower()
            overall_status = fields.get('Overall Status', '')
            created_time = fields.get('Inbound', '')
            
            # Check if this is a Meta lead for Smooth MD
            is_meta_source = any(indicator in contact_source for indicator in meta_indicators)
            is_smooth_md = 'smooth' in brand and ('md' in brand or 'm.d.' in brand)
            
            if is_meta_source and is_smooth_md:
                meta_leads.append({
                    'lead_id': lead_id,
                    'contact_source': fields.get('Contact Source', ''),
                    'brand': fields.get('Brand', ''),
                    'overall_status': overall_status,
                    'created_date': created_time,
                    'first_name': fields.get('First', ''),
                    'last_name': fields.get('Last', ''),
                    'email': fields.get('Email', ''),
                    'phone': fields.get('Phone', ''),
                    'referral_source': fields.get('How did you hear about us?', ''),
                    'is_booked': self._is_booked(overall_status),
                    'is_converted': self._is_converted(overall_status)
                })
        
        return meta_leads
    
    def extract_smooth_md_transactions(self, trans_records):
        """Extract Smooth MD transactions with customer matching info"""
        transactions = []
        meta_indicators = ['instagram', 'facebook', 'meta', 'fb', 'ig', 'instagram dm']
        
        for trans in trans_records:
            fields = trans.get('fields', {})
            
            # Get transaction details
            amount = fields.get('Amount', 0)
            brand_data = fields.get('Brand (from ID)', [])
            brand = brand_data[0] if isinstance(brand_data, list) and brand_data else str(brand_data)
            
            source_data = fields.get('Contact Source (from ID)', [])
            contact_source = source_data[0] if isinstance(source_data, list) and source_data else str(source_data)
            
            # Check if this is Smooth MD Meta transaction
            is_smooth_md = 'smooth' in brand.lower() and ('md' in brand.lower() or 'm.d.' in brand.lower())
            is_meta_source = any(indicator in contact_source.lower() for indicator in meta_indicators)
            
            if isinstance(amount, (int, float)) and amount > 0 and is_smooth_md and is_meta_source:
                transactions.append({
                    'transaction_id': trans.get('id', ''),
                    'amount': amount,
                    'brand': brand,
                    'contact_source': contact_source,
                    'services': fields.get('Services Purchased', ''),
                    'customer_first': fields.get('First (from ID)', []),
                    'customer_last': fields.get('Last (from ID)', []),
                    'customer_email': fields.get('Email (from ID)', []),
                    'customer_phone': fields.get('Phone (from ID)', []),
                    'purchase_date': fields.get('Date', ''),
                    'patient_id': fields.get('ID (from ID)', [])
                })
        
        return transactions
    
    def validate_lead_to_transaction_matching(self, meta_leads, transactions):
        """Validate that transactions actually match Meta leads"""
        validated_matches = []
        unmatched_transactions = []
        
        for trans in transactions:
            # Extract customer info from transaction
            customer_first = trans['customer_first']
            customer_last = trans['customer_last']
            customer_email = trans['customer_email']
            customer_phone = trans['customer_phone']
            
            # Find matching lead
            matched_lead = None
            match_criteria = []
            
            for lead in meta_leads:
                matches = 0
                criteria = []
                
                # Check first name match
                if customer_first and lead['first_name']:
                    if isinstance(customer_first, list):
                        first_trans = customer_first[0] if customer_first else ''
                    else:
                        first_trans = str(customer_first)
                    
                    if first_trans.lower().strip() == lead['first_name'].lower().strip():
                        matches += 1
                        criteria.append('First Name')
                
                # Check last name match
                if customer_last and lead['last_name']:
                    if isinstance(customer_last, list):
                        last_trans = customer_last[0] if customer_last else ''
                    else:
                        last_trans = str(customer_last)
                    
                    if last_trans.lower().strip() == lead['last_name'].lower().strip():
                        matches += 1
                        criteria.append('Last Name')
                
                # Check email match
                if customer_email and lead['email']:
                    if isinstance(customer_email, list):
                        email_trans = customer_email[0] if customer_email else ''
                    else:
                        email_trans = str(customer_email)
                    
                    if email_trans.lower().strip() == lead['email'].lower().strip():
                        matches += 1
                        criteria.append('Email')
                
                # Check phone match (normalize phone numbers)
                if customer_phone and lead['phone']:
                    if isinstance(customer_phone, list):
                        phone_trans = customer_phone[0] if customer_phone else ''
                    else:
                        phone_trans = str(customer_phone)
                    
                    # Normalize phone numbers for comparison
                    phone_trans_norm = ''.join(filter(str.isdigit, phone_trans))[-10:]
                    phone_lead_norm = ''.join(filter(str.isdigit, lead['phone']))[-10:]
                    
                    if phone_trans_norm and phone_lead_norm and phone_trans_norm == phone_lead_norm:
                        matches += 1
                        criteria.append('Phone')
                
                # If we have strong matches, consider this the lead
                if matches >= 2:  # Require at least 2 matching criteria
                    matched_lead = lead
                    match_criteria = criteria
                    break
            
            if matched_lead:
                validated_matches.append({
                    'transaction': trans,
                    'lead': matched_lead,
                    'match_criteria': match_criteria,
                    'match_strength': len(match_criteria),
                    'validation_status': 'VERIFIED' if len(match_criteria) >= 2 else 'WEAK_MATCH'
                })
            else:
                unmatched_transactions.append(trans)
        
        return validated_matches, unmatched_transactions
    
    def create_customer_journey_timeline(self, validated_matches):
        """Create timeline visualization of customer journeys"""
        journey_data = []
        
        for match in validated_matches:
            trans = match['transaction']
            lead = match['lead']
            
            # Create journey steps
            journey_data.append({
                'Customer': f"{lead['first_name']} {lead['last_name']}",
                'Step': 'Meta Ad Exposure',
                'Date': lead['created_date'],
                'Details': f"Source: {lead['contact_source']}",
                'Amount': 0,
                'Step_Order': 1
            })
            
            journey_data.append({
                'Customer': f"{lead['first_name']} {lead['last_name']}",
                'Step': 'Lead Generated',
                'Date': lead['created_date'],
                'Details': f"Status: {lead['overall_status']}",
                'Amount': 0,
                'Step_Order': 2
            })
            
            if lead['is_booked']:
                journey_data.append({
                    'Customer': f"{lead['first_name']} {lead['last_name']}",
                    'Step': 'Consultation Booked',
                    'Date': lead['created_date'],
                    'Details': 'Appointment scheduled',
                    'Amount': 0,
                    'Step_Order': 3
                })
            
            if lead['is_converted']:
                journey_data.append({
                    'Customer': f"{lead['first_name']} {lead['last_name']}",
                    'Step': 'Service Purchased',
                    'Date': trans['purchase_date'],
                    'Details': f"Service: {trans['services']}",
                    'Amount': trans['amount'],
                    'Step_Order': 4
                })
        
        return pd.DataFrame(journey_data)
    
    def _is_booked(self, status):
        """Check if lead is booked"""
        booked_statuses = ['booked', 'scheduled', 'appointment', 'confirmed']
        return any(keyword in str(status).lower() for keyword in booked_statuses)
    
    def _is_converted(self, status):
        """Check if lead converted"""
        converted_statuses = ['closed', 'won', 'purchased', 'converted', 'customer']
        return any(keyword in str(status).lower() for keyword in converted_statuses)

def main():
    """Main validation dashboard"""
    st.set_page_config(
        page_title="Meta Lead Validation Audit",
        page_icon="🔍",
        layout="wide"
    )
    
    apply_validation_styling()
    
    # Header
    st.markdown("""
    <div class="validation-header">
        <h1>🔍 Meta Lead Validation & Attribution Audit</h1>
        <p>Comprehensive validation that transactions truly come from Meta ad leads</p>
        <p>Traces complete customer journey: Meta Ad → Lead → Booking → Purchase → Payment</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize validator
    validator = MetaLeadValidator()
    
    if not validator.api_key:
        st.error("Unable to initialize validator - missing API key")
        return
    
    # Load and process data
    with st.spinner("Loading and validating data..."):
        leads_records, trans_records = validator.load_complete_dataset()
        
        if not leads_records or not trans_records:
            st.error("Failed to load required data")
            return
        
        # Extract Meta leads and transactions
        meta_leads = validator.extract_meta_leads(leads_records)
        smooth_md_transactions = validator.extract_smooth_md_transactions(trans_records)
        
        # Validate matching
        validated_matches, unmatched_transactions = validator.validate_lead_to_transaction_matching(
            meta_leads, smooth_md_transactions
        )
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div class="metric-card">
            <h3>Meta Leads Found</h3>
            <h2 style="color: #667eea;">{}</h2>
            <p>Smooth MD leads from Meta sources</p>
        </div>
        """.format(len(meta_leads)), unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="metric-card">
            <h3>Transactions Found</h3>
            <h2 style="color: #667eea;">{}</h2>
            <p>Smooth MD Meta transactions</p>
        </div>
        """.format(len(smooth_md_transactions)), unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div class="metric-card">
            <h3>Validated Matches</h3>
            <h2 style="color: #28a745;">{}</h2>
            <p>Verified lead-to-transaction connections</p>
        </div>
        """.format(len(validated_matches)), unsafe_allow_html=True)
    
    with col4:
        verified_revenue = sum(match['transaction']['amount'] for match in validated_matches)
        st.markdown("""
        <div class="metric-card">
            <h3>Verified Revenue</h3>
            <h2 style="color: #28a745;">${:,.2f}</h2>
            <p>Revenue from validated Meta leads</p>
        </div>
        """.format(verified_revenue), unsafe_allow_html=True)
    
    # Detailed validation results
    st.header("🔍 Detailed Validation Results")
    
    tabs = st.tabs(["Validated Matches", "Customer Journeys", "Unmatched Transactions", "Raw Data"])
    
    with tabs[0]:
        st.subheader("Verified Lead-to-Transaction Connections")
        
        if validated_matches:
            for i, match in enumerate(validated_matches, 1):
                trans = match['transaction']
                lead = match['lead']
                criteria = match['match_criteria']
                
                status_class = "step-verified" if match['validation_status'] == 'VERIFIED' else "step-warning"
                
                st.markdown(f"""
                <div class="journey-step {status_class}">
                    <h4>Match #{i} - {match['validation_status']}</h4>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div>
                            <h5>📧 Lead Information</h5>
                            <p><strong>Name:</strong> {lead['first_name']} {lead['last_name']}</p>
                            <p><strong>Source:</strong> {lead['contact_source']}</p>
                            <p><strong>Created:</strong> {lead['created_date']}</p>
                            <p><strong>Status:</strong> {lead['overall_status']}</p>
                            <p><strong>Email:</strong> {lead['email']}</p>
                            <p><strong>Phone:</strong> {lead['phone']}</p>
                        </div>
                        <div>
                            <h5>💳 Transaction Information</h5>
                            <p><strong>Amount:</strong> ${trans['amount']:,.2f}</p>
                            <p><strong>Service:</strong> {trans['services']}</p>
                            <p><strong>Date:</strong> {trans['purchase_date']}</p>
                            <p><strong>Brand:</strong> {trans['brand']}</p>
                            <p><strong>Match Criteria:</strong> {', '.join(criteria)}</p>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.warning("No validated matches found. This may indicate data quality issues.")
    
    with tabs[1]:
        st.subheader("Complete Customer Journeys")
        
        if validated_matches:
            journey_df = validator.create_customer_journey_timeline(validated_matches)
            
            # Create journey visualization
            fig = px.timeline(
                journey_df,
                x_start="Date",
                x_end="Date",
                y="Customer",
                color="Step",
                title="Customer Journey Timeline: Meta Ad → Purchase"
            )
            st.plotly_chart(fig, use_container_width=True)
            
            # Journey summary
            st.subheader("Journey Analysis")
            
            total_customers = len(validated_matches)
            total_revenue = sum(match['transaction']['amount'] for match in validated_matches)
            avg_transaction = total_revenue / total_customers if total_customers > 0 else 0
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Complete Journeys", total_customers)
            with col2:
                st.metric("Total Revenue", f"${total_revenue:,.2f}")
            with col3:
                st.metric("Average Transaction", f"${avg_transaction:,.2f}")
        
    with tabs[2]:
        st.subheader("Unmatched Transactions")
        
        if unmatched_transactions:
            st.warning(f"Found {len(unmatched_transactions)} transactions that couldn't be matched to Meta leads")
            
            for i, trans in enumerate(unmatched_transactions, 1):
                st.markdown(f"""
                <div class="journey-step step-warning">
                    <h5>Unmatched Transaction #{i}</h5>
                    <p><strong>Amount:</strong> ${trans['amount']:,.2f}</p>
                    <p><strong>Service:</strong> {trans['services']}</p>
                    <p><strong>Source:</strong> {trans['contact_source']}</p>
                    <p><strong>Customer Info:</strong> {trans['customer_first']} {trans['customer_last']}</p>
                    <p><em>This transaction may not be from a Meta ad lead</em></p>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.success("All transactions successfully matched to Meta leads!")
    
    with tabs[3]:
        st.subheader("Raw Data for Manual Review")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Meta Leads:**")
            if meta_leads:
                leads_df = pd.DataFrame(meta_leads)
                st.dataframe(leads_df, use_container_width=True)
        
        with col2:
            st.write("**Smooth MD Transactions:**")
            if smooth_md_transactions:
                trans_df = pd.DataFrame(smooth_md_transactions)
                st.dataframe(trans_df, use_container_width=True)
    
    # Recommendations
    st.header("📋 Validation Summary & Recommendations")
    
    validation_score = (len(validated_matches) / len(smooth_md_transactions) * 100) if smooth_md_transactions else 0
    
    if validation_score >= 90:
        st.success(f"✅ Excellent validation rate: {validation_score:.1f}% of transactions verified")
    elif validation_score >= 70:
        st.warning(f"⚠️ Good validation rate: {validation_score:.1f}% of transactions verified")
    else:
        st.error(f"❌ Low validation rate: {validation_score:.1f}% of transactions verified")
    
    st.write("**Key Findings:**")
    st.write(f"• {len(validated_matches)} transactions successfully traced back to Meta ads")
    st.write(f"• ${verified_revenue:,.2f} in verified revenue from Meta lead attribution")
    st.write(f"• {len(unmatched_transactions)} transactions need further investigation")
    
    if validation_score < 100:
        st.write("**Recommendations:**")
        st.write("• Review unmatched transactions for data quality issues")
        st.write("• Ensure consistent customer data entry across systems")
        st.write("• Consider implementing stronger lead tracking mechanisms")

if __name__ == "__main__":
    main()