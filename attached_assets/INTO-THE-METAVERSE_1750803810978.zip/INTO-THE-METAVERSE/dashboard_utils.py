"""
Dashboard utilities for Ad Command Center
Including improved transaction matching and data validation
"""
import pandas as pd
import numpy as np
import streamlit as st
import time
import os
from datetime import datetime, timedelta
import json
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('ad_command_center')

# Enable debug mode
DEBUG_MODE = False

def set_debug_mode(enabled=True):
    """Enable or disable debug mode"""
    global DEBUG_MODE
    DEBUG_MODE = enabled
    level = logging.DEBUG if enabled else logging.INFO
    logger.setLevel(level)
    return DEBUG_MODE

def log_debug(message):
    """Log debug message if debug mode is enabled"""
    if DEBUG_MODE:
        logger.debug(message)
        st.sidebar.write(f"DEBUG: {message}")

def log_info(message):
    """Log info message"""
    logger.info(message)
    if DEBUG_MODE:
        st.sidebar.write(f"INFO: {message}")

def log_error(message, exception=None):
    """Log error message with optional exception details"""
    if exception:
        error_details = f"{message}: {str(exception)}"
        logger.error(error_details, exc_info=True)
        if DEBUG_MODE:
            st.sidebar.error(error_details)
    else:
        logger.error(message)
        if DEBUG_MODE:
            st.sidebar.error(message)

def match_lead_transactions(leads_df, transactions_df):
    """
    Match leads with their corresponding transactions using a safe implementation
    that avoids array truth value errors
    
    Args:
        leads_df (pd.DataFrame): DataFrame containing lead data
        transactions_df (pd.DataFrame): DataFrame containing transaction data
        
    Returns:
        pd.DataFrame: Leads DataFrame with transaction data added
    """
    start_time = time.time()
    
    # Early return for empty data
    if (leads_df is None or transactions_df is None or 
        leads_df.empty or transactions_df.empty):
        log_error("Missing lead or transaction data for accurate ROI calculation")
        return leads_df
    
    # Data validation - ensure we have the expected columns
    log_info(f"Transactions columns: {transactions_df.columns.tolist()}")
    log_info(f"Leads columns: {leads_df.columns.tolist()}")
    
    # Create a copy of leads_df to avoid modifying the original
    enriched_leads = leads_df.copy()
    
    # Initialize transaction data columns
    enriched_leads['transaction_count'] = 0
    enriched_leads['transaction_total'] = 0.0
    
    # Find amount field
    amount_field = None
    for field in ['Amount', 'Revenue', 'Payment', 'Value', 'Price', 'Total']:
        if field in transactions_df.columns:
            amount_field = field
            log_info(f"Using amount field: {field}")
            break
    
    if not amount_field:
        log_error("Could not find amount field in transactions data")
        return leads_df
    
    # Create clean version of transactions with standardized amount
    tx_df = transactions_df.copy()
    
    # Convert amount to numeric safely
    try:
        tx_df['clean_amount'] = tx_df[amount_field].apply(
            lambda x: pd.to_numeric(
                str(x).replace('$', '').replace(',', '') if isinstance(x, str) else x,
                errors='coerce'
            )
        ).fillna(0.0)
    except Exception as e:
        log_error(f"Error cleaning amount field", e)
        tx_df['clean_amount'] = 0.0
    
    # Define potential identifier fields
    email_fields = ['Email', 'email', 'email_address', 'Email Address']
    phone_fields = ['Phone', 'phone', 'Phone number', 'phone_number', 'Phone Number']
    id_fields = ['id', 'ID', 'recID', 'record_id']
    
    # Track matching statistics
    matched_count = 0
    matched_leads = set()
    
    # Safe string comparison function
    def safe_string_match(val1, val2):
        """Compare strings safely, avoiding array truth value issues"""
        if pd.isna(val1) or pd.isna(val2):
            return False
            
        try:
            str1 = str(val1).strip().lower()
            str2 = str(val2).strip().lower()
            return str1 in str2 or str2 in str1
        except:
            return False
    
    # Process each lead
    for idx, lead in enriched_leads.iterrows():
        # Extract lead identifiers
        lead_id = None
        lead_email = None
        lead_phone = None
        
        # Get lead ID
        for id_field in id_fields:
            if id_field in lead and pd.notna(lead[id_field]):
                lead_id = str(lead[id_field])
                break
                
        # Get lead email
        for email_field in email_fields:
            if email_field in lead and pd.notna(lead[email_field]):
                lead_email = str(lead[email_field]).lower().strip()
                break
                
        # Get lead phone
        for phone_field in phone_fields:
            if phone_field in lead and pd.notna(lead[phone_field]):
                # Clean phone to digits only
                lead_phone = ''.join(c for c in str(lead[phone_field]) if c.isdigit())
                if len(lead_phone) >= 10:  # Ensure it's a valid phone
                    break
                else:
                    lead_phone = None
        
        # Skip leads with no identifiable info
        if not lead_id and not lead_email and not lead_phone:
            continue
            
        # Find matching transactions
        matches = []
        
        # For each transaction, look for matches with this lead
        for _, tx in tx_df.iterrows():
            # Track if we found a match
            found_match = False
            
            # Try ID matching
            if lead_id:
                for tx_field in tx.index:
                    if tx_field == 'clean_amount' or pd.isna(tx[tx_field]):
                        continue
                        
                    # String comparison
                    if isinstance(tx[tx_field], str):
                        if lead_id in tx[tx_field]:
                            found_match = True
                            if DEBUG_MODE:
                                log_debug(f"ID match: {lead_id} found in field {tx_field}")
                            break
            
            # Try email matching
            if not found_match and lead_email:
                for tx_email_field in email_fields:
                    if tx_email_field in tx and pd.notna(tx[tx_email_field]):
                        tx_email = str(tx[tx_email_field]).lower().strip()
                        if lead_email == tx_email:
                            found_match = True
                            if DEBUG_MODE:
                                log_debug(f"Email match: {lead_email}")
                            break
            
            # Try phone matching
            if not found_match and lead_phone:
                for tx_phone_field in phone_fields:
                    if tx_phone_field in tx and pd.notna(tx[tx_phone_field]):
                        tx_phone = ''.join(c for c in str(tx[tx_phone_field]) if c.isdigit())
                        if len(tx_phone) >= 10 and lead_phone[-10:] == tx_phone[-10:]:
                            found_match = True
                            if DEBUG_MODE:
                                log_debug(f"Phone match: {lead_phone[-10:]} = {tx_phone[-10:]}")
                            break
            
            if found_match:
                matches.append(tx)
        
        # Process matches for this lead
        if matches:
            matched_count += len(matches)
            matched_leads.add(idx)
            
            # Calculate transaction totals
            transaction_count = len(matches)
            total_amount = sum(tx['clean_amount'] for tx in matches)
            
            # Update lead record
            enriched_leads.at[idx, 'transaction_count'] = transaction_count
            enriched_leads.at[idx, 'transaction_total'] = total_amount
    
    # Log matching results
    log_info(f"Matched {matched_count} transactions to {len(matched_leads)} leads")
    log_info(f"Total matched transaction revenue: ${enriched_leads['transaction_total'].sum():.2f}")
    log_info(f"Transaction matching completed in {time.time() - start_time:.2f} seconds")
    
    return enriched_leads

def validate_meta_api_response(response, expected_fields=None):
    """
    Validate Meta API response to ensure it contains required data
    
    Args:
        response (dict): API response 
        expected_fields (list): Fields expected in the response
        
    Returns:
        tuple: (is_valid, error_message)
    """
    if not isinstance(response, dict):
        return False, f"Invalid response type: {type(response)}"
        
    if "error" in response:
        error_msg = response.get("error", {}).get("message", "Unknown API error")
        error_code = response.get("error", {}).get("code", "")
        return False, f"API Error {error_code}: {error_msg}"
        
    if "status" in response and response["status"] == "error":
        return False, response.get("message", "Unknown error")
        
    if expected_fields:
        for field in expected_fields:
            if field not in response:
                return False, f"Missing required field: {field}"
                
    return True, ""

def format_currency(value):
    """Format value as currency"""
    return f"${value:,.2f}"

def format_percent(value):
    """Format value as percentage"""
    return f"{value:.1f}%"

def format_integer(value):
    """Format value as integer with commas"""
    return f"{int(value):,}"

def create_debug_panel():
    """Create debug panel for troubleshooting"""
    with st.sidebar.expander("Debug Tools", expanded=DEBUG_MODE):
        enable_debug = st.checkbox("Enable Debug Mode", value=DEBUG_MODE)
        if enable_debug != DEBUG_MODE:
            set_debug_mode(enable_debug)
            
        if st.button("Clear Session State"):
            for key in list(st.session_state.keys()):
                if key != 'debug_mode':
                    del st.session_state[key]
            st.success("Session state cleared")
            
        if st.button("Show Session State"):
            st.write(st.session_state)
            
        if st.button("Test API Connections"):
            test_results = {}
            # Test Airtable
            try:
                from pyairtable import Api
                api_key = os.environ.get("AIRTABLE_API_KEY")
                base_id = st.session_state.get("base_id", "appri2CgCoIiuZWq3")
                api = Api(api_key)
                tables = api.base(base_id).tables
                test_results["Airtable"] = f"Connected successfully, found {len(tables)} tables"
            except Exception as e:
                test_results["Airtable"] = f"ERROR: {str(e)}"
                
            # Test Meta API
            try:
                import requests
                from enhanced_meta_api import EnhancedMetaAPI
                api = EnhancedMetaAPI()
                response = api.get_campaigns()
                valid, message = validate_meta_api_response(response)
                if valid:
                    test_results["Meta API"] = f"Connected successfully, found {len(response.get('data', []))} campaigns"
                else:
                    test_results["Meta API"] = f"ERROR: {message}"
            except Exception as e:
                test_results["Meta API"] = f"ERROR: {str(e)}"
                
            st.json(test_results)