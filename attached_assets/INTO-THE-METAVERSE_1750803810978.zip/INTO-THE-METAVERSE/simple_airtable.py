"""
Simple, Robust Airtable Connection
Focused on reliability and real data without complex caching
"""
import pandas as pd
import streamlit as st
from pyairtable import Api
import time

def load_airtable_simple(api_key, base_id, table_name):
    """Simple, reliable Airtable data loading"""
    
    if not api_key or not base_id or not table_name:
        st.error("🔑 Missing Airtable credentials. Please check your settings.")
        return pd.DataFrame()
    
    try:
        with st.spinner(f"Loading {table_name} from Airtable..."):
            start_time = time.time()
            
            # Connect to Airtable
            api = Api(api_key)
            table = api.table(base_id, table_name)
            
            # Get all records
            records = table.all()
            load_time = time.time() - start_time
            
            if not records:
                st.warning(f"⚠️ No records found in {table_name} table")
                return pd.DataFrame()
            
            # Convert to DataFrame
            data = []
            for record in records:
                fields = record.get('fields', {})
                fields['airtable_id'] = record['id']  # Keep Airtable record ID
                data.append(fields)
            
            df = pd.DataFrame(data)
            
            st.success(f"✅ Loaded {len(df)} records from {table_name} ({load_time:.2f}s)")
            
            # Show column info for debugging
            with st.expander(f"📋 {table_name} Data Info"):
                st.write(f"**Columns found:** {', '.join(df.columns.tolist())}")
                st.write(f"**Data shape:** {df.shape[0]} rows × {df.shape[1]} columns")
                
                # Show sample data
                if len(df) > 0:
                    st.write("**Sample data:**")
                    st.dataframe(df.head(3))
            
            return df
            
    except Exception as e:
        st.error(f"❌ Failed to load {table_name}: {str(e)}")
        
        # Show helpful error guidance
        if "401" in str(e) or "unauthorized" in str(e).lower():
            st.info("🔧 **Fix:** Check your Airtable API key permissions")
        elif "404" in str(e) or "not found" in str(e).lower():
            st.info("🔧 **Fix:** Verify your Base ID and table name are correct")
        else:
            st.info("🔧 **Fix:** Check your internet connection and try again")
        
        return pd.DataFrame()

def find_status_column(df):
    """Smart detection of status/conversion tracking columns"""
    
    if df.empty:
        return None, [], []
    
    # Priority order for status columns
    exact_matches = ['Overall Status', 'Status', 'Lead Status', 'Current Status', 'Stage', 'Phase']
    
    # Check exact matches first
    for col in exact_matches:
        if col in df.columns:
            return col, df.columns.tolist(), df[col].unique()[:10].tolist()
    
    # Check partial matches
    partial_matches = []
    for col in df.columns:
        col_lower = col.lower()
        if any(keyword in col_lower for keyword in ['status', 'stage', 'phase', 'state', 'step']):
            partial_matches.append(col)
    
    if partial_matches:
        return partial_matches[0], df.columns.tolist(), df[partial_matches[0]].unique()[:10].tolist()
    
    return None, df.columns.tolist(), []

def process_leads_for_conversion(df, status_column=None):
    """Process leads data for conversion tracking"""
    
    if df.empty:
        return df
    
    # Make a copy to avoid modifying original
    processed_df = df.copy()
    
    if status_column and status_column in processed_df.columns:
        # Define booking/conversion keywords
        booking_keywords = [
            'booked', 'scheduled', 'appointment', 'consultation', 
            'confirmed', 'meeting', 'call scheduled'
        ]
        
        conversion_keywords = [
            'closed', 'converted', 'sale', 'purchase', 'completed',
            'paid', 'deposit', 'surgery', 'treatment', 'signed'
        ]
        
        # Create conversion flags
        processed_df['is_booked'] = processed_df[status_column].apply(
            lambda x: any(keyword in str(x).lower() for keyword in booking_keywords) if pd.notna(x) else False
        )
        
        processed_df['is_converted'] = processed_df[status_column].apply(
            lambda x: any(keyword in str(x).lower() for keyword in conversion_keywords) if pd.notna(x) else False
        )
        
        # Calculate metrics
        total_leads = len(processed_df)
        booked_count = processed_df['is_booked'].sum()
        converted_count = processed_df['is_converted'].sum()
        
        booking_rate = (booked_count / total_leads * 100) if total_leads > 0 else 0
        conversion_rate = (converted_count / total_leads * 100) if total_leads > 0 else 0
        
        st.info(f"""
        📊 **Conversion Tracking Results:**
        - Total Leads: {total_leads:,}
        - Booked: {booked_count:,} ({booking_rate:.1f}%)
        - Converted: {converted_count:,} ({conversion_rate:.1f}%)
        """)
        
    else:
        # Set default values if no status column
        processed_df['is_booked'] = False
        processed_df['is_converted'] = False
        st.warning("⚠️ No status column found - using default conversion values")
    
    return processed_df

def filter_meta_leads_simple(df):
    """Simple, reliable filtering for Meta leads"""
    
    if df.empty:
        return df
    
    # Look for source columns
    source_columns = []
    for col in df.columns:
        col_lower = col.lower()
        if any(keyword in col_lower for keyword in ['source', 'origin', 'channel', 'medium', 'referral']):
            source_columns.append(col)
    
    if not source_columns:
        st.warning("⚠️ No source column found - showing all leads")
        return df
    
    # Use the first source column found
    source_col = source_columns[0]
    st.info(f"📍 Using '{source_col}' column for source filtering")
    
    # Filter for Meta sources
    meta_keywords = ['facebook', 'instagram', 'meta', 'fb', 'ig']
    
    meta_filter = df[source_col].str.lower().str.contains('|'.join(meta_keywords), na=False)
    filtered_df = df[meta_filter].copy()
    
    st.success(f"🎯 Found {len(filtered_df)} Meta leads out of {len(df)} total leads")
    
    return filtered_df

def ensure_date_column_simple(df):
    """Simple date column detection and creation"""
    
    if df.empty:
        return df
    
    # Check if Date column already exists
    if 'Date' in df.columns:
        return df
    
    # Look for date-like columns
    date_columns = []
    for col in df.columns:
        col_lower = col.lower()
        if any(keyword in col_lower for keyword in ['date', 'time', 'created', 'submitted', 'inbound']):
            date_columns.append(col)
    
    if date_columns:
        # Use the first date column found
        date_col = date_columns[0]
        df['Date'] = df[date_col]
        st.info(f"📅 Using '{date_col}' as Date column")
    else:
        st.warning("⚠️ No date column found - some time-based analysis may be limited")
    
    return df