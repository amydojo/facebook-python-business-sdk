"""
Reliable Data Connector
Reverse-engineered from working implementations with robust error handling
"""

import pandas as pd
import requests
import logging
import time
import hashlib
import pickle
import os
from datetime import datetime, timedelta
from pyairtable import Api
from typing import Dict, Tuple, List, Optional, Any
from config_manager import get_config
from kv_cache_manager import (
    cache_manager, cache_transactions, get_cached_transactions,
    cache_leads, get_cached_leads, cache_meta_insights, get_cached_meta_insights
)

# Configure robust logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ReliableDataConnector:
    """Robust data connector with advanced caching, validation, and error handling"""

    def __init__(self):
        self.config = get_config()
        self.api_key, self.base_id, self.tables = self.config.get_airtable_config()
        self.meta_token, self.meta_account_id, self.meta_pixel_id = self.config.get_meta_config()
        self.filters = self.config.get_data_filters()

        # Initialize caching system
        self.cache_dir = 'data_cache'
        self._ensure_cache_dir()

        # Performance tracking
        self.request_times = []
        self.error_counts = {'airtable': 0, 'meta': 0}

        # Validation rules
        self.validation_rules = {
            'min_transaction_amount': 1.0,
            'max_transaction_amount': 100000.0,
            'required_fields': {
                'transaction': ['date', 'amount', 'brand'],
                'lead': ['date', 'source', 'brand']
            }
        }

    def _ensure_cache_dir(self):
        """Ensure cache directory exists"""
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)
            logger.info(f"Created cache directory: {self.cache_dir}")

    def _get_cache_key(self, operation: str, params: Dict) -> str:
        """Generate consistent cache key"""
        # Convert params to sorted string for consistent hashing
        params_str = str(sorted(params.items())) if params else ""
        key_string = f"{operation}_{params_str}"
        return hashlib.md5(key_string.encode()).hexdigest()

    def _get_from_cache(self, cache_key: str, ttl_minutes: int = 30) -> Optional[Any]:
        """Retrieve data from cache if valid"""
        cache_file = os.path.join(self.cache_dir, f"{cache_key}.pkl")

        if not os.path.exists(cache_file):
            return None

        # Check TTL
        file_time = datetime.fromtimestamp(os.path.getmtime(cache_file))
        if datetime.now() - file_time > timedelta(minutes=ttl_minutes):
            try:
                os.remove(cache_file)
                logger.info(f"Removed expired cache file: {cache_key}")
            except OSError:
                pass
            return None

        try:
            with open(cache_file, 'rb') as f:
                data = pickle.load(f)
                logger.info(f"Cache hit for operation: {cache_key[:8]}...")
                return data
        except Exception as e:
            logger.error(f"Cache read error for {cache_key}: {e}")
            return None

    def _save_to_cache(self, cache_key: str, data: Any) -> bool:
        """Save data to cache"""
        try:
            cache_file = os.path.join(self.cache_dir, f"{cache_key}.pkl")
            with open(cache_file, 'wb') as f:
                pickle.dump(data, f)
            logger.info(f"Cached data for operation: {cache_key[:8]}...")
            return True
        except Exception as e:
            logger.error(f"Cache write error for {cache_key}: {e}")
            return False

    def _validate_transaction_record(self, record: Dict) -> Tuple[bool, List[str]]:
        """Validate transaction record data quality"""
        issues = []
        fields = record.get('fields', {})

        # Check required fields
        for field in self.validation_rules['required_fields']['transaction']:
            if field == 'date' and not self._extract_date_field(fields):
                issues.append(f"Missing {field}")
            elif field == 'amount' and self._extract_amount_field(fields) <= 0:
                issues.append(f"Missing {field}")
            elif field == 'brand' and not self._extract_brand_field(fields):
                issues.append(f"Missing {field}")

        # Validate amount
        amount = self._extract_amount_field(fields)
        if amount < self.validation_rules['min_transaction_amount']:
            issues.append(f"Amount too low: {amount}")
        elif amount > self.validation_rules['max_transaction_amount']:
            issues.append(f"Amount too high: {amount}")

        # Validate date
        date_value = self._extract_date_field(fields)
        if not date_value:
            issues.append("Invalid date")

        return len(issues) == 0, issues

    def _retry_request(self, func, max_retries: int = 3, delay: float = 1.0, *args, **kwargs):
        """Retry mechanism for API requests"""
        for attempt in range(max_retries):
            try:
                start_time = time.time()
                result = func(*args, **kwargs)

                # Track performance
                request_time = time.time() - start_time
                self.request_times.append(request_time)

                return result

            except Exception as e:
                if attempt == max_retries - 1:
                    raise e

                wait_time = delay * (2 ** attempt)  # Exponential backoff
                logger.warning(f"Request failed (attempt {attempt + 1}/{max_retries}), retrying in {wait_time}s: {e}")
                time.sleep(wait_time)

        return None

    def load_transaction_data(self, start_date: str, end_date: str) -> Dict:
        """Load transaction data using proven field mapping patterns with robust error handling"""
        # Check cache first
        cache_params = {'start_date': start_date, 'end_date': end_date, 'operation': 'transactions'}
        cache_key = self._get_cache_key('load_transactions', cache_params)

        cached_data = self._get_from_cache(cache_key, ttl_minutes=15)
        if cached_data:
            return cached_data

        try:
            if not self.api_key:
                self.error_counts['airtable'] += 1
                return {'success': False, 'error': 'Airtable API key not configured'}

            # Use retry mechanism for API calls
            def _fetch_transactions():
                api = Api(self.api_key)
                table = api.table(self.base_id, self.tables['transactions'])
                return table.all()

            all_records = self._retry_request(_fetch_transactions)
            if not all_records:
                self.error_counts['airtable'] += 1
                return {'success': False, 'error': 'Failed to fetch transaction records'}

            logger.info(f"Loaded {len(all_records)} transaction records from Airtable")

            transactions = []
            total_revenue = 0

            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
            end_dt = datetime.strptime(end_date, '%Y-%m-%d')

            for record in all_records:
                fields = record.get('fields', {})

                # Extract date using multiple field patterns (reverse-engineered from working code)
                date_value = self._extract_date_field(fields)
                if not date_value:
                    continue

                try:
                    if isinstance(date_value, str):
                        if 'T' in date_value:
                            trans_dt = datetime.fromisoformat(date_value.replace('Z', '+00:00')).replace(tzinfo=None)
                        else:
                            trans_dt = datetime.strptime(date_value, '%Y-%m-%d')
                    else:
                        continue

                    # Filter by date range
                    if not (start_dt <= trans_dt <= end_dt):
                        continue

                except (ValueError, TypeError):
                    continue

                # Extract amount using multiple field patterns
                amount = self._extract_amount_field(fields)
                if amount <= 0:
                    continue

                # Extract brand and source using proven patterns
                brand = self._extract_brand_field(fields)
                source = self._extract_source_field(fields)
                service = self._extract_service_field(fields)

                # Apply Smooth MD Meta filtering (reverse-engineered logic)
                if not self._is_smooth_md_meta_transaction(brand, source):
                    continue

                transaction = {
                    'date': trans_dt.strftime('%Y-%m-%d'),
                    'amount': amount,
                    'brand': brand,
                    'source': source,
                    'service': service,
                    'record_id': record.get('id', '')
                }

                transactions.append(transaction)
                total_revenue += amount

            logger.info(f"Filtered to {len(transactions)} Smooth MD Meta transactions worth ${total_revenue:,.2f}")

            return {
                'success': True,
                'transactions': transactions,
                'total_revenue': total_revenue,
                'transaction_count': len(transactions),
                'date_range': f"{start_date} to {end_date}"
            }

        except Exception as e:
            logger.error(f"Transaction data loading error: {e}")
            return {'error': str(e)}

    def load_leads_data(self, start_date: str, end_date: str) -> Dict:
        """Load leads data using proven field mapping patterns"""
        try:
            if not self.api_key:
                return {'error': 'Airtable API key not configured'}

            api = Api(self.api_key)
            table = api.table(self.base_id, self.tables['leads'])

            all_records = table.all()
            logger.info(f"Loaded {len(all_records)} lead records from Airtable")

            leads = []
            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
            end_dt = datetime.strptime(end_date, '%Y-%m-%d')

            for record in all_records:
                fields = record.get('fields', {})

                # Extract date using multiple field patterns
                date_value = self._extract_date_field(fields, lead_record=True)
                if not date_value:
                    continue

                try:
                    if isinstance(date_value, str):
                        if 'T' in date_value:
                            lead_dt = datetime.fromisoformat(date_value.replace('Z', '+00:00')).replace(tzinfo=None)
                        else:
                            lead_dt = datetime.strptime(date_value, '%Y-%m-%d')
                    else:
                        continue

                    # Filter by date range
                    if not (start_dt <= lead_dt <= end_dt):
                        continue

                except (ValueError, TypeError):
                    continue

                # Extract fields using proven patterns
                brand = self._extract_brand_field(fields)
                source = self._extract_source_field(fields)
                status = self._extract_status_field(fields)

                # Apply Smooth MD Meta filtering
                if not self._is_smooth_md_meta_lead(brand, source):
                    continue

                lead = {
                    'date': lead_dt.strftime('%Y-%m-%d'),
                    'brand': brand,
                    'source': source,
                    'status': status,
                    'is_booked': self._is_booked_status(status),
                    'is_converted': self._is_converted_status(status),
                    'record_id': record.get('id', '')
                }

                leads.append(lead)

            booked_count = sum(1 for lead in leads if lead['is_booked'])
            converted_count = sum(1 for lead in leads if lead['is_converted'])

            logger.info(f"Filtered to {len(leads)} Smooth MD Meta leads ({booked_count} booked, {converted_count} converted)")

            return {
                'success': True,
                'leads': leads,
                'total_leads': len(leads),
                'booked_leads': booked_count,
                'converted_leads': converted_count,
                'date_range': f"{start_date} to {end_date}"
            }

        except Exception as e:
            logger.error(f"Leads data loading error: {e}")
            return {'error': str(e)}

    def load_lead_data_optimized(self, start_date: str, end_date: str) -> Dict:
        """Optimized lead loading with reduced processing overhead"""
        cache_key = f"leads_{start_date}_{end_date}"

        try:
            if not self.api_key:
                return {'success': False, 'error': 'Airtable API key not configured'}

            # Use cached approach with simplified processing
            def _fetch_leads():
                api = Api(self.api_key)
                table = api.table(self.base_id, self.tables['leads'])
                return table.all()

            all_records = self._retry_request(_fetch_leads)
            if not all_records:
                return {'success': False, 'error': 'Failed to fetch lead records'}

            # Streamlined filtering for better performance
            leads = []
            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
            end_dt = datetime.strptime(end_date, '%Y-%m-%d')

            for record in all_records:
                fields = record.get('fields', {})

                # Quick brand and source filtering
                brand = self._extract_brand_field(fields)
                source = self._extract_source_field(fields)

                if brand != 'Smooth MD' or 'meta' not in source.lower():
                    continue

                # Simplified date processing
                date_value = self._extract_date_field(fields)
                if not date_value:
                    continue

                try:
                    if isinstance(date_value, str):
                        lead_dt = datetime.fromisoformat(date_value.replace('Z', '+00:00')).replace(tzinfo=None)
                    else:
                        lead_dt = date_value

                    if not (start_dt <= lead_dt <= end_dt):
                        continue
                except:
                    continue

                # Minimal lead object for performance
                leads.append({
                    'date': lead_dt.strftime('%Y-%m-%d'),
                    'brand': brand,
                    'source': source,
                    'record_id': record.get('id', '')
                })

            return {
                'success': True,
                'leads': leads,
                'total_leads': len(leads),
                'date_range': f"{start_date} to {end_date}"
            }

        except Exception as e:
            logger.error(f"Optimized leads loading error: {e}")
            return {'success': False, 'error': str(e)}

    def load_meta_insights(self, start_date: str, end_date: str) -> Dict:
        """Load Meta insights using proven API patterns"""
        try:
            if not (self.meta_token and self.meta_account_id):
                return {'error': 'Meta API credentials not configured'}

            # Account level insights (proven working pattern)
            url = f"https://graph.facebook.com/v18.0/act_{self.meta_account_id}/insights"
            params = {
                'access_token': self.meta_token,
                'fields': 'spend,impressions,clicks,ctr,cpm,reach,frequency,actions',
                'time_range': f'{{"since":"{start_date}","until":"{end_date}"}}',
                'level': 'account'
            }

            response = requests.get(url, params=params)

            if response.status_code == 200:
                data = response.json()
                if data.get('data'):
                    insights = data['data'][0]
                    return {
                        'success': True,
                        'spend': float(insights.get('spend', 0)),
                        'impressions': int(insights.get('impressions', 0)),
                        'clicks': int(insights.get('clicks', 0)),
                        'ctr': float(insights.get('ctr', 0)),
                        'cpm': float(insights.get('cpm', 0)),
                        'reach': int(insights.get('reach', 0)),
                        'frequency': float(insights.get('frequency', 0)),
                        'date_range': f"{start_date} to {end_date}"
                    }

            return {'error': f'Meta API error: {response.status_code}'}

        except Exception as e:
            logger.error(f"Meta insights loading error: {e}")
            return {'error': str(e)}

    def load_campaign_breakdown(self, start_date: str, end_date: str) -> Dict:
        """Load campaign-level breakdown using proven patterns"""
        try:
            if not (self.meta_token and self.meta_account_id):
                return {'error': 'Meta API credentials not configured'}

            breakdown_data = {
                'campaigns': [],
                'adsets': [],
                'ads': []
            }

            # Campaign level
            campaign_url = f"https://graph.facebook.com/v18.0/act_{self.meta_account_id}/insights"
            campaign_params = {
                'access_token': self.meta_token,
                'fields': 'campaign_name,campaign_id,spend,impressions,clicks,ctr,cpm,reach',
                'time_range': f'{{"since":"{start_date}","until":"{end_date}"}}',
                'level': 'campaign'
            }

            response = requests.get(campaign_url, params=campaign_params)
            if response.status_code == 200:
                data = response.json()
                breakdown_data['campaigns'] = data.get('data', [])

            # Ad Set level
            adset_params = campaign_params.copy()
            adset_params['fields'] = 'campaign_name,adset_name,adset_id,spend,impressions,clicks,ctr,cpm'
            adset_params['level'] = 'adset'

            response = requests.get(campaign_url, params=adset_params)
            if response.status_code == 200:
                data = response.json()
                breakdown_data['adsets'] = data.get('data', [])

            # Ad level
            ad_params = campaign_params.copy()
            ad_params['fields'] = 'campaign_name,adset_name,ad_name,ad_id,spend,impressions,clicks,ctr,cpm'
            ad_params['level'] = 'ad'

            response = requests.get(campaign_url, params=ad_params)
            if response.status_code == 200:
                data = response.json()
                breakdown_data['ads'] = data.get('data', [])

            return {
                'success': True,
                'breakdown_data': breakdown_data,
                'date_range': f"{start_date} to {end_date}"
            }

        except Exception as e:
            logger.error(f"Campaign breakdown loading error: {e}")
            return {'error': str(e)}

    def _extract_date_field(self, fields: Dict, lead_record: bool = False) -> Optional[str]:
        """Extract date field using proven field name patterns"""
        date_fields = ['Date', 'Inbound', 'Created Time', 'Transaction Date', 'Lead Date']
        if lead_record:
            date_fields = ['Inbound', 'Date', 'Created Time', 'Lead Date']

        for field_name in date_fields:
            if field_name in fields:
                return fields[field_name]

        return None

    def _extract_amount_field(self, fields: Dict) -> float:
        """Extract amount field using proven field name patterns"""
        amount_fields = ['Amount', 'Total', 'Revenue', 'Transaction Amount', 'Price']

        for field_name in amount_fields:
            if field_name in fields:
                amount_value = fields[field_name]
                if amount_value:
                    try:
                        # Clean amount string (remove $, commas)
                        if isinstance(amount_value, str):
                            clean_amount = amount_value.replace('$', '').replace(',', '').strip()
                            return float(clean_amount) if clean_amount else 0
                        else:
                            return float(amount_value)
                    except (ValueError, TypeError):
                        continue

        return 0

    def _extract_brand_field(self, fields: Dict) -> str:
        """Extract brand field using proven field name patterns"""
        brand_fields = ['Brand', 'Brand (from ID)', 'Brand Name', 'Company']

        for field_name in brand_fields:
            if field_name in fields:
                brand_value = fields[field_name]
                if isinstance(brand_value, list):
                    return brand_value[0] if brand_value else ''
                else:
                    return str(brand_value) if brand_value else ''

        return ''

    def _extract_source_field(self, fields: Dict) -> str:
        """Extract source field using proven field name patterns"""
        source_fields = ['Contact Source', 'Source', 'Lead Source', 'Contact Source (from ID)', 'Channel']

        for field_name in source_fields:
            if field_name in fields:
                source_value = fields[field_name]
                if isinstance(source_value, list):
                    return source_value[0] if source_value else ''
                else:
                    return str(source_value) if source_value else ''

        return ''

    def _extract_service_field(self, fields: Dict) -> str:
        """Extract service field using proven field name patterns"""
        service_fields = ['Services Purchased', 'Service', 'Product', 'Treatment', 'Package']

        for field_name in service_fields:
            if field_name in fields:
                service_value = fields[field_name]
                if isinstance(service_value, list):
                    return service_value[0] if service_value else ''
                else:
                    return str(service_value) if service_value else ''

        return ''

    def _extract_status_field(self, fields: Dict) -> str:
        """Extract status field using proven field name patterns"""
        status_fields = ['Overall Status', 'Status', 'Lead Status', 'Consultation Status']

        for field_name in status_fields:
            if field_name in fields:
                status_value = fields[field_name]
                if isinstance(status_value, list):
                    return status_value[0] if status_value else ''
                else:
                    return str(status_value) if status_value else ''

        return ''

    def _extract_field(self, fields: Dict, possible_keys: List[str]) -> str:
        """Extract field value using multiple possible key names with list handling"""
        for key in possible_keys:
            if key in fields and fields[key]:
                field_value = fields[key]

                # Handle list values (like multiple select fields)
                if isinstance(field_value, list):
                    if len(field_value) == 0:
                        continue

                    # Join multiple values with comma
                    string_items = []
                    for item in field_value:
                        if isinstance(item, dict):
                            # Handle linked record objects
                            string_items.append(str(item.get('name', item.get('id', str(item)))))
                        else:
                            string_items.append(str(item))

                    return ", ".join(string_items)

                # Handle dictionary values (like linked records)
                elif isinstance(field_value, dict):
                    return str(field_value.get('name', field_value.get('id', str(field_value))))

                # Handle string and other values
                else:
                    return str(field_value).strip()

        return ''

    def _is_smooth_md_meta_transaction(self, brand: str, source: str) -> bool:
        """Check if transaction is Smooth MD Meta using proven logic"""
        if not brand or not source:
            return False

        brand_lower = brand.lower()
        source_lower = source.lower()

        # Brand filtering (proven patterns)
        is_smooth_md = any(filter_term in brand_lower for filter_term in self.filters['brand_filters'])

        # Meta source filtering (proven patterns)
        is_meta_source = any(indicator in source_lower for indicator in self.filters['meta_indicators'])

        return is_smooth_md and is_meta_source

    def _is_smooth_md_meta_lead(self, brand: str, source: str) -> bool:
        """Check if lead is Smooth MD Meta using proven logic"""
        return self._is_smooth_md_meta_transaction(brand, source)

    def _is_booked_status(self, status: str) -> bool:
        """Check if status indicates booked using proven logic"""
        if not status:
            return False

        status_lower = status.lower()
        return any(booking_term in status_lower for booking_term in self.filters['booking_statuses'])

    def _is_converted_status(self, status: str) -> bool:
        """Check if status indicates converted using proven logic"""
        if not status:
            return False

        status_lower = status.lower()
        return any(conversion_term in status_lower for conversion_term in self.filters['conversion_statuses'])

    def calculate_roas(self, revenue: float, spend: float) -> float:
        """Calculate ROAS using proven logic"""
        if spend <= 0:
            return 0
        return revenue / spend

    def get_connection_status(self) -> Dict:
        """Get comprehensive connection status"""
        status = self.config.get_status_report()

        # Test actual connections
        try:
            if self.api_key:
                api = Api(self.api_key)
                table = api.table(self.base_id, self.tables['transactions'])
                test_records = table.all(max_records=1)
                status['airtable_test'] = 'Connection successful'
            else:
                status['airtable_test'] = 'API key missing'
        except Exception as e:
            status['airtable_test'] = f'Connection failed: {str(e)}'

        try:
            if self.meta_token and self.meta_account_id:
                url = f"https://graph.facebook.com/v18.0/act_{self.meta_account_id}"
                params = {'access_token': self.meta_token, 'fields': 'name'}
                response = requests.get(url, params=params)
                if response.status_code == 200:
                    status['meta_test'] = 'Connection successful'
                else:
                    status['meta_test'] = f'API error: {response.status_code}'
            else:
                status['meta_test'] = 'Credentials missing'
        except Exception as e:
            status['meta_test'] = f'Connection failed: {str(e)}'

        return status

    def test_airtable_connection(self) -> Dict:
        """Test Airtable connection"""
        try:
            if not self.api_key:
                return {'success': False, 'error': 'API key not configured'}

            api = Api(self.api_key)
            table = api.table(self.base_id, self.tables['transactions'])
            test_records = table.all(max_records=1)
            return {
                'success': True, 
                'base_id': self.base_id,
                'records_found': len(test_records)
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def test_meta_connection(self) -> Dict:
        """Test Meta API connection"""
        try:
            if not (self.meta_token and self.meta_account_id):
                return {'success': False, 'error': 'Credentials not configured'}

            url = f"https://graph.facebook.com/v18.0/act_{self.meta_account_id}"
            params = {'access_token': self.meta_token, 'fields': 'name'}
            response = requests.get(url, params=params)

            if response.status_code == 200:
                data = response.json()
                return {
                    'success': True,
                    'account_id': self.meta_account_id,
                    'account_name': data.get('name', 'Unknown')
                }
            else:
                return {'success': False, 'error': f'API error: {response.status_code}'}
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def get_transactions(self, start_date: str, end_date: str) -> Dict:
        """Get transactions data"""
        return self.load_transaction_data(start_date, end_date)

    def get_leads(self, start_date: str, end_date: str) -> Dict:
        """Get leads data"""
        return self.load_leads_data(start_date, end_date)

    def get_meta_insights(self, start_date: str, end_date: str) -> Dict:
        """Get Meta insights data"""
        return self.load_meta_insights(start_date, end_date)