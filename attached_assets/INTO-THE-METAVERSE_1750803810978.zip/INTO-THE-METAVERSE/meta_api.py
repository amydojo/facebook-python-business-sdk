"""
Meta Marketing API Integration for Ad Command Center
Retrieves ad performance metrics including CTR, engagement rate, and cost metrics
"""
import os
import json
import requests
import pandas as pd
from datetime import datetime, timedelta

class MetaMarketingAPI:
    """Class to handle Meta Marketing API interactions"""
    
    def __init__(self, access_token=None, ad_account_id=None):
        """Initialize with credentials"""
        self.access_token = access_token or os.environ.get("META_ACCESS_TOKEN")
        self.ad_account_id = ad_account_id or os.environ.get("META_AD_ACCOUNT_ID")
        
        # Ensure ad_account_id is properly formatted
        if self.ad_account_id:
            # First convert to string
            self.ad_account_id = str(self.ad_account_id)
            # Remove 'act_' prefix if it exists
            if self.ad_account_id.startswith('act_'):
                self.ad_account_id = self.ad_account_id[4:]
        
        self.api_version = "v22.0"  # Using latest API version
        self.base_url = f"https://graph.facebook.com/{self.api_version}"
        print(f"Initialized Meta API with account ID: {self.ad_account_id}")
        
    def get_campaigns(self, limit=500):
        """Get active ad campaigns"""
        if not self.access_token or not self.ad_account_id:
            return {"error": "Missing Meta credentials"}, []
            
        # Ensure proper formatting of account ID
        account_id = str(self.ad_account_id)
        url = f"{self.base_url}/act_{account_id}/campaigns"
        params = {
            "access_token": self.access_token,
            "fields": "id,name,status,objective,spend,start_time,stop_time,daily_budget,lifetime_budget,special_ad_category,bid_strategy,pacing_type,effective_status",
            "limit": limit
        }
        
        try:
            response = requests.get(url, params=params)
            if response.status_code == 200:
                data = response.json()
                campaigns = data.get("data", [])
                
                # Format into DataFrame
                if campaigns:
                    df = pd.DataFrame(campaigns)
                    return {"success": f"Found {len(campaigns)} campaigns"}, df
                else:
                    return {"warning": "No campaigns found"}, pd.DataFrame()
            else:
                return {"error": f"API Error: {response.text}"}, pd.DataFrame()
        except Exception as e:
            return {"error": f"Failed to fetch campaigns: {str(e)}"}, pd.DataFrame()
    
    def get_campaign_insights(self, campaign_ids=None, date_preset="last_90d", time_increment="1", custom_date_range=None):
        """
        Get detailed campaign performance metrics
        
        Args:
            campaign_ids: List of campaign IDs to get insights for
            date_preset: Time range preset (last_30d, last_90d, etc)
            time_increment: Data aggregation level (1=daily, 7=weekly, etc)
            custom_date_range: Optional dict with since/until dates
            
        Returns:
            Tuple of (status_dict, dataframe)
        """
        if not self.access_token or not self.ad_account_id:
            return {"error": "Missing Meta credentials"}, pd.DataFrame()
        
        # Use account level insights for comprehensive data
        account_id = str(self.ad_account_id)
        url = f"{self.base_url}/act_{account_id}/insights"
        
        # Define fields to retrieve - comprehensive metrics
        fields = [
            "campaign_id",
            "campaign_name",
            "adset_id",
            "adset_name",
            "ad_id",
            "ad_name",
            "impressions",
            "clicks",
            "reach",
            "spend",
            "cpc",  # Cost per click
            "cpm",  # Cost per 1000 impressions
            "ctr",  # Click-through rate
            "frequency",  # Avg number of times ad shown to same person
            "objective", 
            "conversions",
            "cost_per_lead",
            "cost_per_conversion",
            "conversion_values",
            "conversion_rate_ranking",
            "engagement_rate_ranking",
            "quality_ranking",
            "date_start", 
            "date_stop",
            "actions",
            "action_values",
            "video_p25_watched_actions",
            "video_p50_watched_actions",
            "video_p75_watched_actions",
            "video_p100_watched_actions",
            "inline_link_clicks",
            "inline_post_engagement",
            "unique_clicks",
            "unique_ctr",
            "website_ctr"
        ]
        
        # Set parameters with filters specifically for Smooth MD if needed
        params = {
            "access_token": self.access_token,
            "fields": ",".join(fields),
            "level": "ad",  # Most granular level for complete data
            "time_increment": str(time_increment),
            "limit": "500"  # Increased limit for more comprehensive data
        }
        
        # Handle date parameters - either use custom range or preset
        if custom_date_range and isinstance(custom_date_range, dict) and "since" in custom_date_range and "until" in custom_date_range:
            # Use custom date range if provided
            time_range = {
                "since": custom_date_range["since"],
                "until": custom_date_range["until"]
            }
            params["time_range"] = json.dumps(time_range)
            print(f"Using time range: {time_range['since']} to {time_range['until']}")
        elif date_preset:
            # Otherwise use date preset if not empty
            if date_preset.strip():
                params["date_preset"] = date_preset
                print(f"Using date preset: {date_preset}")
        
        # Add campaign filter if provided
        if campaign_ids:
            if isinstance(campaign_ids, list):
                # Convert all IDs to strings to avoid type issues
                campaign_ids = ",".join([str(cid) for cid in campaign_ids])
            params["filtering"] = json.dumps([{
                "field": "campaign.id",
                "operator": "IN",
                "value": campaign_ids.split(",")
            }])
        
        # Filter by Smooth MD brand if needed (this could be customized based on naming conventions)
        # params["filtering"] = f'{{"field":"campaign.name","operator":"CONTAIN","value":"Smooth"}}'
        
        try:
            # Convert all numeric parameters to strings to avoid concatenation errors
            for key, value in params.items():
                if isinstance(value, (int, float)):
                    params[key] = str(value)
            
            # Print request details for debugging
            print(f"Requesting insights from: {url}")
            print(f"With params: {params}")
            
            response = requests.get(url, params=params)
            
            if response.status_code == 200:
                data = response.json()
                insights = data.get("data", [])
                
                # Check if we need to paginate for more results
                paging = data.get("paging", {})
                next_url = paging.get("next")
                
                # Continue fetching if there are more pages
                all_insights = insights.copy()
                
                # Fetch up to 10 pages of data (adjust as needed)
                page_count = 1
                max_pages = 10
                
                while next_url and page_count < max_pages:
                    try:
                        next_response = requests.get(next_url)
                        if next_response.status_code == 200:
                            next_data = next_response.json()
                            next_insights = next_data.get("data", [])
                            if next_insights:
                                all_insights.extend(next_insights)
                            next_url = next_data.get("paging", {}).get("next")
                            page_count += 1
                        else:
                            break
                    except Exception as e:
                        print(f"Error fetching additional page: {str(e)}")
                        break
                
                # Create DataFrame from insights
                if all_insights:
                    df = pd.DataFrame(all_insights)
                    
                    # Process complex nested fields like actions
                    if 'actions' in df.columns:
                        # Extract action values into separate columns
                        def extract_action_values(actions_list):
                            if not actions_list or not isinstance(actions_list, list):
                                return {}
                            
                            result = {}
                            for action in actions_list:
                                if 'action_type' in action and 'value' in action:
                                    action_type = action['action_type']
                                    action_value = action['value']
                                    result[f"action_{action_type}"] = action_value
                            return result
                        
                        # Apply extraction to each row
                        action_dfs = []
                        for i, row in df.iterrows():
                            if 'actions' in row and row['actions'] is not None:
                                action_values = extract_action_values(row['actions'])
                                if action_values:
                                    action_df = pd.DataFrame([action_values], index=[i])
                                    action_dfs.append(action_df)
                        
                        # Combine with main dataframe if we have action data
                        if action_dfs:
                            actions_df = pd.concat(action_dfs)
                            df = pd.merge(df, actions_df, left_index=True, right_index=True, how='left')
                    
                    # Convert date columns
                    if 'date_start' in df.columns:
                        df['date_start'] = pd.to_datetime(df['date_start'])
                    if 'date_stop' in df.columns:
                        df['date_stop'] = pd.to_datetime(df['date_stop'])
                    
                    # Convert numeric columns
                    numeric_cols = ['impressions', 'clicks', 'reach', 'spend', 'cpc', 'cpm', 'ctr', 'frequency']
                    for col in numeric_cols:
                        if col in df.columns:
                            df[col] = pd.to_numeric(df[col], errors='coerce')
                    
                    # Drop the complex nested columns to avoid serialization issues
                    complex_cols = ['actions', 'action_values', 'video_p25_watched_actions', 
                                   'video_p50_watched_actions', 'video_p75_watched_actions', 
                                   'video_p100_watched_actions', 'website_ctr']
                    for col in complex_cols:
                        if col in df.columns:
                            df = df.drop(columns=[col])
                    
                    return {"success": f"Retrieved {len(all_insights)} ad insights"}, df
                else:
                    return {"warning": "No campaign insights found"}, pd.DataFrame()
            else:
                error_message = f"API Error: {response.text}"
                return {"error": error_message}, pd.DataFrame()
        
        except Exception as e:
            error_message = f"Failed to fetch campaign insights: {str(e)}"
            return {"error": error_message}, pd.DataFrame()
    
    def get_ad_performance(self, days=90, custom_date_range=None):
        """
        Get comprehensive ad performance data for all campaigns
        Returns detailed metrics at ad, ad set, and campaign levels
        Includes full data for all Smooth MD campaigns
        
        Args:
            days (int): Number of days to look back for performance data
            custom_date_range (dict, optional): Custom date range in format {"since": "YYYY-MM-DD", "until": "YYYY-MM-DD"}
        """
        if not self.access_token or not self.ad_account_id:
            return {"error": "Missing Meta credentials"}, {}
        
        # Ensure ad_account_id is always a string
        self.ad_account_id = str(self.ad_account_id)
        
        # Use custom date range if provided, otherwise calculate based on days
        if custom_date_range and isinstance(custom_date_range, dict) and "since" in custom_date_range and "until" in custom_date_range:
            date_range = custom_date_range
            print(f"Using custom date range: {date_range['since']} to {date_range['until']}")
        else:
            # Calculate date range - use longer time period for more comprehensive data
            end_date = datetime.now()
            start_date = end_date - timedelta(days=int(days))
            
            # Format dates for API
            date_format = "%Y-%m-%d"
            date_range = {
                "since": start_date.strftime(date_format),
                "until": end_date.strftime(date_format)
            }
            print(f"Using calculated date range: {date_range['since']} to {date_range['until']}")
        
        # Comprehensive fields to retrieve all important metrics
        fields = [
            "account_id",
            "campaign_id",
            "campaign_name",
            "adset_id",
            "adset_name",
            "ad_id",
            "ad_name",
            "impressions",
            "reach",
            "clicks",
            "spend",
            "cpc",
            "cpm", 
            "ctr",
            "frequency",
            "objective",
            "conversions",
            "cost_per_lead",
            "cost_per_conversion",
            "conversion_values",
            "conversion_rate_ranking",
            "engagement_rate_ranking",
            "quality_ranking",
            "actions",
            "action_values",
            "video_p25_watched_actions",
            "video_p50_watched_actions",
            "video_p75_watched_actions",
            "video_p100_watched_actions",
            "inline_link_clicks",
            "inline_post_engagement",
            "unique_clicks",
            "unique_ctr",
            "website_ctr"
        ]
        
        import json
        account_id = str(self.ad_account_id)
        url = f"{self.base_url}/act_{account_id}/insights"
        
        # Ensure all values are strings to avoid concatenation errors
        params = {
            "access_token": self.access_token,
            "fields": ",".join(fields),
            "time_range": json.dumps(date_range),
            "level": "ad",  # Get ad-level data for most granular insights
            "limit": "500"  # Increase limit to get more comprehensive data
        }
        
        # Print request details for debugging
        print(f"Ad performance URL: {url}")
        print(f"Ad performance date range: {date_range}")
        
        try:
            response = requests.get(url, params=params)
            if response.status_code == 200:
                data = response.json()
                insights = data.get("data", [])
                
                # Check if we need to paginate for more results
                paging = data.get("paging", {})
                next_url = paging.get("next")
                
                # Continue fetching if there are more pages
                all_insights = insights.copy()
                
                # Fetch up to 10 pages of data for more comprehensive results
                page_count = 1
                max_pages = 10
                
                while next_url and page_count < max_pages:
                    try:
                        next_response = requests.get(next_url)
                        if next_response.status_code == 200:
                            next_data = next_response.json()
                            next_insights = next_data.get("data", [])
                            if next_insights:
                                all_insights.extend(next_insights)
                            next_url = next_data.get("paging", {}).get("next")
                            page_count += 1
                        else:
                            break
                    except Exception as e:
                        print(f"Error fetching additional page: {str(e)}")
                        break
                
                if all_insights:
                    # Convert to DataFrame for easier processing
                    insights_df = pd.DataFrame(all_insights)
                    
                    # Process complex nested fields like actions if present
                    if 'actions' in insights_df.columns:
                        # Function to extract action values
                        def extract_action_values(actions_list):
                            if not actions_list or not isinstance(actions_list, list):
                                return {}
                            
                            result = {}
                            for action in actions_list:
                                if 'action_type' in action and 'value' in action:
                                    action_type = action['action_type']
                                    action_value = action['value']
                                    result[f"action_{action_type}"] = action_value
                            return result
                        
                        # Apply extraction to each row with actions
                        action_data = []
                        for _, row in insights_df.iterrows():
                            if 'actions' in row and row['actions'] is not None:
                                action_values = extract_action_values(row['actions'])
                                action_data.append(action_values)
                            else:
                                action_data.append({})
                        
                        # Create a DataFrame from the action data
                        action_df = pd.DataFrame(action_data)
                        
                        # Add action columns to main DataFrame if not empty
                        if not action_df.empty and len(action_df.columns) > 0:
                            for col in action_df.columns:
                                insights_df[col] = action_df[col]
                    
                    # Convert numeric columns
                    numeric_cols = ['impressions', 'clicks', 'reach', 'spend', 'cpc', 'cpm', 'ctr', 'frequency']
                    for col in numeric_cols:
                        if col in insights_df.columns:
                            insights_df[col] = pd.to_numeric(insights_df[col], errors='coerce')
                    
                    # Calculate aggregated performance metrics
                    performance = {
                        "impressions": int(insights_df['impressions'].sum()) if 'impressions' in insights_df.columns else 0,
                        "reach": int(insights_df['reach'].sum()) if 'reach' in insights_df.columns else 0,
                        "clicks": int(insights_df['clicks'].sum()) if 'clicks' in insights_df.columns else 0,
                        "spend": float(insights_df['spend'].sum()) if 'spend' in insights_df.columns else 0,
                        "cpc": float(insights_df['cpc'].mean()) if 'cpc' in insights_df.columns else 0,
                        "ctr": float(insights_df['ctr'].mean() * 100) if 'ctr' in insights_df.columns else 0,  # Convert to percentage
                        "frequency": float(insights_df['frequency'].mean()) if 'frequency' in insights_df.columns else 0,
                        "campaign_count": len(insights_df['campaign_id'].unique()) if 'campaign_id' in insights_df.columns else 0,
                        "adset_count": len(insights_df['adset_id'].unique()) if 'adset_id' in insights_df.columns else 0,
                        "ad_count": len(insights_df['ad_id'].unique()) if 'ad_id' in insights_df.columns else 0
                    }
                    
                    # Add additional metrics if available
                    if 'inline_link_clicks' in insights_df.columns:
                        performance["inline_link_clicks"] = int(insights_df['inline_link_clicks'].sum())
                    
                    if 'inline_post_engagement' in insights_df.columns:
                        performance["inline_post_engagement"] = int(insights_df['inline_post_engagement'].sum())
                    
                    # Calculate additional derived metrics
                    performance["engagement_rate"] = (performance["clicks"] / performance["impressions"]) * 100 if performance["impressions"] > 0 else 0
                    performance["cost_per_thousand"] = (performance["spend"] / performance["impressions"]) * 1000 if performance["impressions"] > 0 else 0
                    
                    # Add the full dataframe for detailed analysis
                    performance["insights_data"] = insights_df.to_dict('records')
                    
                    # Calculate total conversions if available
                    conversion_cols = [col for col in insights_df.columns if col.startswith('action_') and (
                        'lead' in col.lower() or 'conversion' in col.lower() or 'purchase' in col.lower())]
                    
                    if conversion_cols:
                        total_conversions = 0
                        for col in conversion_cols:
                            total_conversions += insights_df[col].sum()
                        performance["conversions"] = int(total_conversions)
                        if total_conversions > 0:
                            performance["cost_per_conversion"] = performance["spend"] / total_conversions
                    
                    return {"success": f"Retrieved comprehensive performance data for {len(all_insights)} ad entries"}, performance
                else:
                    return {"warning": "No performance data available"}, {}
            else:
                return {"error": f"API Error: {response.text}"}, {}
        except Exception as e:
            return {"error": f"Failed to fetch ad performance: {str(e)}"}, {}
            
    def get_adsets(self, campaign_id=None, limit=100):
        """Get ad sets for a campaign or account"""
        if not self.access_token or not self.ad_account_id:
            return {"error": "Missing Meta credentials"}, []
            
        # Determine the endpoint based on if campaign_id is provided
        if campaign_id:
            url = f"{self.base_url}/{campaign_id}/adsets"
        else:
            url = f"{self.base_url}/act_{self.ad_account_id}/adsets"
            
        params = {
            "access_token": self.access_token,
            "fields": "id,name,status,campaign_id,lifetime_budget,daily_budget,optimization_goal,targeting",
            "limit": limit
        }
        
        try:
            response = requests.get(url, params=params)
            if response.status_code == 200:
                data = response.json()
                adsets = data.get("data", [])
                
                # Format into DataFrame
                if adsets:
                    df = pd.DataFrame(adsets)
                    return {"success": f"Found {len(adsets)} ad sets"}, df
                else:
                    return {"warning": "No ad sets found"}, pd.DataFrame()
            else:
                return {"error": f"API Error: {response.text}"}, pd.DataFrame()
        except Exception as e:
            return {"error": f"Failed to fetch ad sets: {str(e)}"}, pd.DataFrame()
    
    def get_ads(self, adset_id=None, limit=100):
        """Get ads for an ad set or account"""
        if not self.access_token or not self.ad_account_id:
            return {"error": "Missing Meta credentials"}, []
            
        # Determine the endpoint based on if adset_id is provided
        if adset_id:
            url = f"{self.base_url}/{adset_id}/ads"
        else:
            url = f"{self.base_url}/act_{self.ad_account_id}/ads"
            
        params = {
            "access_token": self.access_token,
            "fields": "id,name,status,adset_id,campaign_id,creative",
            "limit": limit
        }
        
        try:
            response = requests.get(url, params=params)
            if response.status_code == 200:
                data = response.json()
                ads = data.get("data", [])
                
                # Format into DataFrame
                if ads:
                    df = pd.DataFrame(ads)
                    return {"success": f"Found {len(ads)} ads"}, df
                else:
                    return {"warning": "No ads found"}, pd.DataFrame()
            else:
                return {"error": f"API Error: {response.text}"}, pd.DataFrame()
        except Exception as e:
            return {"error": f"Failed to fetch ads: {str(e)}"}, pd.DataFrame()

# Helper function to create visualization of campaign performance
def create_performance_charts(campaign_insights_df):
    """Create plotly visualizations for campaign performance metrics"""
    import plotly.express as px
    import plotly.graph_objects as go
    
    charts = {}
    
    if campaign_insights_df is None or campaign_insights_df.empty:
        return {
            "error": "No campaign data available for visualization"
        }
    
    # Clean and prep data
    df = campaign_insights_df.copy()
    
    # 1. Daily Performance Chart (CTR over time)
    if 'date_start' in df.columns and 'ctr' in df.columns:
        try:
            # Group by date and calculate average CTR
            daily_ctr = df.groupby('date_start')['ctr'].mean().reset_index()
            daily_ctr['ctr'] = daily_ctr['ctr'] * 100  # Convert to percentage
            
            fig_ctr = px.line(
                daily_ctr, 
                x='date_start', 
                y='ctr',
                title='Click-Through Rate (CTR) Over Time',
                labels={'date_start': 'Date', 'ctr': 'CTR (%)'},
                line_shape='linear'
            )
            fig_ctr.update_layout(
                xaxis_title="Date",
                yaxis_title="CTR (%)",
                hovermode="x unified"
            )
            charts["ctr_trend"] = fig_ctr
        except Exception as e:
            print(f"Error creating CTR chart: {e}")
    
    # 2. Campaign Comparison Chart (Horizontal bar chart for key metrics)
    if 'campaign_name' in df.columns:
        try:
            # Aggregate by campaign
            campaign_metrics = df.groupby('campaign_name').agg({
                'impressions': 'sum',
                'clicks': 'sum',
                'spend': 'sum',
                'reach': 'sum'
            }).reset_index()
            
            # Calculate derived metrics
            campaign_metrics['ctr'] = (campaign_metrics['clicks'] / campaign_metrics['impressions']) * 100
            campaign_metrics['cpc'] = campaign_metrics['spend'] / campaign_metrics['clicks'].replace(0, float('nan'))
            campaign_metrics['cpm'] = (campaign_metrics['spend'] / campaign_metrics['impressions']) * 1000
            
            # Sort by clicks
            campaign_metrics = campaign_metrics.sort_values('clicks', ascending=True)
            
            # Create CTR comparison chart
            fig_campaign_ctr = px.bar(
                campaign_metrics.tail(10),  # Top 10 campaigns
                x='ctr',
                y='campaign_name',
                title='Campaign CTR Comparison',
                labels={'ctr': 'CTR (%)', 'campaign_name': 'Campaign'},
                orientation='h'
            )
            fig_campaign_ctr.update_layout(
                xaxis_title="CTR (%)",
                yaxis_title="",
                yaxis={'categoryorder': 'total ascending'}
            )
            charts["campaign_ctr"] = fig_campaign_ctr
            
            # Create CPC comparison chart
            fig_campaign_cpc = px.bar(
                campaign_metrics.tail(10),  # Top 10 campaigns
                x='cpc',
                y='campaign_name',
                title='Campaign Cost Per Click Comparison',
                labels={'cpc': 'CPC ($)', 'campaign_name': 'Campaign'},
                orientation='h'
            )
            fig_campaign_cpc.update_layout(
                xaxis_title="Cost Per Click ($)",
                yaxis_title="",
                yaxis={'categoryorder': 'total ascending'}
            )
            charts["campaign_cpc"] = fig_campaign_cpc
        except Exception as e:
            print(f"Error creating campaign comparison charts: {e}")
    
    # 3. Performance Summary (Donut chart for clicks distribution)
    if 'campaign_name' in df.columns and 'clicks' in df.columns:
        try:
            # Group by campaign and sum clicks
            clicks_by_campaign = df.groupby('campaign_name')['clicks'].sum().reset_index()
            
            # Sort and take top campaigns
            clicks_by_campaign = clicks_by_campaign.sort_values('clicks', ascending=False)
            top_campaigns = clicks_by_campaign.head(5)
            
            # Add "Other" category for remaining campaigns
            if len(clicks_by_campaign) > 5:
                other_clicks = clicks_by_campaign.iloc[5:]['clicks'].sum()
                other_row = pd.DataFrame({'campaign_name': ['Other'], 'clicks': [other_clicks]})
                top_campaigns = pd.concat([top_campaigns, other_row])
            
            # Create donut chart
            fig_donut = px.pie(
                top_campaigns,
                values='clicks',
                names='campaign_name',
                title='Click Distribution by Campaign',
                hole=0.4
            )
            fig_donut.update_traces(textposition='inside', textinfo='percent+label')
            charts["clicks_distribution"] = fig_donut
        except Exception as e:
            print(f"Error creating clicks distribution chart: {e}")
    
    return charts