"""
Lead Matching Diagnostic Tool
Comprehensive analysis of lead matching issues and date range functionality
"""

import streamlit as st
from unified_production_connector import unified_connector
from advanced_lead_matcher import advanced_lead_matcher
from datetime import datetime, timedelta
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def analyze_transaction_field_coverage():
    """Analyze transaction field coverage for matching"""
    
    st.markdown("## Transaction Field Coverage Analysis")
    
    # Load recent transactions
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d')
    
    result = unified_connector.load_transactions(start_date, end_date)
    
    if not result.success:
        st.error(f"Failed to load transactions: {result.error}")
        return
    
    transactions = result.data or []
    st.info(f"Loaded {len(transactions)} transactions for analysis")
    
    # Analyze field coverage
    field_stats = {
        'email': 0,
        'phone': 0,
        'patient_id': 0,
        'lead_links': 0,
        'amount': 0,
        'valid_amount': 0
    }
    
    amount_distribution = []
    sample_transactions = []
    
    for i, tx in enumerate(transactions[:20]):  # Sample first 20
        fields = tx.get('fields', {})
        
        # Extract using matcher logic
        email = advanced_lead_matcher._extract_email(fields)
        phone = advanced_lead_matcher._extract_phone(fields)
        patient_id = advanced_lead_matcher._extract_field_value(fields, ['Patient', 'Patient ID', 'Lead ID', 'ID'])
        lead_links = advanced_lead_matcher._extract_field_value(fields, ['Lead', 'Leads', 'Lead ID', 'Patient', 'ID'])
        amount = advanced_lead_matcher._extract_transaction_amount(fields)
        
        if email:
            field_stats['email'] += 1
        if phone:
            field_stats['phone'] += 1
        if patient_id:
            field_stats['patient_id'] += 1
        if lead_links:
            field_stats['lead_links'] += 1
        if amount > 0:
            field_stats['amount'] += 1
            amount_distribution.append(amount)
            if amount > 0:  # Changed from 500 minimum
                field_stats['valid_amount'] += 1
        
        # Collect sample for display
        sample_transactions.append({
            'id': tx.get('id', '')[:10],
            'email': email,
            'phone': phone,
            'patient_id': patient_id,
            'amount': amount,
            'has_identifiers': bool(email or phone or patient_id)
        })
    
    # Display results
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("**Field Coverage (Sample 20)**")
        for field, count in field_stats.items():
            coverage = (count / 20 * 100) if count > 0 else 0
            st.metric(f"{field.title()}", f"{count}/20", f"{coverage:.1f}%")
    
    with col2:
        st.markdown("**Amount Analysis**")
        if amount_distribution:
            st.metric("Min Amount", f"${min(amount_distribution):,.2f}")
            st.metric("Max Amount", f"${max(amount_distribution):,.2f}")
            st.metric("Avg Amount", f"${sum(amount_distribution)/len(amount_distribution):,.2f}")
    
    with col3:
        st.markdown("**Matching Potential**")
        with_identifiers = len([tx for tx in sample_transactions if tx['has_identifiers']])
        st.metric("With Identifiers", f"{with_identifiers}/20")
        st.metric("Matching Rate", f"{with_identifiers/20*100:.1f}%")
    
    # Display sample transactions
    st.markdown("### Sample Transaction Analysis")
    
    for tx in sample_transactions[:10]:
        with st.expander(f"Transaction {tx['id']} - ${tx['amount']:.2f}"):
            col1, col2 = st.columns(2)
            with col1:
                st.write(f"**Email:** {tx['email'] or 'None'}")
                st.write(f"**Phone:** {tx['phone'] or 'None'}")
            with col2:
                st.write(f"**Patient ID:** {tx['patient_id'] or 'None'}")
                st.write(f"**Matchable:** {'Yes' if tx['has_identifiers'] else 'No'}")

def analyze_lead_field_coverage():
    """Analyze lead field coverage for matching"""
    
    st.markdown("## Lead Field Coverage Analysis")
    
    # Load recent leads
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d')
    
    result = unified_connector.load_leads(start_date, end_date)
    
    if not result.success:
        st.error(f"Failed to load leads: {result.error}")
        return
    
    leads = result.data or []
    meta_leads = advanced_lead_matcher.identify_meta_leads(leads)
    
    st.info(f"Loaded {len(leads)} total leads, {len(meta_leads)} Meta leads")
    
    # Analyze Meta lead field coverage
    field_stats = {
        'email': 0,
        'phone': 0,
        'both': 0,
        'smooth_brand': 0,
        'vigor_brand': 0
    }
    
    sample_leads = []
    
    for i, lead in enumerate(meta_leads[:20]):  # Sample first 20 Meta leads
        email = lead.get('email', '')
        phone = lead.get('phone', '')
        brand = lead.get('brand', '')
        
        if email:
            field_stats['email'] += 1
        if phone:
            field_stats['phone'] += 1
        if email and phone:
            field_stats['both'] += 1
        
        brand_lower = brand.lower()
        if 'smooth' in brand_lower and 'vigor' not in brand_lower:
            field_stats['smooth_brand'] += 1
        elif 'vigor' in brand_lower:
            field_stats['vigor_brand'] += 1
        
        sample_leads.append({
            'id': lead.get('record_id', '')[:10],
            'email': email,
            'phone': phone,
            'brand': brand,
            'source': lead.get('source', ''),
            'status': lead.get('status', ''),
            'is_smooth': 'smooth' in brand_lower and 'vigor' not in brand_lower
        })
    
    # Display results
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("**Contact Coverage (Sample 20)**")
        for field, count in field_stats.items():
            if field in ['email', 'phone', 'both']:
                coverage = (count / 20 * 100) if count > 0 else 0
                st.metric(f"{field.title()}", f"{count}/20", f"{coverage:.1f}%")
    
    with col2:
        st.markdown("**Brand Distribution**")
        st.metric("Smooth MD", field_stats['smooth_brand'])
        st.metric("Dr. Vigor", field_stats['vigor_brand'])
        st.metric("Other", 20 - field_stats['smooth_brand'] - field_stats['vigor_brand'])
    
    with col3:
        st.markdown("**Matching Readiness**")
        matchable = len([lead for lead in sample_leads if lead['email'] or lead['phone']])
        smooth_matchable = len([lead for lead in sample_leads if (lead['email'] or lead['phone']) and lead['is_smooth']])
        st.metric("Matchable Leads", f"{matchable}/20")
        st.metric("Smooth Matchable", f"{smooth_matchable}/20")
    
    # Display sample leads
    st.markdown("### Sample Lead Analysis")
    
    for lead in sample_leads[:10]:
        with st.expander(f"Lead {lead['id']} - {lead['brand']}"):
            col1, col2 = st.columns(2)
            with col1:
                st.write(f"**Email:** {lead['email'] or 'None'}")
                st.write(f"**Phone:** {lead['phone'] or 'None'}")
                st.write(f"**Source:** {lead['source']}")
            with col2:
                st.write(f"**Brand:** {lead['brand']}")
                st.write(f"**Status:** {lead['status']}")
                st.write(f"**Smooth MD:** {'Yes' if lead['is_smooth'] else 'No'}")

def test_date_range_functionality():
    """Test date range selection functionality"""
    
    st.markdown("## Date Range Functionality Test")
    
    # Test different date ranges
    test_ranges = [
        ("Last 7 days", 7),
        ("Last 30 days", 30),
        ("Last 90 days", 90)
    ]
    
    for range_name, days in test_ranges:
        st.markdown(f"### {range_name}")
        
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write(f"**Date Range:** {start_date} to {end_date}")
            
            # Test lead loading
            lead_result = unified_connector.load_leads(start_date, end_date)
            if lead_result.success:
                st.success(f"✓ Loaded {len(lead_result.data or [])} leads")
                
                # Analyze Meta leads in this range
                meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data or [])
                smooth_leads = [l for l in meta_leads if advanced_lead_matcher._is_smooth_brand(l.get('brand', ''))]
                st.metric("Meta Leads", len(meta_leads))
                st.metric("Smooth MD Leads", len(smooth_leads))
            else:
                st.error(f"✗ Lead loading failed: {lead_result.error}")
        
        with col2:
            # Test transaction loading
            tx_result = unified_connector.load_transactions(start_date, end_date)
            if tx_result.success:
                st.success(f"✓ Loaded {len(tx_result.data or [])} transactions")
                
                # Analyze transaction amounts
                transactions = tx_result.data or []
                amounts = []
                for tx in transactions:
                    amount = advanced_lead_matcher._extract_transaction_amount(tx.get('fields', {}))
                    if amount > 0:
                        amounts.append(amount)
                
                if amounts:
                    st.metric("Valid Transactions", len(amounts))
                    st.metric("Total Revenue", f"${sum(amounts):,.2f}")
                else:
                    st.warning("No valid transaction amounts found")
            else:
                st.error(f"✗ Transaction loading failed: {tx_result.error}")

def perform_live_matching_test():
    """Perform live matching test with current data"""
    
    st.markdown("## Live Matching Test")
    
    # Load last 30 days of data
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    
    st.write(f"**Testing with data from:** {start_date} to {end_date}")
    
    # Load data
    transaction_result = unified_connector.load_transactions(start_date, end_date)
    lead_result = unified_connector.load_leads(start_date, end_date)
    
    if not transaction_result.success or not lead_result.success:
        st.error("Failed to load data for matching test")
        return
    
    # Process data
    meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data or [])
    matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
        meta_leads, transaction_result.data or []
    )
    
    # Display detailed results
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("**Lead Statistics**")
        st.metric("Total Leads", len(lead_result.data or []))
        st.metric("Meta Leads", len(meta_leads))
        
        smooth_leads = len([l for l in meta_leads if advanced_lead_matcher._is_smooth_brand(l.get('brand', ''))])
        st.metric("Smooth MD Meta", smooth_leads)
    
    with col2:
        st.markdown("**Transaction Statistics**")
        st.metric("Total Transactions", len(transaction_result.data or []))
        
        valid_transactions = 0
        total_tx_revenue = 0
        for tx in transaction_result.data or []:
            amount = advanced_lead_matcher._extract_transaction_amount(tx.get('fields', {}))
            if amount > 0:
                valid_transactions += 1
                total_tx_revenue += amount
        
        st.metric("Valid Transactions", valid_transactions)
        st.metric("Total TX Revenue", f"${total_tx_revenue:,.2f}")
    
    with col3:
        st.markdown("**Matching Results**")
        matched_count = len([l for l in matched_leads if l['matched_transactions']])
        st.metric("Matched Leads", matched_count)
        st.metric("Attribution Rate", f"{matching_stats.get('attribution_rate', 0):.1f}%")
        st.metric("Matched Revenue", f"${matching_stats.get('total_matched_revenue', 0):,.2f}")
    
    # Show matching method breakdown
    st.markdown("### Matching Method Analysis")
    
    method_stats = matching_stats.get('match_methods', {})
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Direct Links", method_stats.get('direct_link_matches', 0))
    with col2:
        st.metric("Email Matches", method_stats.get('email_matches', 0))
    with col3:
        st.metric("Phone Matches", method_stats.get('phone_matches', 0))
    with col4:
        st.metric("Patient ID", method_stats.get('patient_id_matches', 0))
    
    # Show matched leads details
    if matched_count > 0:
        st.markdown("### Matched Leads Details")
        
        for i, lead in enumerate([l for l in matched_leads if l['matched_transactions']][:5]):
            with st.expander(f"Matched Lead #{i+1} - ${lead['total_revenue']:.2f}"):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write(f"**Brand:** {lead['brand']}")
                    st.write(f"**Email:** {lead['email'] or 'None'}")
                    st.write(f"**Phone:** {lead['phone'] or 'None'}")
                    st.write(f"**Source:** {lead['source']}")
                
                with col2:
                    st.write(f"**Status:** {lead['status']}")
                    st.write(f"**Revenue:** ${lead['total_revenue']:.2f}")
                    st.write(f"**Transactions:** {len(lead['matched_transactions'])}")
                    
                    for tx in lead['matched_transactions']:
                        st.write(f"  - ${tx['amount']:.2f} ({tx['match_method']})")

def calculate_corrected_metrics():
    """Calculate corrected metrics with improved matching"""
    
    st.markdown("## Corrected Metrics Calculation")
    
    # Load last 30 days
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    
    transaction_result = unified_connector.load_transactions(start_date, end_date)
    lead_result = unified_connector.load_leads(start_date, end_date)
    
    if not transaction_result.success or not lead_result.success:
        st.error("Failed to load data")
        return
    
    meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data or [])
    matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
        meta_leads, transaction_result.data or []
    )
    
    # Calculate metrics
    matched_count = len([l for l in matched_leads if l['matched_transactions']])
    total_revenue = matching_stats.get('total_matched_revenue', 0)
    attribution_rate = matching_stats.get('attribution_rate', 0)
    
    # Estimate spend (conservative)
    estimated_spend = len(meta_leads) * 45
    roas = total_revenue / estimated_spend if estimated_spend > 0 else 0
    cost_per_lead = estimated_spend / len(meta_leads) if meta_leads else 0
    cost_per_conversion = estimated_spend / matched_count if matched_count > 0 else 0
    
    st.markdown("### Updated Metrics")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Meta Leads", len(meta_leads))
        st.metric("Matched Leads", matched_count)
    
    with col2:
        st.metric("Total Revenue", f"${total_revenue:,.2f}")
        st.metric("Attribution Rate", f"{attribution_rate:.1f}%")
    
    with col3:
        st.metric("Estimated Spend", f"${estimated_spend:,.2f}")
        st.metric("ROAS", f"{roas:.2f}x")
    
    with col4:
        st.metric("Cost per Lead", f"${cost_per_lead:.2f}")
        st.metric("Cost per Conversion", f"${cost_per_conversion:.2f}")
    
    # Validation
    st.markdown("### Validation Status")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if matched_count > 4:
            st.success(f"✓ Improved matching: {matched_count} vs previous 4")
        else:
            st.warning(f"⚠ Still low matching: {matched_count}")
        
        if 1 <= attribution_rate <= 15:
            st.success(f"✓ Attribution rate in range: {attribution_rate:.1f}%")
        else:
            st.warning(f"⚠ Attribution rate out of range: {attribution_rate:.1f}%")
    
    with col2:
        if 0.5 <= roas <= 10:
            st.success(f"✓ ROAS in range: {roas:.2f}x")
        else:
            st.warning(f"⚠ ROAS out of range: {roas:.2f}x")
        
        if cost_per_conversion < 10000:
            st.success(f"✓ Reasonable cost per conversion: ${cost_per_conversion:.2f}")
        else:
            st.warning(f"⚠ High cost per conversion: ${cost_per_conversion:.2f}")

def main():
    """Main diagnostic application"""
    
    st.set_page_config(
        page_title="Lead Matching Diagnostic",
        page_icon="🔍",
        layout="wide"
    )
    
    st.title("🔍 Lead Matching Diagnostic Tool")
    st.markdown("**Comprehensive analysis of lead matching and date range functionality**")
    
    # Clear cache button
    if st.button("🔄 Clear Cache & Reload Data"):
        st.cache_data.clear()
        unified_connector.clear_cache()
        st.success("Cache cleared - data will be reloaded fresh")
        st.rerun()
    
    # Run all diagnostics
    analyze_transaction_field_coverage()
    st.markdown("---")
    
    analyze_lead_field_coverage()
    st.markdown("---")
    
    test_date_range_functionality()
    st.markdown("---")
    
    perform_live_matching_test()
    st.markdown("---")
    
    calculate_corrected_metrics()

if __name__ == "__main__":
    main()