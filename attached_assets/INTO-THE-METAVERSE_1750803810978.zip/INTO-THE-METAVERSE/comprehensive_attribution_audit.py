"""
Comprehensive Attribution Quality Audit
Deep dive analysis of all KPI calculations, filtering logic, and metric formulas
"""

import streamlit as st
from unified_production_connector import unified_connector
from advanced_lead_matcher import advanced_lead_matcher
from datetime import datetime, timedelta
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def audit_api_connections():
    """Audit all API connections and data quality"""
    
    st.markdown("## API Connection & Data Quality Audit")
    
    # Test Airtable connectivity
    connection_status = {}
    
    # Test tables access
    test_tables = ['leads', 'transactions']
    
    for table_type in test_tables:
        try:
            if table_type == 'leads':
                result = unified_connector.load_leads('2025-06-01', '2025-06-17')
            else:
                result = unified_connector.load_transactions('2025-06-01', '2025-06-17')
            
            if result.success:
                data_count = len(result.data or [])
                connection_status[table_type] = {
                    'status': 'success',
                    'count': data_count,
                    'response_time': result.response_time
                }
            else:
                connection_status[table_type] = {
                    'status': 'error',
                    'error': result.error,
                    'count': 0
                }
        except Exception as e:
            connection_status[table_type] = {
                'status': 'exception',
                'error': str(e),
                'count': 0
            }
    
    # Display connection results
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Leads Table**")
        leads_status = connection_status.get('leads', {})
        if leads_status.get('status') == 'success':
            st.success(f"✓ Connected - {leads_status['count']} records")
            st.metric("Response Time", f"{leads_status.get('response_time', 0):.2f}s")
        else:
            st.error(f"✗ Failed: {leads_status.get('error', 'Unknown error')}")
    
    with col2:
        st.markdown("**Transactions Table**")
        tx_status = connection_status.get('transactions', {})
        if tx_status.get('status') == 'success':
            st.success(f"✓ Connected - {tx_status['count']} records")
            st.metric("Response Time", f"{tx_status.get('response_time', 0):.2f}s")
        else:
            st.error(f"✗ Failed: {tx_status.get('error', 'Unknown error')}")
    
    return connection_status

def audit_lead_filtering_logic():
    """Comprehensive audit of lead filtering and identification logic"""
    
    st.markdown("## Lead Filtering Logic Audit")
    
    # Load sample data
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    
    lead_result = unified_connector.load_leads(start_date, end_date)
    if not lead_result.success:
        st.error(f"Failed to load leads: {lead_result.error}")
        return
    
    raw_leads = lead_result.data or []
    
    # Apply filtering step by step
    st.markdown("### Step-by-Step Filtering Analysis")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Total Raw Leads", len(raw_leads))
    
    # Step 1: Extract Meta leads
    meta_leads = advanced_lead_matcher.identify_meta_leads(raw_leads)
    
    with col2:
        st.metric("Meta Source Leads", len(meta_leads))
        meta_rate = (len(meta_leads) / len(raw_leads) * 100) if raw_leads else 0
        st.metric("Meta Source Rate", f"{meta_rate:.1f}%")
    
    # Step 2: Filter Smooth MD only
    smooth_leads = []
    vigor_leads = []
    other_leads = []
    
    for lead in meta_leads:
        brand = lead.get('brand', '')
        if advanced_lead_matcher._is_smooth_brand(brand):
            smooth_leads.append(lead)
        elif 'vigor' in brand.lower():
            vigor_leads.append(lead)
        else:
            other_leads.append(lead)
    
    with col3:
        st.metric("Smooth MD Meta", len(smooth_leads))
        smooth_rate = (len(smooth_leads) / len(meta_leads) * 100) if meta_leads else 0
        st.metric("Smooth Filter Rate", f"{smooth_rate:.1f}%")
    
    # Brand distribution analysis
    st.markdown("### Brand Distribution Analysis")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("**Smooth MD Leads**")
        st.metric("Count", len(smooth_leads))
        
        # Sample brand values
        smooth_samples = [lead.get('brand', '') for lead in smooth_leads[:10]]
        if smooth_samples:
            st.write("Sample brands:")
            for brand in set(smooth_samples):
                st.write(f"- {brand}")
    
    with col2:
        st.markdown("**Dr. Vigor Leads**")
        st.metric("Count", len(vigor_leads))
        
        vigor_samples = [lead.get('brand', '') for lead in vigor_leads[:10]]
        if vigor_samples:
            st.write("Sample brands:")
            for brand in set(vigor_samples):
                st.write(f"- {brand}")
    
    with col3:
        st.markdown("**Other Brands**")
        st.metric("Count", len(other_leads))
        
        other_samples = [lead.get('brand', '') for lead in other_leads[:10]]
        if other_samples:
            st.write("Sample brands:")
            for brand in set(other_samples):
                st.write(f"- {brand}")
    
    # Source pattern analysis
    st.markdown("### Source Pattern Analysis")
    
    meta_sources = {}
    for lead in meta_leads[:100]:  # Sample 100
        source = lead.get('source', '')
        if source:
            source_lower = source.lower()
            meta_sources[source] = meta_sources.get(source, 0) + 1
    
    if meta_sources:
        st.write("**Meta source patterns found:**")
        for source, count in sorted(meta_sources.items(), key=lambda x: x[1], reverse=True)[:10]:
            st.write(f"- {source}: {count} leads")
    
    return {
        'total_leads': len(raw_leads),
        'meta_leads': len(meta_leads),
        'smooth_leads': len(smooth_leads),
        'vigor_leads': len(vigor_leads)
    }

def audit_transaction_matching_logic():
    """Audit transaction matching and revenue attribution logic"""
    
    st.markdown("## Transaction Matching Logic Audit")
    
    # Load data
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    
    tx_result = unified_connector.load_transactions(start_date, end_date)
    lead_result = unified_connector.load_leads(start_date, end_date)
    
    if not tx_result.success or not lead_result.success:
        st.error("Failed to load data for matching audit")
        return
    
    transactions = tx_result.data or []
    leads = lead_result.data or []
    
    # Process transactions
    processed_tx = advanced_lead_matcher._process_transactions(transactions)
    
    st.markdown("### Transaction Processing Analysis")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Raw Transactions", len(transactions))
        st.metric("Valid Transactions", len(processed_tx))
        
        valid_rate = (len(processed_tx) / len(transactions) * 100) if transactions else 0
        st.metric("Valid Rate", f"{valid_rate:.1f}%")
    
    # Analyze transaction identifiers
    tx_with_email = 0
    tx_with_phone = 0
    tx_with_patient_id = 0
    tx_amounts = []
    
    for tx in processed_tx[:100]:  # Sample 100
        if tx.get('email'):
            tx_with_email += 1
        if tx.get('phone'):
            tx_with_phone += 1
        if tx.get('patient_id'):
            tx_with_patient_id += 1
        if tx.get('amount', 0) > 0:
            tx_amounts.append(tx['amount'])
    
    sample_size = min(len(processed_tx), 100)
    
    with col2:
        st.markdown("**Identifier Coverage (Sample 100)**")
        st.metric("With Email", f"{tx_with_email}/{sample_size}")
        st.metric("With Phone", f"{tx_with_phone}/{sample_size}")
        st.metric("With Patient ID", f"{tx_with_patient_id}/{sample_size}")
    
    with col3:
        st.markdown("**Amount Analysis**")
        if tx_amounts:
            st.metric("Min Amount", f"${min(tx_amounts):.2f}")
            st.metric("Max Amount", f"${max(tx_amounts):,.2f}")
            st.metric("Avg Amount", f"${sum(tx_amounts)/len(tx_amounts):,.2f}")
    
    # Perform matching analysis
    meta_leads = advanced_lead_matcher.identify_meta_leads(leads)
    matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
        meta_leads, transactions
    )
    
    st.markdown("### Matching Results Analysis")
    
    matched_count = len([l for l in matched_leads if l['matched_transactions']])
    total_revenue = matching_stats.get('total_matched_revenue', 0)
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Meta Leads", len(meta_leads))
        st.metric("Matched Leads", matched_count)
    
    with col2:
        attribution_rate = matching_stats.get('attribution_rate', 0)
        st.metric("Attribution Rate", f"{attribution_rate:.1f}%")
        st.metric("Total Revenue", f"${total_revenue:,.2f}")
    
    # Matching method breakdown
    methods = matching_stats.get('match_methods', {})
    
    with col3:
        st.markdown("**Match Methods**")
        for method, count in methods.items():
            st.write(f"{method}: {count}")
    
    with col4:
        st.markdown("**Quality Indicators**")
        
        # Quality checks
        if 1 <= attribution_rate <= 15:
            st.success(f"✓ Attribution Rate: {attribution_rate:.1f}%")
        else:
            st.warning(f"⚠ Attribution Rate: {attribution_rate:.1f}%")
        
        if matched_count > 10:
            st.success(f"✓ Matched Count: {matched_count}")
        else:
            st.warning(f"⚠ Low Match Count: {matched_count}")
    
    return {
        'matched_leads': matched_count,
        'total_revenue': total_revenue,
        'attribution_rate': attribution_rate,
        'methods': methods
    }

def audit_kpi_calculations():
    """Audit all KPI calculations and metric formulas"""
    
    st.markdown("## KPI Calculation Formula Audit")
    
    # Load current data
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    
    tx_result = unified_connector.load_transactions(start_date, end_date)
    lead_result = unified_connector.load_leads(start_date, end_date)
    
    if not tx_result.success or not lead_result.success:
        st.error("Failed to load data for KPI audit")
        return
    
    # Process data through the system
    meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data or [])
    matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
        meta_leads, tx_result.data or []
    )
    
    # Extract key metrics
    total_meta_leads = len(meta_leads)
    matched_count = len([l for l in matched_leads if l['matched_transactions']])
    total_revenue = matching_stats.get('total_matched_revenue', 0)
    attribution_rate = matching_stats.get('attribution_rate', 0)
    
    # Calculate derived metrics
    estimated_spend = total_meta_leads * 45  # Conservative estimate
    roas = total_revenue / estimated_spend if estimated_spend > 0 else 0
    cost_per_lead = estimated_spend / total_meta_leads if total_meta_leads > 0 else 0
    cost_per_conversion = estimated_spend / matched_count if matched_count > 0 else 0
    conversion_rate = (matched_count / total_meta_leads * 100) if total_meta_leads > 0 else 0
    
    st.markdown("### KPI Formula Verification")
    
    # Display formulas and calculations
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Primary Metrics**")
        st.write(f"**Total Meta Leads:** {total_meta_leads}")
        st.write(f"**Matched Leads:** {matched_count}")
        st.write(f"**Total Revenue:** ${total_revenue:,.2f}")
        
        st.markdown("**Attribution Rate Formula:**")
        st.code(f"Attribution Rate = (Matched Leads / Total Meta Leads) × 100")
        st.code(f"Attribution Rate = ({matched_count} / {total_meta_leads}) × 100 = {attribution_rate:.1f}%")
    
    with col2:
        st.markdown("**Derived Metrics**")
        st.write(f"**Estimated Spend:** ${estimated_spend:,.2f}")
        st.write(f"**ROAS:** {roas:.2f}x")
        st.write(f"**Cost per Lead:** ${cost_per_lead:.2f}")
        st.write(f"**Cost per Conversion:** ${cost_per_conversion:,.2f}")
        
        st.markdown("**ROAS Formula:**")
        st.code(f"ROAS = Total Revenue / Total Spend")
        st.code(f"ROAS = ${total_revenue:,.2f} / ${estimated_spend:,.2f} = {roas:.2f}x")
    
    # Validation checks
    st.markdown("### KPI Validation Status")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("**Attribution Quality**")
        if 1 <= attribution_rate <= 15:
            st.success(f"✓ Rate: {attribution_rate:.1f}% (Valid Range)")
        else:
            st.error(f"✗ Rate: {attribution_rate:.1f}% (Out of Range)")
        
        if matched_count >= 20:
            st.success(f"✓ Volume: {matched_count} matches")
        else:
            st.warning(f"⚠ Volume: {matched_count} matches (Low)")
    
    with col2:
        st.markdown("**Revenue Quality**")
        if 10000 <= total_revenue <= 200000:
            st.success(f"✓ Revenue: ${total_revenue:,.2f} (Realistic)")
        else:
            st.warning(f"⚠ Revenue: ${total_revenue:,.2f} (Check Range)")
        
        if 0.5 <= roas <= 10:
            st.success(f"✓ ROAS: {roas:.2f}x (Valid Range)")
        else:
            st.warning(f"⚠ ROAS: {roas:.2f}x (Check Calculation)")
    
    with col3:
        st.markdown("**Cost Efficiency**")
        if 20 <= cost_per_lead <= 100:
            st.success(f"✓ CPL: ${cost_per_lead:.2f} (Efficient)")
        else:
            st.warning(f"⚠ CPL: ${cost_per_lead:.2f} (Review Spend)")
        
        if cost_per_conversion <= 5000:
            st.success(f"✓ CPC: ${cost_per_conversion:.2f} (Efficient)")
        else:
            st.warning(f"⚠ CPC: ${cost_per_conversion:.2f} (High Cost)")
    
    return {
        'meta_leads': total_meta_leads,
        'matched_leads': matched_count,
        'revenue': total_revenue,
        'attribution_rate': attribution_rate,
        'roas': roas,
        'cost_per_conversion': cost_per_conversion
    }

def audit_date_filtering_accuracy():
    """Audit date filtering and time-based attribution accuracy"""
    
    st.markdown("## Date Filtering Accuracy Audit")
    
    # Test different date ranges
    test_ranges = [
        ("Last 7 days", 7),
        ("Last 14 days", 14),
        ("Last 30 days", 30)
    ]
    
    results = {}
    
    for range_name, days in test_ranges:
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
        
        # Load data for this range
        tx_result = unified_connector.load_transactions(start_date, end_date)
        lead_result = unified_connector.load_leads(start_date, end_date)
        
        if tx_result.success and lead_result.success:
            meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data or [])
            matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
                meta_leads, tx_result.data or []
            )
            
            results[range_name] = {
                'leads': len(meta_leads),
                'matched': len([l for l in matched_leads if l['matched_transactions']]),
                'revenue': matching_stats.get('total_matched_revenue', 0),
                'attribution': matching_stats.get('attribution_rate', 0)
            }
    
    # Display date range comparison
    st.markdown("### Date Range Comparison")
    
    col1, col2, col3 = st.columns(3)
    
    for i, (range_name, data) in enumerate(results.items()):
        col = [col1, col2, col3][i]
        with col:
            st.markdown(f"**{range_name}**")
            st.metric("Meta Leads", data['leads'])
            st.metric("Matched", data['matched'])
            st.metric("Revenue", f"${data['revenue']:,.2f}")
            st.metric("Attribution", f"{data['attribution']:.1f}%")
    
    # Validate date consistency
    st.markdown("### Date Filtering Validation")
    
    if len(results) >= 2:
        ranges = list(results.values())
        
        # Check if longer periods have more or equal data
        leads_increasing = ranges[0]['leads'] <= ranges[1]['leads'] <= ranges[2]['leads']
        revenue_increasing = ranges[0]['revenue'] <= ranges[1]['revenue'] <= ranges[2]['revenue']
        
        if leads_increasing:
            st.success("✓ Lead counts increase with longer date ranges")
        else:
            st.warning("⚠ Lead count inconsistency across date ranges")
        
        if revenue_increasing:
            st.success("✓ Revenue increases with longer date ranges")
        else:
            st.warning("⚠ Revenue inconsistency across date ranges")
    
    return results

def generate_attribution_quality_score():
    """Generate overall attribution quality score"""
    
    st.markdown("## Attribution Quality Score")
    
    # Run all audits and collect scores
    api_status = audit_api_connections()
    filtering_results = audit_lead_filtering_logic()
    matching_results = audit_transaction_matching_logic()
    kpi_results = audit_kpi_calculations()
    date_results = audit_date_filtering_accuracy()
    
    # Calculate quality scores
    scores = {}
    
    # API Connection Score (0-25 points)
    api_score = 0
    if api_status.get('leads', {}).get('status') == 'success':
        api_score += 12.5
    if api_status.get('transactions', {}).get('status') == 'success':
        api_score += 12.5
    scores['api'] = api_score
    
    # Filtering Quality Score (0-25 points)
    filter_score = 0
    if filtering_results:
        meta_rate = (filtering_results['meta_leads'] / filtering_results['total_leads'] * 100) if filtering_results['total_leads'] > 0 else 0
        if 5 <= meta_rate <= 30:  # Reasonable Meta lead percentage
            filter_score += 12.5
        if filtering_results['smooth_leads'] > 0:  # Has Smooth MD leads
            filter_score += 12.5
    scores['filtering'] = filter_score
    
    # Matching Quality Score (0-25 points)
    match_score = 0
    if matching_results:
        if matching_results['matched_leads'] >= 20:  # Good match volume
            match_score += 12.5
        if 1 <= matching_results['attribution_rate'] <= 15:  # Realistic attribution
            match_score += 12.5
    scores['matching'] = match_score
    
    # KPI Accuracy Score (0-25 points)
    kpi_score = 0
    if kpi_results:
        if 0.5 <= kpi_results['roas'] <= 10:  # Realistic ROAS
            kpi_score += 8.33
        if kpi_results['cost_per_conversion'] <= 5000:  # Efficient conversion cost
            kpi_score += 8.33
        if 1 <= kpi_results['attribution_rate'] <= 15:  # Valid attribution rate
            kpi_score += 8.34
    scores['kpi'] = kpi_score
    
    # Total quality score
    total_score = sum(scores.values())
    
    st.markdown("### Quality Score Breakdown")
    
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        st.metric("API Quality", f"{scores['api']:.1f}/25")
        if scores['api'] >= 20:
            st.success("Excellent")
        elif scores['api'] >= 15:
            st.warning("Good")
        else:
            st.error("Needs Fix")
    
    with col2:
        st.metric("Filter Quality", f"{scores['filtering']:.1f}/25")
        if scores['filtering'] >= 20:
            st.success("Excellent")
        elif scores['filtering'] >= 15:
            st.warning("Good")
        else:
            st.error("Needs Fix")
    
    with col3:
        st.metric("Match Quality", f"{scores['matching']:.1f}/25")
        if scores['matching'] >= 20:
            st.success("Excellent")
        elif scores['matching'] >= 15:
            st.warning("Good")
        else:
            st.error("Needs Fix")
    
    with col4:
        st.metric("KPI Quality", f"{scores['kpi']:.1f}/25")
        if scores['kpi'] >= 20:
            st.success("Excellent")
        elif scores['kpi'] >= 15:
            st.warning("Good")
        else:
            st.error("Needs Fix")
    
    with col5:
        st.metric("Total Score", f"{total_score:.1f}/100")
        if total_score >= 80:
            st.success("High Quality")
        elif total_score >= 60:
            st.warning("Medium Quality")
        else:
            st.error("Low Quality")
    
    # Recommendations
    st.markdown("### Quality Improvement Recommendations")
    
    recommendations = []
    
    if scores['api'] < 20:
        recommendations.append("🔧 Fix API connection issues - check authentication and permissions")
    
    if scores['filtering'] < 20:
        recommendations.append("🎯 Improve lead filtering logic - validate Meta source patterns and brand classification")
    
    if scores['matching'] < 20:
        recommendations.append("🔗 Enhance transaction matching - increase identifier coverage and matching algorithms")
    
    if scores['kpi'] < 20:
        recommendations.append("📊 Validate KPI calculations - review formulas and input data quality")
    
    if total_score < 80:
        recommendations.append("⚡ Overall system optimization needed for production deployment")
    
    if recommendations:
        for rec in recommendations:
            st.write(rec)
    else:
        st.success("🎉 Attribution system meets high quality standards for production deployment!")

def main():
    """Main comprehensive audit application"""
    
    st.set_page_config(
        page_title="Attribution Quality Audit",
        page_icon="🎯",
        layout="wide"
    )
    
    st.title("🎯 Comprehensive Attribution Quality Audit")
    st.markdown("**Deep dive analysis of KPI calculations, filtering logic, and attribution accuracy**")
    
    # Run comprehensive audit
    generate_attribution_quality_score()

if __name__ == "__main__":
    main()