"""
Advanced Ad Performance Visualizations
Comprehensive charts and tables for granular ad analysis
"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from typing import Dict, List
import numpy as np

class AdPerformanceVisualizations:
    """Create advanced visualizations for ad performance analysis"""
    
    def display_campaign_performance_matrix(self, campaign_analysis: List[Dict]):
        """Display comprehensive campaign performance matrix"""
        if not campaign_analysis:
            st.warning("No campaign data available for analysis")
            return
        
        st.markdown("### Campaign Performance Matrix")
        
        # Create performance matrix
        df = pd.DataFrame(campaign_analysis)
        
        # Performance scatter plot
        col1, col2 = st.columns(2)
        
        with col1:
            fig = px.scatter(
                df, 
                x='spend', 
                y='roas',
                size='attributed_revenue',
                color='performance_score',
                hover_data=['campaign_name', 'conversion_rate', 'ctr'],
                title="Campaign Performance: Spend vs ROAS",
                labels={'spend': 'Ad Spend ($)', 'roas': 'ROAS', 'performance_score': 'Performance Score'},
                color_continuous_scale='RdYlGn'
            )
            fig.add_hline(y=2.0, line_dash="dash", line_color="green", annotation_text="Target ROAS: 2.0x")
            fig.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                font_color='white',
                title_font_color='white'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # ROAS distribution
            fig = px.bar(
                df.head(10), 
                x='campaign_name', 
                y='roas',
                color='efficiency_rating',
                title="Campaign ROAS Comparison",
                labels={'roas': 'ROAS', 'campaign_name': 'Campaign'}
            )
            fig.add_hline(y=2.0, line_dash="dash", line_color="green")
            fig.update_xaxes(tickangle=45)
            fig.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                font_color='white',
                title_font_color='white'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        # Detailed campaign table
        st.markdown("#### Campaign Performance Details")
        
        display_df = df[[
            'campaign_name', 'spend', 'attributed_revenue', 'roas', 
            'ctr', 'conversion_rate', 'cost_per_conversion', 
            'performance_score', 'efficiency_rating'
        ]].copy()
        
        # Format columns
        display_df['spend'] = display_df['spend'].apply(lambda x: f"${x:,.2f}")
        display_df['attributed_revenue'] = display_df['attributed_revenue'].apply(lambda x: f"${x:,.2f}")
        display_df['roas'] = display_df['roas'].apply(lambda x: f"{x:.2f}x")
        display_df['ctr'] = display_df['ctr'].apply(lambda x: f"{x:.2f}%")
        display_df['conversion_rate'] = display_df['conversion_rate'].apply(lambda x: f"{x:.2f}%")
        display_df['cost_per_conversion'] = display_df['cost_per_conversion'].apply(lambda x: f"${x:.2f}")
        display_df['performance_score'] = display_df['performance_score'].apply(lambda x: f"{x:.1f}")
        
        display_df.columns = [
            'Campaign', 'Spend', 'Revenue', 'ROAS', 'CTR', 
            'Conv Rate', 'Cost/Conv', 'Score', 'Rating'
        ]
        
        st.dataframe(display_df, use_container_width=True)
    
    def display_adset_efficiency_analysis(self, adset_analysis: List[Dict]):
        """Display ad set efficiency and optimization insights"""
        if not adset_analysis:
            st.warning("No ad set data available for analysis")
            return
        
        st.markdown("### Ad Set Efficiency Analysis")
        
        df = pd.DataFrame(adset_analysis)
        
        # Efficiency matrix
        col1, col2 = st.columns(2)
        
        with col1:
            fig = px.scatter(
                df, 
                x='cpc', 
                y='conversion_rate',
                size='spend',
                color='audience_efficiency',
                hover_data=['adset_name', 'campaign_name', 'roas'],
                title="Ad Set Efficiency: CPC vs Conversion Rate",
                labels={'cpc': 'Cost Per Click ($)', 'conversion_rate': 'Conversion Rate (%)', 'audience_efficiency': 'Audience Efficiency'},
                color_continuous_scale='Viridis'
            )
            fig.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                font_color='white',
                title_font_color='white'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Optimization opportunities
            fig = px.bar(
                df.head(8), 
                x='adset_name', 
                y='roas',
                color='optimization_potential',
                title="Ad Set ROAS & Optimization Priority"
            )
            fig.update_xaxis(tickangle=45)
            fig.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                font_color='white',
                title_font_color='white'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        # Ad set performance table
        st.markdown("#### Ad Set Performance & Optimization")
        
        display_df = df[[
            'adset_name', 'campaign_name', 'spend', 'roas', 'ctr', 
            'cpc', 'conversion_rate', 'audience_efficiency', 'optimization_potential'
        ]].copy()
        
        # Format columns
        display_df['spend'] = display_df['spend'].apply(lambda x: f"${x:,.2f}")
        display_df['roas'] = display_df['roas'].apply(lambda x: f"{x:.2f}x")
        display_df['ctr'] = display_df['ctr'].apply(lambda x: f"{x:.2f}%")
        display_df['cpc'] = display_df['cpc'].apply(lambda x: f"${x:.2f}")
        display_df['conversion_rate'] = display_df['conversion_rate'].apply(lambda x: f"{x:.2f}%")
        display_df['audience_efficiency'] = display_df['audience_efficiency'].apply(lambda x: f"{x:.1f}")
        
        display_df.columns = [
            'Ad Set', 'Campaign', 'Spend', 'ROAS', 'CTR', 
            'CPC', 'Conv Rate', 'Audience Eff', 'Optimization'
        ]
        
        st.dataframe(display_df, use_container_width=True)
    
    def display_individual_ad_insights(self, ad_analysis: List[Dict]):
        """Display detailed individual ad performance insights"""
        if not ad_analysis:
            st.warning("No individual ad data available for analysis")
            return
        
        st.markdown("### Individual Ad Creative Performance")
        
        df = pd.DataFrame(ad_analysis)
        
        # Creative performance matrix
        col1, col2 = st.columns(2)
        
        with col1:
            fig = px.scatter(
                df.head(20), 
                x='revenue_per_impression', 
                y='creative_score',
                size='spend',
                color='performance_tier',
                hover_data=['ad_name', 'roas', 'conversion_rate'],
                title="Creative Performance: Revenue per Impression vs Creative Score",
                labels={
                    'revenue_per_impression': 'Revenue per Impression ($)', 
                    'creative_score': 'Creative Score',
                    'performance_tier': 'Performance Tier'
                }
            )
            fig.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                font_color='white',
                title_font_color='white'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Top performing ads
            top_ads = df.head(10)
            fig = px.bar(
                top_ads, 
                x='ad_name', 
                y='creative_score',
                color='scaling_potential',
                title="Top 10 Ad Creatives by Performance Score"
            )
            fig.update_xaxis(tickangle=45)
            fig.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                font_color='white',
                title_font_color='white'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        # Performance tiers breakdown
        tier_counts = df['performance_tier'].value_counts()
        col1, col2, col3, col4 = st.columns(4)
        
        for i, (tier, count) in enumerate(tier_counts.items()):
            col = [col1, col2, col3, col4][i % 4]
            with col:
                st.metric(tier, count)
        
        # Detailed ad performance table
        st.markdown("#### Individual Ad Performance Details")
        
        # Add filters
        col1, col2, col3 = st.columns(3)
        with col1:
            tier_filter = st.selectbox("Filter by Performance Tier", 
                                     ['All'] + list(df['performance_tier'].unique()))
        with col2:
            scaling_filter = st.selectbox("Filter by Scaling Potential", 
                                        ['All'] + list(df['scaling_potential'].unique()))
        with col3:
            min_spend = st.number_input("Minimum Spend", min_value=0.0, value=0.0, step=10.0)
        
        # Apply filters
        filtered_df = df.copy()
        if tier_filter != 'All':
            filtered_df = filtered_df[filtered_df['performance_tier'] == tier_filter]
        if scaling_filter != 'All':
            filtered_df = filtered_df[filtered_df['scaling_potential'] == scaling_filter]
        filtered_df = filtered_df[filtered_df['spend'] >= min_spend]
        
        # Display filtered results
        display_df = filtered_df[[
            'ad_name', 'campaign_name', 'spend', 'attributed_revenue', 'roas',
            'ctr', 'conversion_rate', 'cost_per_conversion', 'creative_score',
            'performance_tier', 'scaling_potential'
        ]].copy()
        
        # Format columns
        display_df['spend'] = display_df['spend'].apply(lambda x: f"${x:,.2f}")
        display_df['attributed_revenue'] = display_df['attributed_revenue'].apply(lambda x: f"${x:,.2f}")
        display_df['roas'] = display_df['roas'].apply(lambda x: f"{x:.2f}x")
        display_df['ctr'] = display_df['ctr'].apply(lambda x: f"{x:.2f}%")
        display_df['conversion_rate'] = display_df['conversion_rate'].apply(lambda x: f"{x:.2f}%")
        display_df['cost_per_conversion'] = display_df['cost_per_conversion'].apply(lambda x: f"${x:.2f}")
        display_df['creative_score'] = display_df['creative_score'].apply(lambda x: f"{x:.1f}")
        
        display_df.columns = [
            'Ad Creative', 'Campaign', 'Spend', 'Revenue', 'ROAS',
            'CTR', 'Conv Rate', 'Cost/Conv', 'Score', 'Tier', 'Scaling'
        ]
        
        st.dataframe(display_df, use_container_width=True, height=400)
    
    def display_service_optimization_insights(self, service_analysis: Dict):
        """Display service/treatment performance for campaign optimization"""
        if not service_analysis.get('services'):
            st.warning("No service performance data available")
            return
        
        st.markdown("### Service/Treatment Performance Analysis")
        
        services = service_analysis['services']
        df = pd.DataFrame(services)
        
        # Service performance overview
        col1, col2 = st.columns(2)
        
        with col1:
            # Revenue breakdown pie chart
            fig = px.pie(
                df, 
                values='revenue', 
                names='service',
                title="Revenue Distribution by Service/Treatment",
                color_discrete_sequence=px.colors.qualitative.Set3
            )
            fig.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                font_color='white',
                title_font_color='white'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Service ROAS comparison
            fig = px.bar(
                df.head(8), 
                x='service', 
                y='estimated_roas',
                color='optimization_priority',
                title="Service ROAS & Optimization Priority",
                labels={'estimated_roas': 'Estimated ROAS', 'service': 'Service/Treatment'}
            )
            fig.add_hline(y=2.0, line_dash="dash", line_color="green", annotation_text="Target ROAS")
            fig.update_xaxis(tickangle=45)
            fig.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                font_color='white',
                title_font_color='white'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        # Service metrics grid
        st.markdown("#### Service Performance Metrics")
        
        # Top performers
        col1, col2, col3 = st.columns(3)
        
        with col1:
            top_revenue = df.iloc[0] if not df.empty else None
            if top_revenue:
                st.metric(
                    "Top Revenue Generator",
                    top_revenue['service'],
                    f"${top_revenue['revenue']:,.0f} ({top_revenue['revenue_share']:.1f}%)"
                )
        
        with col2:
            high_value = df.loc[df['average_value'].idxmax()] if not df.empty else None
            if high_value:
                st.metric(
                    "Highest Average Value",
                    high_value['service'],
                    f"${high_value['average_value']:,.0f}"
                )
        
        with col3:
            best_roas = df.loc[df['estimated_roas'].idxmax()] if not df.empty else None
            if best_roas:
                st.metric(
                    "Best ROAS",
                    best_roas['service'],
                    f"{best_roas['estimated_roas']:.2f}x"
                )
        
        # Detailed service table
        display_df = df.copy()
        display_df['revenue'] = display_df['revenue'].apply(lambda x: f"${x:,.2f}")
        display_df['average_value'] = display_df['average_value'].apply(lambda x: f"${x:,.2f}")
        display_df['revenue_share'] = display_df['revenue_share'].apply(lambda x: f"{x:.1f}%")
        display_df['estimated_roas'] = display_df['estimated_roas'].apply(lambda x: f"{x:.2f}x")
        
        display_df.columns = [
            'Service/Treatment', 'Revenue', 'Transactions', 'Avg Value',
            'Revenue Share', 'Est. ROAS', 'Optimization Priority'
        ]
        
        st.dataframe(display_df, use_container_width=True)
        
        # Strategic insights
        insights = service_analysis.get('insights', [])
        if insights:
            st.markdown("#### Strategic Insights & Recommendations")
            for i, insight in enumerate(insights, 1):
                st.markdown(f"**{i}.** {insight}")
    
    def display_performance_summary_dashboard(self, analysis_data: Dict):
        """Display executive summary dashboard with key insights"""
        summary = analysis_data.get('summary_metrics', {})
        
        st.markdown("### Performance Summary Dashboard")
        
        # Key metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                "Total Revenue",
                f"${summary.get('total_revenue', 0):,.2f}",
                help="Total attributed revenue from Meta campaigns"
            )
        
        with col2:
            st.metric(
                "Total Ad Spend",
                f"${summary.get('total_spend', 0):,.2f}",
                help="Total spend across all campaigns"
            )
        
        with col3:
            st.metric(
                "Overall ROAS",
                f"{summary.get('overall_roas', 0):.2f}x",
                help="Overall return on ad spend"
            )
        
        with col4:
            st.metric(
                "Total Conversions",
                f"{summary.get('total_conversions', 0):.0f}",
                help="Total attributed conversions"
            )
        
        # Performance insights
        campaigns = analysis_data.get('campaign_analysis', [])
        ads = analysis_data.get('ad_analysis', [])
        
        if campaigns and ads:
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### Top Performing Elements")
                
                # Best campaign
                best_campaign = max(campaigns, key=lambda x: x.get('roas', 0))
                st.markdown(f"**Best Campaign:** {best_campaign.get('campaign_name', 'N/A')} ({best_campaign.get('roas', 0):.2f}x ROAS)")
                
                # Best ad
                best_ad = max(ads, key=lambda x: x.get('creative_score', 0))
                st.markdown(f"**Best Ad Creative:** {best_ad.get('ad_name', 'N/A')} ({best_ad.get('creative_score', 0):.1f} score)")
                
                # Performance distribution
                excellent_campaigns = len([c for c in campaigns if c.get('efficiency_rating') == 'Excellent'])
                st.markdown(f"**Excellent Campaigns:** {excellent_campaigns}/{len(campaigns)}")
            
            with col2:
                st.markdown("#### Optimization Opportunities")
                
                # Scaling opportunities
                scalable_ads = len([a for a in ads if 'High' in a.get('scaling_potential', '')])
                st.markdown(f"**Ready to Scale:** {scalable_ads} ads identified")
                
                # Underperformers
                underperformers = len([c for c in campaigns if c.get('roas', 0) < 1.0])
                st.markdown(f"**Need Optimization:** {underperformers} campaigns below breakeven")
                
                # High potential
                high_score_ads = len([a for a in ads if a.get('creative_score', 0) > 70])
                st.markdown(f"**High Performers:** {high_score_ads} top-scoring ads")