"""
Advanced Audit & Debugging Dashboard
Comprehensive system to ensure all metrics and data sources are accurate and connected
Eliminates mock data and ensures robust, high-quality real data connections
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import os
import requests
from pyairtable import Api
import logging
import json
from typing import Dict, List, Tuple, Any
from datetime import datetime, timedelta
import hashlib
from typing import Dict, Tuple, Optional

# Configure comprehensive logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Advanced Audit Dashboard",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="collapsed"
)

def apply_advanced_audit_styling():
    """Advanced styling for audit dashboard"""
    st.markdown("""
    <style>
    .stApp {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    }
    
    .audit-header {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(20px);
        border-radius: 20px;
        padding: 30px;
        margin: 20px 0;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    }
    
    .audit-title {
        font-size: 32px;
        font-weight: 700;
        color: #1d1d1f;
        margin: 0 0 10px 0;
    }
    
    .status-card {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 16px;
        padding: 20px;
        margin: 12px 0;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    }
    
    .status-success { border-left: 4px solid #34c759; }
    .status-error { border-left: 4px solid #ff3b30; }
    .status-warning { border-left: 4px solid #ff9500; }
    
    .metric-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin: 20px 0;
    }
    </style>
    """, unsafe_allow_html=True)

class AdvancedDataAuditor:
    """Advanced data auditing and validation system"""
    
    def __init__(self):
        self.audit_results = {
            'timestamp': datetime.now().isoformat(),
            'connections': {},
            'data_quality': {},
            'metrics_validation': {},
            'security_check': {},
            'performance': {}
        }
    
    def audit_environment_security(self) -> Dict:
        """Comprehensive security audit of environment variables"""
        st.subheader("🔐 Security & Environment Audit")
        
        required_vars = {
            'AIRTABLE_API_KEY': {'min_length': 15, 'prefix': 'pat'},
            'META_ACCESS_TOKEN': {'min_length': 20, 'prefix': None},
            'META_AD_ACCOUNT_ID': {'min_length': 10, 'prefix': None},
            'META_PIXEL_ID': {'min_length': 10, 'prefix': None}
        }
        
        security_status = {}
        
        for var_name, requirements in required_vars.items():
            value = os.getenv(var_name)
            
            status = {
                'exists': value is not None,
                'length_valid': len(value) >= requirements['min_length'] if value else False,
                'format_valid': True,
                'security_level': 'high'
            }
            
            if value:
                # Check prefix requirements
                if requirements['prefix'] and not value.startswith(requirements['prefix']):
                    status['format_valid'] = False
                    status['security_level'] = 'low'
                
                # Mask sensitive data for display
                masked_value = f"{value[:4]}...{value[-4:]}" if len(value) > 8 else "***"
                status['display_value'] = masked_value
            else:
                status['display_value'] = "❌ MISSING"
                status['security_level'] = 'critical'
            
            security_status[var_name] = status
            
            # Display status
            if status['exists'] and status['length_valid'] and status['format_valid']:
                st.success(f"✅ {var_name}: {status['display_value']} - Secure")
            elif status['exists']:
                st.warning(f"⚠️ {var_name}: {status['display_value']} - Validation Issues")
            else:
                st.error(f"❌ {var_name}: Missing - Critical")
        
        self.audit_results['security_check'] = security_status
        return security_status
    
    def audit_airtable_connection(self) -> Tuple[bool, Dict]:
        """Advanced Airtable connection audit with detailed diagnostics"""
        st.subheader("📊 Airtable Connection Audit")
        
        airtable_key = os.getenv('AIRTABLE_API_KEY')
        if not airtable_key:
            st.error("❌ Airtable API key not found")
            return False, {'error': 'missing_api_key'}
        
        try:
            # Test connection with timeout and retry logic
            api = Api(airtable_key)
            
            # Test multiple table configurations
            table_configs = [
                {'base': 'appwPsfAb2ZmWqhJD', 'table': 'tblhU4gONxgdA5jTF', 'name': 'Leads'},
                {'base': 'appwPsfAb2ZmWqhJD', 'table': 'tbl364vtt5U8DxmT3', 'name': 'Transactions'}
            ]
            
            connection_results = {}
            
            for config in table_configs:
                st.write(f"🔍 Testing {config['name']} table...")
                
                try:
                    table = api.table(config['base'], config['table'])
                    
                    # Test with minimal data first
                    test_records = table.all(max_records=3)
                    
                    if test_records:
                        df = pd.DataFrame([record['fields'] for record in test_records])
                        
                        connection_results[config['name']] = {
                            'status': 'success',
                            'record_count': len(df),
                            'columns': list(df.columns),
# REMOVED:                             'sample_data': dict(df.iloc[0]) if len(df) > 0 else {},
                            'data_types': df.dtypes.to_dict() if len(df) > 0 else {}
                        }
                        
                        st.success(f"✅ {config['name']}: {len(df)} records, {len(df.columns)} columns")
                        
                        # Show column analysis
                        with st.expander(f"📋 {config['name']} Column Analysis"):
                            col1, col2 = st.columns(2)
                            with col1:
                                st.write("**Available Columns:**")
                                for col in df.columns:
                                    st.write(f"• {col}")
                            with col2:
                                st.write("**Sample Record:**")
# REMOVED:                                 st.json(connection_results[config['name']]['sample_data'])
                    
                    else:
                        st.warning(f"⚠️ {config['name']}: Connected but no records found")
                        connection_results[config['name']] = {
                            'status': 'empty',
                            'record_count': 0
                        }
                
                except Exception as table_error:
                    st.error(f"❌ {config['name']}: {str(table_error)}")
                    connection_results[config['name']] = {
                        'status': 'error',
                        'error': str(table_error)
                    }
            
            self.audit_results['connections']['airtable'] = connection_results
            
            # Overall success if at least one table works
            success = any(result.get('status') == 'success' for result in connection_results.values())
            return success, connection_results
            
        except Exception as e:
            st.error(f"❌ Airtable API Error: {str(e)}")
            error_result = {'error': str(e), 'status': 'failed'}
            self.audit_results['connections']['airtable'] = error_result
            return False, error_result
    
    def audit_meta_api_connection(self) -> Tuple[bool, Dict]:
        """Advanced Meta API connection audit with performance testing"""
        st.subheader("📈 Meta API Connection Audit")
        
        access_token = os.getenv('META_ACCESS_TOKEN')
        ad_account_id = os.getenv('META_AD_ACCOUNT_ID')
        
        if not access_token or not ad_account_id:
            st.error("❌ Meta API credentials missing")
            return False, {'error': 'missing_credentials'}
        
        try:
            # Test different API endpoints
            test_endpoints = [
                {
                    'name': 'Account Insights',
                    'url': f"https://graph.facebook.com/v18.0/act_{ad_account_id}/insights",
                    'params': {
                        'access_token': access_token,
                        'fields': 'spend,impressions,clicks,actions',
                        'date_preset': 'last_7d',
                        'limit': 5
                    }
                },
                {
                    'name': 'Account Info',
                    'url': f"https://graph.facebook.com/v18.0/act_{ad_account_id}",
                    'params': {
                        'access_token': access_token,
                        'fields': 'name,account_status,currency'
                    }
                }
            ]
            
            meta_results = {}
            
            for endpoint in test_endpoints:
                st.write(f"🔍 Testing {endpoint['name']}...")
                
                start_time = datetime.now()
                response = requests.get(endpoint['url'], params=endpoint['params'], timeout=15)
                response_time = (datetime.now() - start_time).total_seconds()
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if endpoint['name'] == 'Account Insights':
                        insights = data.get('data', [])
                        total_spend = sum(float(insight.get('spend', 0)) for insight in insights)
                        total_impressions = sum(int(insight.get('impressions', 0)) for insight in insights)
                        
                        meta_results[endpoint['name']] = {
                            'status': 'success',
                            'response_time': response_time,
                            'insights_count': len(insights),
                            'total_spend': total_spend,
                            'total_impressions': total_impressions,
                            'sample_insight': insights[0] if insights else {}
                        }
                        
                        st.success(f"✅ {endpoint['name']}: ${total_spend:,.2f} spend, {total_impressions:,} impressions")
                        
                    else:
                        meta_results[endpoint['name']] = {
                            'status': 'success',
                            'response_time': response_time,
                            'data': data
                        }
                        st.success(f"✅ {endpoint['name']}: Connected successfully")
                
                else:
                    error_msg = f"HTTP {response.status_code}"
                    st.error(f"❌ {endpoint['name']}: {error_msg}")
                    meta_results[endpoint['name']] = {
                        'status': 'error',
                        'error': error_msg,
                        'response_time': response_time
                    }
            
            self.audit_results['connections']['meta'] = meta_results
            
            # Success if insights endpoint works
            success = meta_results.get('Account Insights', {}).get('status') == 'success'
            return success, meta_results
            
        except Exception as e:
            st.error(f"❌ Meta API Error: {str(e)}")
            error_result = {'error': str(e), 'status': 'failed'}
            self.audit_results['connections']['meta'] = error_result
            return False, error_result
    
    def validate_data_quality(self, airtable_success: bool, airtable_data: Dict) -> Dict:
        """Comprehensive data quality validation"""
        st.subheader("🎯 Data Quality Validation")
        
        if not airtable_success:
            st.error("❌ Cannot validate data quality - Airtable connection failed")
            return {'status': 'failed', 'reason': 'no_connection'}
        
        try:
            # Load full datasets for comprehensive analysis
            api = Api(os.getenv('AIRTABLE_API_KEY'))
            
            # Load leads data
            leads_table = api.table('appwPsfAb2ZmWqhJD', 'tblhU4gONxgdA5jTF')
            leads_records = leads_table.all()
            leads_df = pd.DataFrame([record['fields'] for record in leads_records])
            
            # Load transactions data  
            trans_table = api.table('appwPsfAb2ZmWqhJD', 'tbl364vtt5U8DxmT3')
            trans_records = trans_table.all()
            trans_df = pd.DataFrame([record['fields'] for record in trans_records])
            
            st.success(f"📊 Loaded {len(leads_df)} leads and {len(trans_df)} transactions")
            
            # Data quality metrics
            quality_metrics = {}
            
            # 1. Lead Data Quality
            st.write("**🔍 Lead Data Analysis:**")
            
            leads_quality = {
                'total_records': len(leads_df),
                'missing_data_percentage': 0,
                'duplicate_percentage': 0,
                'valid_brands': 0,
                'valid_sources': 0
            }
            
            if not leads_df.empty:
                # Check for missing data
                missing_data = leads_df.isnull().sum().sum()
                total_cells = len(leads_df) * len(leads_df.columns)
                leads_quality['missing_data_percentage'] = (missing_data / total_cells) * 100
                
                # Check for duplicates
                duplicates = leads_df.duplicated().sum()
                leads_quality['duplicate_percentage'] = (duplicates / len(leads_df)) * 100
                
                # Brand analysis
                if 'Brand' in leads_df.columns:
                    brand_counts = leads_df['Brand'].value_counts()
                    smooth_md_count = leads_df['Brand'].astype(str).str.contains('Smooth MD', case=False, na=False).sum()
                    leads_quality['valid_brands'] = smooth_md_count
                    st.write(f"• **Smooth MD Leads:** {smooth_md_count} / {len(leads_df)} ({(smooth_md_count/len(leads_df)*100):.1f}%)")
                
                # Source analysis
                if 'Contact Source' in leads_df.columns:
                    source_counts = leads_df['Contact Source'].value_counts()
                    meta_sources = leads_df['Contact Source'].astype(str).str.contains(
                        'Facebook|Instagram|Meta', case=False, na=False
                    ).sum()
                    leads_quality['valid_sources'] = meta_sources
                    st.write(f"• **Meta Sources:** {meta_sources} / {len(leads_df)} ({(meta_sources/len(leads_df)*100):.1f}%)")
                
                st.write(f"• **Data Completeness:** {100-leads_quality['missing_data_percentage']:.1f}%")
                st.write(f"• **Duplicate Rate:** {leads_quality['duplicate_percentage']:.1f}%")
            
            # 2. Transaction Data Quality
            st.write("**💰 Transaction Data Analysis:**")
            
            trans_quality = {
                'total_records': len(trans_df),
                'valid_amounts': 0,
                'total_revenue': 0,
                'amount_range': {'min': 0, 'max': 0},
                'missing_data_percentage': 0
            }
            
            if not trans_df.empty:
                # Revenue analysis
                if 'Amount' in trans_df.columns:
                    amounts = pd.to_numeric(trans_df['Amount'], errors='coerce').dropna()
                    trans_quality['valid_amounts'] = len(amounts)
                    trans_quality['total_revenue'] = float(amounts.sum())
                    
                    if len(amounts) > 0:
                        trans_quality['amount_range'] = {
                            'min': float(amounts.min()),
                            'max': float(amounts.max()),
                            'avg': float(amounts.mean())
                        }
                    
                    st.write(f"• **Total Revenue:** ${trans_quality['total_revenue']:,.2f}")
                    st.write(f"• **Valid Transactions:** {len(amounts)} / {len(trans_df)}")
                    st.write(f"• **Average Amount:** ${trans_quality['amount_range']['avg']:,.2f}")
                    st.write(f"• **Range:** ${trans_quality['amount_range']['min']:,.2f} - ${trans_quality['amount_range']['max']:,.2f}")
                
                # Missing data analysis
                missing_trans_data = trans_df.isnull().sum().sum()
                total_trans_cells = len(trans_df) * len(trans_df.columns)
                trans_quality['missing_data_percentage'] = (missing_trans_data / total_trans_cells) * 100
                st.write(f"• **Data Completeness:** {100-trans_quality['missing_data_percentage']:.1f}%")
            
            quality_metrics = {
                'leads': leads_quality,
                'transactions': trans_quality,
                'overall_score': self._calculate_quality_score(leads_quality, trans_quality)
            }
            
            self.audit_results['data_quality'] = quality_metrics
            
            # Display quality score
            score = quality_metrics['overall_score']
            if score >= 80:
                st.success(f"✅ **Data Quality Score: {score:.1f}/100** - Excellent")
            elif score >= 60:
                st.warning(f"⚠️ **Data Quality Score: {score:.1f}/100** - Good")
            else:
                st.error(f"❌ **Data Quality Score: {score:.1f}/100** - Needs Improvement")
            
            return quality_metrics
            
        except Exception as e:
            st.error(f"❌ Data validation error: {str(e)}")
            return {'status': 'error', 'error': str(e)}
    
    def _calculate_quality_score(self, leads_quality: Dict, trans_quality: Dict) -> float:
        """Calculate overall data quality score"""
        score = 0
        
        # Data completeness (40% weight)
        leads_completeness = 100 - leads_quality.get('missing_data_percentage', 100)
        trans_completeness = 100 - trans_quality.get('missing_data_percentage', 100)
        completeness_score = (leads_completeness + trans_completeness) / 2
        score += completeness_score * 0.4
        
        # Revenue validity (30% weight)
        if trans_quality.get('total_revenue', 0) > 0:
            revenue_score = min(100, (trans_quality['valid_amounts'] / max(1, trans_quality['total_records'])) * 100)
            score += revenue_score * 0.3
        
        # Lead filtering efficiency (20% weight)
        if leads_quality.get('total_records', 0) > 0:
            brand_efficiency = (leads_quality.get('valid_brands', 0) / leads_quality['total_records']) * 100
            source_efficiency = (leads_quality.get('valid_sources', 0) / leads_quality['total_records']) * 100
            filtering_score = (brand_efficiency + source_efficiency) / 2
            score += filtering_score * 0.2
        
        # Duplicate prevention (10% weight)
        duplicate_score = 100 - leads_quality.get('duplicate_percentage', 0)
        score += duplicate_score * 0.1
        
        return min(100, max(0, score))
    
    def generate_optimization_recommendations(self) -> List[str]:
        """Generate actionable optimization recommendations"""
        recommendations = []
        
        # Connection issues
        airtable_status = self.audit_results.get('connections', {}).get('airtable', {})
        meta_status = self.audit_results.get('connections', {}).get('meta', {})
        
        if not any(table.get('status') == 'success' for table in airtable_status.values()):
            recommendations.append("🔑 **Airtable Connection**: Update API key permissions or verify table access")
        
        if not meta_status.get('Account Insights', {}).get('status') == 'success':
            recommendations.append("🔑 **Meta API Connection**: Verify access token and ad account permissions")
        
        # Data quality issues
        quality_data = self.audit_results.get('data_quality', {})
        
        if quality_data.get('overall_score', 0) < 70:
            recommendations.append("📊 **Data Quality**: Improve data completeness and reduce missing values")
        
        if quality_data.get('transactions', {}).get('total_revenue', 0) == 0:
            recommendations.append("💰 **Revenue Data**: Verify transaction Amount column and data format")
        
        leads_quality = quality_data.get('leads', {})
        if leads_quality.get('valid_brands', 0) / max(1, leads_quality.get('total_records', 1)) < 0.1:
            recommendations.append("🏷️ **Lead Filtering**: Review brand filtering criteria for better efficiency")
        
        if not recommendations:
            recommendations.append("✅ **All Systems Optimal**: Your dashboard is performing excellently!")
        
        return recommendations

def main():
    """Main audit dashboard application"""
    
    # Apply styling
    apply_advanced_audit_styling()
    
    # Header
    st.markdown("""
    <div class="audit-header">
        <h1 class="audit-title">🔬 Advanced Audit & Debugging Dashboard</h1>
        <p>Comprehensive system ensuring all metrics and data sources are accurate and connected</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize auditor
    auditor = AdvancedDataAuditor()
    
    # Run comprehensive audit
    st.header("🔍 Comprehensive System Audit")
    
    with st.spinner("Running advanced diagnostics..."):
        # 1. Security audit
        security_results = auditor.audit_environment_security()
        
        # 2. Connection audits
        airtable_success, airtable_data = auditor.audit_airtable_connection()
        meta_success, meta_data = auditor.audit_meta_api_connection()
        
        # 3. Data quality validation
        quality_results = auditor.validate_data_quality(airtable_success, airtable_data)
    
    # Summary dashboard
    st.header("📊 Audit Results Summary")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        security_score = sum(1 for status in security_results.values() 
                           if status.get('exists') and status.get('length_valid') and status.get('format_valid'))
        st.metric("🔐 Security", f"{security_score}/4", "Keys Valid")
    
    with col2:
        connection_score = (1 if airtable_success else 0) + (1 if meta_success else 0)
        st.metric("🔗 Connections", f"{connection_score}/2", "APIs Connected")
    
    with col3:
        quality_score = quality_results.get('overall_score', 0)
        st.metric("📊 Data Quality", f"{quality_score:.0f}/100", "Quality Score")
    
    with col4:
        total_revenue = quality_results.get('transactions', {}).get('total_revenue', 0)
        st.metric("💰 Revenue Data", f"${total_revenue:,.0f}", "Total Found")
    
    # Optimization recommendations
    st.header("🚀 Optimization Recommendations")
    
    recommendations = auditor.generate_optimization_recommendations()
    
    for i, rec in enumerate(recommendations, 1):
        st.write(f"{i}. {rec}")
    
    # Detailed results
    with st.expander("📋 Detailed Audit Results"):
        st.json(auditor.audit_results)
    
    # Real-time monitoring
    st.header("📈 Real-time Monitoring")
    
    if airtable_success and meta_success:
        # Show live metrics
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📊 Live Airtable Metrics")
            if quality_results.get('leads'):
                leads_data = quality_results['leads']
                st.write(f"• Total Leads: {leads_data.get('total_records', 0)}")
                st.write(f"• Smooth MD Leads: {leads_data.get('valid_brands', 0)}")
                st.write(f"• Meta Sources: {leads_data.get('valid_sources', 0)}")
        
        with col2:
            st.subheader("📈 Live Meta Metrics")
            if meta_data.get('Account Insights'):
                insights_data = meta_data['Account Insights']
                st.write(f"• Total Spend: ${insights_data.get('total_spend', 0):,.2f}")
                st.write(f"• Impressions: {insights_data.get('total_impressions', 0):,}")
                st.write(f"• Response Time: {insights_data.get('response_time', 0):.2f}s")
        
        # Calculate and display ROAS
        if quality_results.get('transactions', {}).get('total_revenue', 0) > 0 and meta_data.get('Account Insights', {}).get('total_spend', 0) > 0:
            revenue = quality_results['transactions']['total_revenue']
            spend = meta_data['Account Insights']['total_spend']
            roas = revenue / spend
            
            st.success(f"🎯 **Real ROAS Calculated: {roas:.2f}x** (${revenue:,.2f} revenue / ${spend:,.2f} spend)")
        else:
            st.warning("⚠️ Cannot calculate ROAS - missing revenue or spend data")
    
    else:
        st.error("❌ Cannot display real-time monitoring - API connections required")
    
    # Auto-refresh option
    if st.button("🔄 Refresh Audit", type="primary"):
        st.experimental_rerun()

if __name__ == "__main__":
    main()