"""
Data Validation Audit
Comprehensive audit of lead matching, brand filtering, and revenue attribution for Smooth MD
"""

import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import logging
from unified_production_connector import unified_connector
from advanced_lead_matcher import advanced_lead_matcher

logger = logging.getLogger(__name__)

def audit_raw_data_samples():
    """Audit raw data samples to understand actual field values"""
    
    st.markdown("## Raw Data Sample Audit")
    
    # Load small sample of raw data
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    transaction_result = unified_connector.load_transactions(start_date, end_date)
    lead_result = unified_connector.load_leads(start_date, end_date)
    
    if not transaction_result.success or not lead_result.success:
        st.error("Failed to load raw data")
        return None, None
    
    # Sample leads data
    st.markdown("### Lead Data Sample (First 5 Records)")
    if lead_result.data:
        sample_leads = lead_result.data[:5]
        for i, lead in enumerate(sample_leads):
            fields = lead.get('fields', {})
            st.markdown(f"**Lead {i+1}:**")
            
            brand = fields.get('Brand', 'N/A')
            contact_source = fields.get('Contact Source', 'N/A')
            email = fields.get('Email', 'N/A')
            status = fields.get('Overall Status', 'N/A')
            
            st.write(f"- Brand: {brand}")
            st.write(f"- Contact Source: {contact_source}")
            st.write(f"- Email: {email}")
            st.write(f"- Status: {status}")
            st.markdown("---")
    
    # Sample transaction data
    st.markdown("### Transaction Data Sample (First 5 Records)")
    if transaction_result.data:
        sample_transactions = transaction_result.data[:5]
        for i, transaction in enumerate(sample_transactions):
            fields = transaction.get('fields', {})
            st.markdown(f"**Transaction {i+1}:**")
            
            amount = fields.get('Amount', 'N/A')
            patient = fields.get('Patient', 'N/A')
            date = fields.get('Date', 'N/A')
            links = fields.get('ID', 'N/A')  # Lead links
            
            st.write(f"- Amount: ${amount}")
            st.write(f"- Patient: {patient}")
            st.write(f"- Date: {date}")
            st.write(f"- Lead Links: {links}")
            st.markdown("---")
    
    return lead_result.data, transaction_result.data

def audit_brand_filtering(leads_data):
    """Audit brand filtering logic"""
    
    st.markdown("## Brand Filtering Audit")
    
    if not leads_data:
        st.error("No leads data available")
        return
    
    # Analyze all unique brand values
    brand_values = {}
    for lead in leads_data:
        fields = lead.get('fields', {})
        brand = fields.get('Brand', '')
        if brand:
            brand_values[brand] = brand_values.get(brand, 0) + 1
    
    st.markdown("### All Brand Values in Dataset")
    brand_df = pd.DataFrame(list(brand_values.items()), columns=['Brand', 'Count'])
    brand_df = brand_df.sort_values('Count', ascending=False)
    st.dataframe(brand_df)
    
    # Test Smooth MD pattern matching
    st.markdown("### Smooth MD Pattern Matching Test")
    smooth_patterns = ['smooth md', 'smooth m.d.', 'smooth m.d', 'smoothmd']
    
    smooth_matches = {}
    for brand, count in brand_values.items():
        is_smooth = any(pattern in brand.lower() for pattern in smooth_patterns)
        if is_smooth:
            smooth_matches[brand] = count
    
    if smooth_matches:
        st.success(f"Found {len(smooth_matches)} Smooth MD brand variations:")
        for brand, count in smooth_matches.items():
            st.write(f"- '{brand}': {count} leads")
    else:
        st.error("No Smooth MD brands found with current patterns")
        st.warning("Consider updating brand patterns based on actual data")

def audit_meta_source_filtering(leads_data):
    """Audit Meta source filtering logic"""
    
    st.markdown("## Meta Source Filtering Audit")
    
    if not leads_data:
        st.error("No leads data available")
        return
    
    # Analyze all unique contact source values
    source_values = {}
    for lead in leads_data:
        fields = lead.get('fields', {})
        source = fields.get('Contact Source', '')
        if source:
            source_values[source] = source_values.get(source, 0) + 1
    
    st.markdown("### All Contact Source Values in Dataset")
    source_df = pd.DataFrame(list(source_values.items()), columns=['Contact Source', 'Count'])
    source_df = source_df.sort_values('Count', ascending=False)
    st.dataframe(source_df)
    
    # Test Meta pattern matching
    st.markdown("### Meta Source Pattern Matching Test")
    meta_patterns = ['facebook ad', 'instagram ad', 'meta', 'fb', 'ig', 'facebook ads', 'instagram ads', 'meta ads']
    
    meta_matches = {}
    for source, count in source_values.items():
        is_meta = any(pattern in source.lower() for pattern in meta_patterns)
        if is_meta:
            meta_matches[source] = count
    
    if meta_matches:
        st.success(f"Found {len(meta_matches)} Meta source variations:")
        for source, count in meta_matches.items():
            st.write(f"- '{source}': {count} leads")
    else:
        st.error("No Meta sources found with current patterns")
        st.warning("Consider updating Meta source patterns based on actual data")

def audit_lead_matching_process(leads_data, transactions_data):
    """Audit the complete lead matching process"""
    
    st.markdown("## Lead Matching Process Audit")
    
    if not leads_data or not transactions_data:
        st.error("Missing data for matching audit")
        return
    
    # Step 1: Identify Meta leads
    meta_leads = advanced_lead_matcher.identify_meta_leads(leads_data)
    
    st.markdown("### Step 1: Meta Lead Identification")
    st.write(f"Total leads processed: {len(leads_data)}")
    st.write(f"Meta leads identified: {len(meta_leads)}")
    st.write(f"Identification rate: {len(meta_leads)/len(leads_data)*100:.1f}%")
    
    # Analyze identified leads by brand
    brand_breakdown = {}
    source_breakdown = {}
    
    for lead in meta_leads:
        brand = lead.get('brand', 'Unknown')
        source = lead.get('contact_source', 'Unknown')
        
        brand_breakdown[brand] = brand_breakdown.get(brand, 0) + 1
        source_breakdown[source] = source_breakdown.get(source, 0) + 1
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Meta Leads by Brand:**")
        for brand, count in brand_breakdown.items():
            st.write(f"- {brand}: {count}")
    
    with col2:
        st.markdown("**Meta Leads by Source:**")
        for source, count in source_breakdown.items():
            st.write(f"- {source}: {count}")
    
    # Step 2: Transaction matching
    matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
        meta_leads, transactions_data
    )
    
    st.markdown("### Step 2: Transaction Matching")
    st.write(f"Leads with transactions: {len([l for l in matched_leads if l['matched_transactions']])}")
    st.write(f"Total transactions matched: {sum(len(l['matched_transactions']) for l in matched_leads)}")
    st.write(f"Attribution rate: {matching_stats.get('attribution_rate', 0):.1f}%")
    st.write(f"Total attributed revenue: ${matching_stats.get('total_matched_revenue', 0):,.2f}")
    
    # Analyze matching methods
    st.markdown("**Matching Methods Used:**")
    methods = ['direct_link_matches', 'email_matches', 'phone_matches', 'patient_id_matches']
    for method in methods:
        count = matching_stats.get(method, 0)
        st.write(f"- {method.replace('_', ' ').title()}: {count}")
    
    return matched_leads, matching_stats

def audit_revenue_attribution(matched_leads):
    """Audit revenue attribution calculations"""
    
    st.markdown("## Revenue Attribution Audit")
    
    if not matched_leads:
        st.error("No matched leads data available")
        return
    
    # Analyze revenue distribution
    revenue_data = []
    for lead in matched_leads:
        if lead['matched_transactions']:
            for transaction in lead['matched_transactions']:
                revenue_data.append({
                    'lead_id': lead['record_id'],
                    'brand': lead['brand'],
                    'source': lead['contact_source'],
                    'amount': transaction['amount'],
                    'match_method': transaction.get('match_method', 'unknown')
                })
    
    if revenue_data:
        revenue_df = pd.DataFrame(revenue_data)
        
        st.markdown("### Revenue Attribution Summary")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            total_revenue = revenue_df['amount'].sum()
            st.metric("Total Attributed Revenue", f"${total_revenue:,.2f}")
        
        with col2:
            avg_transaction = revenue_df['amount'].mean()
            st.metric("Average Transaction", f"${avg_transaction:,.2f}")
        
        with col3:
            transaction_count = len(revenue_df)
            st.metric("Transaction Count", transaction_count)
        
        # Revenue by brand
        st.markdown("### Revenue by Brand")
        brand_revenue = revenue_df.groupby('brand')['amount'].agg(['sum', 'count', 'mean'])
        st.dataframe(brand_revenue)
        
        # Revenue by source
        st.markdown("### Revenue by Contact Source")
        source_revenue = revenue_df.groupby('source')['amount'].agg(['sum', 'count', 'mean'])
        st.dataframe(source_revenue)
        
        # Revenue by matching method
        st.markdown("### Revenue by Matching Method")
        method_revenue = revenue_df.groupby('match_method')['amount'].agg(['sum', 'count', 'mean'])
        st.dataframe(method_revenue)
    
    else:
        st.warning("No revenue attribution data found")

def generate_optimization_recommendations(audit_results):
    """Generate specific optimization recommendations"""
    
    st.markdown("## Optimization Recommendations")
    
    recommendations = []
    
    # Check if we have the correct data
    if not audit_results:
        recommendations.append({
            'priority': 'Critical',
            'issue': 'Data loading failed',
            'recommendation': 'Check API credentials and network connectivity'
        })
    
    # Add specific recommendations based on audit findings
    # This would be populated based on the actual audit results
    
    if recommendations:
        for i, rec in enumerate(recommendations, 1):
            priority_color = {
                'Critical': 'red',
                'High': 'orange',
                'Medium': 'blue',
                'Low': 'green'
            }.get(rec['priority'], 'gray')
            
            st.markdown(f"""
            **{i}. {rec['issue']}** <span style="color:{priority_color}">({rec['priority']} Priority)</span>
            
            **Recommendation:** {rec['recommendation']}
            """, unsafe_allow_html=True)
            st.markdown("---")
    else:
        st.success("No critical issues identified in current configuration")

def main():
    """Main audit application"""
    
    st.set_page_config(
        page_title="Data Validation Audit",
        page_icon="🔍",
        layout="wide"
    )
    
    st.title("🔍 Data Validation Audit")
    st.markdown("**Comprehensive audit of Smooth MD lead matching and revenue attribution**")
    
    with st.spinner("Running comprehensive data audit..."):
        
        # Step 1: Raw data audit
        leads_data, transactions_data = audit_raw_data_samples()
        
        if leads_data and transactions_data:
            # Step 2: Brand filtering audit
            audit_brand_filtering(leads_data)
            
            # Step 3: Meta source filtering audit
            audit_meta_source_filtering(leads_data)
            
            # Step 4: Lead matching process audit
            matched_leads, matching_stats = audit_lead_matching_process(leads_data, transactions_data)
            
            # Step 5: Revenue attribution audit
            if matched_leads:
                audit_revenue_attribution(matched_leads)
            
            # Step 6: Generate recommendations
            generate_optimization_recommendations({
                'leads_data': leads_data,
                'transactions_data': transactions_data,
                'matched_leads': matched_leads,
                'matching_stats': matching_stats
            })
        
        else:
            st.error("Failed to load data for audit")

if __name__ == "__main__":
    main()