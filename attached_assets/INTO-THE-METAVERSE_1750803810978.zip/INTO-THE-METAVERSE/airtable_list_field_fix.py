
"""
Airtable List Field Fix
Handles cases where Airtable fields return lists instead of strings
"""

import pandas as pd
import streamlit as st
from pyairtable import Api
import os
from typing import Any, List, Union, Dict


def safe_extract_field(field_value: Any, default: str = "") -> str:
    """
    Safely extract string value from various Airtable field types
    
    Args:
        field_value: The field value from Airtable (could be string, list, dict, etc.)
        default: Default value to return if extraction fails
        
    Returns:
        String representation of the field value
    """
    if field_value is None:
        return default
    
    # Handle list values (like multiple select fields)
    if isinstance(field_value, list):
        if len(field_value) == 0:
            return default
        
        # Join multiple values with comma
        string_items = []
        for item in field_value:
            if isinstance(item, dict):
                # Handle linked record objects
                string_items.append(str(item.get('name', item.get('id', str(item)))))
            else:
                string_items.append(str(item))
        
        return ", ".join(string_items)
    
    # Handle dictionary values (like linked records)
    elif isinstance(field_value, dict):
        return str(field_value.get('name', field_value.get('id', str(field_value))))
    
    # Handle string values
    elif isinstance(field_value, str):
        return field_value.strip()
    
    # Handle other types (numbers, booleans, etc.)
    else:
        return str(field_value)


def safe_extract_source(fields: Dict, possible_keys: List[str] = None) -> str:
    """
    Safely extract source field from Airtable record
    
    Args:
        fields: Dictionary of field values from Airtable record
        possible_keys: List of possible field names to check
        
    Returns:
        Cleaned source string
    """
    if possible_keys is None:
        possible_keys = ['Source', 'source', 'Lead Source', 'Traffic Source', 'Campaign Source']
    
    for key in possible_keys:
        if key in fields and fields[key]:
            source_value = safe_extract_field(fields[key])
            if source_value:
                return source_value
    
    return ""


def is_meta_source(source: str) -> bool:
    """
    Check if source indicates Meta/Facebook advertising
    
    Args:
        source: Source string to check
        
    Returns:
        True if source is Meta-related
    """
    if not source:
        return False
    
    source_lower = source.lower()
    meta_indicators = [
        'facebook', 'fb', 'instagram', 'meta', 
        'facebook ad', 'instagram ad', 'facebook ads', 'instagram ads'
    ]
    
    return any(indicator in source_lower for indicator in meta_indicators)


def load_airtable_data_safely():
    """
    Load Airtable data with robust field handling
    """
    st.title("🔧 Fixed Airtable Data Loader")
    
    # Get credentials
    api_key = os.environ.get('AIRTABLE_API_KEY')
    base_id = os.environ.get('AIRTABLE_BASE_ID', 'appri2CgCoIiuZWq3')
    
    if not api_key:
        st.error("❌ AIRTABLE_API_KEY environment variable not set")
        return
    
    # Load leads data
    try:
        st.info("Loading leads data...")
        
        api = Api(api_key)
        leads_table = api.table(base_id, 'Leads')
        leads_records = leads_table.all()
        
        st.success(f"✅ Loaded {len(leads_records)} lead records")
        
        # Process leads with safe field extraction
        processed_leads = []
        meta_leads = []
        
        for record in leads_records:
            fields = record.get('fields', {})
            
            # Extract fields safely
            brand = safe_extract_field(fields.get('Brand', ''))
            source = safe_extract_source(fields)
            
            processed_lead = {
                'id': record.get('id', ''),
                'brand': brand,
                'source': source,
                'is_meta': is_meta_source(source),
                'raw_source': fields.get('Source', fields.get('source', ''))  # Keep raw for debugging
            }
            
            processed_leads.append(processed_lead)
            
            # Filter for Meta leads
            if brand == 'Smooth MD' and is_meta_source(source):
                meta_leads.append(processed_lead)
        
        # Display results
        st.subheader("📊 Processing Results")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Total Leads", len(processed_leads))
        
        with col2:
            st.metric("Smooth MD Leads", len([l for l in processed_leads if l['brand'] == 'Smooth MD']))
        
        with col3:
            st.metric("Meta Leads", len(meta_leads))
        
        # Show sample of processed data
        if processed_leads:
            st.subheader("📋 Sample Processed Data")
            sample_df = pd.DataFrame(processed_leads[:10])
            st.dataframe(sample_df)
        
        # Show Meta leads specifically
        if meta_leads:
            st.subheader("🎯 Meta Leads (Smooth MD)")
            meta_df = pd.DataFrame(meta_leads)
            st.dataframe(meta_df)
        
        # Debug: Show unique sources
        st.subheader("🔍 Debug: Unique Sources Found")
        unique_sources = set(lead['source'] for lead in processed_leads if lead['source'])
        for source in sorted(unique_sources):
            meta_indicator = "✅ Meta" if is_meta_source(source) else "❌ Not Meta"
            st.write(f"- {source} ({meta_indicator})")
        
        # Show raw source types for debugging
        with st.expander("🐛 Debug: Raw Source Types"):
            raw_sources = {}
            for record in leads_records[:20]:  # Check first 20 records
                fields = record.get('fields', {})
                for key in ['Source', 'source', 'Lead Source']:
                    if key in fields:
                        value = fields[key]
                        value_type = type(value).__name__
                        if value_type not in raw_sources:
                            raw_sources[value_type] = []
                        raw_sources[value_type].append(str(value)[:100])  # Limit length
            
            for data_type, examples in raw_sources.items():
                st.write(f"**Type: {data_type}**")
                for example in examples[:5]:  # Show first 5 examples
                    st.write(f"  - {example}")
    
    except Exception as e:
        st.error(f"❌ Error loading data: {str(e)}")
        st.expander("Full Error Details").code(str(e))


def test_field_extraction():
    """
    Test the field extraction function with various input types
    """
    st.subheader("🧪 Field Extraction Tests")
    
    test_cases = [
        ("String value", "Facebook AD"),
        ("List of strings", ['Facebook AD', 'Instagram AD', 'Facebook AD Sign Up']),
        ("Empty list", []),
        ("Single item list", ['Facebook AD']),
        ("Dictionary", {'name': 'Facebook AD', 'id': 'rec123'}),
        ("None value", None),
        ("Number", 123),
        ("Boolean", True)
    ]
    
    results = []
    for test_name, test_value in test_cases:
        try:
            result = safe_extract_field(test_value)
            results.append({
                'Test': test_name,
                'Input': str(test_value),
                'Output': result,
                'Type': type(test_value).__name__,
                'Success': '✅'
            })
        except Exception as e:
            results.append({
                'Test': test_name,
                'Input': str(test_value),
                'Output': f"ERROR: {str(e)}",
                'Type': type(test_value).__name__,
                'Success': '❌'
            })
    
    test_df = pd.DataFrame(results)
    st.dataframe(test_df)


if __name__ == "__main__":
    st.set_page_config(page_title="Airtable Field Fix", layout="wide")
    
    tab1, tab2 = st.tabs(["Load Data", "Test Extraction"])
    
    with tab1:
        load_airtable_data_safely()
    
    with tab2:
        test_field_extraction()
