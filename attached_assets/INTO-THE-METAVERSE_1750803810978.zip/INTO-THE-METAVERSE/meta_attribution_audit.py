"""
Meta Revenue Attribution System using Social Media View
Accurate Meta lead tracking and revenue calculations for Smooth MD
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import os
import requests
from datetime import datetime, timedelta
from pyairtable import Api
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Meta Attribution Audit",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

def apply_attribution_styling():
    """Professional attribution audit styling"""
    st.markdown("""
    <style>
    .stApp {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    }
    
    .main .block-container {
        padding: 1rem;
        max-width: 100%;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 20px;
        backdrop-filter: blur(20px);
        margin-top: 1rem;
    }
    
    .header-section {
        text-align: center;
        padding: 2rem 0;
        background: linear-gradient(135deg, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0.05) 100%);
        border-radius: 20px;
        margin-bottom: 2rem;
        backdrop-filter: blur(10px);
    }
    
    .metric-row {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
        margin: 2rem 0;
    }
    
    .metric-card {
        background: rgba(255, 255, 255, 0.12);
        backdrop-filter: blur(20px);
        border-radius: 16px;
        padding: 1.5rem;
        border: 1px solid rgba(255, 255, 255, 0.2);
        transition: all 0.3s ease;
    }
    
    .metric-card:hover {
        transform: translateY(-2px);
        background: rgba(255, 255, 255, 0.18);
    }
    
    .metric-title {
        font-size: 0.9rem;
        color: rgba(255,255,255,0.8);
        font-weight: 500;
        margin-bottom: 0.5rem;
    }
    
    .metric-value {
        font-size: 2rem;
        font-weight: 700;
        color: white;
        margin-bottom: 0.5rem;
    }
    
    .metric-subtitle {
        font-size: 0.85rem;
        color: rgba(255,255,255,0.7);
    }
    
    .roas-hero {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        border-radius: 24px;
        padding: 3rem 2rem;
        text-align: center;
        margin: 2rem 0;
        box-shadow: 0 20px 60px rgba(17, 153, 142, 0.3);
    }
    
    .roas-value {
        font-size: 3.5rem;
        font-weight: 800;
        color: white;
        margin: 0;
        text-shadow: 0 4px 20px rgba(0,0,0,0.2);
    }
    
    .section-container {
        background: rgba(255, 255, 255, 0.08);
        border-radius: 16px;
        padding: 2rem;
        margin: 2rem 0;
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .section-title {
        color: white;
        font-size: 1.4rem;
        font-weight: 600;
        margin-bottom: 1rem;
        border-bottom: 2px solid rgba(255,255,255,0.2);
        padding-bottom: 0.5rem;
    }
    
    .data-table {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 12px;
        padding: 1rem;
        margin: 1rem 0;
    }
    
    #MainMenu, footer, header, .stDeployButton {
        visibility: hidden;
    }
    </style>
    """, unsafe_allow_html=True)

class MetaAttributionAnalyzer:
    """Analyzes Meta revenue attribution using Social Media view"""
    
    def __init__(self):
        self.base_id = 'appri2CgCoIiuZWq3'
        self.meta_spend = 0
        self.meta_revenue = 0
        self.social_media_transactions = []
        self.meta_leads_data = []
    
    def load_meta_spend_data(self):
        """Load Meta advertising spend data"""
        try:
            access_token = os.getenv('META_ACCESS_TOKEN')
            ad_account_id = os.getenv('META_AD_ACCOUNT_ID')
            
            if not access_token or not ad_account_id:
                return False, "Meta API credentials missing"
            
            url = f"https://graph.facebook.com/v18.0/act_{ad_account_id}/insights"
            params = {
                'access_token': access_token,
                'fields': 'spend,impressions,clicks,actions,cpm,cpc,ctr',
                'date_preset': 'last_30d',
                'limit': 50
            }
            
            response = requests.get(url, params=params, timeout=15)
            
            if response.status_code == 200:
                data = response.json()
                insights = data.get('data', [])
                
                if insights:
                    self.meta_spend = sum(float(insight.get('spend', 0)) for insight in insights)
                    self.meta_impressions = sum(int(insight.get('impressions', 0)) for insight in insights)
                    self.meta_clicks = sum(int(insight.get('clicks', 0)) for insight in insights)
                    
                    # Extract leads from actions
                    self.meta_leads = 0
                    for insight in insights:
                        actions = insight.get('actions', [])
                        for action in actions:
                            if action.get('action_type') == 'lead':
                                self.meta_leads += int(action.get('value', 0))
                    
                    return True, f"Loaded ${self.meta_spend:,.2f} spend data"
                else:
                    return False, "No Meta insights data available"
            else:
                return False, f"Meta API error: {response.status_code}"
                
        except Exception as e:
            return False, f"Meta API connection failed: {str(e)}"
    
    def load_social_media_transactions(self):
        """Load transactions using Patient ID matching for precise Meta attribution"""
        try:
            airtable_key = os.getenv('AIRTABLE_API_KEY')
            if not airtable_key:
                return False, "Airtable API key missing"
            
            api = Api(airtable_key)
            
            # Load Meta leads first to get Patient IDs
            leads_table = api.table(self.base_id, 'Leads')
            leads_records = leads_table.all()
            
            # Build Meta leads mapping by Patient ID
            meta_patient_ids = set()
            meta_leads_map = {}
            
            for lead in leads_records:
                fields = lead.get('fields', {})
                contact_source = str(fields.get('Contact Source', '')).lower()
                patient_id = fields.get('Patient ID', '')
                
                # Check if Meta source
                meta_indicators = ['instagram', 'facebook', 'meta', 'fb', 'ig']
                is_meta = any(indicator in contact_source for indicator in meta_indicators)
                
                if is_meta and patient_id:
                    meta_patient_ids.add(patient_id)
                    meta_leads_map[patient_id] = {
                        'contact_source': fields.get('Contact Source', ''),
                        'brand': fields.get('Brand', ''),
                        'status': fields.get('Status', ''),
                        'created_time': fields.get('Created Time', '')
                    }
            
            # Load transactions from Social Media view
            trans_table = api.table(self.base_id, 'Transactions')
            social_records = trans_table.all(view='Social Media')
            
            meta_revenue = 0
            smooth_md_meta_revenue = 0
            transactions_processed = 0
            patient_matched_transactions = 0
            
            for record in social_records:
                fields = record.get('fields', {})
                
                # Get Patient ID for precise matching
                patient_id = fields.get('Patient', '')  # Patient field contains Patient ID
                
                # Try multiple amount fields
                amount = None
                for field_name in ['Amount', 'Remaining', 'Purchased']:
                    if field_name in fields:
                        value = fields[field_name]
                        if isinstance(value, (int, float)) and value > 0:
                            amount = value
                            break
                
                if amount and amount > 0 and patient_id:
                    # Check if this Patient ID is from a Meta lead
                    is_meta_patient = patient_id in meta_patient_ids
                    
                    # Get brand information
                    brand_data = fields.get('Brand (from ID)', [])
                    brand = brand_data[0] if isinstance(brand_data, list) and brand_data else str(brand_data) if brand_data else ''
                    
                    # Get contact source from linked lead data
                    lead_data = meta_leads_map.get(patient_id, {})
                    contact_source = lead_data.get('contact_source', '')
                    
                    # Get other fields
                    services = fields.get('Services Purchased', '')
                    status = fields.get('Status', '')
                    date = fields.get('Date', '')
                    
                    # Check if Smooth MD
                    is_smooth_md = 'smooth' in brand.lower() and 'md' in brand.lower()
                    
                    transaction_data = {
                        'amount': amount,
                        'patient_id': patient_id,
                        'brand': brand,
                        'contact_source': contact_source,
                        'services': services,
                        'status': status,
                        'date': date,
                        'is_meta': is_meta_patient,
                        'is_smooth_md': is_smooth_md,
                        'lead_data': lead_data
                    }
                    
                    self.social_media_transactions.append(transaction_data)
                    transactions_processed += 1
                    
                    if is_meta_patient:
                        meta_revenue += amount
                        patient_matched_transactions += 1
                        if is_smooth_md:
                            smooth_md_meta_revenue += amount
            
            self.meta_revenue = meta_revenue
            self.smooth_md_meta_revenue = smooth_md_meta_revenue
            
            return True, f"Processed {transactions_processed} transactions, {patient_matched_transactions} Meta-matched via Patient ID, ${meta_revenue:,.2f} Meta revenue"
            
        except Exception as e:
            return False, f"Patient ID matching failed: {str(e)}"
    
    def calculate_attribution_metrics(self):
        """Calculate comprehensive attribution metrics"""
        if self.meta_spend == 0:
            return {}
        
        # Meta transactions only
        meta_transactions = [t for t in self.social_media_transactions if t['is_meta']]
        smooth_md_meta_transactions = [t for t in meta_transactions if t['is_smooth_md']]
        
        metrics = {
            'roas': self.meta_revenue / self.meta_spend if self.meta_spend > 0 else 0,
            'smooth_md_roas': self.smooth_md_meta_revenue / self.meta_spend if self.meta_spend > 0 else 0,
            'total_meta_revenue': self.meta_revenue,
            'smooth_md_meta_revenue': self.smooth_md_meta_revenue,
            'meta_spend': self.meta_spend,
            'meta_transactions_count': len(meta_transactions),
            'smooth_md_transactions_count': len(smooth_md_meta_transactions),
            'avg_transaction_value': self.meta_revenue / len(meta_transactions) if meta_transactions else 0,
            'cost_per_acquisition': self.meta_spend / len(meta_transactions) if meta_transactions else 0,
            'revenue_per_dollar_spent': self.meta_revenue / self.meta_spend if self.meta_spend > 0 else 0
        }
        
        return metrics
    
    def get_services_breakdown(self):
        """Get breakdown of Meta revenue by services"""
        meta_transactions = [t for t in self.social_media_transactions if t['is_meta']]
        
        services_data = {}
        for transaction in meta_transactions:
            service = transaction['services']
            if service not in services_data:
                services_data[service] = {'revenue': 0, 'count': 0}
            services_data[service]['revenue'] += transaction['amount']
            services_data[service]['count'] += 1
        
        # Sort by revenue
        sorted_services = sorted(services_data.items(), key=lambda x: x[1]['revenue'], reverse=True)
        
        return sorted_services
    
    def get_brand_breakdown(self):
        """Get breakdown of Meta revenue by brand"""
        meta_transactions = [t for t in self.social_media_transactions if t['is_meta']]
        
        brand_data = {}
        for transaction in meta_transactions:
            brand = transaction['brand']
            if brand not in brand_data:
                brand_data[brand] = {'revenue': 0, 'count': 0}
            brand_data[brand]['revenue'] += transaction['amount']
            brand_data[brand]['count'] += 1
        
        # Sort by revenue
        sorted_brands = sorted(brand_data.items(), key=lambda x: x[1]['revenue'], reverse=True)
        
        return sorted_brands

def create_roas_gauge(roas_value):
    """Create ROAS gauge visualization"""
    fig = go.Figure(go.Indicator(
        mode = "gauge+number+delta",
        value = roas_value,
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': "Meta ROAS", 'font': {'size': 24, 'color': 'white'}},
        delta = {'reference': 3.0, 'position': "top"},
        gauge = {
            'axis': {'range': [None, 10], 'tickcolor': 'white'},
            'bar': {'color': "#11998e"},
            'steps': [
                {'range': [0, 2], 'color': "rgba(255, 107, 107, 0.3)"},
                {'range': [2, 4], 'color': "rgba(255, 217, 61, 0.3)"},
                {'range': [4, 10], 'color': "rgba(107, 207, 127, 0.3)"}
            ],
            'threshold': {
                'line': {'color': "white", 'width': 4},
                'thickness': 0.75,
                'value': 3.0
            }
        }
    ))
    
    fig.update_layout(
        height=400,
        font={'color': 'white'},
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    
    return fig

def create_services_chart(services_data):
    """Create services revenue breakdown chart"""
    if not services_data:
        return None
    
    services = [item[0] for item in services_data[:10]]
    revenues = [item[1]['revenue'] for item in services_data[:10]]
    
    fig = px.bar(
        x=revenues,
        y=services,
        orientation='h',
        title="Meta Revenue by Service",
        labels={'x': 'Revenue ($)', 'y': 'Service'},
        color=revenues,
        color_continuous_scale='viridis'
    )
    
    fig.update_layout(
        height=500,
        font={'color': 'white'},
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        title_font_color='white'
    )
    
    return fig

def main():
    """Main attribution audit application"""
    
    apply_attribution_styling()
    
    # Header
    st.markdown("""
    <div class="header-section">
        <h1 style="color: white; font-size: 2.5rem; margin: 0;">📊 Meta Attribution Audit</h1>
        <p style="color: rgba(255,255,255,0.8); font-size: 1.1rem; margin: 0.5rem 0 0 0;">
            Accurate revenue attribution using Social Media view
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize analyzer
    analyzer = MetaAttributionAnalyzer()
    
    # Load data
    with st.spinner("Loading Meta spend and Social Media transaction data..."):
        meta_success, meta_message = analyzer.load_meta_spend_data()
        social_success, social_message = analyzer.load_social_media_transactions()
    
    # Connection status
    col1, col2 = st.columns(2)
    
    with col1:
        status_color = "success" if meta_success else "error"
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Meta API Status</div>
            <div class="metric-value" style="color: {'#4CAF50' if meta_success else '#F44336'}">
                {'✅ Connected' if meta_success else '❌ Error'}
            </div>
            <div class="metric-subtitle">{meta_message}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        status_color = "success" if social_success else "error"
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Social Media View Status</div>
            <div class="metric-value" style="color: {'#4CAF50' if social_success else '#F44336'}">
                {'✅ Connected' if social_success else '❌ Error'}
            </div>
            <div class="metric-subtitle">{social_message}</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Main analysis
    if meta_success and social_success:
        metrics = analyzer.calculate_attribution_metrics()
        
        # ROAS Hero Section
        roas = metrics.get('roas', 0)
        st.markdown(f"""
        <div class="roas-hero">
            <h2 class="roas-value">{roas:.2f}x</h2>
            <h3 style="color: white; margin: 0.5rem 0; font-size: 1.4rem;">Meta ROAS</h3>
            <p style="color: rgba(255,255,255,0.8); margin: 0;">
                ${metrics.get('total_meta_revenue', 0):,.2f} revenue ÷ ${metrics.get('meta_spend', 0):,.2f} spend
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        # Key Metrics Grid
        st.markdown('<div class="metric-row">', unsafe_allow_html=True)
        
        # Total Meta Revenue
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Total Meta Revenue</div>
            <div class="metric-value">${metrics.get('total_meta_revenue', 0):,.2f}</div>
            <div class="metric-subtitle">From {metrics.get('meta_transactions_count', 0)} transactions</div>
        </div>
        """, unsafe_allow_html=True)
        
        # Smooth MD Meta Revenue
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Smooth MD Meta Revenue</div>
            <div class="metric-value">${metrics.get('smooth_md_meta_revenue', 0):,.2f}</div>
            <div class="metric-subtitle">From {metrics.get('smooth_md_transactions_count', 0)} transactions</div>
        </div>
        """, unsafe_allow_html=True)
        
        # Average Transaction Value
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Avg Transaction Value</div>
            <div class="metric-value">${metrics.get('avg_transaction_value', 0):,.2f}</div>
            <div class="metric-subtitle">Per Meta transaction</div>
        </div>
        """, unsafe_allow_html=True)
        
        # Cost per Acquisition
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Cost per Acquisition</div>
            <div class="metric-value">${metrics.get('cost_per_acquisition', 0):,.2f}</div>
            <div class="metric-subtitle">Meta spend per transaction</div>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        # ROAS Gauge
        st.markdown('<div class="section-container">', unsafe_allow_html=True)
        st.markdown('<h2 class="section-title">📈 ROAS Performance Analysis</h2>', unsafe_allow_html=True)
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            roas_chart = create_roas_gauge(roas)
            st.plotly_chart(roas_chart, use_container_width=True)
        
        with col2:
            smooth_md_roas = metrics.get('smooth_md_roas', 0)
            st.markdown(f"""
            <div style="padding: 2rem 0;">
                <h3 style="color: white; margin-bottom: 1rem;">Brand Performance</h3>
                <div style="background: rgba(255,255,255,0.1); padding: 1rem; border-radius: 12px; margin: 1rem 0;">
                    <div style="color: rgba(255,255,255,0.8); font-size: 0.9rem;">Smooth MD ROAS</div>
                    <div style="color: white; font-size: 1.8rem; font-weight: 700;">{smooth_md_roas:.2f}x</div>
                </div>
                <div style="background: rgba(255,255,255,0.1); padding: 1rem; border-radius: 12px; margin: 1rem 0;">
                    <div style="color: rgba(255,255,255,0.8); font-size: 0.9rem;">Revenue per $ Spent</div>
                    <div style="color: white; font-size: 1.8rem; font-weight: 700;">${metrics.get('revenue_per_dollar_spent', 0):.2f}</div>
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Services Breakdown
        services_data = analyzer.get_services_breakdown()
        if services_data:
            st.markdown('<div class="section-container">', unsafe_allow_html=True)
            st.markdown('<h2 class="section-title">🛍️ Revenue by Service</h2>', unsafe_allow_html=True)
            
            services_chart = create_services_chart(services_data)
            if services_chart:
                st.plotly_chart(services_chart, use_container_width=True)
            
            # Services table
            st.markdown('<div class="data-table">', unsafe_allow_html=True)
            services_df = pd.DataFrame([
                {
                    'Service': item[0],
                    'Revenue': f"${item[1]['revenue']:,.2f}",
                    'Transactions': item[1]['count'],
                    'Avg Value': f"${item[1]['revenue']/item[1]['count']:,.2f}"
                }
                for item in services_data[:10]
            ])
            st.dataframe(services_df, use_container_width=True, hide_index=True)
            st.markdown('</div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)
        
        # Brand Breakdown
        brand_data = analyzer.get_brand_breakdown()
        if brand_data:
            st.markdown('<div class="section-container">', unsafe_allow_html=True)
            st.markdown('<h2 class="section-title">🏢 Revenue by Brand</h2>', unsafe_allow_html=True)
            
            col1, col2 = st.columns(2)
            
            for i, (brand, data) in enumerate(brand_data[:4]):
                with col1 if i % 2 == 0 else col2:
                    st.markdown(f"""
                    <div class="metric-card">
                        <div class="metric-title">{brand}</div>
                        <div class="metric-value">${data['revenue']:,.2f}</div>
                        <div class="metric-subtitle">{data['count']} transactions</div>
                    </div>
                    """, unsafe_allow_html=True)
            
            st.markdown('</div>', unsafe_allow_html=True)
        
    else:
        st.error("Data loading failed. Please check API connections.")
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <p style="color: rgba(255,255,255,0.6); text-align: center;">
        🔒 Attribution based on Social Media view transactions with verified Meta sources
    </p>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()