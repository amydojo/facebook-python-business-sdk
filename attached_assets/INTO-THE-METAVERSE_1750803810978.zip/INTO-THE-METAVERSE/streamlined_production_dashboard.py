"""
Streamlined Production Dashboard
Single consolidated dashboard with maximum performance and accurate data validation
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import logging
import time
from unified_production_connector import unified_connector
from advanced_lead_matcher import advanced_lead_matcher

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Production Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for professional styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        margin-bottom: 2rem;
        text-align: center;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1.5rem;
        border-radius: 10px;
        margin: 0.5rem 0;
        text-align: center;
    }
    .metric-value {
        font-size: 2rem;
        font-weight: bold;
    }
    .metric-label {
        font-size: 0.9rem;
        opacity: 0.9;
    }
    .status-good {
        background: #28a745;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        margin: 0.2rem;
    }
    .status-warning {
        background: #ffc107;
        color: black;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        margin: 0.2rem;
    }
    .status-error {
        background: #dc3545;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        margin: 0.2rem;
    }
    .diagnostic-section {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
        border-left: 4px solid #007bff;
    }
</style>
""", unsafe_allow_html=True)

def display_connection_health():
    """Display real-time connection health status"""
    st.markdown("### 🔗 Connection Health Monitor")
    
    health_status = unified_connector.get_health_status()
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if health_status['api_connected']:
            st.markdown('<div class="status-good">✅ API Connected</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="status-error">❌ API Disconnected</div>', unsafe_allow_html=True)
    
    with col2:
        if health_status['tables_validated']:
            st.markdown('<div class="status-good">✅ Tables Validated</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="status-error">❌ Tables Invalid</div>', unsafe_allow_html=True)
    
    with col3:
        if health_status['credentials_configured']:
            st.markdown('<div class="status-good">✅ Credentials OK</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="status-error">❌ Credentials Missing</div>', unsafe_allow_html=True)
    
    with col4:
        success_rate = 0
        if health_status['success_count'] + health_status['error_count'] > 0:
            success_rate = health_status['success_count'] / (health_status['success_count'] + health_status['error_count']) * 100
        
        if success_rate >= 80:
            st.markdown(f'<div class="status-good">✅ Success: {success_rate:.0f}%</div>', unsafe_allow_html=True)
        elif success_rate >= 50:
            st.markdown(f'<div class="status-warning">⚠️ Success: {success_rate:.0f}%</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="status-error">❌ Success: {success_rate:.0f}%</div>', unsafe_allow_html=True)
    
    # Display table access status
    st.markdown("**Table Access Status:**")
    available_tables = health_status.get('available_tables', {})
    inaccessible_tables = health_status.get('inaccessible_tables', {})
    
    if available_tables:
        for data_type, table_name in available_tables.items():
            st.success(f"✅ {data_type.title()}: {table_name}")
    
    if inaccessible_tables:
        for data_type, error in inaccessible_tables.items():
            st.error(f"❌ {data_type.title()}: {error}")

def load_data_with_advanced_matching(start_date: str, end_date: str):
    """Load data with sophisticated lead-to-transaction matching"""
    
    st.markdown("### ⚡ Advanced Lead Matching & Revenue Attribution")
    
    # Initialize results
    results = {
        'matched_leads': [],
        'matching_stats': {},
        'performance_metrics': {},
        'diagnostic_report': {},
        'total_load_time': 0,
        'errors': []
    }
    
    # Progress tracking
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    start_time = time.time()
    
    try:
        # Step 1: Load raw data
        status_text.text("Loading transactions and leads data...")
        
        transaction_result = unified_connector.load_transactions(start_date, end_date)
        lead_result = unified_connector.load_leads(start_date, end_date)
        
        progress_bar.progress(30)
        
        if not transaction_result.success or not lead_result.success:
            if not transaction_result.success:
                results['errors'].append(f"Transactions: {transaction_result.error}")
            if not lead_result.success:
                results['errors'].append(f"Leads: {lead_result.error}")
            return results
        
        # Step 2: Identify Meta leads with sophisticated filtering
        status_text.text("Identifying Meta advertising leads...")
        
        meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data or [])
        
        progress_bar.progress(60)
        st.info(f"Identified {len(meta_leads)} Meta leads from {lead_result.count} total leads")
        
        # Step 3: Match transactions to leads
        status_text.text("Matching transactions to leads...")
        
        matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
            meta_leads, transaction_result.data or []
        )
        
        progress_bar.progress(80)
        
        # Step 4: Calculate performance metrics
        status_text.text("Calculating performance metrics...")
        
        # Estimate ad spend (would be replaced with actual Meta API data)
        estimated_spend = len(meta_leads) * 45  # Conservative estimate
        
        performance_metrics = advanced_lead_matcher.calculate_performance_metrics(
            matched_leads, estimated_spend
        )
        
        # Step 5: Generate diagnostic report
        diagnostic_report = advanced_lead_matcher.get_diagnostic_report(
            matched_leads, matching_stats
        )
        
        progress_bar.progress(100)
        
        # Update results
        results.update({
            'matched_leads': matched_leads,
            'matching_stats': matching_stats,
            'performance_metrics': performance_metrics,
            'diagnostic_report': diagnostic_report,
            'total_load_time': time.time() - start_time
        })
        
        # Display summary
        revenue_attributed = matching_stats.get('total_matched_revenue', 0)
        attribution_rate = matching_stats.get('attribution_rate', 0)
        
        st.success(f"✅ Advanced matching completed: {len(matched_leads)} Meta leads, ${revenue_attributed:,.2f} attributed revenue ({attribution_rate:.1f}% attribution rate)")
        
    except Exception as e:
        st.error(f"❌ Advanced matching failed: {str(e)}")
        results['errors'].append(f"Matching: {str(e)}")
        logger.error(f"Advanced matching error: {e}")
    
    status_text.text(f"Advanced matching completed in {results['total_load_time']:.2f}s")
    
    return results

def display_advanced_performance_metrics(matching_results):
    """Display sophisticated performance metrics from lead matching"""
    
    st.markdown("### 📊 Advanced Performance Metrics")
    
    if not matching_results or 'performance_metrics' not in matching_results:
        st.warning("No performance metrics available - run advanced matching first")
        return
    
    metrics = matching_results['performance_metrics']
    
    # Primary KPI row
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        revenue = metrics.get('total_revenue', 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">${revenue:,.2f}</div>
            <div class="metric-label">Attributed Revenue</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        lead_count = metrics.get('total_leads', 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{lead_count}</div>
            <div class="metric-label">Meta Leads</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        conversion_rate = metrics.get('conversion_rate', 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{conversion_rate:.1f}%</div>
            <div class="metric-label">Conversion Rate</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        roas = metrics.get('roas', 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{roas:.2f}x</div>
            <div class="metric-label">ROAS</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Secondary metrics row
    st.markdown("---")
    col5, col6, col7, col8 = st.columns(4)
    
    with col5:
        booking_rate = metrics.get('booking_rate', 0)
        st.metric("Booking Rate", f"{booking_rate:.1f}%")
    
    with col6:
        avg_order_value = metrics.get('average_order_value', 0)
        st.metric("Avg Order Value", f"${avg_order_value:,.2f}")
    
    with col7:
        cost_per_lead = metrics.get('cost_per_lead', 0)
        st.metric("Cost Per Lead", f"${cost_per_lead:.2f}")
    
    with col8:
        cost_per_conversion = metrics.get('cost_per_conversion', 0)
        st.metric("Cost Per Conversion", f"${cost_per_conversion:.2f}")
    
    # Revenue funnel visualization
    st.markdown("### 🎯 Revenue Attribution Funnel")
    
    funnel_data = {
        'Stage': ['Total Leads', 'Booked', 'Converted', 'Revenue Generated'],
        'Count': [
            metrics.get('total_leads', 0),
            metrics.get('booked_leads', 0),
            metrics.get('converted_leads', 0),
            metrics.get('revenue_generating_leads', 0)
        ],
        'Rate': [100, 0, 0, 0]
    }
    
    if funnel_data['Count'][0] > 0:
        funnel_data['Rate'][1] = (funnel_data['Count'][1] / funnel_data['Count'][0]) * 100
        funnel_data['Rate'][2] = (funnel_data['Count'][2] / funnel_data['Count'][0]) * 100
        funnel_data['Rate'][3] = (funnel_data['Count'][3] / funnel_data['Count'][0]) * 100
    
    import plotly.graph_objects as go
    
    fig = go.Figure(go.Funnel(
        y = funnel_data['Stage'],
        x = funnel_data['Count'],
        textinfo = "value+percent initial",
        marker = {"color": ["deepskyblue", "lightsalmon", "tan", "lightgreen"]}
    ))
    
    fig.update_layout(height=400, title="Lead to Revenue Conversion Funnel")
    st.plotly_chart(fig, use_container_width=True)

def display_matching_diagnostics(matching_results):
    """Display comprehensive matching diagnostics and data quality analysis"""
    
    st.markdown("### 🔍 Lead Matching Diagnostics")
    
    if not matching_results or 'diagnostic_report' not in matching_results:
        st.warning("No diagnostic data available - run advanced matching first")
        return
    
    diagnostics = matching_results['diagnostic_report']
    matching_stats = matching_results['matching_stats']
    
    # Matching quality overview
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Matching Quality Metrics**")
        
        quality = diagnostics.get('matching_quality', {})
        attribution_rate = quality.get('attribution_rate', 0)
        avg_revenue = quality.get('average_revenue_per_lead', 0)
        
        if attribution_rate >= 60:
            st.success(f"✅ Attribution Rate: {attribution_rate:.1f}%")
        elif attribution_rate >= 30:
            st.warning(f"⚠️ Attribution Rate: {attribution_rate:.1f}%")
        else:
            st.error(f"❌ Attribution Rate: {attribution_rate:.1f}%")
        
        st.metric("Avg Revenue Per Lead", f"${avg_revenue:.2f}")
        st.metric("Leads with Transactions", quality.get('leads_with_transactions', 0))
    
    with col2:
        st.markdown("**Match Method Breakdown**")
        
        methods = diagnostics.get('match_methods', {})
        total_matches = sum(methods.values())
        
        if total_matches > 0:
            for method, count in methods.items():
                percentage = (count / total_matches) * 100
                method_name = method.replace('_', ' ').title()
                st.write(f"{method_name}: {count} ({percentage:.1f}%)")
        else:
            st.info("No transaction matches found")
    
    # Data quality assessment
    st.markdown("---")
    st.markdown("**Data Quality Assessment**")
    
    col3, col4, col5 = st.columns(3)
    
    with col3:
        data_quality = diagnostics.get('data_quality', {})
        total_leads = matching_results.get('performance_metrics', {}).get('total_leads', 0)
        
        if total_leads > 0:
            email_rate = (data_quality.get('leads_with_email', 0) / total_leads) * 100
            phone_rate = (data_quality.get('leads_with_phone', 0) / total_leads) * 100
            status_rate = (data_quality.get('leads_with_status', 0) / total_leads) * 100
            
            st.metric("Email Completion", f"{email_rate:.1f}%")
            st.metric("Phone Completion", f"{phone_rate:.1f}%")
            st.metric("Status Completion", f"{status_rate:.1f}%")
    
    with col4:
        # Revenue distribution
        revenue_dist = diagnostics.get('revenue_distribution', {})
        if revenue_dist.get('count', 0) > 0:
            st.metric("Revenue Transactions", revenue_dist.get('count', 0))
            st.metric("Median Revenue", f"${revenue_dist.get('median', 0):.2f}")
            st.metric("Max Revenue", f"${revenue_dist.get('max', 0):.2f}")
        else:
            st.info("No revenue data available")
    
    with col5:
        # Attribution efficiency gauge
        fig = go.Figure(go.Indicator(
            mode = "gauge+number",
            value = attribution_rate,
            domain = {'x': [0, 1], 'y': [0, 1]},
            title = {'text': "Attribution Efficiency"},
            gauge = {
                'axis': {'range': [None, 100]},
                'bar': {'color': "darkblue"},
                'steps': [
                    {'range': [0, 30], 'color': "lightcoral"},
                    {'range': [30, 60], 'color': "yellow"},
                    {'range': [60, 100], 'color': "lightgreen"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 80
                }
            }
        ))
        
        fig.update_layout(height=250)
        st.plotly_chart(fig, use_container_width=True)
    
    # Detailed matching statistics
    with st.expander("Detailed Matching Statistics"):
        st.json(matching_stats)

def run_comprehensive_diagnostics():
    """Run and display comprehensive system diagnostics"""
    
    st.markdown("### 🔧 System Diagnostics")
    
    if st.button("🚀 Run Full Diagnostic Scan", type="primary"):
        with st.spinner("Running comprehensive diagnostics..."):
            
            diagnostics = unified_connector.run_diagnostics()
            
            st.success("Diagnostic scan completed!")
            
            # Display connection test results
            st.markdown("**Connection Test Results:**")
            
            for data_type, test_result in diagnostics['connection_tests'].items():
                if test_result['success']:
                    st.success(f"✅ {data_type.title()}: {test_result['record_count']} records in {test_result['response_time']:.2f}s")
                else:
                    st.error(f"❌ {data_type.title()}: {test_result.get('error', 'Unknown error')}")
            
            # Display recommendations
            if diagnostics['recommendations']:
                st.markdown("**Recommendations:**")
                for rec in diagnostics['recommendations']:
                    st.info(f"💡 {rec}")
            
            # Display detailed health status
            with st.expander("Detailed Health Status"):
                st.json(diagnostics['health_status'])

def main():
    """Main streamlined production dashboard"""
    
    st.markdown('<div class="main-header">📊 Streamlined Production Dashboard</div>', unsafe_allow_html=True)
    st.markdown("**Unified high-performance data connector with comprehensive validation**")
    
    # Sidebar controls
    st.sidebar.markdown("## 📅 Date Range")
    
    # Date selection
    end_date = st.sidebar.date_input(
        "End Date",
        value=datetime.now().date(),
        max_value=datetime.now().date()
    )
    
    start_date = st.sidebar.date_input(
        "Start Date",
        value=end_date - timedelta(days=30),
        max_value=end_date
    )
    
    # Convert to strings
    start_date_str = start_date.strftime('%Y-%m-%d')
    end_date_str = end_date.strftime('%Y-%m-%d')
    
    st.sidebar.markdown("## ⚙️ Controls")
    auto_refresh = st.sidebar.checkbox("Auto-refresh (30s)", value=False)
    
    if st.sidebar.button("🔄 Refresh Data"):
        st.rerun()
    
    # Main dashboard content
    try:
        # Display connection health
        display_connection_health()
        
        st.markdown("---")
        
        # Load data with advanced lead matching
        matching_results = load_data_with_advanced_matching(start_date_str, end_date_str)
        
        # Display any critical errors
        if matching_results['errors']:
            st.markdown("### ⚠️ Critical Issues Detected")
            for error in matching_results['errors']:
                st.error(error)
            
            st.markdown("""
            <div class="diagnostic-section">
                <strong>Troubleshooting Steps:</strong><br>
                1. Verify AIRTABLE_API_KEY has read permissions for the base<br>
                2. Confirm AIRTABLE_BASE_ID is correct<br>
                3. Check that table names match exactly<br>
                4. Ensure base is shared with the API key
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown("---")
        
        # Display advanced performance metrics
        if matching_results and 'performance_metrics' in matching_results:
            display_advanced_performance_metrics(matching_results)
            
            st.markdown("---")
            
            # Display matching diagnostics
            display_matching_diagnostics(matching_results)
        
        st.markdown("---")
        
        # Comprehensive diagnostics
        run_comprehensive_diagnostics()
        
        # Sidebar system info
        st.sidebar.markdown("## 📊 System Info")
        health_status = unified_connector.get_health_status()
        st.sidebar.json({
            "Cache Size": health_status['cache_size'],
            "Success Count": health_status['success_count'],
            "Error Count": health_status['error_count'],
            "Last Updated": datetime.now().strftime("%H:%M:%S")
        })
        
        # Auto-refresh logic
        if auto_refresh:
            time.sleep(30)
            st.rerun()
            
    except Exception as e:
        st.error(f"Dashboard error: {str(e)}")
        logger.error(f"Dashboard error: {e}")
        
        # Emergency diagnostic info
        st.markdown("### 🚨 Emergency Diagnostic")
        st.code(f"""
Error: {type(e).__name__}: {str(e)}
Time: {datetime.now().isoformat()}

Check:
1. Environment variables are set correctly
2. API key has proper permissions
3. Base ID format is correct (starts with 'app')
4. Network connectivity to Airtable
        """)

if __name__ == "__main__":
    main()