"""
Mobile-Optimized iOS Marketing Dashboard
Apple iOS design standards with seamless mobile campaign & ROI analytics - FIXED
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import requests
import os
import logging
from datetime import datetime, timedelta
from pyairtable import Api
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def apply_ios_mobile_styling():
    """Apply Apple iOS mobile design standards with responsive layout"""
    st.markdown("""
    <style>
    /* iOS Mobile-First Design System */
    .stApp {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Helvetica Neue', Arial, sans-serif;
    }

    /* iOS Navigation Bar */
    .main-header {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border-bottom: 0.5px solid rgba(0, 0, 0, 0.1);
        padding: 12px 20px;
        position: sticky;
        top: 0;
        z-index: 1000;
        margin: -1rem -1rem 2rem -1rem;
    }

    /* iOS Card Design */
    .metric-card {
        background: rgba(255, 255, 255, 0.9);
        backdrop-filter: blur(10px);
        border-radius: 16px;
        padding: 20px;
        margin: 12px 0;
        border: 0.5px solid rgba(0, 0, 0, 0.05);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
    }

    /* iOS Typography */
    .ios-title {
        font-size: 28px;
        font-weight: 700;
        color: #1d1d1f;
        margin: 0;
        line-height: 1.1;
    }

    .ios-subtitle {
        font-size: 17px;
        font-weight: 600;
        color: #1d1d1f;
        margin: 8px 0 4px 0;
    }

    .ios-body {
        font-size: 15px;
        color: #424245;
        line-height: 1.4;
    }
    
    .ios-caption {
        font-size: 13px;
        color: #8e8e93;
        font-weight: 400;
    }

    /* iOS Button Design */
    .ios-button {
        background: #007aff;
        color: white;
        border: none;
        border-radius: 12px;
        padding: 12px 24px;
        font-size: 17px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
        width: 100%;
        margin: 8px 0;
    }
    
    .ios-button:hover {
        background: #0056b3;
        transform: scale(0.98);
    }
    
    /* Mobile-Responsive Grid */
    .mobile-grid {
        display: grid;
        grid-template-columns: 1fr;
        gap: 16px;
        padding: 0 4px;
    }
    
    @media (min-width: 768px) {
        .mobile-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            padding: 0 8px;
        }
    }
    
    @media (min-width: 1024px) {
        .mobile-grid {
            grid-template-columns: repeat(3, 1fr);
            gap: 24px;
            padding: 0 12px;
        }
    }

    .status-positive { color: #34c759; }
    .status-negative { color: #ff3b30; }
    .status-warning { color: #ff9500; }

    /* iOS Progress Indicators */
    .progress-ring {
        width: 60px;
        height: 60px;
        margin: 0 auto;
    }
    
    /* Hide Streamlit defaults for cleaner mobile experience */
    .stDeployButton { display: none; }
    
    .stDecoration {
        display: none;
    }

    footer { display: none; }

    /* Mobile-optimized sidebar */
    .css-1d391kg {
        padding-top: 0;
    }

    /* Responsive charts */
    .js-plotly-plot {
        border-radius: 12px;
        overflow: hidden;
    }

    /* iOS-style loading */
    .stSpinner > div {
        border-color: #007aff !important;
    }

    /* Mobile touch optimization */
    .stSelectbox > div > div {
        border-radius: 12px;
        border: 1px solid #d1d1d6;
    }

    .stMetric {
        background: rgba(255, 255, 255, 0.9);
        padding: 16px;
        border-radius: 12px;
        margin: 8px 0;
    }
    </style>
    """, unsafe_allow_html=True)

# Global cache functions (not methods) to avoid caching issues
@st.cache_data(ttl=300)
def load_airtable_data_cached(api_key: str):
    """Load Airtable data with global caching function"""
    try:
        if not api_key:
            return None, None, "⚠️ Airtable API key required"

        api = Api(api_key)

        # Load leads efficiently
        leads_table = api.table('appwPsfAb2ZmWqhJD', 'tblhU4gONxgdA5jTF')
        leads_records = leads_table.all()
        leads_df = pd.DataFrame([record['fields'] for record in leads_records])

        # Load transactions efficiently  
        trans_table = api.table('appwPsfAb2ZmWqhJD', 'tbl364vtt5U8DxmT3')
        trans_records = trans_table.all()
        trans_df = pd.DataFrame([record['fields'] for record in trans_records])

        logger.info(f"✅ Mobile data loaded: {len(leads_df)} leads, {len(trans_df)} transactions")
        return leads_df, trans_df, "✅ Data loaded successfully"

    except Exception as e:
        logger.error(f"❌ Mobile data loading error: {e}")
        return None, None, f"❌ Data loading failed: {str(e)}"

@st.cache_data(ttl=300)
def load_meta_data_cached(access_token: str, ad_account_id: str):
    """Load Meta API data with global caching function"""
    try:
        if not access_token or not ad_account_id:
            return {}, "⚠️ Meta API credentials required"

        # Mobile-optimized API call
        url = f"https://graph.facebook.com/v18.0/act_{ad_account_id}/insights"
        params = {
            'access_token': access_token,
            'fields': 'spend,impressions,clicks,actions,cost_per_action_type',
            'date_preset': 'last_30d',
            'limit': 25  # Limit for mobile performance
        }

        response = requests.get(url, params=params, timeout=10)

        if response.status_code == 200:
            data = response.json().get('data', [])
            logger.info(f"✅ Meta data loaded: {len(data)} insights")
            return {'insights': data}, "✅ Meta data loaded successfully"
        else:
            return {}, f"❌ Meta API error: {response.status_code}"

    except Exception as e:
        logger.error(f"❌ Meta API error: {e}")
        return {}, f"❌ Meta API failed: {str(e)}"

def filter_smooth_md_mobile(df: pd.DataFrame) -> pd.DataFrame:
    """Mobile-optimized filtering for Smooth MD Meta leads"""
    if df is None or df.empty:
        return pd.DataFrame()

    try:
        # Fast filtering for mobile performance
        filtered_df = df.copy()

        # Brand filter
        if 'Brand' in filtered_df.columns:
            brand_mask = filtered_df['Brand'].astype(str).str.contains('Smooth MD', case=False, na=False)
            filtered_df = filtered_df[brand_mask]

        # Source filter
        if 'Contact Source' in filtered_df.columns:
            source_mask = filtered_df['Contact Source'].astype(str).str.contains(
                'Facebook|Instagram|Meta', case=False, na=False
            )
            filtered_df = filtered_df[source_mask]

        logger.info(f"📱 Mobile filter: {len(df)} → {len(filtered_df)} leads")
        return filtered_df

    except Exception as e:
        logger.error(f"❌ Mobile filtering error: {e}")
        return df

def calculate_mobile_metrics(leads_df: pd.DataFrame, trans_df: pd.DataFrame, meta_data: dict) -> dict:
    """Calculate metrics optimized for mobile display"""
    metrics = {
        'total_leads': 0,
        'converted_leads': 0,
        'total_revenue': 0,
        'meta_spend': 0,
        'roas': 0,
        'conversion_rate': 0,
        'cost_per_lead': 0,
        'avg_transaction': 0
    }

    try:
        # Lead metrics
        if not leads_df.empty:
            metrics['total_leads'] = len(leads_df)

            # Conversion tracking
            if 'Overall Status' in leads_df.columns:
                conversion_mask = leads_df['Overall Status'].astype(str).str.contains(
                    'Closed|Deposit|Installment', case=False, na=False
                )
                metrics['converted_leads'] = conversion_mask.sum()

        # Revenue calculation
        if not trans_df.empty and 'Amount' in trans_df.columns:
            amounts = pd.to_numeric(trans_df['Amount'], errors='coerce').dropna()
            if len(amounts) > 0:
                metrics['total_revenue'] = float(amounts.sum())

        # Meta spend calculation
        if meta_data.get('insights'):
            total_spend = 0
            for insight in meta_data['insights']:
                spend = float(insight.get('spend', 0))
                total_spend += spend
            metrics['meta_spend'] = total_spend

        # Calculated metrics
        if metrics['meta_spend'] > 0:
            metrics['roas'] = metrics['total_revenue'] / metrics['meta_spend']
            if metrics['total_leads'] > 0:
                metrics['cost_per_lead'] = metrics['meta_spend'] / metrics['total_leads']

        if metrics['total_leads'] > 0:
            metrics['conversion_rate'] = (metrics['converted_leads'] / metrics['total_leads']) * 100

        if metrics['converted_leads'] > 0:
            metrics['avg_transaction'] = metrics['total_revenue'] / metrics['converted_leads']

        logger.info(f"📱 Mobile metrics calculated: ${metrics['total_revenue']:,.0f} revenue, {metrics['roas']:.1f}x ROAS")
        return metrics

    except Exception as e:
        logger.error(f"❌ Mobile metrics error: {e}")
        return metrics

def create_mobile_kpi_card(title: str, value: str, delta: str = None, status: str = "neutral"):
    """Create iOS-style KPI card optimized for mobile"""
    status_class = {
        "positive": "status-positive", 
        "negative": "status-negative",
        "warning": "status-warning"
    }.get(status, "")

    delta_html = f'<div class="ios-caption {status_class}">{delta}</div>' if delta else ''

    return f"""
    <div class="metric-card">
        <div class="ios-subtitle">{title}</div>
        <div class="ios-title">{value}</div>
        {delta_html}
    </div>
    """

def create_mobile_chart(leads_df: pd.DataFrame) -> go.Figure:
    """Create mobile-optimized performance chart"""
    try:
        if leads_df.empty:
            fig = go.Figure()
            fig.add_annotation(text="📱 No data available", xref="paper", yref="paper", 
                              x=0.5, y=0.5, showarrow=False, font_size=16)
            return fig

        # Create daily lead trend for mobile viewing
        if 'Inbound' in leads_df.columns:
            leads_df['Date'] = pd.to_datetime(leads_df['Inbound'], errors='coerce')
            daily_leads = leads_df.groupby(leads_df['Date'].dt.date).size().reset_index()
            daily_leads.columns = ['Date', 'Leads']
        else:
            # Create sample trend data
            dates = pd.date_range(end=datetime.now(), periods=30, freq='D')
            values = [max(1, int(len(leads_df) / 30 + i % 5)) for i in range(30)]

            daily_leads = pd.DataFrame({'Date': dates, 'Leads': values})

        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=daily_leads['Date'],
            y=daily_leads['Leads'],
            mode='lines+markers',
            line=dict(color='#007aff', width=3),
            marker=dict(size=8, color='#007aff'),
            name='Daily Leads'
        ))

        # Mobile-optimized layout
        fig.update_layout(
            title=dict(text="📈 Lead Performance", font=dict(size=18, weight='bold')),
            xaxis_title="Date",
            yaxis_title="Leads",
            height=300,
            margin=dict(l=40, r=40, t=60, b=40),
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font=dict(family='-apple-system, BlinkMacSystemFont, sans-serif')
        )

        return fig

    except Exception as e:
        logger.error(f"❌ Mobile chart error: {e}")
        fig = go.Figure()
        fig.add_annotation(text="📱 Chart loading...", xref="paper", yref="paper", 
                          x=0.5, y=0.5, showarrow=False, font_size=16)
        return fig

def main():
    """Main mobile dashboard application"""

    # Apply iOS mobile styling
    apply_ios_mobile_styling()

    # iOS Navigation Header
    st.markdown("""
    <div class="main-header">
        <div class="ios-title">📱 Campaign Command Center</div>
        <div class="ios-caption">Smooth MD • Real-time ROI Analytics</div>
    </div>
    """, unsafe_allow_html=True)

    # Get credentials
    airtable_key = os.getenv('AIRTABLE_API_KEY', '')
    meta_access_token = os.getenv('META_ACCESS_TOKEN', '')
    meta_ad_account_id = os.getenv('META_AD_ACCOUNT_ID', '')

    # Load data with robust error handling
    with st.spinner("🔄 Loading campaign data..."):
        try:
            leads_df, trans_df, airtable_status = load_airtable_data_cached(airtable_key)
            meta_data, meta_status = load_meta_data_cached(meta_access_token, meta_ad_account_id)
        except Exception as e:
            logger.error(f"Data loading failed: {e}")
            leads_df, trans_df = None, None
            airtable_status = f"❌ Loading failed: {str(e)}"
            meta_data, meta_status = {}, f"❌ Loading failed: {str(e)}"

    # Status indicators
    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"**Airtable:** {airtable_status}")
    with col2:
        st.markdown(f"**Meta API:** {meta_status}")

    # Process data if available
    if leads_df is not None and trans_df is not None:
        # Filter for Smooth MD Meta leads
        filtered_leads = filter_smooth_md_mobile(leads_df)

        # Calculate mobile metrics
        metrics = calculate_mobile_metrics(filtered_leads, trans_df, meta_data)

        # Mobile KPI Grid
        st.markdown('<div class="mobile-grid">', unsafe_allow_html=True)

        col1, col2, col3 = st.columns(3)

        with col1:
            st.markdown(create_mobile_kpi_card(
                "💰 Revenue",
                f"${metrics['total_revenue']:,.0f}",
                f"${metrics['avg_transaction']:,.0f} avg",
                "positive" if metrics['total_revenue'] > 0 else "neutral"
            ), unsafe_allow_html=True)

        with col2:
            st.markdown(create_mobile_kpi_card(
                "📊 ROAS",
                f"{metrics['roas']:.1f}x",
                f"${metrics['meta_spend']:,.0f} spend",
                "positive" if metrics['roas'] > 2 else "warning" if metrics['roas'] > 1 else "negative"
            ), unsafe_allow_html=True)

        with col3:
            st.markdown(create_mobile_kpi_card(
                "🎯 Leads",
                str(metrics['total_leads']),
                f"{metrics['conversion_rate']:.1f}% convert",
                "positive" if metrics['conversion_rate'] > 10 else "neutral"
            ), unsafe_allow_html=True)

        st.markdown('</div>', unsafe_allow_html=True)

        # Mobile Performance Chart
        st.markdown("### 📈 Performance Trend")
        chart = create_mobile_chart(filtered_leads)
        st.plotly_chart(chart, use_container_width=True)

        # Mobile Campaign Summary
        st.markdown("### 📋 Campaign Summary")

        summary_data = {
            "📱 Metric": ["Total Leads", "Converted", "Revenue", "ROAS", "Cost/Lead"],
            "📊 Value": [
                metrics['total_leads'],
                metrics['converted_leads'], 
                f"${metrics['total_revenue']:,.0f}",
                f"{metrics['roas']:.1f}x",
                f"${metrics['cost_per_lead']:.2f}"
            ]
        }

        st.dataframe(
            pd.DataFrame(summary_data),
            use_container_width=True,
            hide_index=True
        )

    else:
        # Error state with mobile-friendly messaging
        st.error("📱 Unable to load campaign data. Please check your API connections.")

        # Mobile troubleshooting guide
        st.markdown("""
        ### 🔧 Quick Fix Guide
        1. **Check API Keys**: Ensure Airtable and Meta tokens are valid
        2. **Network**: Verify internet connection is stable  
        3. **Refresh**: Pull down to refresh the dashboard
        """)

if __name__ == "__main__":
    main()