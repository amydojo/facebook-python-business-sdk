"""
Debug script to find the exact Meta leads in your Airtable
"""
import streamlit as st
from pyairtable import Api

def debug_leads():
    st.title("🔍 Lead Debug Tool")
    
    api_key = st.text_input("Airtable API Key", type="password")
    if not api_key:
        st.stop()
    
    if st.button("Debug Lead Data"):
        try:
            api = Api(api_key)
            leads_table = api.table('appri2CgCoIiuZWq3', 'Leads')
            records = leads_table.all()
            
            st.write(f"Total records found: {len(records)}")
            
            # Sample first few records
            st.write("### Sample Records (first 5):")
            for i, record in enumerate(records[:5]):
                st.write(f"**Record {i+1}:**")
                fields = record.get('fields', {})
                for field_id, value in fields.items():
                    st.write(f"  {field_id}: {value}")
                st.write("---")
            
            # Check brand field specifically
            brand_field = 'flddGiLa7lQ0nodBz'
            st.write(f"### Brand Field Analysis ({brand_field}):")
            brand_values = set()
            for record in records[:100]:  # Check first 100
                brand = record.get('fields', {}).get(brand_field, '')
                if brand:
                    brand_values.add(str(brand))
            
            st.write("Unique brand values found:")
            for brand in sorted(brand_values):
                st.write(f"- '{brand}'")
            
            # Check source field
            source_field = 'fldBUfZjdVhhJpRRA'
            st.write(f"### Source Field Analysis ({source_field}):")
            source_values = set()
            for record in records[:100]:
                source = record.get('fields', {}).get(source_field, '')
                if source:
                    source_values.add(str(source))
            
            st.write("Unique source values found:")
            for source in sorted(source_values):
                st.write(f"- '{source}'")
                
        except Exception as e:
            st.error(f"Error: {e}")

if __name__ == "__main__":
    debug_leads()