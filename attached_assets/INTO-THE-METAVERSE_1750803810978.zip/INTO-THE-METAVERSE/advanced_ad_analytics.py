"""
Advanced Ad Performance Analytics
Granular analysis of individual ads, ad sets, and campaigns with revenue attribution
"""

import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import numpy as np
from reliable_data_connector import ReliableDataConnector

class AdvancedAdAnalytics:
    """Advanced analytics for individual ad performance with revenue attribution"""
    
    def __init__(self):
        self.connector = ReliableDataConnector()
        
    def analyze_ad_performance_with_revenue(self, start_date: str, end_date: str) -> Dict:
        """Comprehensive ad performance analysis with revenue attribution"""
        
        # Load all data sources
        transactions_data = self.connector.load_transaction_data(start_date, end_date)
        leads_data = self.connector.load_leads_data(start_date, end_date)
        meta_data = self.connector.load_meta_insights(start_date, end_date)
        breakdown_data = self.connector.load_campaign_breakdown(start_date, end_date)
        
        if breakdown_data.get('error') or not breakdown_data.get('breakdown_data'):
            return {'error': 'Meta ad breakdown data unavailable'}
        
        breakdown = breakdown_data['breakdown_data']
        total_revenue = transactions_data.get('total_revenue', 0)
        total_conversions = leads_data.get('converted_leads', 0)
        
        # Analyze campaigns with revenue attribution
        campaign_analysis = self._analyze_campaigns_with_revenue(
            breakdown.get('campaigns', []), 
            total_revenue, 
            total_conversions,
            transactions_data.get('transactions', [])
        )
        
        # Analyze ad sets with performance insights
        adset_analysis = self._analyze_adsets_with_insights(
            breakdown.get('adsets', []),
            total_revenue,
            total_conversions
        )
        
        # Analyze individual ads with detailed metrics
        ad_analysis = self._analyze_individual_ads(
            breakdown.get('ads', []),
            total_revenue,
            total_conversions,
            transactions_data.get('transactions', [])
        )
        
        # Service/offer breakdown analysis
        service_analysis = self._analyze_service_performance(
            transactions_data.get('transactions', []),
            breakdown.get('campaigns', [])
        )
        
        return {
            'campaign_analysis': campaign_analysis,
            'adset_analysis': adset_analysis,
            'ad_analysis': ad_analysis,
            'service_analysis': service_analysis,
            'summary_metrics': {
                'total_revenue': total_revenue,
                'total_conversions': total_conversions,
                'total_spend': sum(float(c.get('spend', 0)) for c in breakdown.get('campaigns', [])),
                'overall_roas': total_revenue / sum(float(c.get('spend', 0)) for c in breakdown.get('campaigns', [])) if breakdown.get('campaigns') else 0
            }
        }
    
    def _analyze_campaigns_with_revenue(self, campaigns: List[Dict], total_revenue: float, total_conversions: int, transactions: List[Dict]) -> List[Dict]:
        """Analyze campaign performance with revenue attribution"""
        
        if not campaigns:
            return []
        
        total_spend = sum(float(c.get('spend', 0)) for c in campaigns)
        
        campaign_insights = []
        for campaign in campaigns:
            spend = float(campaign.get('spend', 0))
            impressions = int(campaign.get('impressions', 0))
            clicks = int(campaign.get('clicks', 0))
            reach = int(campaign.get('reach', 0))
            
            # Calculate proportional revenue attribution
            spend_share = spend / total_spend if total_spend > 0 else 0
            attributed_revenue = total_revenue * spend_share
            attributed_conversions = total_conversions * spend_share
            
            # Calculate key metrics
            ctr = float(campaign.get('ctr', 0))
            cpm = float(campaign.get('cpm', 0))
            cpc = spend / clicks if clicks > 0 else 0
            roas = attributed_revenue / spend if spend > 0 else 0
            conversion_rate = (attributed_conversions / clicks * 100) if clicks > 0 else 0
            cost_per_conversion = spend / attributed_conversions if attributed_conversions > 0 else 0
            
            # Performance scoring
            performance_score = self._calculate_performance_score(roas, ctr, conversion_rate)
            
            campaign_insights.append({
                'campaign_name': campaign.get('campaign_name', 'Unknown'),
                'campaign_id': campaign.get('campaign_id', ''),
                'spend': spend,
                'impressions': impressions,
                'clicks': clicks,
                'reach': reach,
                'ctr': ctr,
                'cpm': cpm,
                'cpc': cpc,
                'attributed_revenue': attributed_revenue,
                'attributed_conversions': attributed_conversions,
                'roas': roas,
                'conversion_rate': conversion_rate,
                'cost_per_conversion': cost_per_conversion,
                'performance_score': performance_score,
                'spend_share': spend_share * 100,
                'efficiency_rating': self._get_efficiency_rating(roas, ctr, conversion_rate)
            })
        
        # Sort by performance score
        return sorted(campaign_insights, key=lambda x: x['performance_score'], reverse=True)
    
    def _analyze_adsets_with_insights(self, adsets: List[Dict], total_revenue: float, total_conversions: int) -> List[Dict]:
        """Analyze ad set performance with detailed insights"""
        
        if not adsets:
            return []
        
        total_spend = sum(float(a.get('spend', 0)) for a in adsets)
        
        adset_insights = []
        for adset in adsets:
            spend = float(adset.get('spend', 0))
            impressions = int(adset.get('impressions', 0))
            clicks = int(adset.get('clicks', 0))
            
            # Calculate proportional attribution
            spend_share = spend / total_spend if total_spend > 0 else 0
            attributed_revenue = total_revenue * spend_share
            attributed_conversions = total_conversions * spend_share
            
            # Calculate metrics
            ctr = float(adset.get('ctr', 0))
            cpm = float(adset.get('cpm', 0))
            cpc = spend / clicks if clicks > 0 else 0
            roas = attributed_revenue / spend if spend > 0 else 0
            conversion_rate = (attributed_conversions / clicks * 100) if clicks > 0 else 0
            
            # Audience insights
            audience_efficiency = self._calculate_audience_efficiency(ctr, cpm, conversion_rate)
            
            adset_insights.append({
                'adset_name': adset.get('adset_name', 'Unknown'),
                'campaign_name': adset.get('campaign_name', 'Unknown'),
                'adset_id': adset.get('adset_id', ''),
                'spend': spend,
                'impressions': impressions,
                'clicks': clicks,
                'ctr': ctr,
                'cpm': cpm,
                'cpc': cpc,
                'attributed_revenue': attributed_revenue,
                'attributed_conversions': attributed_conversions,
                'roas': roas,
                'conversion_rate': conversion_rate,
                'audience_efficiency': audience_efficiency,
                'optimization_potential': self._assess_optimization_potential(ctr, cpm, roas),
                'spend_share': spend_share * 100
            })
        
        return sorted(adset_insights, key=lambda x: x['roas'], reverse=True)
    
    def _analyze_individual_ads(self, ads: List[Dict], total_revenue: float, total_conversions: int, transactions: List[Dict]) -> List[Dict]:
        """Detailed analysis of individual ad performance"""
        
        if not ads:
            return []
        
        total_spend = sum(float(a.get('spend', 0)) for a in ads)
        
        ad_insights = []
        for ad in ads:
            spend = float(ad.get('spend', 0))
            impressions = int(ad.get('impressions', 0))
            clicks = int(ad.get('clicks', 0))
            
            # Calculate attribution
            spend_share = spend / total_spend if total_spend > 0 else 0
            attributed_revenue = total_revenue * spend_share
            attributed_conversions = total_conversions * spend_share
            
            # Calculate comprehensive metrics
            ctr = float(ad.get('ctr', 0))
            cpm = float(ad.get('cpm', 0))
            cpc = spend / clicks if clicks > 0 else 0
            roas = attributed_revenue / spend if spend > 0 else 0
            conversion_rate = (attributed_conversions / clicks * 100) if clicks > 0 else 0
            cost_per_conversion = spend / attributed_conversions if attributed_conversions > 0 else 0
            
            # Creative performance insights
            creative_score = self._calculate_creative_score(ctr, roas, conversion_rate)
            
            # Revenue per impression
            revenue_per_impression = attributed_revenue / impressions if impressions > 0 else 0
            
            ad_insights.append({
                'ad_name': ad.get('ad_name', 'Unknown'),
                'campaign_name': ad.get('campaign_name', 'Unknown'),
                'adset_name': ad.get('adset_name', 'Unknown'),
                'ad_id': ad.get('ad_id', ''),
                'spend': spend,
                'impressions': impressions,
                'clicks': clicks,
                'ctr': ctr,
                'cpm': cpm,
                'cpc': cpc,
                'attributed_revenue': attributed_revenue,
                'attributed_conversions': attributed_conversions,
                'roas': roas,
                'conversion_rate': conversion_rate,
                'cost_per_conversion': cost_per_conversion,
                'revenue_per_impression': revenue_per_impression,
                'creative_score': creative_score,
                'performance_tier': self._get_performance_tier(roas, ctr, conversion_rate),
                'scaling_potential': self._assess_scaling_potential(roas, ctr, spend, impressions),
                'spend_share': spend_share * 100
            })
        
        return sorted(ad_insights, key=lambda x: x['creative_score'], reverse=True)
    
    def _analyze_service_performance(self, transactions: List[Dict], campaigns: List[Dict]) -> Dict:
        """Analyze service/treatment performance for campaign optimization"""
        
        if not transactions:
            return {'services': [], 'insights': []}
        
        # Group transactions by service
        service_revenue = {}
        service_counts = {}
        
        for transaction in transactions:
            service = transaction.get('service', 'Unknown Service')
            amount = transaction.get('amount', 0)
            
            if service not in service_revenue:
                service_revenue[service] = 0
                service_counts[service] = 0
            
            service_revenue[service] += amount
            service_counts[service] += 1
        
        # Calculate service metrics
        total_campaign_spend = sum(float(c.get('spend', 0)) for c in campaigns)
        
        service_analysis = []
        for service in service_revenue:
            revenue = service_revenue[service]
            count = service_counts[service]
            avg_value = revenue / count if count > 0 else 0
            revenue_share = revenue / sum(service_revenue.values()) * 100 if service_revenue else 0
            
            # Estimate service-specific ROAS
            service_spend_allocation = total_campaign_spend * (revenue_share / 100)
            service_roas = revenue / service_spend_allocation if service_spend_allocation > 0 else 0
            
            service_analysis.append({
                'service': service,
                'revenue': revenue,
                'transaction_count': count,
                'average_value': avg_value,
                'revenue_share': revenue_share,
                'estimated_roas': service_roas,
                'optimization_priority': self._get_optimization_priority(revenue_share, avg_value, service_roas)
            })
        
        # Sort by revenue
        service_analysis.sort(key=lambda x: x['revenue'], reverse=True)
        
        # Generate strategic insights
        insights = self._generate_service_insights(service_analysis)
        
        return {
            'services': service_analysis,
            'insights': insights,
            'top_performer': service_analysis[0] if service_analysis else None,
            'total_services': len(service_analysis),
            'average_transaction_value': sum(t.get('amount', 0) for t in transactions) / len(transactions) if transactions else 0
        }
    
    def _calculate_performance_score(self, roas: float, ctr: float, conversion_rate: float) -> float:
        """Calculate overall performance score (0-100)"""
        roas_score = min(roas * 20, 40)  # Max 40 points, optimal at 2.0 ROAS
        ctr_score = min(ctr * 10, 30)   # Max 30 points, optimal at 3.0% CTR
        conv_score = min(conversion_rate * 3, 30)  # Max 30 points, optimal at 10% conversion
        
        return roas_score + ctr_score + conv_score
    
    def _get_efficiency_rating(self, roas: float, ctr: float, conversion_rate: float) -> str:
        """Get efficiency rating based on performance metrics"""
        score = self._calculate_performance_score(roas, ctr, conversion_rate)
        
        if score >= 80:
            return "Excellent"
        elif score >= 60:
            return "Good"
        elif score >= 40:
            return "Average"
        elif score >= 20:
            return "Below Average"
        else:
            return "Poor"
    
    def _calculate_audience_efficiency(self, ctr: float, cpm: float, conversion_rate: float) -> float:
        """Calculate audience targeting efficiency score"""
        ctr_efficiency = min(ctr / 2.0, 1.0)  # Normalized to 2% CTR as good
        cpm_efficiency = max(1 - (cpm / 50), 0)  # Lower CPM is better, normalized to $50
        conv_efficiency = min(conversion_rate / 5.0, 1.0)  # Normalized to 5% conversion as good
        
        return (ctr_efficiency + cpm_efficiency + conv_efficiency) / 3 * 100
    
    def _assess_optimization_potential(self, ctr: float, cpm: float, roas: float) -> str:
        """Assess optimization potential for ad sets"""
        if roas < 1.0:
            return "High - Needs immediate optimization"
        elif ctr < 1.0:
            return "Medium - Improve creative/targeting"
        elif cpm > 30:
            return "Medium - Optimize audience"
        elif roas > 3.0:
            return "Low - Scale current setup"
        else:
            return "Low - Monitor performance"
    
    def _calculate_creative_score(self, ctr: float, roas: float, conversion_rate: float) -> float:
        """Calculate creative performance score"""
        ctr_weight = 0.4
        roas_weight = 0.4
        conv_weight = 0.2
        
        ctr_score = min(ctr / 3.0, 1.0) * 100  # Normalized to 3% CTR
        roas_score = min(roas / 2.0, 1.0) * 100  # Normalized to 2.0 ROAS
        conv_score = min(conversion_rate / 10.0, 1.0) * 100  # Normalized to 10% conversion
        
        return (ctr_score * ctr_weight + roas_score * roas_weight + conv_score * conv_weight)
    
    def _get_performance_tier(self, roas: float, ctr: float, conversion_rate: float) -> str:
        """Categorize ad into performance tiers"""
        score = self._calculate_performance_score(roas, ctr, conversion_rate)
        
        if score >= 70:
            return "Top Performer"
        elif score >= 50:
            return "Strong Performer"
        elif score >= 30:
            return "Average Performer"
        else:
            return "Underperformer"
    
    def _assess_scaling_potential(self, roas: float, ctr: float, spend: float, impressions: int) -> str:
        """Assess potential for scaling ad spend"""
        if roas > 3.0 and ctr > 2.0:
            return "High - Ready to scale"
        elif roas > 2.0 and spend < 100:
            return "Medium - Test increased budget"
        elif roas > 1.5 and impressions < 10000:
            return "Medium - Expand reach"
        elif roas < 1.0:
            return "Low - Optimize before scaling"
        else:
            return "Low - Monitor closely"
    
    def _get_optimization_priority(self, revenue_share: float, avg_value: float, roas: float) -> str:
        """Determine optimization priority for services"""
        if revenue_share > 30 and roas > 2.0:
            return "High - Scale winning service"
        elif avg_value > 1000 and roas > 1.5:
            return "High - Promote high-value service"
        elif revenue_share > 15:
            return "Medium - Optimize current campaigns"
        else:
            return "Low - Consider testing"
    
    def _generate_service_insights(self, service_analysis: List[Dict]) -> List[str]:
        """Generate actionable insights for service optimization"""
        insights = []
        
        if not service_analysis:
            return insights
        
        # Top performing service
        top_service = service_analysis[0]
        insights.append(f"Focus on {top_service['service']} - generates {top_service['revenue_share']:.1f}% of revenue with ${top_service['average_value']:.0f} average value")
        
        # High-value services
        high_value_services = [s for s in service_analysis if s['average_value'] > 1000]
        if high_value_services:
            insights.append(f"Promote premium services: {', '.join([s['service'] for s in high_value_services[:3]])} have highest transaction values")
        
        # ROAS opportunities
        high_roas_services = [s for s in service_analysis if s['estimated_roas'] > 2.0]
        if high_roas_services:
            insights.append(f"Scale campaigns for {', '.join([s['service'] for s in high_roas_services[:2]])} - showing strong ROAS")
        
        # Underperforming services
        low_performers = [s for s in service_analysis if s['estimated_roas'] < 1.0]
        if low_performers:
            insights.append(f"Optimize or pause campaigns for {', '.join([s['service'] for s in low_performers[:2]])} - below breakeven ROAS")
        
        return insights