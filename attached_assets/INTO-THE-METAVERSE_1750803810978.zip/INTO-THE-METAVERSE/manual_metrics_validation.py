#!/usr/bin/env python3
"""
Manual Metrics Validation
Step-by-step calculation of metrics using Airtable data as source of truth
"""

from pyairtable import Api
import json
from datetime import datetime, timedelta

# API credentials
API_KEY = 'patRpwfhYlGferLE8.17a89cf5c31e4ef29041a67a4b28ca4058bb443779beb0dd4352ad999b186cdd'
BASE_ID = 'appH4MePHS6qLsk5z'

def load_all_data():
    """Load complete datasets from Airtable"""
    print("Loading all Airtable data...")
    
    api = Api(API_KEY)
    base = api.base(BASE_ID)
    
    # Load leads
    leads_table = base.table('Leads')
    all_leads = leads_table.all()
    leads_data = []
    for record in all_leads:
        row = {'record_id': record['id']}
        row.update(record['fields'])
        leads_data.append(row)
    
    # Load transactions
    tx_table = base.table('Transactions')
    all_transactions = tx_table.all()
    tx_data = []
    for record in all_transactions:
        row = {'record_id': record['id']}
        row.update(record['fields'])
        tx_data.append(row)
    
    print(f"Loaded {len(leads_data)} leads and {len(tx_data)} transactions")
    return leads_data, tx_data

def manual_step1_identify_meta_leads(leads_data):
    """Step 1: Manually identify Meta/Facebook leads"""
    print("\n=== STEP 1: Identifying Meta Leads ===")
    
    meta_leads = []
    source_analysis = {}
    
    for lead in leads_data:
        contact_source = lead.get('Contact Source', '')
        if contact_source:
            source_lower = str(contact_source).lower()
            source_analysis[contact_source] = source_analysis.get(contact_source, 0) + 1
            
            # Check for Meta/Facebook indicators
            if any(term in source_lower for term in ['facebook', 'meta', 'fb', 'instagram']):
                meta_leads.append(lead)
    
    print(f"Total leads: {len(leads_data)}")
    print(f"Meta leads found: {len(meta_leads)}")
    print("\nContact Source distribution (top 20):")
    sorted_sources = sorted(source_analysis.items(), key=lambda x: x[1], reverse=True)
    for source, count in sorted_sources[:20]:
        indicator = "🎯 META" if any(term in str(source).lower() for term in ['facebook', 'meta', 'fb', 'instagram']) else ""
        print(f"  {source}: {count} {indicator}")
    
    return meta_leads

def manual_step2_filter_smooth_md(meta_leads):
    """Step 2: Filter to only Smooth MD leads"""
    print("\n=== STEP 2: Filtering to Smooth MD ===")
    
    smooth_meta_leads = []
    brand_analysis = {}
    
    for lead in meta_leads:
        brand = lead.get('Brand', '')
        if brand:
            brand_analysis[brand] = brand_analysis.get(brand, 0) + 1
            
            brand_lower = str(brand).lower()
            if 'smooth' in brand_lower and 'vigor' not in brand_lower:
                smooth_meta_leads.append(lead)
    
    print(f"Meta leads: {len(meta_leads)}")
    print(f"Smooth MD Meta leads: {len(smooth_meta_leads)}")
    print("\nBrand distribution in Meta leads:")
    for brand, count in sorted(brand_analysis.items(), key=lambda x: x[1], reverse=True):
        indicator = "✅ SMOOTH MD" if 'smooth' in str(brand).lower() and 'vigor' not in str(brand).lower() else ""
        print(f"  {brand}: {count} {indicator}")
    
    return smooth_meta_leads

def manual_step3_analyze_transactions(tx_data):
    """Step 3: Analyze transaction data for Smooth MD filtering"""
    print("\n=== STEP 3: Analyzing Transactions ===")
    
    brand_analysis = {}
    smooth_transactions = []
    dr_vigor_transactions = []
    unknown_brand_transactions = []
    
    for tx in tx_data:
        # Analyze Brand (from ID) field
        brand_field = tx.get('Brand (from ID)', [])
        if isinstance(brand_field, list) and brand_field:
            brand = str(brand_field[0])
        else:
            brand = str(brand_field) if brand_field else "Unknown"
        
        brand_analysis[brand] = brand_analysis.get(brand, 0) + 1
        
        # Categorize transactions
        brand_lower = brand.lower()
        if 'smooth' in brand_lower and 'vigor' not in brand_lower:
            smooth_transactions.append(tx)
        elif 'vigor' in brand_lower:
            dr_vigor_transactions.append(tx)
        elif brand == "Unknown" or not brand:
            unknown_brand_transactions.append(tx)
        else:
            # Default to Smooth MD if not explicitly Dr. Vigor
            smooth_transactions.append(tx)
    
    print(f"Total transactions: {len(tx_data)}")
    print(f"Smooth MD transactions: {len(smooth_transactions)}")
    print(f"Dr. Vigor transactions: {len(dr_vigor_transactions)}")
    print(f"Unknown brand transactions: {len(unknown_brand_transactions)}")
    
    print("\nTransaction brand distribution:")
    for brand, count in sorted(brand_analysis.items(), key=lambda x: x[1], reverse=True):
        print(f"  {brand}: {count}")
    
    return smooth_transactions

def manual_step4_match_leads_to_transactions(smooth_leads, smooth_transactions):
    """Step 4: Match Smooth MD leads to transactions"""
    print("\n=== STEP 4: Matching Leads to Transactions ===")
    
    # Create transaction lookup by lead record ID
    transaction_lookup = {}
    unmatched_transactions = []
    
    for tx in smooth_transactions:
        if 'ID' in tx and tx['ID']:
            lead_ids = tx['ID'] if isinstance(tx['ID'], list) else [tx['ID']]
            matched = False
            for lead_id in lead_ids:
                lead_record_id = str(lead_id).strip()
                if lead_record_id not in transaction_lookup:
                    transaction_lookup[lead_record_id] = []
                transaction_lookup[lead_record_id].append(tx)
                matched = True
            if not matched:
                unmatched_transactions.append(tx)
        else:
            unmatched_transactions.append(tx)
    
    print(f"Transaction lookup created for {len(transaction_lookup)} lead record IDs")
    print(f"Unmatched transactions: {len(unmatched_transactions)}")
    
    # Match leads to transactions
    matched_leads = []
    total_revenue = 0
    matched_count = 0
    
    for lead in smooth_leads:
        lead_record_id = lead.get('record_id', '')
        lead_copy = lead.copy()
        lead_copy['matched_transactions'] = []
        lead_copy['total_revenue'] = 0
        
        if lead_record_id in transaction_lookup:
            lead_copy['matched_transactions'] = transaction_lookup[lead_record_id]
            matched_count += 1
            
            # Calculate revenue
            for tx in lead_copy['matched_transactions']:
                if 'Amount' in tx and tx['Amount']:
                    try:
                        amount = float(tx['Amount'])
                        lead_copy['total_revenue'] += amount
                        total_revenue += amount
                    except:
                        print(f"Warning: Could not parse amount for transaction {tx.get('record_id', 'Unknown')}: {tx.get('Amount', 'N/A')}")
        
        matched_leads.append(lead_copy)
    
    print(f"Matched leads: {matched_count}/{len(smooth_leads)} ({matched_count/len(smooth_leads)*100:.1f}%)")
    print(f"Total revenue attributed: ${total_revenue:,.2f}")
    
    # Show sample matches
    high_value_matches = [l for l in matched_leads if l['total_revenue'] > 1000]
    if high_value_matches:
        print(f"\nHigh-value matches (>${1000}+): {len(high_value_matches)}")
        for i, lead in enumerate(high_value_matches[:5]):
            print(f"  {i+1}. Lead {lead.get('ID', 'Unknown')}: ${lead['total_revenue']:,.2f} ({len(lead['matched_transactions'])} transactions)")
    
    return matched_leads, {
        'total_revenue': total_revenue,
        'matched_count': matched_count,
        'total_leads': len(smooth_leads),
        'match_rate': matched_count/len(smooth_leads)*100 if smooth_leads else 0
    }

def manual_step5_date_filtering(matched_leads, start_date='2025-06-01', end_date='2025-06-17'):
    """Step 5: Apply date filtering"""
    print(f"\n=== STEP 5: Date Filtering ({start_date} to {end_date}) ===")
    
    start_dt = datetime.strptime(start_date, '%Y-%m-%d')
    end_dt = datetime.strptime(end_date, '%Y-%m-%d')
    
    date_filtered_leads = []
    date_filtered_revenue = 0
    date_filtered_matched = 0
    
    for lead in matched_leads:
        # Check if lead falls in date range using Inbound field
        if 'Inbound' in lead and lead['Inbound']:
            try:
                inbound_str = str(lead['Inbound'])
                if 'T' in inbound_str:
                    lead_date = datetime.fromisoformat(inbound_str.split('T')[0])
                else:
                    lead_date = datetime.strptime(inbound_str, '%Y-%m-%d')
                
                if start_dt <= lead_date <= end_dt:
                    date_filtered_leads.append(lead)
                    date_filtered_revenue += lead['total_revenue']
                    if lead['matched_transactions']:
                        date_filtered_matched += 1
            except:
                # If date parsing fails, include the lead
                date_filtered_leads.append(lead)
                date_filtered_revenue += lead['total_revenue']
                if lead['matched_transactions']:
                    date_filtered_matched += 1
    
    print(f"Leads in date range: {len(date_filtered_leads)}")
    print(f"Matched leads in date range: {date_filtered_matched}")
    print(f"Revenue in date range: ${date_filtered_revenue:,.2f}")
    
    return date_filtered_leads, {
        'total_revenue': date_filtered_revenue,
        'matched_count': date_filtered_matched,
        'total_leads': len(date_filtered_leads),
        'match_rate': date_filtered_matched/len(date_filtered_leads)*100 if date_filtered_leads else 0
    }

def main():
    """Main validation process"""
    print("🔍 MANUAL METRICS VALIDATION")
    print("=" * 50)
    
    # Load all data
    leads_data, tx_data = load_all_data()
    
    # Step-by-step validation
    meta_leads = manual_step1_identify_meta_leads(leads_data)
    smooth_meta_leads = manual_step2_filter_smooth_md(meta_leads)
    smooth_transactions = manual_step3_analyze_transactions(tx_data)
    matched_leads, overall_stats = manual_step4_match_leads_to_transactions(smooth_meta_leads, smooth_transactions)
    date_filtered_leads, date_stats = manual_step5_date_filtering(matched_leads)
    
    # Final summary
    print("\n" + "=" * 50)
    print("📊 FINAL VALIDATION RESULTS")
    print("=" * 50)
    print(f"Total Leads in Database: {len(leads_data):,}")
    print(f"Meta Leads: {len(meta_leads):,}")
    print(f"Smooth MD Meta Leads: {len(smooth_meta_leads):,}")
    print(f"Smooth MD Transactions: {len(smooth_transactions):,}")
    print(f"Overall Matched Leads: {overall_stats['matched_count']:,}")
    print(f"Overall Revenue: ${overall_stats['total_revenue']:,.2f}")
    print(f"Overall Match Rate: {overall_stats['match_rate']:.1f}%")
    print()
    print("📅 DATE RANGE RESULTS (2025-06-01 to 2025-06-17):")
    print(f"Leads in Range: {date_stats['total_leads']:,}")
    print(f"Matched Leads in Range: {date_stats['matched_count']:,}")
    print(f"Revenue in Range: ${date_stats['total_revenue']:,.2f}")
    print(f"Match Rate in Range: {date_stats['match_rate']:.1f}%")
    
    # Comparison with dashboard
    print("\n" + "=" * 50)
    print("🔧 DASHBOARD VALIDATION SUMMARY")
    print("=" * 50)
    print("These are the verified metrics that should appear in your dashboard:")
    print(f"✓ Smooth MD Meta Leads: {len(smooth_meta_leads):,}")
    print(f"✓ Matched Leads: {date_stats['matched_count']:,}")
    print(f"✓ Revenue Attributed: ${date_stats['total_revenue']:,.2f}")
    print(f"✓ Match Rate: {date_stats['match_rate']:.1f}%")

if __name__ == "__main__":
    main()