"""
Fault-Tolerant Data Connector
Advanced computer science methods for future-proof critical data connections
"""

import os
import time
import logging
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass
from enum import Enum
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pyairtable import Api
import requests

logger = logging.getLogger(__name__)

class ConnectionHealth(Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    CRITICAL = "critical"
    RECOVERING = "recovering"

@dataclass
class ConnectionAttempt:
    timestamp: float
    success: bool
    response_time: float
    error_type: Optional[str] = None
    error_message: Optional[str] = None

class AdvancedCircuitBreaker:
    """Production-grade circuit breaker with intelligent failure detection"""
    
    def __init__(self, failure_threshold: int = 3, recovery_timeout: int = 30):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failure_count = 0
        self.last_failure_time = None
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
        self.lock = threading.Lock()
        self.recent_attempts = []
    
    def call(self, func: Callable, *args, **kwargs):
        """Execute function with circuit breaker protection"""
        with self.lock:
            if self.state == "OPEN":
                if self._should_try_recovery():
                    self.state = "HALF_OPEN"
                else:
                    raise ConnectionError("Circuit breaker OPEN - service unavailable")
        
        start_time = time.time()
        try:
            result = func(*args, **kwargs)
            response_time = time.time() - start_time
            self._record_success(response_time)
            return result
        except Exception as e:
            response_time = time.time() - start_time
            self._record_failure(str(e), response_time)
            raise
    
    def _should_try_recovery(self) -> bool:
        if not self.last_failure_time:
            return True
        return time.time() - self.last_failure_time >= self.recovery_timeout
    
    def _record_success(self, response_time: float):
        with self.lock:
            self.failure_count = 0
            self.state = "CLOSED"
            attempt = ConnectionAttempt(time.time(), True, response_time)
            self.recent_attempts.append(attempt)
            self._cleanup_old_attempts()
    
    def _record_failure(self, error: str, response_time: float):
        with self.lock:
            self.failure_count += 1
            self.last_failure_time = time.time()
            
            error_type = self._classify_error(error)
            attempt = ConnectionAttempt(
                time.time(), False, response_time, error_type, error
            )
            self.recent_attempts.append(attempt)
            self._cleanup_old_attempts()
            
            if self.failure_count >= self.failure_threshold:
                self.state = "OPEN"
    
    def _classify_error(self, error: str) -> str:
        error_lower = error.lower()
        if "403" in error or "forbidden" in error_lower:
            return "PERMISSION_ERROR"
        elif "404" in error or "not found" in error_lower:
            return "NOT_FOUND"
        elif "401" in error or "unauthorized" in error_lower:
            return "AUTH_ERROR"
        elif "timeout" in error_lower:
            return "TIMEOUT_ERROR"
        else:
            return "UNKNOWN_ERROR"
    
    def _cleanup_old_attempts(self):
        cutoff_time = time.time() - 300  # Keep 5 minutes of history
        self.recent_attempts = [
            attempt for attempt in self.recent_attempts 
            if attempt.timestamp > cutoff_time
        ]

class ExponentialBackoff:
    """Adaptive exponential backoff with jitter"""
    
    def __init__(self, base_delay: float = 1.0, max_delay: float = 30.0, 
                 multiplier: float = 2.0, jitter: bool = True):
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.multiplier = multiplier
        self.jitter = jitter
    
    def retry(self, func: Callable, max_attempts: int = 5, *args, **kwargs):
        """Execute function with exponential backoff retry"""
        last_exception = None
        
        for attempt in range(max_attempts):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                
                if attempt == max_attempts - 1:
                    break
                
                delay = min(
                    self.base_delay * (self.multiplier ** attempt),
                    self.max_delay
                )
                
                if self.jitter:
                    import random
                    delay *= (0.5 + random.random() * 0.5)
                
                logger.warning(f"Attempt {attempt + 1} failed, retrying in {delay:.2f}s: {e}")
                time.sleep(delay)
        
        raise last_exception

class ConnectionPool:
    """Thread-safe connection pool with health monitoring"""
    
    def __init__(self, api_key: str, max_size: int = 5):
        self.api_key = api_key
        self.max_size = max_size
        self.pool = []
        self.active_connections = 0
        self.lock = threading.Lock()
        self.connection_health = {}
    
    def get_connection(self) -> Api:
        """Get connection from pool or create new one"""
        with self.lock:
            if self.pool:
                connection = self.pool.pop()
                self.active_connections += 1
                return connection
            
            if self.active_connections < self.max_size:
                connection = Api(self.api_key)
                self.active_connections += 1
                connection_id = id(connection)
                self.connection_health[connection_id] = {
                    'created': time.time(),
                    'requests': 0,
                    'errors': 0
                }
                return connection
        
        # Pool is full, create temporary connection
        return Api(self.api_key)
    
    def return_connection(self, connection: Api):
        """Return connection to pool"""
        with self.lock:
            if len(self.pool) < self.max_size:
                self.pool.append(connection)
            self.active_connections = max(0, self.active_connections - 1)
    
    def record_request(self, connection: Api, success: bool):
        """Record connection usage statistics"""
        connection_id = id(connection)
        if connection_id in self.connection_health:
            health = self.connection_health[connection_id]
            health['requests'] += 1
            if not success:
                health['errors'] += 1

class FaultTolerantConnector:
    """Production-ready fault-tolerant data connector"""
    
    def __init__(self):
        self.api_key = os.getenv('AIRTABLE_API_KEY')
        self.base_id = os.getenv('AIRTABLE_BASE_ID')
        
        # Initialize resilience components
        self.connection_pool = ConnectionPool(self.api_key) if self.api_key else None
        self.circuit_breaker = AdvancedCircuitBreaker()
        self.backoff = ExponentialBackoff()
        self.executor = ThreadPoolExecutor(max_workers=3)
        
        # Table mappings with fallbacks
        self.table_mappings = {
            'transactions': ['Social Media', 'Transactions', 'Sales', 'Revenue'],
            'leads': ['Leads', 'Lead', 'Prospects', 'Customers']
        }
        
        # Validated table names
        self.validated_tables = {}
        self.last_validation = {}
        
        # Connection health monitoring
        self.health_status = ConnectionHealth.HEALTHY
        self.last_health_check = 0
        
        logger.info("Fault-tolerant connector initialized")
    
    def _validate_credentials(self) -> Dict[str, Any]:
        """Validate API credentials"""
        if not self.api_key:
            return {
                'valid': False,
                'error': 'AIRTABLE_API_KEY not configured',
                'recommendation': 'Set AIRTABLE_API_KEY environment variable'
            }
        
        if not self.base_id:
            return {
                'valid': False,
                'error': 'AIRTABLE_BASE_ID not configured',
                'recommendation': 'Set AIRTABLE_BASE_ID environment variable'
            }
        
        # Validate key format
        if not self.api_key.startswith(('pat', 'key')):
            return {
                'valid': False,
                'error': 'Invalid API key format',
                'recommendation': 'Use personal access token (starts with "pat") or legacy key'
            }
        
        return {'valid': True}
    
    def _discover_table(self, data_type: str) -> Optional[str]:
        """Discover correct table name with intelligent fallback"""
        possible_names = self.table_mappings.get(data_type, [])
        
        for table_name in possible_names:
            try:
                # Test table access with minimal query
                connection = self.connection_pool.get_connection()
                table = connection.table(self.base_id, table_name)
                records = table.all(max_records=1)
                
                self.connection_pool.return_connection(connection)
                self.connection_pool.record_request(connection, True)
                
                # Cache successful mapping
                self.validated_tables[data_type] = table_name
                self.last_validation[data_type] = time.time()
                
                logger.info(f"Discovered table for {data_type}: {table_name}")
                return table_name
                
            except Exception as e:
                self.connection_pool.record_request(connection, False)
                logger.debug(f"Table {table_name} not accessible for {data_type}: {e}")
                continue
        
        return None
    
    def _get_table_name(self, data_type: str) -> str:
        """Get validated table name with caching"""
        # Check cache first
        if data_type in self.validated_tables:
            last_check = self.last_validation.get(data_type, 0)
            if time.time() - last_check < 3600:  # 1 hour cache
                return self.validated_tables[data_type]
        
        # Discover table name
        table_name = self._discover_table(data_type)
        if not table_name:
            raise ValueError(f"No accessible table found for {data_type}")
        
        return table_name
    
    def _load_data_with_resilience(self, data_type: str, filters: Optional[Dict] = None) -> Dict[str, Any]:
        """Load data with full resilience patterns"""
        
        def _fetch_data():
            table_name = self._get_table_name(data_type)
            connection = self.connection_pool.get_connection()
            
            try:
                table = connection.table(self.base_id, table_name)
                
                if filters:
                    records = table.all(**filters)
                else:
                    records = table.all()
                
                self.connection_pool.record_request(connection, True)
                return records
                
            finally:
                self.connection_pool.return_connection(connection)
        
        # Execute with circuit breaker and retry logic
        try:
            records = self.circuit_breaker.call(
                lambda: self.backoff.retry(_fetch_data, max_attempts=3)
            )
            
            return {
                'success': True,
                'data': records,
                'count': len(records),
                'data_type': data_type,
                'table_name': self.validated_tables.get(data_type)
            }
            
        except Exception as e:
            error_type = self.circuit_breaker._classify_error(str(e))
            
            return {
                'success': False,
                'error': str(e),
                'error_type': error_type,
                'data_type': data_type,
                'recommendations': self._get_error_recommendations(error_type)
            }
    
    def _get_error_recommendations(self, error_type: str) -> List[str]:
        """Get actionable recommendations for error types"""
        recommendations = {
            'PERMISSION_ERROR': [
                'Verify API key has read permissions for this base',
                'Check that the base is shared with your API key',
                'Ensure table permissions allow read access'
            ],
            'AUTH_ERROR': [
                'Verify API key is valid and not expired',
                'Check AIRTABLE_API_KEY environment variable',
                'Generate new personal access token if needed'
            ],
            'NOT_FOUND': [
                'Verify AIRTABLE_BASE_ID is correct',
                'Check that table names exist in the base',
                'Ensure base is not deleted or moved'
            ],
            'TIMEOUT_ERROR': [
                'Check network connectivity',
                'Verify Airtable service status',
                'Consider reducing query size'
            ]
        }
        
        return recommendations.get(error_type, ['Contact system administrator'])
    
    def load_transactions(self, start_date: str, end_date: str) -> Dict[str, Any]:
        """Load transaction data with fault tolerance"""
        filters = {
            'formula': f"AND(IS_AFTER({{Date}}, '{start_date}'), IS_BEFORE({{Date}}, '{end_date}'))"
        }
        
        result = self._load_data_with_resilience('transactions', filters)
        
        if result['success']:
            # Process and filter data
            transactions = self._process_transactions(result['data'], start_date, end_date)
            result['processed_data'] = transactions
            result['revenue'] = sum(t.get('amount', 0) for t in transactions)
        
        return result
    
    def load_leads(self, start_date: str, end_date: str) -> Dict[str, Any]:
        """Load lead data with fault tolerance"""
        filters = {
            'formula': f"AND(IS_AFTER({{Inbound}}, '{start_date}'), IS_BEFORE({{Inbound}}, '{end_date}'))"
        }
        
        result = self._load_data_with_resilience('leads', filters)
        
        if result['success']:
            # Process and filter data
            leads = self._process_leads(result['data'], start_date, end_date)
            result['processed_data'] = leads
            result['lead_count'] = len(leads)
        
        return result
    
    def _process_transactions(self, records: List[Dict], start_date: str, end_date: str) -> List[Dict]:
        """Process transaction records with robust field mapping"""
        processed = []
        
        for record in records:
            fields = record.get('fields', {})
            
            # Extract brand
            brand = self._extract_field(fields, ['Brand', 'brand', 'Company'])
            if not brand or 'smooth' not in brand.lower():
                continue
            
            # Extract source
            source = self._extract_field(fields, ['Source', 'source', 'Lead Source', 'Campaign'])
            if not self._is_meta_source(source):
                continue
            
            # Extract amount
            amount = self._extract_amount(fields)
            if amount <= 0:
                continue
            
            # Extract date
            date_str = self._extract_date(fields)
            if not date_str:
                continue
            
            processed.append({
                'record_id': record.get('id'),
                'amount': amount,
                'date': date_str,
                'brand': brand,
                'source': source
            })
        
        return processed
    
    def _process_leads(self, records: List[Dict], start_date: str, end_date: str) -> List[Dict]:
        """Process lead records with robust field mapping"""
        processed = []
        
        for record in records:
            fields = record.get('fields', {})
            
            # Extract brand
            brand = self._extract_field(fields, ['Brand', 'brand', 'Company'])
            if not brand or 'smooth' not in brand.lower():
                continue
            
            # Extract source
            source = self._extract_field(fields, ['Source', 'source', 'Lead Source', 'Campaign'])
            if not self._is_meta_source(source):
                continue
            
            # Extract date
            date_str = self._extract_date(fields, ['Inbound', 'Date', 'Created'])
            if not date_str:
                continue
            
            # Extract status
            status = self._extract_field(fields, ['Overall Status', 'Status', 'Lead Status'])
            
            processed.append({
                'record_id': record.get('id'),
                'date': date_str,
                'brand': brand,
                'source': source,
                'status': status
            })
        
        return processed
    
    def _extract_field(self, fields: Dict, possible_keys: List[str]) -> str:
        """Extract field value with multiple key attempts"""
        for key in possible_keys:
            value = fields.get(key)
            if value:
                return str(value).strip()
        return ''
    
    def _extract_amount(self, fields: Dict) -> float:
        """Extract amount with robust parsing"""
        amount_keys = ['Amount', 'amount', 'Total', 'Revenue', 'Value']
        
        for key in amount_keys:
            value = fields.get(key)
            if value is not None:
                try:
                    # Handle different formats
                    if isinstance(value, (int, float)):
                        return float(value)
                    elif isinstance(value, str):
                        # Remove currency symbols and commas
                        clean_value = value.replace('$', '').replace(',', '').strip()
                        return float(clean_value)
                except (ValueError, TypeError):
                    continue
        
        return 0.0
    
    def _extract_date(self, fields: Dict, date_keys: Optional[List[str]] = None) -> str:
        """Extract date with robust parsing"""
        if not date_keys:
            date_keys = ['Date', 'date', 'Created', 'Timestamp']
        
        for key in date_keys:
            value = fields.get(key)
            if value:
                try:
                    if isinstance(value, str):
                        # Parse ISO format
                        dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
                        return dt.strftime('%Y-%m-%d')
                    elif hasattr(value, 'strftime'):
                        return value.strftime('%Y-%m-%d')
                except (ValueError, TypeError):
                    continue
        
        return ''
    
    def _is_meta_source(self, source: str) -> bool:
        """Check if source indicates Meta/Facebook"""
        if not source:
            return False
        
        source_lower = source.lower()
        meta_indicators = ['meta', 'facebook', 'fb', 'instagram', 'ig']
        
        return any(indicator in source_lower for indicator in meta_indicators)
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get comprehensive health status"""
        credential_check = self._validate_credentials()
        
        status = {
            'overall_health': self.health_status.value,
            'circuit_breaker_state': self.circuit_breaker.state,
            'credentials_valid': credential_check['valid'],
            'validated_tables': self.validated_tables,
            'connection_pool_size': len(self.connection_pool.pool) if self.connection_pool else 0,
            'recent_attempts': len(self.circuit_breaker.recent_attempts),
            'last_check': datetime.now().isoformat()
        }
        
        if not credential_check['valid']:
            status['error'] = credential_check['error']
            status['recommendation'] = credential_check['recommendation']
        
        return status
    
    def diagnose_and_heal(self) -> Dict[str, Any]:
        """Comprehensive diagnostics and auto-healing"""
        diagnosis = {
            'timestamp': datetime.now().isoformat(),
            'health_status': self.get_health_status(),
            'healing_actions': [],
            'recommendations': []
        }
        
        # Reset circuit breaker if appropriate
        if self.circuit_breaker.state == "OPEN":
            if self.circuit_breaker._should_try_recovery():
                self.circuit_breaker.state = "HALF_OPEN"
                diagnosis['healing_actions'].append('Reset circuit breaker to HALF_OPEN')
        
        # Clear validated table cache if old
        current_time = time.time()
        for data_type, last_check in list(self.last_validation.items()):
            if current_time - last_check > 3600:  # 1 hour
                del self.validated_tables[data_type]
                del self.last_validation[data_type]
                diagnosis['healing_actions'].append(f'Cleared stale cache for {data_type}')
        
        # Test connections
        if self.api_key and self.base_id:
            try:
                for data_type in ['transactions', 'leads']:
                    self._discover_table(data_type)
                diagnosis['healing_actions'].append('Successfully validated table access')
            except Exception as e:
                diagnosis['recommendations'].append(f'Table validation failed: {e}')
        
        return diagnosis

# Global instance
fault_tolerant_connector = FaultTolerantConnector()

__all__ = ['FaultTolerantConnector', 'fault_tolerant_connector']