"""
Attribution Demo Dashboard
Demonstrates the attribution features integrated into your main dashboard
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import logging
import os
import requests
from pyairtable import Api

# Force enable attribution for demo
os.environ["ENABLE_ATTRIBUTION"] = "true"
ENABLE_ATTRIBUTION = True

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Attribution imports
from attribution import AttributionModels, build_journeys, calculate_attribution_roas

# Configure APIs
API_KEY = 'patRpwfhYlGferLE8.17a89cf5c31e4ef29041a67a4b28ca4058bb443779beb0dd4352ad999b186cdd'
BASE_ID = 'appH4MePHS6qLsk5z'

# Page configuration
st.set_page_config(page_title="Attribution Demo Dashboard",
                   page_icon="🎯",
                   layout="wide",
                   initial_sidebar_state="expanded")

st.title("🎯 Revenue Attribution Analysis Demo")
st.info("This demonstrates the new attribution features integrated into your main dashboard")

def load_sample_data():
    """Load sample data for attribution demonstration"""
    
    # Create realistic sample leads
    leads_data = []
    for i in range(20):
        leads_data.append({
            'lead_id': f'lead_{i}',
            'Phone': f'555-{1000+i}',
            'Email': f'lead{i}@smoothmd.com',
            'Source': 'Facebook' if i % 3 == 0 else ('Instagram' if i % 3 == 1 else 'Google'),
            'Inbound': datetime.now() - timedelta(days=i),
            'Overall Status': 'Converted' if i % 4 == 0 else 'Lead',
            'Brand': 'Smooth MD',
            'timestamp': datetime.now() - timedelta(days=i),
            'channel': 'Facebook' if i % 3 == 0 else ('Instagram' if i % 3 == 1 else 'Google')
        })
    
    # Create corresponding transactions for converted leads
    transactions_data = []
    for i in range(0, 20, 4):  # Every 4th lead converted
        transactions_data.append({
            'lead_id': f'lead_{i}',
            'Phone': f'555-{1000+i}',
            'Email': f'lead{i}@smoothmd.com',
            'Amount': 2500 + (i * 100),
            'Service': 'CoolSculpting' if i % 2 == 0 else 'Laser Treatment',
            'Date': datetime.now() - timedelta(days=i-1),
            'revenue_amount': 2500 + (i * 100),
            'channel': 'Facebook' if i % 3 == 0 else ('Instagram' if i % 3 == 1 else 'Google')
        })
    
    return pd.DataFrame(leads_data), pd.DataFrame(transactions_data)

def demo_attribution_analysis():
    """Demonstrate attribution analysis"""
    
    st.header("Attribution Model Comparison")
    
    # Load sample data
    leads_df, transactions_df = load_sample_data()
    
    # Merge for journey building
    merged_df = pd.merge(leads_df, transactions_df, on=['lead_id', 'Phone', 'Email'], how='inner')
    
    if not merged_df.empty:
        st.success(f"Loaded {len(merged_df)} converted leads for attribution analysis")
        
        # Build journeys
        journeys_df = build_journeys(merged_df)
        
        if not journeys_df.empty:
            st.success(f"Built {len(journeys_df)} customer journeys")
            
            # Show sample journeys
            with st.expander("Sample Customer Journeys"):
                for i, journey in journeys_df.head(3).iterrows():
                    st.write(f"**Journey {i+1}:** {' → '.join(journey['channel_sequence'])} → ${journey['revenue_amount']:,.0f}")
            
            # Attribution model selection
            col1, col2 = st.columns(2)
            
            with col1:
                attribution_model = st.selectbox(
                    "Select Attribution Model:",
                    ["first_touch", "last_touch", "linear", "position_based", "time_decay", "markov_chain"],
                    index=0
                )
            
            with col2:
                if attribution_model == "position_based":
                    first_weight = st.slider("First Touch Weight", 0.1, 0.7, 0.4, 0.1)
                    last_weight = st.slider("Last Touch Weight", 0.1, 0.7, 0.4, 0.1)
                elif attribution_model == "time_decay":
                    half_life_days = st.slider("Half-life (days)", 1, 30, 7)
                else:
                    first_weight = 0.4
                    last_weight = 0.4
                    half_life_days = 7
            
            # Apply attribution model
            try:
                if attribution_model == "first_touch":
                    credit_df = AttributionModels.first_touch(journeys_df)
                elif attribution_model == "last_touch":
                    credit_df = AttributionModels.last_touch(journeys_df)
                elif attribution_model == "linear":
                    credit_df = AttributionModels.linear_attribution(journeys_df)
                elif attribution_model == "position_based":
                    credit_df = AttributionModels.position_based(journeys_df, first_weight, last_weight)
                elif attribution_model == "time_decay":
                    credit_df = AttributionModels.time_decay(journeys_df, half_life_days)
                else:  # markov_chain
                    credit_df = AttributionModels.markov_chain_attribution(journeys_df)
                
                if not credit_df.empty:
                    # Sample spend data
                    spend_data = [
                        {'channel': 'meta_facebook', 'spend': 1500.0},
                        {'channel': 'meta_instagram', 'spend': 800.0},
                        {'channel': 'google_ads', 'spend': 1200.0}
                    ]
                    spend_df = pd.DataFrame(spend_data)
                    
                    # Calculate attribution ROAS
                    attribution_results = calculate_attribution_roas(credit_df, journeys_df, spend_df)
                    
                    if not attribution_results.empty:
                        st.subheader("Attribution Results")
                        
                        # Key metrics
                        col1, col2, col3, col4 = st.columns(4)
                        
                        total_attributed = attribution_results['attributed_revenue'].sum()
                        total_spend = attribution_results['spend'].sum()
                        attributed_roas = total_attributed / total_spend if total_spend > 0 else 0
                        
                        with col1:
                            st.metric("Total Attribution Revenue", f"${total_attributed:,.0f}")
                        with col2:
                            st.metric("Attribution ROAS", f"{attributed_roas:.2f}x")
                        with col3:
                            st.metric("Model Used", attribution_model.replace('_', ' ').title())
                        with col4:
                            st.metric("Journeys Analyzed", f"{len(journeys_df)}")
                        
                        # Attribution breakdown
                        st.subheader("Channel Attribution Breakdown")
                        
                        # Display table
                        display_df = attribution_results.copy()
                        display_df['attributed_revenue'] = display_df['attributed_revenue'].apply(lambda x: f"${x:,.0f}")
                        display_df['spend'] = display_df['spend'].apply(lambda x: f"${x:,.0f}")
                        display_df['roas'] = display_df['roas'].apply(lambda x: f"{x:.2f}x" if pd.notna(x) else "N/A")
                        
                        st.dataframe(display_df, use_container_width=True)
                        
                        # Visualization
                        fig = px.bar(
                            attribution_results,
                            x='channel',
                            y='attributed_revenue',
                            title=f"{attribution_model.replace('_', ' ').title()} Attribution Results",
                            labels={'attributed_revenue': 'Attributed Revenue ($)', 'channel': 'Channel'},
                            color='attributed_revenue',
                            color_continuous_scale='Blues'
                        )
                        fig.update_layout(height=400)
                        st.plotly_chart(fig, use_container_width=True)
                        
                        # Credit distribution pie chart
                        credit_summary = credit_df.groupby('channel')['credit_fraction'].sum().reset_index()
                        credit_summary['credit_percentage'] = (credit_summary['credit_fraction'] * 100).round(1)
                        
                        fig_pie = px.pie(
                            credit_summary,
                            values='credit_percentage',
                            names='channel',
                            title=f"{attribution_model.replace('_', ' ').title()} Credit Distribution"
                        )
                        st.plotly_chart(fig_pie, use_container_width=True)
                        
                    else:
                        st.warning("No attribution results generated")
                else:
                    st.warning("No attribution credits generated")
                    
            except Exception as e:
                st.error(f"Attribution analysis failed: {str(e)}")
        else:
            st.warning("No customer journeys could be built")
    else:
        st.warning("No converted leads found for attribution analysis")

def show_attribution_guide():
    """Show attribution model guide"""
    
    with st.expander("Attribution Model Guide"):
        st.markdown("""
        **Attribution Models Explained:**
        
        - **First Touch**: 100% credit to the first interaction
        - **Last Touch**: 100% credit to the final interaction before conversion
        - **Linear**: Equal credit distributed across all touchpoints
        - **Position-Based (U-Shaped)**: Higher weight to first and last touches, remainder split among middle
        - **Time Decay**: More recent touchpoints receive higher credit
        - **Markov Chain**: Data-driven model using transition probabilities
        
        **How to Enable in Main Dashboard:**
        1. Set environment variable: `ENABLE_ATTRIBUTION=true`
        2. Restart the dashboard
        3. Look for the "Revenue Attribution Analysis" section
        """)

def main():
    """Main demo application"""
    
    # Show the demo
    demo_attribution_analysis()
    
    # Show guide
    show_attribution_guide()
    
    st.success("These attribution features are now integrated into your main dashboard!")
    st.info("To activate in your main dashboard, set ENABLE_ATTRIBUTION=true and restart")

if __name__ == "__main__":
    main()