"""
The code is modified to use json.dumps() to encode the time_range parameter for Meta API calls.
"""
import os
import json
import requests
import time
import pandas as pd
from datetime import datetime, timedelta
import streamlit as st

class MetaMarketingAPIConnector:
    """
    Connector for Meta Marketing API that follows best practices

    Reference: https://developers.facebook.com/docs/marketing-api/insights/
    """

    def __init__(self, access_token=None, ad_account_id=None, api_version='v22.0'):
        self.access_token = access_token or os.environ.get("META_ACCESS_TOKEN", "")
        self.ad_account_id = ad_account_id or os.environ.get("META_AD_ACCOUNT_ID", "")
        self.api_version = api_version
        self.base_url = "https://graph.facebook.com"

        # Add act_ prefix if missing
        if self.ad_account_id and not self.ad_account_id.startswith('act_'):
            self.ad_account_id = f"act_{self.ad_account_id}"

    def get_campaigns(self, limit=50, fields=None):
        """
        Get campaigns from the Meta Marketing API

        Args:
            limit (int): Number of results per page
            fields (list): List of fields to retrieve

        Returns:
            list: Campaign data
        """
        if not self.access_token or not self.ad_account_id:
            return []

        if fields is None:
            fields = [
                "id", 
                "name", 
                "status", 
                "objective", 
                "daily_budget", 
                "lifetime_budget", 
                "start_time", 
                "stop_time", 
                "created_time", 
                "effective_status"
            ]

        url = f"{self.base_url}/{self.api_version}/{self.ad_account_id}/campaigns"
        params = {
            "access_token": self.access_token,
            "fields": ",".join(fields),
            "limit": limit
        }

        all_campaigns = []

        try:
            while url:
                st.info(f"Fetching campaigns from Meta Marketing API...")
                response = requests.get(url, params=params)

                # Rate limit handling
                if response.status_code == 429:
                    st.warning("Meta API rate limit reached. Waiting 60 seconds...")
                    time.sleep(60)
                    continue

                if response.status_code != 200:
                    error_msg = f"Meta API Error: {response.status_code}"
                    try:
                        error_data = response.json()
                        if "error" in error_data:
                            error_msg = f"{error_msg} - {error_data['error'].get('message', '')}"
                    except:
                        pass
                    st.error(error_msg)
                    break

                result = response.json()

                if "data" in result:
                    st.success(f"Retrieved {len(result['data'])} campaigns")
                    all_campaigns.extend(result["data"])

                # Handle pagination
                url = None
                if "paging" in result and "next" in result["paging"]:
                    url = result["paging"]["next"]
                    params = {}  # Params are included in the next URL

        except Exception as e:
            st.error(f"Error retrieving campaigns: {str(e)}")

        return all_campaigns

    def get_insights(self, level="campaign", fields=None, date_preset="last_90d", limit=50, since=None, until=None):
        """
        Get insights from the Meta Marketing API

        Args:
            level (str): Insights level (campaign, adset, ad)
            fields (list): List of fields to retrieve
            date_preset (str): Date preset (today, yesterday, last_3d, last_7d, last_14d, last_28d, last_30d, last_90d, last_quarter, last_year)
            limit (int): Number of results per page

        Returns:
            list: Insights data
        """
        if not self.access_token or not self.ad_account_id:
            return []

        if fields is None:
            fields = [
                "campaign_id",
                "campaign_name",
                "spend",
                "impressions",
                "clicks",
                "reach",
                "frequency",
                "cpm",
                "cpc",
                "ctr",
                "inline_link_clicks",
                "cost_per_inline_link_click",
                "unique_clicks",
                "cost_per_unique_click",
                "account_currency"
            ]

        url = f"{self.base_url}/{self.api_version}/{self.ad_account_id}/insights"

        # Use time_range if since and until are provided, otherwise use date_preset
        if since and until:
            time_range = json.dumps({"since": since, "until": until})
            params = {
                "access_token": self.access_token,
                "fields": ",".join(fields),
                "level": level,
                "limit": limit,
                "time_range": time_range
            }
        else:
            # Set parameters with filters specifically for Smooth MD if needed
            params = {
                "access_token": self.access_token,
                "fields": ",".join(fields),
                "level": level,
                "date_preset": date_preset,
                "limit": limit
            }

        all_insights = []

        try:
            while url:
                st.info(f"Fetching insights from Meta Marketing API...")
                response = requests.get(url, params=params)

                # Rate limit handling
                if response.status_code == 429:
                    st.warning("Meta API rate limit reached. Waiting 60 seconds...")
                    time.sleep(60)
                    continue

                if response.status_code != 200:
                    error_msg = f"Meta API Error: {response.status_code}"
                    try:
                        error_data = response.json()
                        if "error" in error_data:
                            error_msg = f"{error_msg} - {error_data['error'].get('message', '')}"
                    except:
                        pass
                    st.error(error_msg)
                    break

                result = response.json()

                if "data" in result:
                    st.success(f"Retrieved insights for {len(result['data'])} items")
                    all_insights.extend(result["data"])

                # Handle pagination
                url = None
                if "paging" in result and "next" in result["paging"]:
                    url = result["paging"]["next"]
                    params = {}  # Params are included in the next URL

        except Exception as e:
            st.error(f"Error retrieving insights: {str(e)}")

        return all_insights

    def get_ad_account_info(self):
        """
        Get information about the ad account

        Returns:
            dict: Ad account information
        """
        if not self.access_token or not self.ad_account_id:
            return {}

        url = f"{self.base_url}/{self.api_version}/{self.ad_account_id}"
        params = {
            "access_token": self.access_token,
            "fields": "id,name,account_status,currency,timezone_name,business_country_code,funding_source_details"
        }

        try:
            response = requests.get(url, params=params)

            if response.status_code != 200:
                st.error(f"Meta API Error: {response.status_code}")
                return {}

            return response.json()

        except Exception as e:
            st.error(f"Error retrieving ad account info: {str(e)}")
            return {}

    def get_lead_forms(self, limit=50):
        """
        Get lead forms from the Meta Marketing API

        Args:
            limit (int): Number of results per page

        Returns:
            list: Lead form data
        """
        if not self.access_token or not self.ad_account_id:
            return []

        url = f"{self.base_url}/{self.api_version}/{self.ad_account_id}/leadgen_forms"
        params = {
            "access_token": self.access_token,
            "fields": "id,name,status,created_time,questions,leads_count",
            "limit": limit
        }

        all_forms = []

        try:
            while url:
                response = requests.get(url, params=params)

                # Rate limit handling
                if response.status_code == 429:
                    time.sleep(60)
                    continue

                if response.status_code != 200:
                    st.error(f"Meta API Error: {response.status_code}")
                    break

                result = response.json()

                if "data" in result:
                    all_forms.extend(result["data"])

                # Handle pagination
                url = None
                if "paging" in result and "next" in result["paging"]:
                    url = result["paging"]["next"]
                    params = {}  # Params are included in the next URL

        except Exception as e:
            st.error(f"Error retrieving lead forms: {str(e)}")

        return all_forms

# Function to get campaign data from Meta API
def get_meta_campaign_data(access_token=None, ad_account_id=None):
    """
    Get campaign data from Meta Marketing API using best practices

    Args:
        access_token (str): Meta access token
        ad_account_id (str): Meta ad account ID

    Returns:
        tuple: (campaigns, insights, account_info)
    """
    # Create connector
    connector = MetaMarketingAPIConnector(access_token, ad_account_id)

    # Get account info
    account_info = connector.get_ad_account_info()

    # Get campaigns
    campaigns = connector.get_campaigns()

    # Get insights
    insights = connector.get_insights()

    return campaigns, insights, account_info

# Function to process Meta campaign data
def process_meta_campaign_data(campaigns, insights, leads_df=None):
    """
    Process Meta campaign data to create a unified dataset

    Args:
        campaigns (list): Campaign data from Meta API
        insights (list): Insights data from Meta API
        leads_df (pd.DataFrame): Leads data from Airtable

    Returns:
        pd.DataFrame: Processed campaign data
    """
    if not campaigns or not insights:
        return pd.DataFrame()

    # Create campaign mapping (id to name)
    campaign_map = {c.get("id"): c.get("name") for c in campaigns if "id" in c and "name" in c}

    # Create insights dictionary
    campaign_insights = {}

    # Process insights
    for insight in insights:
        if "campaign_id" in insight:
            campaign_id = insight["campaign_id"]

            if campaign_id not in campaign_insights:
                campaign_name = insight.get("campaign_name", campaign_map.get(campaign_id, "Unknown"))

                campaign_insights[campaign_id] = {
                    "campaign_id": campaign_id,
                    "campaign_name": campaign_name,
                    "spend": 0.0,
                    "impressions": 0,
                    "clicks": 0,
                    "reach": 0,
                    "ctr": 0.0,
                    "cpc": 0.0,
                    "cpm": 0.0,
                    "frequency": 0.0,
                    "inline_link_clicks": 0,
                    "unique_clicks": 0,
                    "currency": insight.get("account_currency", "USD")
                }

            # Add values with proper type conversion
            if "spend" in insight:
                campaign_insights[campaign_id]["spend"] += float(insight["spend"])

            if "impressions" in insight:
                campaign_insights[campaign_id]["impressions"] += int(insight["impressions"])

            if "clicks" in insight:
                campaign_insights[campaign_id]["clicks"] += int(insight["clicks"])

            if "reach" in insight:
                campaign_insights[campaign_id]["reach"] += int(insight["reach"])

            if "ctr" in insight:
                campaign_insights[campaign_id]["ctr"] = float(insight["ctr"]) * 100  # Convert to percentage

            if "cpc" in insight:
                campaign_insights[campaign_id]["cpc"] = float(insight["cpc"])

            if "cpm" in insight:
                campaign_insights[campaign_id]["cpm"] = float(insight["cpm"])

            if "frequency" in insight:
                campaign_insights[campaign_id]["frequency"] = float(insight["frequency"])

            if "inline_link_clicks" in insight:
                campaign_insights[campaign_id]["inline_link_clicks"] += int(insight["inline_link_clicks"])

            if "unique_clicks" in insight:
                campaign_insights[campaign_id]["unique_clicks"] += int(insight["unique_clicks"])

    # Process lead attribution
    campaign_data = []

    for campaign_id, data in campaign_insights.items():
        campaign_name = data["campaign_name"]

        # Match leads to campaign by source
        matched_leads = 0
        if leads_df is not None and not leads_df.empty and "Source" in leads_df.columns:
            campaign_name_lower = campaign_name.lower()
            matched_leads = leads_df[leads_df["Source"].str.lower().str.contains(campaign_name_lower, na=False)].shape[0]

        # Calculate lead metrics
        leads = max(matched_leads, 1)  # Avoid division by zero
        cpl = data["spend"] / leads if leads > 0 else 0

        # Calculate conversion metrics
        converted_leads = 0
        if leads_df is not None and not leads_df.empty and "is_converted" in leads_df.columns:
            if matched_leads > 0:
                # Filter to leads that match this campaign
                campaign_leads = leads_df[leads_df["Source"].str.lower().str.contains(campaign_name.lower(), na=False)]
                converted_leads = campaign_leads["is_converted"].sum()
            else:
                # Use overall conversion rate for estimation
                conversion_rate = leads_df["is_converted"].sum() / len(leads_df) if len(leads_df) > 0 else 0.15
                converted_leads = leads * conversion_rate

        # Calculate ROAS
        avg_transaction_value = 2500
        estimated_revenue = converted_leads * avg_transaction_value
        roas = estimated_revenue / data["spend"] if data["spend"] > 0 else 0

        # Build complete record
        record = {
            "Campaign": campaign_name,
            "Campaign ID": campaign_id,
            "Spend": data["spend"],
            "Impressions": data["impressions"],
            "Clicks": data["clicks"],
            "Reach": data["reach"],
            "CTR": data["ctr"],
            "CPC": data["cpc"],
            "CPM": data["cpm"],
            "Frequency": data["frequency"],
            "Link Clicks": data["inline_link_clicks"],
            "Unique Clicks": data["unique_clicks"],
            "Leads": leads,
            "CPL": cpl,
            "Conversions": converted_leads,
            "Revenue": estimated_revenue,
            "ROAS": roas,
            "Currency": data["currency"]
        }

        campaign_data.append(record)

    # Create DataFrame
    if campaign_data:
        return pd.DataFrame(campaign_data)
    else:
        return pd.DataFrame()