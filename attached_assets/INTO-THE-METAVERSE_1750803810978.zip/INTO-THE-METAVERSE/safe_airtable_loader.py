"""
Ultra-Safe Airtable Data Loader
Handles all complex data types and serialization issues
"""
import streamlit as st
import pandas as pd
import numpy as np
from pyairtable import Api
import json

def safe_clean_value(x):
    """Ultra-safe value cleaning that handles any data type"""
    try:
        if x is None or pd.isna(x):
            return ''
        elif isinstance(x, (dict, list)):
            # Convert complex types to JSON strings, but handle problematic objects
            try:
                return json.dumps(x) if x else ''
            except:
                return str(x) if x else ''
        elif isinstance(x, (int, float)):
            # Handle any numeric issues
            if pd.isna(x):
                return ''
            return str(x)
        else:
            # Force everything else to string and handle any encoding issues
            result = str(x)
            # Remove any problematic characters that might cause Arrow issues
            return result.replace('\x00', '').strip()
    except:
        try:
            return str(x) if x is not None else ''
        except:
            return ''

def load_smooth_md_leads_safe(api_key, base_id='appri2CgCoIiuZWq3', table_name='Leads'):
    """
    Ultra-safe loading of Smooth MD leads from Meta sources
    """
    try:
        st.info(f"🔄 Connecting to Airtable: {base_id} - {table_name}")
        
        api = Api(api_key)
        table = api.table(base_id, table_name)
        
        # Get all records
        records = table.all()
        st.info(f"📊 Retrieved {len(records)} total records")
        
        # Convert to clean data
        data = []
        for record in records:
            clean_record = {'airtable_record_id': record['id']}
            
            # Clean all fields
            for field, value in record['fields'].items():
                clean_record[field] = safe_clean_value(value)
            
            data.append(clean_record)
        
        df = pd.DataFrame(data)
        
        # Ensure all columns are properly formatted for Arrow compatibility
        for col in df.columns:
            # Convert to string first, then handle any remaining complex objects
            df[col] = df[col].astype(str)
            # Replace any problematic values that might cause Arrow issues
            df[col] = df[col].replace(['nan', 'None', 'null'], '')
            # Ensure no mixed types by forcing everything to be consistent strings
            df[col] = df[col].fillna('').astype(str)
        
        # First filter for Smooth MD only
        brand_col = 'flddGiLa7lQ0nodBz'  # Brand field
        if brand_col in df.columns:
            smooth_mask = df[brand_col].str.contains('Smooth', case=False, na=False)
            df = df[smooth_mask]
            st.info(f"🏢 After Brand filter: {len(df)} Smooth MD records")
        
        # Then filter for Meta sources (should be ~652 leads)
        source_col = 'fldBUfZjdVhhJpRRA'  # Contact Source
        if source_col in df.columns:
            # More comprehensive Meta source detection
            meta_mask = df[source_col].str.contains('Facebook|Instagram|Meta|FB|IG', case=False, na=False)
            df = df[meta_mask]
            st.success(f"📱 Found {len(df)} authentic Smooth MD Meta leads (expecting ~652)")
        
        if len(df) == 0:
            st.error("❌ No Meta leads found! Checking available source values...")
            if source_col in pd.DataFrame(data).columns:
                unique_sources = pd.DataFrame(data)[source_col].value_counts().head(10)
                st.write("Top contact sources in your data:", unique_sources)
        
        # Add calculated columns
        consult_status_col = 'fldqLu3ORdmQyGYHw'  # Consult Status
        overall_status_col = 'fld8g4VRmZj7hAUrM'   # Overall Status
        
        if consult_status_col in df.columns:
            df['is_booked'] = df[consult_status_col].str.contains('Scheduled|Arrived', case=False, na=False)
        else:
            df['is_booked'] = False
            
        if overall_status_col in df.columns:
            df['is_converted'] = df[overall_status_col].str.contains('Closed|Deposit Paid|Installment Plan', case=False, na=False)
        else:
            df['is_converted'] = False
        
        # Add transaction_amount column for compatibility
        df['transaction_amount'] = '0.0'
        
        st.success(f"✅ Successfully loaded {len(df)} Smooth MD leads from Meta sources")
        return df
        
    except Exception as e:
        st.error(f"❌ Error loading leads data: {str(e)}")
        return pd.DataFrame()

def load_transactions_safe(api_key, base_id='appri2CgCoIiuZWq3', table_name='Transactions'):
    """
    Ultra-safe loading of transactions data
    """
    try:
        st.info(f"🔄 Connecting to Airtable: {base_id} - {table_name}")
        
        api = Api(api_key)
        table = api.table(base_id, table_name)
        
        # Get all records
        records = table.all()
        st.info(f"💰 Retrieved {len(records)} transaction records")
        
        # Convert to clean data
        data = []
        for record in records:
            clean_record = {'airtable_record_id': record['id']}
            
            # Clean all fields
            for field, value in record['fields'].items():
                clean_record[field] = safe_clean_value(value)
            
            data.append(clean_record)
        
        df = pd.DataFrame(data)
        
        # Ensure all columns are properly formatted for Arrow compatibility
        for col in df.columns:
            # Convert to string first, then handle any remaining complex objects
            df[col] = df[col].astype(str)
            # Replace any problematic values that might cause Arrow issues
            df[col] = df[col].replace(['nan', 'None', 'null'], '')
            # Ensure no mixed types by forcing everything to be consistent strings
            df[col] = df[col].fillna('').astype(str)
        
        # Convert amount field to numeric
        amount_col = 'fldUIvamoBDCIayd3'  # Amount field
        if amount_col in df.columns:
            # Clean and convert to numeric
            df[amount_col] = df[amount_col].str.replace(',', '').str.replace('$', '').str.replace('nan', '0')
            df[amount_col] = pd.to_numeric(df[amount_col], errors='coerce').fillna(0)
        
        st.success(f"✅ Successfully loaded {len(df)} transaction records")
        return df
        
    except Exception as e:
        st.error(f"❌ Error loading transactions data: {str(e)}")
        return pd.DataFrame()

def match_leads_with_transactions(leads_df, transactions_df):
    """
    Match the 652 Meta leads with their corresponding transactions using email/phone
    """
    if leads_df.empty or transactions_df.empty:
        return leads_df, 0, 0
    
    # Email and phone field mappings
    lead_email_col = 'fldAnzFEtflKfcrcB'  # Email field in leads
    lead_phone_col = 'fld8xTYVdZPis6HDZ'  # Phone field in leads
    
    # Find matching columns in transactions (you may need to adjust these)
    transaction_email_cols = [col for col in transactions_df.columns if 'email' in col.lower() or 'mail' in col.lower()]
    transaction_phone_cols = [col for col in transactions_df.columns if 'phone' in col.lower() or 'mobile' in col.lower()]
    
    matched_leads = []
    total_matched_revenue = 0
    leads_with_revenue = 0
    
    for idx, lead in leads_df.iterrows():
        lead_email = str(lead.get(lead_email_col, '')).strip().lower()
        lead_phone = str(lead.get(lead_phone_col, '')).strip()
        
        # Try to find matching transactions
        matched_transactions = pd.DataFrame()
        
        # Match by email first
        if lead_email and lead_email != '' and transaction_email_cols:
            for email_col in transaction_email_cols:
                email_matches = transactions_df[
                    transactions_df[email_col].str.lower().str.strip() == lead_email
                ]
                matched_transactions = pd.concat([matched_transactions, email_matches])
        
        # Match by phone if no email match
        if matched_transactions.empty and lead_phone and lead_phone != '' and transaction_phone_cols:
            for phone_col in transaction_phone_cols:
                phone_matches = transactions_df[
                    transactions_df[phone_col].str.strip() == lead_phone
                ]
                matched_transactions = pd.concat([matched_transactions, phone_matches])
        
        # Calculate revenue for this lead
        lead_revenue = 0
        if not matched_transactions.empty:
            amount_col = 'fldUIvamoBDCIayd3'
            if amount_col in matched_transactions.columns:
                lead_revenue = matched_transactions[amount_col].sum()
                if lead_revenue > 0:
                    leads_with_revenue += 1
                    total_matched_revenue += lead_revenue
        
        # Add revenue info to lead
        lead_copy = lead.copy()
        lead_copy['matched_revenue'] = lead_revenue
        lead_copy['has_transaction'] = not matched_transactions.empty
        matched_leads.append(lead_copy)
    
    matched_leads_df = pd.DataFrame(matched_leads)
    return matched_leads_df, total_matched_revenue, leads_with_revenue

def calculate_safe_roas_metrics(leads_df, transactions_df, meta_spend):
    """
    Calculate ROAS metrics using properly matched lead-transaction data
    """
    if leads_df.empty:
        return {
            'total_leads': 0,
            'booked_leads': 0,
            'converted_leads': 0,
            'leads_with_revenue': 0,
            'total_revenue': 0,
            'roas': 0,
            'cost_per_lead': 0,
            'cost_per_conversion': 0,
            'conversion_rate': 0,
            'booking_rate': 0,
            'avg_revenue_per_conversion': 0
        }
    
    # Match leads with transactions to get accurate revenue
    matched_leads_df, total_revenue, leads_with_revenue = match_leads_with_transactions(leads_df, transactions_df)
    
    # Calculate lead metrics
    total_leads = len(matched_leads_df)
    booked_leads = matched_leads_df['is_booked'].sum() if 'is_booked' in matched_leads_df.columns else 0
    converted_leads = matched_leads_df['is_converted'].sum() if 'is_converted' in matched_leads_df.columns else 0
    
    # Calculate ROAS and other metrics
    roas = total_revenue / meta_spend if meta_spend > 0 else 0
    avg_revenue_per_conversion = total_revenue / converted_leads if converted_leads > 0 else 0
    
    # Calculate revenue per lead
    revenue_per_lead = total_revenue / total_leads if total_leads > 0 else 0
    
    return {
        'total_leads': int(total_leads),
        'booked_leads': int(booked_leads),
        'converted_leads': int(converted_leads),
        'leads_with_revenue': int(leads_with_revenue),
        'total_revenue': float(total_revenue),
        'revenue_per_lead': float(revenue_per_lead),
        'roas': float(roas),
        'cost_per_lead': float(meta_spend / total_leads) if total_leads > 0 else 0,
        'cost_per_conversion': float(meta_spend / converted_leads) if converted_leads > 0 else 0,
        'conversion_rate': float(converted_leads / total_leads * 100) if total_leads > 0 else 0,
        'booking_rate': float(booked_leads / total_leads * 100) if total_leads > 0 else 0,
        'avg_revenue_per_conversion': float(avg_revenue_per_conversion)
    }