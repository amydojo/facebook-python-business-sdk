#!/usr/bin/env python3
"""
Debug Lead-Transaction Matching Logic
"""

from pyairtable import Api

API_KEY = 'patRpwfhYlGferLE8.17a89cf5c31e4ef29041a67a4b28ca4058bb443779beb0dd4352ad999b186cdd'
BASE_ID = 'appH4MePHS6qLsk5z'

def debug_matching():
    """Debug the exact matching mechanism"""
    print("Debugging Lead-Transaction Matching")
    print("=" * 40)
    
    api = Api(API_KEY)
    base = api.base(BASE_ID)
    
    # Get 10 leads and 10 transactions for detailed analysis
    leads_table = base.table('Leads')
    sample_leads = leads_table.all(max_records=10)
    
    tx_table = base.table('Transactions')
    sample_transactions = tx_table.all(max_records=10)
    
    print("SAMPLE LEAD ANALYSIS:")
    print("-" * 30)
    for i, record in enumerate(sample_leads[:3]):
        print(f"\nLead {i+1}:")
        print(f"  Record ID: {record['id']}")
        fields = record['fields']
        print(f"  Lead ID: {fields.get('ID', 'N/A')}")
        print(f"  Brand: {fields.get('Brand', 'N/A')}")
        print(f"  Contact Source: {fields.get('Contact Source', 'N/A')}")
        print(f"  Email: {fields.get('Email', 'N/A')}")
    
    print("\n\nSAMPLE TRANSACTION ANALYSIS:")
    print("-" * 30)
    for i, record in enumerate(sample_transactions[:3]):
        print(f"\nTransaction {i+1}:")
        print(f"  Record ID: {record['id']}")
        fields = record['fields']
        print(f"  Patient: {fields.get('Patient', 'N/A')}")
        print(f"  Amount: {fields.get('Amount', 'N/A')}")
        print(f"  ID field: {fields.get('ID', 'N/A')}")
        print(f"  ID type: {type(fields.get('ID', 'N/A'))}")
        print(f"  Brand (from ID): {fields.get('Brand (from ID)', 'N/A')}")
        print(f"  Email: {fields.get('Email', 'N/A')}")
        print(f"  Phone number: {fields.get('Phone number', 'N/A')}")
    
    # Examine relationship between lead record IDs and transaction ID fields
    print("\n\nMATCHING ANALYSIS:")
    print("-" * 30)
    
    lead_record_ids = [record['id'] for record in sample_leads]
    print(f"Lead record IDs: {lead_record_ids[:3]}...")
    
    for i, tx_record in enumerate(sample_transactions[:5]):
        tx_id_field = tx_record['fields'].get('ID', [])
        print(f"\nTransaction {i+1} ID field: {tx_id_field}")
        print(f"  Type: {type(tx_id_field)}")
        
        if isinstance(tx_id_field, list) and tx_id_field:
            for linked_id in tx_id_field:
                print(f"  Linked ID: {linked_id}")
                if linked_id in lead_record_ids:
                    print(f"    ✅ MATCH FOUND with lead!")
                else:
                    print(f"    ❌ No match in sample leads")
    
    # Try alternative matching strategies
    print("\n\nALTERNATIVE MATCHING STRATEGIES:")
    print("-" * 30)
    
    # Strategy 1: Email matching
    lead_emails = {}
    for record in sample_leads:
        email = record['fields'].get('Email', '')
        if email:
            lead_emails[email.lower()] = record['id']
    
    print(f"Lead emails: {list(lead_emails.keys())[:3]}...")
    
    email_matches = 0
    for tx_record in sample_transactions:
        tx_emails = tx_record['fields'].get('Email', [])
        if isinstance(tx_emails, list):
            for tx_email in tx_emails:
                if tx_email and tx_email.lower() in lead_emails:
                    email_matches += 1
                    print(f"✅ Email match: {tx_email}")
    
    print(f"Email matches found: {email_matches}")
    
    # Strategy 2: Phone matching
    lead_phones = {}
    for record in sample_leads:
        phone = record['fields'].get('Phone', '')
        if phone:
            # Normalize phone number
            clean_phone = ''.join(filter(str.isdigit, phone))
            if len(clean_phone) >= 10:
                lead_phones[clean_phone[-10:]] = record['id']  # Last 10 digits
    
    print(f"Lead phones: {list(lead_phones.keys())[:3]}...")
    
    phone_matches = 0
    for tx_record in sample_transactions:
        tx_phones = tx_record['fields'].get('Phone number', [])
        if isinstance(tx_phones, list):
            for tx_phone in tx_phones:
                if tx_phone:
                    clean_tx_phone = ''.join(filter(str.isdigit, str(tx_phone)))
                    if len(clean_tx_phone) >= 10:
                        tx_phone_key = clean_tx_phone[-10:]
                        if tx_phone_key in lead_phones:
                            phone_matches += 1
                            print(f"✅ Phone match: {tx_phone}")
    
    print(f"Phone matches found: {phone_matches}")
    
    return {
        'total_leads': len(sample_leads),
        'total_transactions': len(sample_transactions),
        'email_matches': email_matches,
        'phone_matches': phone_matches
    }

if __name__ == "__main__":
    results = debug_matching()
    
    print(f"\n\nDEBUG SUMMARY:")
    print(f"Total sample leads: {results['total_leads']}")
    print(f"Total sample transactions: {results['total_transactions']}")
    print(f"Email matches: {results['email_matches']}")
    print(f"Phone matches: {results['phone_matches']}")
    
    if results['email_matches'] > 0 or results['phone_matches'] > 0:
        print("\n✅ Alternative matching strategies work - updating dashboard logic")
    else:
        print("\n❌ Need to investigate further - no matches found with any strategy")