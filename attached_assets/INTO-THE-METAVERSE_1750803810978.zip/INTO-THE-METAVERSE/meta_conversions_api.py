"""
Meta Conversions API Implementation

This module implements best practices for Meta Conversions API including:
- Sending both pixel and server events
- Using deduplication parameters
- Real-time event transmission
- Value optimization
- Proper user data hashing
"""

import os
import hashlib
import json
import time
import uuid
import requests
from datetime import datetime, timezone

class MetaConversionsAPI:
    """
    Implementation of Meta Conversions API following best practices from Meta documentation
    """
    
    def __init__(self, access_token=None, pixel_id=None):
        """Initialize with Meta credentials"""
        self.access_token = access_token or os.environ.get("META_ACCESS_TOKEN")
        self.pixel_id = pixel_id or os.environ.get("META_PIXEL_ID")
        
        # API version and endpoint
        self.api_version = "v22.0"
        self.endpoint = f"https://graph.facebook.com/{self.api_version}/{self.pixel_id}/events"
        
        # Debug mode for testing
        self.debug_mode = False
        
        # For tracking API rate limits
        self.rate_limit_remaining = 200  # Default assumption
        self.rate_limit_reset_time = None
    
    def normalize_and_hash(self, data):
        """
        Normalize and hash user data following Meta's requirements
        
        Args:
            data (str): The data to normalize and hash
            
        Returns:
            str: Normalized and hashed data in SHA256
        """
        if not data:
            return None
        
        # Convert to string if not already
        data = str(data)
        
        # Normalize by removing whitespace and converting to lowercase
        normalized = data.strip().lower()
        
        # Hash using SHA256
        hashed = hashlib.sha256(normalized.encode()).hexdigest()
        
        return hashed
    
    def prepare_user_data(self, user_data):
        """
        Prepare user data for the Conversions API
        
        Args:
            user_data (dict): User data like email, phone, name, etc.
            
        Returns:
            dict: Prepared user data object following Meta requirements
        """
        prepared_data = {}
        
        # Process email if provided
        if 'email' in user_data and user_data['email']:
            prepared_data['em'] = self.normalize_and_hash(user_data['email'])
        
        # Process phone if provided
        if 'phone' in user_data and user_data['phone']:
            # Remove all non-numeric characters
            phone = ''.join(filter(str.isdigit, str(user_data['phone'])))
            prepared_data['ph'] = self.normalize_and_hash(phone)
        
        # Process name if provided
        if 'first_name' in user_data and 'last_name' in user_data:
            if user_data['first_name'] and user_data['last_name']:
                # Format: lowercase first name + space + lowercase last name
                name = f"{user_data['first_name'].lower()} {user_data['last_name'].lower()}"
                prepared_data['fn'] = self.normalize_and_hash(user_data['first_name'])
                prepared_data['ln'] = self.normalize_and_hash(user_data['last_name'])
                prepared_data['db'] = self.normalize_and_hash(name)
        
        # Process external ID if provided
        if 'external_id' in user_data and user_data['external_id']:
            prepared_data['external_id'] = self.normalize_and_hash(user_data['external_id'])
        
        # Set client IP if provided
        if 'client_ip_address' in user_data and user_data['client_ip_address']:
            prepared_data['client_ip_address'] = user_data['client_ip_address']
        
        # Set client user agent if provided
        if 'client_user_agent' in user_data and user_data['client_user_agent']:
            prepared_data['client_user_agent'] = user_data['client_user_agent']
        
        # Set advanced matching parameters
        if 'city' in user_data and user_data['city']:
            prepared_data['ct'] = self.normalize_and_hash(user_data['city'])
            
        if 'state' in user_data and user_data['state']:
            prepared_data['st'] = self.normalize_and_hash(user_data['state'])
            
        if 'zip' in user_data and user_data['zip']:
            prepared_data['zp'] = self.normalize_and_hash(user_data['zip'])
            
        if 'country' in user_data and user_data['country']:
            prepared_data['country'] = self.normalize_and_hash(user_data['country'])
        
        return prepared_data
    
    def get_event_id(self, event_name, user_data):
        """
        Generate a consistent event ID for deduplication
        
        Args:
            event_name (str): Name of the event
            user_data (dict): User data for the event
            
        Returns:
            str: UUID v5 event ID
        """
        # Use a namespace based on pixel ID
        namespace = uuid.uuid5(uuid.NAMESPACE_DNS, f"meta.pixel.{self.pixel_id}")
        
        # Construct a string using event details
        if isinstance(user_data, dict):
            user_string = json.dumps(user_data, sort_keys=True)
        else:
            user_string = str(user_data)
        
        # Include timestamp to the minute for idempotency within a time window
        timestamp = datetime.now().strftime("%Y%m%d%H%M")
        
        # Generate deterministic ID
        id_string = f"{event_name}:{user_string}:{timestamp}"
        event_id = str(uuid.uuid5(namespace, id_string))
        
        return event_id
    
    def send_conversion_event(self, event_name, user_data, event_time=None, 
                              custom_data=None, event_source_url=None, 
                              action_source="website"):
        """
        Send a conversion event to Meta Conversions API
        
        Args:
            event_name (str): Standard event name (e.g., "Lead", "Purchase")
            user_data (dict): User data for identity matching
            event_time (int, optional): Unix timestamp of event
            custom_data (dict, optional): Custom event data
            event_source_url (str, optional): URL where event occurred
            action_source (str): Source of the event
            
        Returns:
            tuple: (success (bool), response (dict), error_message (str))
        """
        if not self.access_token or not self.pixel_id:
            return False, None, "Missing access token or pixel ID"
        
        # Generate or use provided event time
        if not event_time:
            event_time = int(datetime.now(timezone.utc).timestamp())
        
        # Generate a deterministic event ID for deduplication
        event_id = self.get_event_id(event_name, user_data)
        
        # Prepare user data following Meta requirements
        prepared_user_data = self.prepare_user_data(user_data)
        
        # Prepare the event data
        event_data = {
            "event_name": event_name,
            "event_time": event_time,
            "event_id": event_id,
            "user_data": prepared_user_data,
            "action_source": action_source
        }
        
        # Add custom data if provided
        if custom_data:
            # Ensure value is included for optimization
            if 'value' in custom_data:
                # Convert to proper format if needed
                custom_data['value'] = float(custom_data['value'])
            
            # Add currency for optimization
            if 'currency' not in custom_data and 'value' in custom_data:
                custom_data['currency'] = "USD"  # Default to USD if not specified
            
            event_data["custom_data"] = custom_data
        
        # Add event source URL if provided
        if event_source_url:
            event_data["event_source_url"] = event_source_url
        
        # Prepare the API request payload
        payload = {
            "data": [event_data],
            "access_token": self.access_token,
            "test_event_code": "TEST12345" if self.debug_mode else None
        }
        
        # Remove None values from payload
        payload = {k: v for k, v in payload.items() if v is not None}
        
        # Check rate limits before sending
        if self.rate_limit_reset_time and time.time() < self.rate_limit_reset_time:
            wait_time = self.rate_limit_reset_time - time.time()
            print(f"Rate limit reached. Waiting {wait_time:.2f} seconds.")
            time.sleep(wait_time)
        
        # Make the API request
        try:
            response = requests.post(self.endpoint, json=payload)
            response_data = response.json()
            
            # Check for rate limit headers
            if 'x-business-use-case-usage' in response.headers:
                usage_data = json.loads(response.headers['x-business-use-case-usage'])
                if self.pixel_id in usage_data:
                    pixel_usage = usage_data[self.pixel_id][0]
                    self.rate_limit_remaining = pixel_usage.get('call_count', 200)
                    if 'estimated_time_to_regain_access' in pixel_usage:
                        reset_seconds = pixel_usage['estimated_time_to_regain_access']
                        self.rate_limit_reset_time = time.time() + reset_seconds
            
            # Check if the request was successful
            if response.status_code == 200:
                return True, response_data, None
            else:
                error_message = f"Error: {response.status_code} - {response_data}"
                return False, response_data, error_message
                
        except Exception as e:
            error_message = f"Exception sending event: {str(e)}"
            return False, None, error_message
    
    def send_lead_event(self, lead_data, event_source_url=None):
        """
        Send a Lead event to Meta Conversions API
        
        Args:
            lead_data (dict): Lead information including user data and custom data
            event_source_url (str, optional): URL where the lead was generated
            
        Returns:
            tuple: (success (bool), response (dict), error_message (str))
        """
        # Extract user data
        user_data = {
            'email': lead_data.get('email'),
            'phone': lead_data.get('phone'),
            'first_name': lead_data.get('first_name'),
            'last_name': lead_data.get('last_name'),
            'external_id': lead_data.get('id') or lead_data.get('lead_id')
        }
        
        # Prepare custom data
        custom_data = {
            'content_name': lead_data.get('source') or 'Website Form',
            'content_category': lead_data.get('service') or 'Lead',
            'lead_id': lead_data.get('id') or lead_data.get('lead_id'),
            'status': lead_data.get('status')
        }
        
        # Add value if available
        if 'value' in lead_data:
            custom_data['value'] = float(lead_data['value'])
            custom_data['currency'] = lead_data.get('currency', 'USD')
        else:
            # Default lead value for optimization
            custom_data['value'] = 50.0
            custom_data['currency'] = 'USD'
        
        # Send the event
        return self.send_conversion_event(
            event_name="Lead",
            user_data=user_data,
            custom_data=custom_data,
            event_source_url=event_source_url
        )
    
    def send_consultation_booked_event(self, booking_data, event_source_url=None):
        """
        Send a custom ConsultationBooked event to Meta Conversions API
        
        Args:
            booking_data (dict): Booking information including user data and custom data
            event_source_url (str, optional): URL where the booking occurred
            
        Returns:
            tuple: (success (bool), response (dict), error_message (str))
        """
        # Extract user data
        user_data = {
            'email': booking_data.get('email'),
            'phone': booking_data.get('phone'),
            'first_name': booking_data.get('first_name'),
            'last_name': booking_data.get('last_name'),
            'external_id': booking_data.get('id') or booking_data.get('lead_id')
        }
        
        # Prepare custom data
        custom_data = {
            'content_name': 'Consultation Booking',
            'content_category': booking_data.get('service') or 'Booking',
            'lead_id': booking_data.get('id') or booking_data.get('lead_id'),
            'appointment_date': booking_data.get('appointment_date'),
            'location': booking_data.get('location')
        }
        
        # Add value if available, otherwise use default
        if 'value' in booking_data:
            custom_data['value'] = float(booking_data['value'])
            custom_data['currency'] = booking_data.get('currency', 'USD')
        else:
            # Default booking value for optimization (higher than lead)
            custom_data['value'] = 150.0
            custom_data['currency'] = 'USD'
        
        # Send the event as a custom event (ScheduleAppointment isn't a standard event)
        return self.send_conversion_event(
            event_name="ScheduleAppointment",  # Custom event name
            user_data=user_data,
            custom_data=custom_data,
            event_source_url=event_source_url
        )
    
    def send_purchase_event(self, purchase_data, event_source_url=None):
        """
        Send a Purchase event to Meta Conversions API
        
        Args:
            purchase_data (dict): Purchase information including user and transaction data
            event_source_url (str, optional): URL where the purchase occurred
            
        Returns:
            tuple: (success (bool), response (dict), error_message (str))
        """
        # Extract user data
        user_data = {
            'email': purchase_data.get('email'),
            'phone': purchase_data.get('phone'),
            'first_name': purchase_data.get('first_name'),
            'last_name': purchase_data.get('last_name'),
            'external_id': purchase_data.get('id') or purchase_data.get('lead_id') or purchase_data.get('customer_id')
        }
        
        # Extract transaction value
        value = 0.0
        if 'value' in purchase_data:
            value = float(purchase_data['value'])
        elif 'amount' in purchase_data:
            value = float(purchase_data['amount'])
        elif 'total' in purchase_data:
            value = float(purchase_data['total'])
        elif 'revenue' in purchase_data:
            value = float(purchase_data['revenue'])
        
        # Prepare custom data
        custom_data = {
            'value': value,
            'currency': purchase_data.get('currency', 'USD'),
            'content_name': purchase_data.get('service') or 'Treatment',
            'content_category': purchase_data.get('category') or 'Service',
            'order_id': purchase_data.get('transaction_id') or purchase_data.get('id'),
            'content_type': 'product',
        }
        
        # Include transaction details if available
        if 'items' in purchase_data and isinstance(purchase_data['items'], list):
            custom_data['contents'] = purchase_data['items']
        
        # Send the event
        return self.send_conversion_event(
            event_name="Purchase",
            user_data=user_data,
            custom_data=custom_data,
            event_source_url=event_source_url
        )
    
    def batch_send_events(self, events):
        """
        Send multiple events in a single batch request
        
        Args:
            events (list): List of event dictionaries
            
        Returns:
            tuple: (success (bool), response (dict), error_message (str))
        """
        if not self.access_token or not self.pixel_id:
            return False, None, "Missing access token or pixel ID"
        
        # Prepare events data
        prepared_events = []
        
        for event in events:
            event_name = event.get('event_name')
            user_data = event.get('user_data', {})
            custom_data = event.get('custom_data', {})
            event_source_url = event.get('event_source_url')
            action_source = event.get('action_source', 'website')
            event_time = event.get('event_time', int(datetime.now(timezone.utc).timestamp()))
            
            # Generate event ID for deduplication
            event_id = self.get_event_id(event_name, user_data)
            
            # Prepare user data
            prepared_user_data = self.prepare_user_data(user_data)
            
            # Prepare event
            prepared_event = {
                "event_name": event_name,
                "event_time": event_time,
                "event_id": event_id,
                "user_data": prepared_user_data,
                "action_source": action_source
            }
            
            # Add custom data if provided
            if custom_data:
                prepared_event["custom_data"] = custom_data
            
            # Add event source URL if provided
            if event_source_url:
                prepared_event["event_source_url"] = event_source_url
            
            prepared_events.append(prepared_event)
        
        # Prepare the API request payload
        payload = {
            "data": prepared_events,
            "access_token": self.access_token,
            "test_event_code": "TEST12345" if self.debug_mode else None
        }
        
        # Remove None values from payload
        payload = {k: v for k, v in payload.items() if v is not None}
        
        # Make the API request
        try:
            response = requests.post(self.endpoint, json=payload)
            response_data = response.json()
            
            # Check if the request was successful
            if response.status_code == 200:
                return True, response_data, None
            else:
                error_message = f"Error: {response.status_code} - {response_data}"
                return False, response_data, error_message
                
        except Exception as e:
            error_message = f"Exception sending batch events: {str(e)}"
            return False, None, error_message


# Convenience functions

def send_lead_conversion(lead_data, source_url=None):
    """
    Convenience function to send a lead conversion event
    
    Args:
        lead_data (dict): Lead information
        source_url (str, optional): Source URL
        
    Returns:
        bool: Success status
    """
    api = MetaConversionsAPI()
    success, _, error = api.send_lead_event(lead_data, event_source_url=source_url)
    
    if not success and error:
        print(f"Error sending lead conversion: {error}")
    
    return success

def send_booking_conversion(booking_data, source_url=None):
    """
    Convenience function to send a booking conversion event
    
    Args:
        booking_data (dict): Booking information
        source_url (str, optional): Source URL
        
    Returns:
        bool: Success status
    """
    api = MetaConversionsAPI()
    success, _, error = api.send_consultation_booked_event(booking_data, event_source_url=source_url)
    
    if not success and error:
        print(f"Error sending booking conversion: {error}")
    
    return success

def send_purchase_conversion(purchase_data, source_url=None):
    """
    Convenience function to send a purchase conversion event
    
    Args:
        purchase_data (dict): Purchase information
        source_url (str, optional): Source URL
        
    Returns:
        bool: Success status
    """
    api = MetaConversionsAPI()
    success, _, error = api.send_purchase_event(purchase_data, event_source_url=source_url)
    
    if not success and error:
        print(f"Error sending purchase conversion: {error}")
    
    return success

def update_lead_status_in_meta(lead_data, new_status, source_url=None):
    """
    Send an updated lead status to Meta
    
    Args:
        lead_data (dict): Lead information
        new_status (str): New lead status
        source_url (str, optional): Source URL
        
    Returns:
        bool: Success status
    """
    # Clone lead data to avoid modifying the original
    updated_lead = lead_data.copy() if lead_data else {}
    
    # Update status
    updated_lead['status'] = new_status
    
    # Determine event type based on status
    if new_status.lower() in ['booked', 'consulted', 'scheduled']:
        return send_booking_conversion(updated_lead, source_url)
    elif new_status.lower() in ['closed', 'converted', 'deposit paid', 'installment plan']:
        return send_purchase_conversion(updated_lead, source_url)
    else:
        # For other status updates, send as lead update
        return send_lead_conversion(updated_lead, source_url)