"""
Comprehensive API Connection and Data Logic Audit
Optimizes filtering, matching, and revenue calculation for real Smooth MD data
"""

import streamlit as st
import pandas as pd
import os
import requests
from pyairtable import Api
import logging
import json
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def audit_api_connections():
    """Comprehensive audit of all API connections"""
    st.title("🔍 API Connection & Data Logic Audit")
    
    audit_results = {
        'airtable': {'status': 'unknown', 'details': {}},
        'meta': {'status': 'unknown', 'details': {}},
        'data_quality': {'leads': {}, 'transactions': {}},
        'filtering': {'original_count': 0, 'filtered_count': 0, 'efficiency': 0},
        'matching': {'revenue_found': 0, 'matches': 0, 'accuracy': 0}
    }
    
    # Check environment variables
    st.header("🔐 Environment Variables Check")
    
    env_vars = ['AIRTABLE_API_KEY', 'META_ACCESS_TOKEN', 'META_AD_ACCOUNT_ID', 'META_PIXEL_ID']
    env_status = {}
    
    for var in env_vars:
        value = os.getenv(var)
        env_status[var] = {
            'exists': value is not None,
            'length': len(value) if value else 0,
            'valid_format': bool(value and len(value) > 10) if value else False
        }
    
    # Display environment status
    for var, status in env_status.items():
        status_icon = "✅" if status['exists'] and status['valid_format'] else "❌"
        st.write(f"{status_icon} **{var}**: {'Present & Valid' if status['valid_format'] else 'Missing or Invalid'}")
    
    # Audit Airtable Connection
    st.header("📊 Airtable Connection Audit")
    
    try:
        airtable_key = os.getenv('AIRTABLE_API_KEY')
        if airtable_key:
            api = Api(airtable_key)
            
            # Test leads table connection
            leads_table = api.table('appwPsfAb2ZmWqhJD', 'tblhU4gONxgdA5jTF')
            leads_records = leads_table.all(max_records=10)  # Test with small sample
            
            if leads_records:
                leads_df = pd.DataFrame([record['fields'] for record in leads_records])
                audit_results['airtable']['status'] = 'success'
                audit_results['airtable']['details'] = {
                    'leads_sample_count': len(leads_df),
                    'leads_columns': list(leads_df.columns),
                    'sample_record': dict(leads_df.iloc[0]) if len(leads_df) > 0 else {}
                }
                
                st.success(f"✅ Airtable Leads: {len(leads_df)} sample records loaded")
                st.write(f"**Available Columns:** {', '.join(leads_df.columns)}")
                
                # Show sample data structure
                with st.expander("📋 Sample Lead Record"):
                    st.json(audit_results['airtable']['details']['sample_record'])
            
            # Test transactions table connection
            trans_table = api.table('appwPsfAb2ZmWqhJD', 'tbl364vtt5U8DxmT3')
            trans_records = trans_table.all(max_records=10)
            
            if trans_records:
                trans_df = pd.DataFrame([record['fields'] for record in trans_records])
                audit_results['airtable']['details']['transactions'] = {
                    'trans_sample_count': len(trans_df),
                    'trans_columns': list(trans_df.columns),
                    'sample_transaction': dict(trans_df.iloc[0]) if len(trans_df) > 0 else {}
                }
                
                st.success(f"✅ Airtable Transactions: {len(trans_df)} sample records loaded")
                st.write(f"**Transaction Columns:** {', '.join(trans_df.columns)}")
                
                # Show sample transaction
                with st.expander("💰 Sample Transaction Record"):
                    st.json(audit_results['airtable']['details']['transactions']['sample_transaction'])
                
    except Exception as e:
        audit_results['airtable']['status'] = 'error'
        audit_results['airtable']['details'] = {'error': str(e)}
        st.error(f"❌ Airtable Connection Failed: {e}")
    
    # Audit Meta API Connection
    st.header("📈 Meta API Connection Audit")
    
    try:
        access_token = os.getenv('META_ACCESS_TOKEN')
        ad_account_id = os.getenv('META_AD_ACCOUNT_ID')
        
        if access_token and ad_account_id:
            # Test Meta API connection
            url = f"https://graph.facebook.com/v18.0/act_{ad_account_id}/insights"
            params = {
                'access_token': access_token,
                'fields': 'spend,impressions,clicks,actions',
                'date_preset': 'last_7d',
                'limit': 5
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                meta_data = response.json()
                insights = meta_data.get('data', [])
                
                audit_results['meta']['status'] = 'success'
                audit_results['meta']['details'] = {
                    'insights_count': len(insights),
                    'total_spend': sum(float(insight.get('spend', 0)) for insight in insights),
                    'sample_insight': insights[0] if insights else {}
                }
                
                st.success(f"✅ Meta API: {len(insights)} insights retrieved")
                st.write(f"**Total Spend (7 days):** ${audit_results['meta']['details']['total_spend']:,.2f}")
                
                with st.expander("📊 Sample Meta Insight"):
                    st.json(audit_results['meta']['details']['sample_insight'])
            else:
                st.error(f"❌ Meta API Error: HTTP {response.status_code}")
                audit_results['meta']['status'] = 'error'
        else:
            st.warning("⚠️ Meta API credentials missing")
            
    except Exception as e:
        audit_results['meta']['status'] = 'error'
        audit_results['meta']['details'] = {'error': str(e)}
        st.error(f"❌ Meta API Connection Failed: {e}")
    
    # Data Quality Analysis
    st.header("🎯 Data Quality & Filtering Analysis")
    
    if audit_results['airtable']['status'] == 'success':
        try:
            # Load full datasets for analysis
            leads_table = api.table('appwPsfAb2ZmWqhJD', 'tblhU4gONxgdA5jTF')
            leads_records = leads_table.all()
            leads_df = pd.DataFrame([record['fields'] for record in leads_records])
            
            trans_table = api.table('appwPsfAb2ZmWqhJD', 'tbl364vtt5U8DxmT3')
            trans_records = trans_table.all()
            trans_df = pd.DataFrame([record['fields'] for record in trans_records])
            
            st.success(f"📊 **Full Dataset:** {len(leads_df)} leads, {len(trans_df)} transactions")
            
            # Analyze filtering criteria
            original_count = len(leads_df)
            audit_results['filtering']['original_count'] = original_count
            
            # Brand filtering analysis
            brand_analysis = {}
            if 'Brand' in leads_df.columns:
                brand_counts = leads_df['Brand'].value_counts()
                smooth_md_count = leads_df['Brand'].astype(str).str.contains('Smooth MD', case=False, na=False).sum()
                brand_analysis = {
                    'total_brands': len(brand_counts),
                    'smooth_md_leads': smooth_md_count,
                    'brand_distribution': dict(brand_counts.head())
                }
                st.write(f"**Brand Analysis:** {smooth_md_count} Smooth MD leads out of {original_count} total")
            
            # Source filtering analysis
            source_analysis = {}
            if 'Contact Source' in leads_df.columns:
                source_counts = leads_df['Contact Source'].value_counts()
                meta_sources = leads_df['Contact Source'].astype(str).str.contains(
                    'Facebook|Instagram|Meta', case=False, na=False
                ).sum()
                source_analysis = {
                    'total_sources': len(source_counts),
                    'meta_leads': meta_sources,
                    'source_distribution': dict(source_counts.head())
                }
                st.write(f"**Source Analysis:** {meta_sources} Meta leads out of {original_count} total")
            
            # Combined filtering
            filtered_df = leads_df.copy()
            if 'Brand' in leads_df.columns:
                brand_mask = filtered_df['Brand'].astype(str).str.contains('Smooth MD', case=False, na=False)
                filtered_df = filtered_df[brand_mask]
            
            if 'Contact Source' in filtered_df.columns:
                source_mask = filtered_df['Contact Source'].astype(str).str.contains(
                    'Facebook|Instagram|Meta', case=False, na=False
                )
                filtered_df = filtered_df[source_mask]
            
            filtered_count = len(filtered_df)
            audit_results['filtering']['filtered_count'] = filtered_count
            audit_results['filtering']['efficiency'] = (filtered_count / original_count) * 100 if original_count > 0 else 0
            
            st.metric("🎯 **Filtering Efficiency**", 
                     f"{filtered_count} leads", 
                     f"{audit_results['filtering']['efficiency']:.1f}% of total")
            
            # Revenue Matching Analysis
            st.subheader("💰 Revenue Matching Analysis")
            
            revenue_analysis = {}
            if 'Amount' in trans_df.columns:
                amounts = pd.to_numeric(trans_df['Amount'], errors='coerce').dropna()
                total_revenue = amounts.sum()
                
                revenue_analysis = {
                    'total_transactions': len(trans_df),
                    'valid_amounts': len(amounts),
                    'total_revenue': float(total_revenue),
                    'avg_transaction': float(amounts.mean()) if len(amounts) > 0 else 0,
                    'revenue_range': {
                        'min': float(amounts.min()) if len(amounts) > 0 else 0,
                        'max': float(amounts.max()) if len(amounts) > 0 else 0
                    }
                }
                
                st.write(f"**Revenue Found:** ${total_revenue:,.2f} from {len(amounts)} valid transactions")
                st.write(f"**Average Transaction:** ${revenue_analysis['avg_transaction']:,.2f}")
                
                audit_results['matching']['revenue_found'] = total_revenue
                audit_results['matching']['matches'] = len(amounts)
            
            # Display comprehensive analysis
            with st.expander("📊 Complete Data Analysis"):
                st.json({
                    'brand_analysis': brand_analysis,
                    'source_analysis': source_analysis,
                    'revenue_analysis': revenue_analysis
                })
                
        except Exception as e:
            st.error(f"❌ Data analysis error: {e}")
    
    # Optimization Recommendations
    st.header("🚀 Optimization Recommendations")
    
    recommendations = []
    
    if audit_results['filtering']['efficiency'] < 5:
        recommendations.append("⚠️ **Low Filtering Efficiency**: Consider reviewing filtering criteria")
    
    if audit_results['matching']['revenue_found'] == 0:
        recommendations.append("❌ **No Revenue Found**: Check transaction data and Amount column")
    
    if audit_results['airtable']['status'] != 'success':
        recommendations.append("🔑 **Airtable Connection**: Verify API key and table permissions")
    
    if audit_results['meta']['status'] != 'success':
        recommendations.append("🔑 **Meta API Connection**: Verify access token and account ID")
    
    if not recommendations:
        recommendations.append("✅ **All Systems Optimal**: Data connections and logic are working correctly")
    
    for rec in recommendations:
        st.write(rec)
    
    # Summary Report
    st.header("📋 Audit Summary")
    
    summary_data = {
        "Component": ["Airtable API", "Meta API", "Lead Filtering", "Revenue Matching"],
        "Status": [
            "✅ Connected" if audit_results['airtable']['status'] == 'success' else "❌ Failed",
            "✅ Connected" if audit_results['meta']['status'] == 'success' else "❌ Failed", 
            f"🎯 {audit_results['filtering']['filtered_count']} leads",
            f"💰 ${audit_results['matching']['revenue_found']:,.0f}"
        ],
        "Efficiency": [
            "100%" if audit_results['airtable']['status'] == 'success' else "0%",
            "100%" if audit_results['meta']['status'] == 'success' else "0%",
            f"{audit_results['filtering']['efficiency']:.1f}%",
            f"{(audit_results['matching']['matches'] / max(1, audit_results['filtering']['filtered_count'])) * 100:.1f}%"
        ]
    }
    
    st.dataframe(pd.DataFrame(summary_data), use_container_width=True, hide_index=True)
    
    return audit_results

if __name__ == "__main__":
    audit_results = audit_api_connections()