"""
Advanced Lead Matcher with Accurate Revenue Attribution
Sophisticated lead-to-transaction matching for precise ROAS calculations
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import logging
import re

logger = logging.getLogger(__name__)

class AdvancedLeadMatcher:
    """Production-grade lead matching with revenue attribution"""
    
    def __init__(self):
        # Meta source identification patterns
        self.meta_source_patterns = [
            'facebook ad', 'instagram ad', 'meta', 'fb', 'ig',
            'facebook ads', 'instagram ads', 'meta ads'
        ]
        
        # Brand identification patterns - Smooth MD only for Meta attribution
        self.smooth_brand_patterns = [
            'smooth md', 'smooth m.d.', 'smooth m.d', 'smoothmd'
        ]
        
        # Status classifications
        self.booking_statuses = [
            'booked', 'scheduled', 'appointment', 'confirmed',
            'arrived', 'checked in', 'in consultation'
        ]
        
        self.conversion_statuses = [
            'converted', 'closed', 'sold', 'purchased', 'won',
            'deposit paid', 'paid in full', 'installment plan',
            'treatment started', 'procedure complete'
        ]
        
        # Performance metrics
        self.match_statistics = {
            'total_leads': 0,
            'meta_leads': 0,
            'smooth_leads': 0,
            'matched_transactions': 0,
            'unmatched_transactions': 0,
            'attribution_rate': 0.0,
            'revenue_attributed': 0.0
        }
    
    def identify_meta_leads(self, leads_data: List[Dict]) -> List[Dict]:
        """Identify leads from Meta advertising sources"""
        meta_leads = []
        debug_count = 0
        
        for lead in leads_data:
            fields = lead.get('fields', {})
            
            # Extract contact source
            contact_source = self._extract_contact_source(fields)
            brand = self._extract_brand(fields)
            
            # Check if it's a Meta source
            is_meta = self._is_meta_source(contact_source)
            is_smooth = self._is_smooth_brand(brand)
            
            # Optional debug logging (disabled for production)
            # if is_meta and debug_count < 5:
            #     logger.debug(f"Meta lead: Brand='{brand}' | Source='{contact_source}' | Smooth={is_smooth}")
            #     debug_count += 1
            
            if is_meta and is_smooth:
                # Enrich lead with extracted data
                enriched_lead = {
                    'record_id': lead.get('id'),
                    'email': self._extract_email(fields),
                    'phone': self._extract_phone(fields),
                    'contact_source': contact_source,
                    'brand': brand,
                    'inbound_date': self._extract_date(fields, ['Inbound', 'Date', 'Created']),
                    'overall_status': self._extract_status(fields),
                    'service': self._extract_service(fields),
                    'location': self._extract_location(fields),
                    'lead_id': self._extract_lead_id(fields),
                    'is_booked': False,
                    'is_converted': False,
                    'matched_transactions': [],
                    'total_revenue': 0.0,
                    'raw_fields': fields
                }
                
                # Classify booking and conversion status
                enriched_lead['is_booked'] = self._is_booked_status(enriched_lead['overall_status'])
                enriched_lead['is_converted'] = self._is_converted_status(enriched_lead['overall_status'])
                
                meta_leads.append(enriched_lead)
        
        logger.info(f"Identified {len(meta_leads)} Meta leads from {len(leads_data)} total leads")
        return meta_leads
    
    def match_transactions_to_leads(self, meta_leads: List[Dict], transactions_data: List[Dict]) -> Tuple[List[Dict], Dict]:
        """Match transactions to Meta leads using multiple methods"""
        
        matched_leads = []
        matching_stats = {
            'direct_link_matches': 0,
            'email_matches': 0,
            'phone_matches': 0,
            'patient_id_matches': 0,
            'total_matched_revenue': 0.0,
            'unmatched_transactions': 0
        }
        
        # Process transactions for matching
        processed_transactions = self._process_transactions(transactions_data)
        
        # Create lookup dictionaries for efficient matching
        email_lookup = self._create_email_lookup(meta_leads)
        phone_lookup = self._create_phone_lookup(meta_leads)
        patient_lookup = self._create_patient_lookup(meta_leads)
        
        # Match each transaction to leads
        for transaction in processed_transactions:
            matched_lead = None
            match_method = None
            
            # Method 1: Direct link via Airtable relationships
            if transaction.get('lead_links'):
                lead_links = transaction['lead_links']
                if isinstance(lead_links, str):
                    lead_links = [lead_links]
                elif isinstance(lead_links, list):
                    pass
                else:
                    lead_links = []
                    
                for lead_link in lead_links:
                    matched_lead = self._find_lead_by_id(meta_leads, str(lead_link))
                    if matched_lead:
                        match_method = 'direct_link'
                        matching_stats['direct_link_matches'] += 1
                        break
            
            # Method 2: Email matching (exact and fuzzy)
            if not matched_lead and transaction.get('email'):
                email = self._normalize_email(transaction['email'])
                if email and len(email) > 5:  # Valid email check
                    if email in email_lookup:
                        matched_lead = email_lookup[email]
                        match_method = 'email'
                        matching_stats['email_matches'] += 1
                    # Fuzzy email matching disabled - only exact matches for accuracy
            
            # Method 3: Phone matching (enhanced)
            if not matched_lead and transaction.get('phone'):
                phone = self._normalize_phone(transaction['phone'])
                if phone and len(phone) >= 10:  # Valid phone check
                    # Try exact match first
                    if phone in phone_lookup:
                        matched_lead = phone_lookup[phone]
                        match_method = 'phone'
                        matching_stats['phone_matches'] += 1
                    # Partial phone matching disabled - only exact matches for accuracy
            
            # Method 4: Patient ID matching (enhanced)
            if not matched_lead and transaction.get('patient_id'):
                patient_id = str(transaction['patient_id']).upper().strip()
                if patient_id and len(patient_id) > 2:
                    if patient_id in patient_lookup:
                        matched_lead = patient_lookup[patient_id]
                        match_method = 'patient_id'
                        matching_stats['patient_id_matches'] += 1
                    # Partial patient ID matching disabled - only exact matches for accuracy
            
            # Method 5: Date-based proximity matching (DISABLED - too aggressive)
            # This method was creating false matches and inflating revenue
            # Only use exact identifier matching for accurate attribution
            
            # Apply the match with validation
            if matched_lead:
                # Validate transaction amount and source for accuracy
                tx_amount = transaction.get('amount', 0)
                
                # Accept all positive transaction amounts for medical services
                if tx_amount > 0:  # Any positive amount is valid
                    transaction['match_method'] = match_method
                    matched_lead['matched_transactions'].append(transaction)
                    matched_lead['total_revenue'] += tx_amount
                    matching_stats['total_matched_revenue'] += tx_amount
                    
                    # Log for debugging
                    if tx_amount < 100 or tx_amount > 20000:
                        logger.info(f"Unusual transaction amount: ${tx_amount} (method: {match_method})")
                else:
                    matching_stats['filtered_transactions'] = matching_stats.get('filtered_transactions', 0) + 1
            else:
                matching_stats['unmatched_transactions'] += 1
        
        # Update conversion status based on transactions
        for lead in meta_leads:
            if lead['matched_transactions']:
                lead['is_converted'] = True  # Has revenue = converted
                
        matching_stats['attribution_rate'] = (
            len([l for l in meta_leads if l['matched_transactions']]) / 
            len(meta_leads) * 100 if meta_leads else 0
        )
        
        self.match_statistics.update(matching_stats)
        
        logger.info(f"Matched {len([l for l in meta_leads if l['matched_transactions']])} leads to transactions")
        logger.info(f"Total attributed revenue: ${matching_stats['total_matched_revenue']:,.2f}")
        
        return meta_leads, matching_stats
    
    def calculate_performance_metrics(self, matched_leads: List[Dict], ad_spend: float = 0.0) -> Dict:
        """Calculate comprehensive performance metrics"""
        
        total_leads = len(matched_leads)
        booked_leads = len([l for l in matched_leads if l['is_booked']])
        converted_leads = len([l for l in matched_leads if l['is_converted']])
        revenue_generating_leads = len([l for l in matched_leads if l['total_revenue'] > 0])
        
        total_revenue = sum(lead['total_revenue'] for lead in matched_leads)
        average_order_value = total_revenue / converted_leads if converted_leads > 0 else 0
        
        # Calculate rates
        booking_rate = (booked_leads / total_leads * 100) if total_leads > 0 else 0
        conversion_rate = (converted_leads / total_leads * 100) if total_leads > 0 else 0
        revenue_rate = (revenue_generating_leads / total_leads * 100) if total_leads > 0 else 0
        
        # ROAS calculation
        roas = (total_revenue / ad_spend) if ad_spend > 0 else 0
        
        # Cost metrics
        cost_per_lead = ad_spend / total_leads if total_leads > 0 else 0
        cost_per_conversion = ad_spend / converted_leads if converted_leads > 0 else 0
        
        return {
            'total_leads': total_leads,
            'booked_leads': booked_leads,
            'converted_leads': converted_leads,
            'revenue_generating_leads': revenue_generating_leads,
            'total_revenue': total_revenue,
            'average_order_value': average_order_value,
            'booking_rate': booking_rate,
            'conversion_rate': conversion_rate,
            'revenue_rate': revenue_rate,
            'roas': roas,
            'cost_per_lead': cost_per_lead,
            'cost_per_conversion': cost_per_conversion,
            'ad_spend': ad_spend
        }
    
    def get_diagnostic_report(self, matched_leads: List[Dict], matching_stats: Dict) -> Dict:
        """Generate comprehensive diagnostic report"""
        
        return {
            'matching_quality': {
                'total_leads_processed': len(matched_leads),
                'leads_with_transactions': len([l for l in matched_leads if l['matched_transactions']]),
                'attribution_rate': matching_stats.get('attribution_rate', 0),
                'average_revenue_per_lead': (
                    matching_stats.get('total_matched_revenue', 0) / 
                    len(matched_leads) if matched_leads else 0
                )
            },
            'match_methods': {
                'direct_link_matches': matching_stats.get('direct_link_matches', 0),
                'email_matches': matching_stats.get('email_matches', 0),
                'phone_matches': matching_stats.get('phone_matches', 0),
                'patient_id_matches': matching_stats.get('patient_id_matches', 0)
            },
            'data_quality': {
                'leads_with_email': len([l for l in matched_leads if l.get('email')]),
                'leads_with_phone': len([l for l in matched_leads if l.get('phone')]),
                'leads_with_status': len([l for l in matched_leads if l.get('overall_status')])
            },
            'revenue_distribution': self._analyze_revenue_distribution(matched_leads)
        }
    
    # Helper methods for data extraction and processing
    
    def _extract_field_value(self, fields: Dict, field_names: List[str]) -> str:
        """Extract field value with multiple field name attempts"""
        for field_name in field_names:
            value = fields.get(field_name)
            if value:
                if isinstance(value, list) and value:
                    return str(value[0]).strip()
                return str(value).strip()
        return ''

    def _extract_contact_source(self, fields: Dict) -> str:
        """Extract contact source with multiple field attempts"""
        source_fields = ['Contact Source', 'Source', 'Lead Source', 'Campaign Source']
        for field in source_fields:
            value = fields.get(field)
            if value:
                return str(value).strip()
        return ''
    
    def _extract_brand(self, fields: Dict) -> str:
        """Extract brand information"""
        brand_fields = ['Brand', 'Company', 'Client', 'Brand (from ID)']
        for field in brand_fields:
            value = fields.get(field)
            if value:
                if isinstance(value, list) and value:
                    return str(value[0]).strip()
                return str(value).strip()
        return ''
    
    def _extract_email(self, fields: Dict) -> str:
        """Extract email address"""
        email_fields = ['Email', 'email', 'Email Address']
        for field in email_fields:
            value = fields.get(field)
            if value:
                if isinstance(value, list) and value:
                    return str(value[0]).strip().lower()
                return str(value).strip().lower()
        return ''
    
    def _extract_phone(self, fields: Dict) -> str:
        """Extract phone number"""
        phone_fields = ['Phone', 'phone', 'Phone Number', 'Phone number']
        for field in phone_fields:
            value = fields.get(field)
            if value:
                if isinstance(value, list) and value:
                    return self._normalize_phone(str(value[0]))
                return self._normalize_phone(str(value))
        return ''
    
    def _extract_date(self, fields: Dict, date_fields: List[str]) -> str:
        """Extract date with robust parsing"""
        for field in date_fields:
            value = fields.get(field)
            if value:
                try:
                    if isinstance(value, str):
                        if 'T' in value:
                            dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
                        else:
                            dt = datetime.strptime(value, '%Y-%m-%d')
                        return dt.strftime('%Y-%m-%d')
                    elif hasattr(value, 'strftime'):
                        return value.strftime('%Y-%m-%d')
                except (ValueError, TypeError):
                    continue
        return ''
    
    def _extract_status(self, fields: Dict) -> str:
        """Extract overall status"""
        status_fields = ['Overall Status', 'Status', 'Lead Status']
        for field in status_fields:
            value = fields.get(field)
            if value:
                return str(value).strip()
        return ''
    
    def _extract_service(self, fields: Dict) -> str:
        """Extract service information"""
        service_fields = ['Service', 'Services', 'Treatment', 'Services Purchased']
        for field in service_fields:
            value = fields.get(field)
            if value:
                if isinstance(value, list):
                    return ', '.join(str(v) for v in value)
                return str(value).strip()
        return ''
    
    def _extract_location(self, fields: Dict) -> str:
        """Extract location information"""
        location_fields = ['Original Location', 'Scheduled Location', 'Location']
        for field in location_fields:
            value = fields.get(field)
            if value:
                if isinstance(value, list) and value:
                    return str(value[0]).strip()
                return str(value).strip()
        return ''
    
    def _extract_lead_id(self, fields: Dict) -> str:
        """Extract lead ID"""
        id_fields = ['ID', 'Lead ID', 'id']
        for field in id_fields:
            value = fields.get(field)
            if value:
                return str(value).strip()
        return ''
    
    def _is_meta_source(self, source: str) -> bool:
        """Check if source indicates Meta advertising"""
        if not source:
            return False
        source_lower = source.lower()
        return any(pattern in source_lower for pattern in self.meta_source_patterns)
    
    def _is_smooth_brand(self, brand: str) -> bool:
        """Check if brand is Smooth MD only (exclude Dr. Vigor)"""
        if not brand:
            return False
        brand_lower = brand.lower()
        
        # Must contain 'smooth' but NOT 'vigor'
        has_smooth = any(pattern in brand_lower for pattern in self.smooth_brand_patterns)
        has_vigor = 'vigor' in brand_lower
        
        return has_smooth and not has_vigor
    
    def _is_booked_status(self, status: str) -> bool:
        """Check if status indicates booking"""
        if not status:
            return False
        status_lower = status.lower()
        return any(booking_status in status_lower for booking_status in self.booking_statuses)
    
    def _is_converted_status(self, status: str) -> bool:
        """Check if status indicates conversion"""
        if not status:
            return False
        status_lower = status.lower()
        return any(conversion_status in status_lower for conversion_status in self.conversion_statuses)
    
    def _process_transactions(self, transactions_data: List[Dict]) -> List[Dict]:
        """Process transactions for matching"""
        processed = []
        debug_count = 0
        
        for transaction in transactions_data:
            fields = transaction.get('fields', {})
            
            # Extract transaction data
            processed_transaction = {
                'record_id': transaction.get('id'),
                'amount': self._extract_transaction_amount(fields),
                'date': self._extract_date(fields, ['Date', 'Transaction Date', 'Created']),
                'patient_id': self._extract_field_value(fields, ['Patient', 'Patient ID', 'Lead ID', 'ID']),
                'email': self._extract_email(fields),
                'phone': self._extract_phone(fields),
                'lead_links': self._extract_field_value(fields, ['Lead', 'Leads', 'Lead ID', 'Patient', 'ID']),
                'status': fields.get('Status', ''),
                'payment_type': fields.get('Payment Type', ''),
                'services': fields.get('Services Purchased', ''),
                'raw_fields': fields
            }
            
            # Debug: Log first few transactions with identifiers
            if debug_count < 10 and processed_transaction['amount'] > 0:
                logger.info(f"Transaction #{debug_count + 1}: Amount=${processed_transaction['amount']}, Email='{processed_transaction['email']}', Phone='{processed_transaction['phone']}', Patient='{processed_transaction['patient_id']}'")
                debug_count += 1
            
            if processed_transaction['amount'] > 0:
                processed.append(processed_transaction)
        
        logger.info(f"Processed {len(processed)} transactions with amounts > 0")
        return processed
    
    def _extract_transaction_amount(self, fields: Dict) -> float:
        """Extract transaction amount"""
        amount_fields = ['Amount', 'Total', 'Revenue', 'Value']
        
        for field in amount_fields:
            value = fields.get(field)
            if value is not None:
                try:
                    if isinstance(value, (int, float)):
                        return float(value)
                    elif isinstance(value, str):
                        clean_value = re.sub(r'[^\d.]', '', value)
                        return float(clean_value) if clean_value else 0.0
                except (ValueError, TypeError):
                    continue
        return 0.0
    
    def _normalize_email(self, email: str) -> str:
        """Normalize email for matching"""
        return email.strip().lower() if email else ''
    
    def _normalize_phone(self, phone: str) -> str:
        """Normalize phone number for matching"""
        if not phone:
            return ''
        # Remove all non-digits
        digits_only = re.sub(r'\D', '', phone)
        # Return last 10 digits for US numbers
        return digits_only[-10:] if len(digits_only) >= 10 else digits_only
    
    def _create_email_lookup(self, leads: List[Dict]) -> Dict:
        """Create email lookup dictionary"""
        lookup = {}
        for lead in leads:
            email = lead.get('email')
            if email:
                lookup[email] = lead
        return lookup
    
    def _create_phone_lookup(self, leads: List[Dict]) -> Dict:
        """Create phone lookup dictionary"""
        lookup = {}
        for lead in leads:
            phone = lead.get('phone')
            if phone:
                lookup[phone] = lead
        return lookup
    
    def _create_patient_lookup(self, leads: List[Dict]) -> Dict:
        """Create patient ID lookup dictionary"""
        lookup = {}
        for lead in leads:
            lead_id = lead.get('lead_id')
            if lead_id:
                lookup[lead_id.upper()] = lead
        return lookup
    
    def _find_lead_by_id(self, leads: List[Dict], lead_id: str) -> Optional[Dict]:
        """Find lead by record ID"""
        for lead in leads:
            if lead.get('record_id') == lead_id:
                return lead
        return None
    
    def _analyze_revenue_distribution(self, leads: List[Dict]) -> Dict:
        """Analyze revenue distribution across leads"""
        revenues = [lead['total_revenue'] for lead in leads if lead['total_revenue'] > 0]
        
        if not revenues:
            return {'count': 0, 'total': 0, 'average': 0, 'median': 0}
        
        return {
            'count': len(revenues),
            'total': sum(revenues),
            'average': np.mean(revenues),
            'median': np.median(revenues),
            'min': min(revenues),
            'max': max(revenues)
        }

# Global instance
advanced_lead_matcher = AdvancedLeadMatcher()

__all__ = ['AdvancedLeadMatcher', 'advanced_lead_matcher']