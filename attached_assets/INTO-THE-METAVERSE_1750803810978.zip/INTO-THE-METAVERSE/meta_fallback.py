"""
Fallback data for Meta Ad Performance Dashboard when API is unavailable
Provides realistic sample data structures to demonstrate dashboard capabilities
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def get_sample_campaign_data():
    """Generate realistic sample campaign data"""
    campaigns = [
        {
            "id": "23855970654880123",
            "name": "FB - Lead Generation - Botox Special",
            "status": "ACTIVE",
            "objective": "LEAD_GENERATION",
            "spend": "1245.67"
        },
        {
            "id": "23855970654880124",
            "name": "IG - Conversion - Weight Loss",
            "status": "ACTIVE",
            "objective": "CONVERSIONS",
            "spend": "2789.45"
        },
        {
            "id": "23855970654880125",
            "name": "FB - Conversion - Med Spa Bundle",
            "status": "PAUSED",
            "objective": "CONVERSIONS",
            "spend": "945.21"
        },
        {
            "id": "23855970654880126",
            "name": "IG - Awareness - Summer Specials",
            "status": "ACTIVE",
            "objective": "BRAND_AWARENESS",
            "spend": "587.32"
        },
        {
            "id": "23855970654880127",
            "name": "FB - Video - Client Testimonials",
            "status": "ACTIVE",
            "objective": "VIDEO_VIEWS",
            "spend": "1120.78"
        }
    ]
    return pd.DataFrame(campaigns)

def get_sample_campaign_insights():
    """Generate realistic sample campaign insights data"""
    # Create date range for the last 30 days
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    
    campaigns = [
        "FB - Lead Generation - Botox Special",
        "IG - Conversion - Weight Loss",
        "FB - Conversion - Med Spa Bundle",
        "IG - Awareness - Summer Specials",
        "FB - Video - Client Testimonials"
    ]
    
    # Generate sample data
    insights = []
    
    for date in date_range:
        for campaign in campaigns:
            # Base values
            base_impressions = np.random.randint(1000, 5000)
            base_clicks = np.random.randint(20, 200)
            base_spend = np.random.uniform(20, 100)
            
            # Calculated metrics
            ctr = (base_clicks / base_impressions) * 100
            cpc = base_spend / max(base_clicks, 1)  # Avoid division by zero
            
            insight = {
                "date_start": date,
                "date_stop": date,
                "campaign_name": campaign,
                "impressions": base_impressions,
                "clicks": base_clicks,
                "reach": int(base_impressions * 0.7),  # Assuming reach is about 70% of impressions
                "spend": base_spend,
                "cpc": cpc,
                "cpm": (base_spend / base_impressions) * 1000,
                "ctr": ctr,
                "frequency": np.random.uniform(1.1, 3.0),
                "quality_ranking": np.random.choice(["ABOVE_AVERAGE", "AVERAGE", "BELOW_AVERAGE"]),
                "engagement_rate_ranking": np.random.choice(["ABOVE_AVERAGE", "AVERAGE", "BELOW_AVERAGE"]),
                "conversion_rate_ranking": np.random.choice(["ABOVE_AVERAGE", "AVERAGE", "BELOW_AVERAGE"])
            }
            insights.append(insight)
    
    return pd.DataFrame(insights)

def get_sample_ad_performance():
    """Generate realistic sample overall ad performance metrics"""
    performance = {
        "impressions": 124568,
        "reach": 89432,
        "clicks": 3782,
        "spend": 4689.43,
        "cpc": 1.24,
        "ctr": 3.04,
        "frequency": 1.39,
        "engagement_rate": 4.26,
        "cost_per_thousand": 37.65
    }
    return performance