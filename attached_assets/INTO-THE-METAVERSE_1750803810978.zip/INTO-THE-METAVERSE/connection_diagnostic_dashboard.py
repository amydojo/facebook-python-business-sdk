"""
Connection Diagnostic Dashboard
Advanced diagnostics and auto-healing for critical data connections
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import logging
import json
from fault_tolerant_connector import fault_tolerant_connector

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Connection Diagnostics",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for diagnostic styling
st.markdown("""
<style>
    .diagnostic-header {
        font-size: 2rem;
        font-weight: bold;
        color: #dc3545;
        margin-bottom: 1rem;
    }
    .health-good {
        background: linear-gradient(135deg, #28a745, #20c997);
        color: white;
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
    }
    .health-warning {
        background: linear-gradient(135deg, #ffc107, #fd7e14);
        color: white;
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
    }
    .health-critical {
        background: linear-gradient(135deg, #dc3545, #e83e8c);
        color: white;
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
    }
    .recommendation {
        background: #f8f9fa;
        border-left: 4px solid #007bff;
        padding: 1rem;
        margin: 0.5rem 0;
    }
    .action-button {
        background: #007bff;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 4px;
        border: none;
        cursor: pointer;
    }
</style>
""", unsafe_allow_html=True)

def display_health_status(health_data):
    """Display connection health status with visual indicators"""
    
    st.markdown('<div class="diagnostic-header">🔧 Connection Health Status</div>', unsafe_allow_html=True)
    
    overall_health = health_data.get('overall_health', 'unknown')
    
    if overall_health == 'healthy':
        st.markdown("""
        <div class="health-good">
            ✅ <strong>System Healthy</strong><br>
            All connections are operational and performing within normal parameters.
        </div>
        """, unsafe_allow_html=True)
    elif overall_health == 'degraded':
        st.markdown("""
        <div class="health-warning">
            ⚠️ <strong>System Degraded</strong><br>
            Some connections are experiencing issues but core functionality remains available.
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown("""
        <div class="health-critical">
            🚨 <strong>System Critical</strong><br>
            Critical connection failures detected. Immediate attention required.
        </div>
        """, unsafe_allow_html=True)
    
    # Connection details
    col1, col2, col3 = st.columns(3)
    
    with col1:
        credentials_valid = health_data.get('credentials_valid', False)
        if credentials_valid:
            st.success("✅ Credentials Valid")
        else:
            st.error("❌ Credentials Invalid")
    
    with col2:
        circuit_state = health_data.get('circuit_breaker_state', 'UNKNOWN')
        if circuit_state == 'CLOSED':
            st.success(f"✅ Circuit Breaker: {circuit_state}")
        elif circuit_state == 'HALF_OPEN':
            st.warning(f"⚠️ Circuit Breaker: {circuit_state}")
        else:
            st.error(f"🚨 Circuit Breaker: {circuit_state}")
    
    with col3:
        validated_tables = health_data.get('validated_tables', {})
        table_count = len(validated_tables)
        if table_count >= 2:
            st.success(f"✅ Tables Accessible: {table_count}")
        elif table_count == 1:
            st.warning(f"⚠️ Tables Accessible: {table_count}")
        else:
            st.error(f"❌ Tables Accessible: {table_count}")

def display_error_analysis(health_data):
    """Display detailed error analysis and recommendations"""
    
    if 'error' in health_data:
        st.markdown("### 🔍 Error Analysis")
        
        error_message = health_data.get('error', 'Unknown error')
        recommendation = health_data.get('recommendation', 'Contact system administrator')
        
        st.error(f"**Error:** {error_message}")
        
        st.markdown(f"""
        <div class="recommendation">
            <strong>Recommended Action:</strong><br>
            {recommendation}
        </div>
        """, unsafe_allow_html=True)

def test_connection_functionality():
    """Test connection functionality with diagnostic reporting"""
    
    st.markdown("### 🧪 Connection Testing")
    
    with st.spinner("Running comprehensive connection tests..."):
        
        # Test transaction loading
        st.markdown("**Testing Transaction Data Access...**")
        try:
            end_date = datetime.now().strftime('%Y-%m-%d')
            start_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
            
            transaction_result = fault_tolerant_connector.load_transactions(start_date, end_date)
            
            if transaction_result['success']:
                processed_count = len(transaction_result.get('processed_data', []))
                revenue = transaction_result.get('revenue', 0)
                st.success(f"✅ Transactions: {processed_count} records, ${revenue:.2f} revenue")
            else:
                error_type = transaction_result.get('error_type', 'Unknown')
                st.error(f"❌ Transactions: {error_type}")
                
                # Display recommendations
                recommendations = transaction_result.get('recommendations', [])
                for rec in recommendations:
                    st.info(f"💡 {rec}")
                    
        except Exception as e:
            st.error(f"❌ Transaction test failed: {str(e)}")
        
        # Test lead loading
        st.markdown("**Testing Lead Data Access...**")
        try:
            lead_result = fault_tolerant_connector.load_leads(start_date, end_date)
            
            if lead_result['success']:
                lead_count = lead_result.get('lead_count', 0)
                st.success(f"✅ Leads: {lead_count} records")
            else:
                error_type = lead_result.get('error_type', 'Unknown')
                st.error(f"❌ Leads: {error_type}")
                
                # Display recommendations
                recommendations = lead_result.get('recommendations', [])
                for rec in recommendations:
                    st.info(f"💡 {rec}")
                    
        except Exception as e:
            st.error(f"❌ Lead test failed: {str(e)}")

def run_auto_healing():
    """Execute auto-healing procedures"""
    
    st.markdown("### 🔧 Auto-Healing Procedures")
    
    if st.button("🚀 Run Auto-Healing", type="primary"):
        with st.spinner("Executing auto-healing procedures..."):
            
            try:
                healing_result = fault_tolerant_connector.diagnose_and_heal()
                
                st.success("Auto-healing completed!")
                
                # Display healing actions taken
                actions = healing_result.get('healing_actions', [])
                if actions:
                    st.markdown("**Actions Taken:**")
                    for action in actions:
                        st.info(f"🔧 {action}")
                else:
                    st.info("No healing actions were necessary")
                
                # Display recommendations
                recommendations = healing_result.get('recommendations', [])
                if recommendations:
                    st.markdown("**Additional Recommendations:**")
                    for rec in recommendations:
                        st.warning(f"💡 {rec}")
                
                # Display health status after healing
                health_status = healing_result.get('health_status', {})
                st.json(health_status)
                
            except Exception as e:
                st.error(f"Auto-healing failed: {str(e)}")

def display_connection_metrics():
    """Display connection performance metrics"""
    
    st.markdown("### 📊 Connection Performance Metrics")
    
    health_data = fault_tolerant_connector.get_health_status()
    
    # Recent attempts analysis
    recent_attempts = health_data.get('recent_attempts', 0)
    connection_pool_size = health_data.get('connection_pool_size', 0)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.metric("Recent Connection Attempts", recent_attempts)
        st.metric("Connection Pool Size", connection_pool_size)
    
    with col2:
        # Circuit breaker state visualization
        circuit_state = health_data.get('circuit_breaker_state', 'UNKNOWN')
        
        fig = go.Figure(go.Indicator(
            mode = "gauge+number",
            value = 1 if circuit_state == 'CLOSED' else 0.5 if circuit_state == 'HALF_OPEN' else 0,
            domain = {'x': [0, 1], 'y': [0, 1]},
            title = {'text': "Circuit Breaker Health"},
            gauge = {
                'axis': {'range': [None, 1]},
                'bar': {'color': "darkgreen" if circuit_state == 'CLOSED' else "orange" if circuit_state == 'HALF_OPEN' else "red"},
                'steps': [
                    {'range': [0, 0.33], 'color': "lightgray"},
                    {'range': [0.33, 0.66], 'color': "yellow"},
                    {'range': [0.66, 1], 'color': "lightgreen"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 0.9
                }
            }
        ))
        
        fig.update_layout(height=300)
        st.plotly_chart(fig, use_container_width=True)

def display_table_validation_status():
    """Display table validation and discovery status"""
    
    st.markdown("### 📋 Table Validation Status")
    
    health_data = fault_tolerant_connector.get_health_status()
    validated_tables = health_data.get('validated_tables', {})
    
    if validated_tables:
        table_data = []
        for data_type, table_name in validated_tables.items():
            table_data.append({
                'Data Type': data_type.title(),
                'Table Name': table_name,
                'Status': '✅ Validated'
            })
        
        df = pd.DataFrame(table_data)
        st.dataframe(df, use_container_width=True)
    else:
        st.warning("No validated tables found. Run auto-healing to discover tables.")
    
    # Table discovery button
    if st.button("🔍 Rediscover Tables"):
        with st.spinner("Discovering table mappings..."):
            try:
                # Force table rediscovery
                fault_tolerant_connector.validated_tables.clear()
                fault_tolerant_connector.last_validation.clear()
                
                # Test discovery for each data type
                for data_type in ['transactions', 'leads']:
                    try:
                        table_name = fault_tolerant_connector._discover_table(data_type)
                        if table_name:
                            st.success(f"✅ Discovered {data_type}: {table_name}")
                        else:
                            st.error(f"❌ Could not discover table for {data_type}")
                    except Exception as e:
                        st.error(f"❌ Discovery failed for {data_type}: {str(e)}")
                
            except Exception as e:
                st.error(f"Table discovery failed: {str(e)}")

def main():
    """Main diagnostic dashboard application"""
    
    st.markdown('<div class="diagnostic-header">🔧 Advanced Connection Diagnostics</div>', unsafe_allow_html=True)
    st.markdown("**Comprehensive diagnostics and auto-healing for critical data connections**")
    
    # Sidebar controls
    st.sidebar.markdown("## 🛠️ Diagnostic Controls")
    
    auto_refresh = st.sidebar.checkbox("Auto-refresh every 30 seconds", value=False)
    
    if st.sidebar.button("🔄 Refresh Status"):
        st.rerun()
    
    # Main diagnostics
    try:
        # Get current health status
        health_data = fault_tolerant_connector.get_health_status()
        
        # Display health status
        display_health_status(health_data)
        
        st.markdown("---")
        
        # Display error analysis if needed
        display_error_analysis(health_data)
        
        # Connection testing section
        with st.expander("🧪 Run Connection Tests", expanded=False):
            test_connection_functionality()
        
        st.markdown("---")
        
        # Auto-healing section
        with st.expander("🔧 Auto-Healing Controls", expanded=True):
            run_auto_healing()
        
        st.markdown("---")
        
        # Performance metrics
        display_connection_metrics()
        
        st.markdown("---")
        
        # Table validation
        display_table_validation_status()
        
        # System information
        st.sidebar.markdown("## 📊 System Information")
        st.sidebar.json({
            "Last Updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "Connector Status": "Active",
            "Health Check": health_data.get('overall_health', 'unknown').title()
        })
        
        # Auto-refresh logic
        if auto_refresh:
            import time
            time.sleep(30)
            st.rerun()
            
    except Exception as e:
        st.error(f"Dashboard error: {str(e)}")
        logger.error(f"Dashboard error: {e}")
        
        # Emergency diagnostics
        st.markdown("### 🚨 Emergency Diagnostics")
        st.code(f"""
Error Details:
- Type: {type(e).__name__}
- Message: {str(e)}
- Timestamp: {datetime.now().isoformat()}

Recommended Actions:
1. Check environment variables (AIRTABLE_API_KEY, AIRTABLE_BASE_ID)
2. Verify API key permissions
3. Confirm base ID is correct
4. Test network connectivity
        """)

if __name__ == "__main__":
    main()