"""
Robust Ad Performance Visualizations with Comprehensive Error Handling
Fixed Plotly methods and defensive programming practices
"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from typing import Dict, List, Optional, Any
import numpy as np
import logging

logger = logging.getLogger(__name__)

class RobustAdVisualizations:
    """Robust visualizations with comprehensive error handling"""
    
    def __init__(self):
        self.default_chart_config = {
            'plot_bgcolor': 'rgba(0,0,0,0)',
            'paper_bgcolor': 'rgba(0,0,0,0)',
            'font_color': 'white',
            'title_font_color': 'white'
        }
    
    def safe_display_campaign_performance_matrix(self, campaign_analysis: List[Dict]):
        """Safely display campaign performance matrix with error handling"""
        try:
            if not campaign_analysis:
                st.info("No campaign data available for analysis")
                return
            
            st.markdown("### Campaign Performance Matrix")
            
            # Safely create DataFrame
            df = self._safe_create_dataframe(campaign_analysis, 'campaign')
            if df.empty:
                st.warning("Unable to process campaign data")
                return
            
            # Safe visualization creation
            col1, col2 = st.columns(2)
            
            with col1:
                self._safe_create_performance_scatter(df)
            
            with col2:
                self._safe_create_roas_comparison(df)
            
            # Safe table display
            self._safe_display_campaign_table(df)
            
        except Exception as e:
            logger.error(f"Error in campaign performance matrix: {e}")
            st.error("Unable to display campaign performance. Please check your data connections.")
    
    def safe_display_adset_efficiency_analysis(self, adset_analysis: List[Dict]):
        """Safely display ad set efficiency analysis"""
        try:
            if not adset_analysis:
                st.info("No ad set data available for analysis")
                return
            
            st.markdown("### Ad Set Efficiency Analysis")
            
            df = self._safe_create_dataframe(adset_analysis, 'adset')
            if df.empty:
                st.warning("Unable to process ad set data")
                return
            
            col1, col2 = st.columns(2)
            
            with col1:
                self._safe_create_efficiency_scatter(df)
            
            with col2:
                self._safe_create_optimization_chart(df)
            
            self._safe_display_adset_table(df)
            
        except Exception as e:
            logger.error(f"Error in ad set analysis: {e}")
            st.error("Unable to display ad set performance. Data may be incomplete.")
    
    def safe_display_individual_ad_insights(self, ad_analysis: List[Dict]):
        """Safely display individual ad performance insights"""
        try:
            if not ad_analysis:
                st.info("No individual ad data available for analysis")
                return
            
            st.markdown("### Individual Ad Creative Performance")
            
            df = self._safe_create_dataframe(ad_analysis, 'ad')
            if df.empty:
                st.warning("Unable to process ad creative data")
                return
            
            col1, col2 = st.columns(2)
            
            with col1:
                self._safe_create_creative_scatter(df)
            
            with col2:
                self._safe_create_top_ads_chart(df)
            
            # Performance tier metrics
            self._safe_display_performance_tiers(df)
            
            # Filterable table
            self._safe_display_ad_table_with_filters(df)
            
        except Exception as e:
            logger.error(f"Error in ad insights: {e}")
            st.error("Unable to display ad performance. Please verify your Meta API connection.")
    
    def safe_display_service_optimization_insights(self, service_analysis: Dict):
        """Safely display service optimization insights"""
        try:
            services = service_analysis.get('services', [])
            if not services:
                st.info("No service performance data available")
                return
            
            st.markdown("### Service/Treatment Performance Analysis")
            
            df = self._safe_create_dataframe(services, 'service')
            if df.empty:
                st.warning("Unable to process service data")
                return
            
            col1, col2 = st.columns(2)
            
            with col1:
                self._safe_create_service_pie_chart(df)
            
            with col2:
                self._safe_create_service_roas_chart(df)
            
            # Service metrics
            self._safe_display_service_metrics(df, service_analysis)
            
            # Service table
            self._safe_display_service_table(df)
            
            # Strategic insights
            self._safe_display_service_insights(service_analysis)
            
        except Exception as e:
            logger.error(f"Error in service analysis: {e}")
            st.error("Unable to display service performance. Transaction data may be unavailable.")
    
    def safe_display_performance_summary_dashboard(self, analysis_data: Dict):
        """Safely display performance summary dashboard"""
        try:
            summary = analysis_data.get('summary_metrics', {})
            
            st.markdown("### Performance Summary Dashboard")
            
            # Key metrics with safe value extraction
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                revenue = self._safe_get_numeric(summary, 'total_revenue', 0)
                st.metric("Total Revenue", f"${revenue:,.2f}")
            
            with col2:
                spend = self._safe_get_numeric(summary, 'total_spend', 0)
                st.metric("Total Ad Spend", f"${spend:,.2f}")
            
            with col3:
                roas = self._safe_get_numeric(summary, 'overall_roas', 0)
                st.metric("Overall ROAS", f"{roas:.2f}x")
            
            with col4:
                conversions = self._safe_get_numeric(summary, 'total_conversions', 0)
                st.metric("Total Conversions", f"{conversions:.0f}")
            
            # Performance insights
            self._safe_display_performance_insights(analysis_data)
            
        except Exception as e:
            logger.error(f"Error in summary dashboard: {e}")
            st.error("Unable to display performance summary. Data aggregation failed.")
    
    def _safe_create_dataframe(self, data: List[Dict], data_type: str) -> pd.DataFrame:
        """Safely create DataFrame with validation"""
        try:
            if not data or not isinstance(data, list):
                return pd.DataFrame()
            
            # Filter out invalid records
            valid_data = [record for record in data if isinstance(record, dict) and record]
            
            if not valid_data:
                return pd.DataFrame()
            
            df = pd.DataFrame(valid_data)
            
            # Type conversion with error handling
            numeric_columns = {
                'campaign': ['spend', 'impressions', 'clicks', 'ctr', 'cpm', 'roas', 'conversion_rate'],
                'adset': ['spend', 'impressions', 'clicks', 'ctr', 'cpm', 'roas', 'conversion_rate'],
                'ad': ['spend', 'impressions', 'clicks', 'ctr', 'cpm', 'roas', 'conversion_rate', 'creative_score'],
                'service': ['revenue', 'transaction_count', 'average_value', 'revenue_share', 'estimated_roas']
            }
            
            for col in numeric_columns.get(data_type, []):
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)
            
            return df
            
        except Exception as e:
            logger.error(f"Error creating DataFrame for {data_type}: {e}")
            return pd.DataFrame()
    
    def _safe_create_performance_scatter(self, df: pd.DataFrame):
        """Safely create performance scatter plot"""
        try:
            if df.empty or 'spend' not in df.columns or 'roas' not in df.columns:
                st.info("Insufficient data for performance scatter plot")
                return
            
            fig = px.scatter(
                df.head(20),  # Limit to prevent overcrowding
                x='spend', 
                y='roas',
                size='attributed_revenue' if 'attributed_revenue' in df.columns else None,
                color='performance_score' if 'performance_score' in df.columns else None,
                hover_data=[col for col in ['campaign_name', 'conversion_rate', 'ctr'] if col in df.columns],
                title="Campaign Performance: Spend vs ROAS",
                labels={'spend': 'Ad Spend ($)', 'roas': 'ROAS'},
                color_continuous_scale='RdYlGn'
            )
            
            fig.add_hline(y=2.0, line_dash="dash", line_color="green", annotation_text="Target ROAS: 2.0x")
            fig.update_layout(**self.default_chart_config)
            
            st.plotly_chart(fig, use_container_width=True)
            
        except Exception as e:
            logger.error(f"Error creating performance scatter: {e}")
            st.warning("Unable to create performance scatter plot")
    
    def _safe_create_roas_comparison(self, df: pd.DataFrame):
        """Safely create ROAS comparison chart"""
        try:
            if df.empty or 'roas' not in df.columns:
                st.info("Insufficient data for ROAS comparison")
                return
            
            # Get name column
            name_col = next((col for col in ['campaign_name', 'adset_name', 'ad_name', 'service'] if col in df.columns), None)
            if not name_col:
                st.warning("No name column found for ROAS comparison")
                return
            
            top_df = df.nlargest(10, 'roas')
            
            fig = px.bar(
                top_df,
                x=name_col,
                y='roas',
                color='efficiency_rating' if 'efficiency_rating' in df.columns else None,
                title="Top Performance by ROAS",
                labels={'roas': 'ROAS'}
            )
            
            fig.add_hline(y=2.0, line_dash="dash", line_color="green")
            fig.update_xaxes(tickangle=45)
            fig.update_layout(**self.default_chart_config)
            
            st.plotly_chart(fig, use_container_width=True)
            
        except Exception as e:
            logger.error(f"Error creating ROAS comparison: {e}")
            st.warning("Unable to create ROAS comparison chart")
    
    def _safe_create_efficiency_scatter(self, df: pd.DataFrame):
        """Safely create efficiency scatter plot"""
        try:
            required_cols = ['cpc', 'conversion_rate']
            if df.empty or not all(col in df.columns for col in required_cols):
                st.info("Insufficient data for efficiency analysis")
                return
            
            # Calculate CPC if not present
            if 'cpc' not in df.columns and 'spend' in df.columns and 'clicks' in df.columns:
                df['cpc'] = df['spend'] / df['clicks'].replace(0, 1)
            
            fig = px.scatter(
                df,
                x='cpc',
                y='conversion_rate',
                size='spend' if 'spend' in df.columns else None,
                color='audience_efficiency' if 'audience_efficiency' in df.columns else None,
                hover_data=[col for col in ['adset_name', 'campaign_name', 'roas'] if col in df.columns],
                title="Ad Set Efficiency: CPC vs Conversion Rate",
                labels={'cpc': 'Cost Per Click ($)', 'conversion_rate': 'Conversion Rate (%)'},
                color_continuous_scale='Viridis'
            )
            
            fig.update_layout(**self.default_chart_config)
            st.plotly_chart(fig, use_container_width=True)
            
        except Exception as e:
            logger.error(f"Error creating efficiency scatter: {e}")
            st.warning("Unable to create efficiency analysis")
    
    def _safe_create_optimization_chart(self, df: pd.DataFrame):
        """Safely create optimization chart"""
        try:
            if df.empty or 'roas' not in df.columns:
                st.info("Insufficient data for optimization chart")
                return
            
            name_col = next((col for col in ['adset_name', 'campaign_name'] if col in df.columns), None)
            if not name_col:
                return
            
            top_df = df.nlargest(8, 'roas')
            
            fig = px.bar(
                top_df,
                x=name_col,
                y='roas',
                color='optimization_potential' if 'optimization_potential' in df.columns else None,
                title="Top Ad Sets by ROAS & Optimization Priority"
            )
            
            fig.update_xaxes(tickangle=45)
            fig.update_layout(**self.default_chart_config)
            st.plotly_chart(fig, use_container_width=True)
            
        except Exception as e:
            logger.error(f"Error creating optimization chart: {e}")
            st.warning("Unable to create optimization chart")
    
    def _safe_create_creative_scatter(self, df: pd.DataFrame):
        """Safely create creative performance scatter"""
        try:
            required_cols = ['revenue_per_impression', 'creative_score']
            if df.empty or not all(col in df.columns for col in required_cols):
                st.info("Insufficient data for creative analysis")
                return
            
            fig = px.scatter(
                df.head(20),
                x='revenue_per_impression',
                y='creative_score',
                size='spend' if 'spend' in df.columns else None,
                color='performance_tier' if 'performance_tier' in df.columns else None,
                hover_data=[col for col in ['ad_name', 'roas', 'conversion_rate'] if col in df.columns],
                title="Creative Performance: Revenue per Impression vs Creative Score"
            )
            
            fig.update_layout(**self.default_chart_config)
            st.plotly_chart(fig, use_container_width=True)
            
        except Exception as e:
            logger.error(f"Error creating creative scatter: {e}")
            st.warning("Unable to create creative performance analysis")
    
    def _safe_create_top_ads_chart(self, df: pd.DataFrame):
        """Safely create top ads chart"""
        try:
            if df.empty or 'creative_score' not in df.columns:
                st.info("Insufficient data for top ads chart")
                return
            
            name_col = 'ad_name' if 'ad_name' in df.columns else df.columns[0]
            top_ads = df.nlargest(10, 'creative_score')
            
            fig = px.bar(
                top_ads,
                x=name_col,
                y='creative_score',
                color='scaling_potential' if 'scaling_potential' in df.columns else None,
                title="Top 10 Ad Creatives by Performance Score"
            )
            
            fig.update_xaxes(tickangle=45)
            fig.update_layout(**self.default_chart_config)
            st.plotly_chart(fig, use_container_width=True)
            
        except Exception as e:
            logger.error(f"Error creating top ads chart: {e}")
            st.warning("Unable to create top ads visualization")
    
    def _safe_create_service_pie_chart(self, df: pd.DataFrame):
        """Safely create service revenue pie chart"""
        try:
            if df.empty or 'revenue' not in df.columns:
                st.info("Insufficient data for service breakdown")
                return
            
            name_col = 'service' if 'service' in df.columns else df.columns[0]
            
            fig = px.pie(
                df,
                values='revenue',
                names=name_col,
                title="Revenue Distribution by Service/Treatment",
                color_discrete_sequence=px.colors.qualitative.Set3
            )
            
            fig.update_layout(**self.default_chart_config)
            st.plotly_chart(fig, use_container_width=True)
            
        except Exception as e:
            logger.error(f"Error creating service pie chart: {e}")
            st.warning("Unable to create service breakdown")
    
    def _safe_create_service_roas_chart(self, df: pd.DataFrame):
        """Safely create service ROAS chart"""
        try:
            if df.empty or 'estimated_roas' not in df.columns:
                st.info("Insufficient data for service ROAS analysis")
                return
            
            name_col = 'service' if 'service' in df.columns else df.columns[0]
            top_services = df.nlargest(8, 'estimated_roas')
            
            fig = px.bar(
                top_services,
                x=name_col,
                y='estimated_roas',
                color='optimization_priority' if 'optimization_priority' in df.columns else None,
                title="Service ROAS & Optimization Priority"
            )
            
            fig.add_hline(y=2.0, line_dash="dash", line_color="green", annotation_text="Target ROAS")
            fig.update_xaxes(tickangle=45)
            fig.update_layout(**self.default_chart_config)
            st.plotly_chart(fig, use_container_width=True)
            
        except Exception as e:
            logger.error(f"Error creating service ROAS chart: {e}")
            st.warning("Unable to create service ROAS analysis")
    
    def _safe_display_campaign_table(self, df: pd.DataFrame):
        """Safely display campaign performance table"""
        try:
            if df.empty:
                return
            
            st.markdown("#### Campaign Performance Details")
            
            # Select available columns
            available_cols = [col for col in [
                'campaign_name', 'spend', 'attributed_revenue', 'roas', 
                'ctr', 'conversion_rate', 'cost_per_conversion', 
                'performance_score', 'efficiency_rating'
            ] if col in df.columns]
            
            if not available_cols:
                st.warning("No suitable columns found for campaign table")
                return
            
            display_df = df[available_cols].copy()
            
            # Safe formatting
            for col in ['spend', 'attributed_revenue', 'cost_per_conversion']:
                if col in display_df.columns:
                    display_df[col] = display_df[col].apply(lambda x: f"${x:,.2f}" if pd.notnull(x) else "$0.00")
            
            for col in ['roas']:
                if col in display_df.columns:
                    display_df[col] = display_df[col].apply(lambda x: f"{x:.2f}x" if pd.notnull(x) else "0.00x")
            
            for col in ['ctr', 'conversion_rate']:
                if col in display_df.columns:
                    display_df[col] = display_df[col].apply(lambda x: f"{x:.2f}%" if pd.notnull(x) else "0.00%")
            
            if 'performance_score' in display_df.columns:
                display_df['performance_score'] = display_df['performance_score'].apply(lambda x: f"{x:.1f}" if pd.notnull(x) else "0.0")
            
            st.dataframe(display_df, use_container_width=True)
            
        except Exception as e:
            logger.error(f"Error displaying campaign table: {e}")
            st.warning("Unable to display campaign performance table")
    
    def _safe_display_performance_tiers(self, df: pd.DataFrame):
        """Safely display performance tier breakdown"""
        try:
            if df.empty or 'performance_tier' not in df.columns:
                return
            
            tier_counts = df['performance_tier'].value_counts()
            cols = st.columns(min(4, len(tier_counts)))
            
            for i, (tier, count) in enumerate(tier_counts.items()):
                if i < len(cols):
                    with cols[i]:
                        st.metric(str(tier), int(count))
                        
        except Exception as e:
            logger.error(f"Error displaying performance tiers: {e}")
    
    def _safe_get_numeric(self, data: Dict, key: str, default: float = 0.0) -> float:
        """Safely extract numeric value from dictionary"""
        try:
            value = data.get(key, default)
            return float(value) if value is not None else default
        except (ValueError, TypeError):
            return default
    
    def _safe_display_adset_table(self, df: pd.DataFrame):
        """Safely display ad set table"""
        try:
            if df.empty:
                return
            
            st.markdown("#### Ad Set Performance & Optimization")
            
            available_cols = [col for col in [
                'adset_name', 'campaign_name', 'spend', 'roas', 'ctr', 
                'cpc', 'conversion_rate', 'audience_efficiency', 'optimization_potential'
            ] if col in df.columns]
            
            if available_cols:
                display_df = df[available_cols].head(20).copy()
                
                # Format numeric columns safely
                for col in ['spend', 'cpc']:
                    if col in display_df.columns:
                        display_df[col] = display_df[col].apply(lambda x: f"${x:,.2f}" if pd.notnull(x) else "$0.00")
                
                st.dataframe(display_df, use_container_width=True)
            
        except Exception as e:
            logger.error(f"Error displaying ad set table: {e}")
    
    def _safe_display_ad_table_with_filters(self, df: pd.DataFrame):
        """Safely display ad table with filters"""
        try:
            if df.empty:
                return
            
            st.markdown("#### Individual Ad Performance Details")
            
            # Add filters with error handling
            col1, col2, col3 = st.columns(3)
            
            filtered_df = df.copy()
            
            with col1:
                if 'performance_tier' in df.columns:
                    tiers = ['All'] + list(df['performance_tier'].dropna().unique())
                    tier_filter = st.selectbox("Performance Tier", tiers)
                    if tier_filter != 'All':
                        filtered_df = filtered_df[filtered_df['performance_tier'] == tier_filter]
            
            with col2:
                if 'scaling_potential' in df.columns:
                    potentials = ['All'] + list(df['scaling_potential'].dropna().unique())
                    scaling_filter = st.selectbox("Scaling Potential", potentials)
                    if scaling_filter != 'All':
                        filtered_df = filtered_df[filtered_df['scaling_potential'] == scaling_filter]
            
            with col3:
                if 'spend' in df.columns:
                    min_spend = st.number_input("Minimum Spend", min_value=0.0, value=0.0, step=10.0)
                    filtered_df = filtered_df[filtered_df['spend'] >= min_spend]
            
            # Display filtered table
            available_cols = [col for col in [
                'ad_name', 'campaign_name', 'spend', 'attributed_revenue', 'roas',
                'ctr', 'conversion_rate', 'cost_per_conversion', 'creative_score',
                'performance_tier', 'scaling_potential'
            ] if col in filtered_df.columns]
            
            if available_cols and not filtered_df.empty:
                display_df = filtered_df[available_cols].head(50)
                st.dataframe(display_df, use_container_width=True, height=400)
            else:
                st.info("No ads match the selected filters")
            
        except Exception as e:
            logger.error(f"Error displaying ad table: {e}")
    
    def _safe_display_service_metrics(self, df: pd.DataFrame, service_analysis: Dict):
        """Safely display service metrics"""
        try:
            st.markdown("#### Service Performance Metrics")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if not df.empty and 'revenue' in df.columns:
                    top_revenue = df.loc[df['revenue'].idxmax()]
                    service_name = str(top_revenue.get('service', 'Unknown'))[:20]
                    revenue_val = self._safe_get_numeric(top_revenue, 'revenue', 0)
                    share_val = self._safe_get_numeric(top_revenue, 'revenue_share', 0)
                    st.metric("Top Revenue Generator", service_name, f"${revenue_val:,.0f} ({share_val:.1f}%)")
            
            with col2:
                if not df.empty and 'average_value' in df.columns:
                    high_value = df.loc[df['average_value'].idxmax()]
                    service_name = str(high_value.get('service', 'Unknown'))[:20]
                    avg_val = self._safe_get_numeric(high_value, 'average_value', 0)
                    st.metric("Highest Average Value", service_name, f"${avg_val:,.0f}")
            
            with col3:
                if not df.empty and 'estimated_roas' in df.columns:
                    best_roas = df.loc[df['estimated_roas'].idxmax()]
                    service_name = str(best_roas.get('service', 'Unknown'))[:20]
                    roas_val = self._safe_get_numeric(best_roas, 'estimated_roas', 0)
                    st.metric("Best ROAS", service_name, f"{roas_val:.2f}x")
            
        except Exception as e:
            logger.error(f"Error displaying service metrics: {e}")
    
    def _safe_display_service_table(self, df: pd.DataFrame):
        """Safely display service table"""
        try:
            if df.empty:
                return
            
            display_df = df.copy()
            
            # Safe formatting
            for col in ['revenue', 'average_value']:
                if col in display_df.columns:
                    display_df[col] = display_df[col].apply(lambda x: f"${x:,.2f}" if pd.notnull(x) else "$0.00")
            
            if 'revenue_share' in display_df.columns:
                display_df['revenue_share'] = display_df['revenue_share'].apply(lambda x: f"{x:.1f}%" if pd.notnull(x) else "0.0%")
            
            if 'estimated_roas' in display_df.columns:
                display_df['estimated_roas'] = display_df['estimated_roas'].apply(lambda x: f"{x:.2f}x" if pd.notnull(x) else "0.00x")
            
            st.dataframe(display_df, use_container_width=True)
            
        except Exception as e:
            logger.error(f"Error displaying service table: {e}")
    
    def _safe_display_service_insights(self, service_analysis: Dict):
        """Safely display service insights"""
        try:
            insights = service_analysis.get('insights', [])
            if insights:
                st.markdown("#### Strategic Insights & Recommendations")
                for i, insight in enumerate(insights, 1):
                    if isinstance(insight, str) and insight.strip():
                        st.markdown(f"**{i}.** {insight}")
        except Exception as e:
            logger.error(f"Error displaying service insights: {e}")
    
    def _safe_display_performance_insights(self, analysis_data: Dict):
        """Safely display performance insights"""
        try:
            campaigns = analysis_data.get('campaign_analysis', [])
            ads = analysis_data.get('ad_analysis', [])
            
            if campaigns and ads:
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("#### Top Performing Elements")
                    
                    # Best campaign
                    best_campaign = max(campaigns, key=lambda x: self._safe_get_numeric(x, 'roas', 0))
                    campaign_name = str(best_campaign.get('campaign_name', 'N/A'))[:30]
                    campaign_roas = self._safe_get_numeric(best_campaign, 'roas', 0)
                    st.markdown(f"**Best Campaign:** {campaign_name} ({campaign_roas:.2f}x ROAS)")
                    
                    # Best ad
                    best_ad = max(ads, key=lambda x: self._safe_get_numeric(x, 'creative_score', 0))
                    ad_name = str(best_ad.get('ad_name', 'N/A'))[:30]
                    ad_score = self._safe_get_numeric(best_ad, 'creative_score', 0)
                    st.markdown(f"**Best Ad Creative:** {ad_name} ({ad_score:.1f} score)")
                    
                    # Performance distribution
                    excellent_campaigns = len([c for c in campaigns if c.get('efficiency_rating') == 'Excellent'])
                    st.markdown(f"**Excellent Campaigns:** {excellent_campaigns}/{len(campaigns)}")
                
                with col2:
                    st.markdown("#### Optimization Opportunities")
                    
                    # Scaling opportunities
                    scalable_ads = len([a for a in ads if 'High' in str(a.get('scaling_potential', ''))])
                    st.markdown(f"**Ready to Scale:** {scalable_ads} ads identified")
                    
                    # Underperformers
                    underperformers = len([c for c in campaigns if self._safe_get_numeric(c, 'roas', 0) < 1.0])
                    st.markdown(f"**Need Optimization:** {underperformers} campaigns below breakeven")
                    
                    # High potential
                    high_score_ads = len([a for a in ads if self._safe_get_numeric(a, 'creative_score', 0) > 70])
                    st.markdown(f"**High Performers:** {high_score_ads} top-scoring ads")
        
        except Exception as e:
            logger.error(f"Error displaying performance insights: {e}")