
import os
import streamlit as st
import pandas as pd
from pyairtable import Api
import time

# Set page config
st.set_page_config(page_title="Airtable Connection Test", layout="wide")

# Function to test Airtable connection
def test_airtable_connection(api_key, base_id, table_name):
    """Test connection to Airtable"""
    try:
        start_time = time.time()
        st.info(f"Attempting to connect to Airtable: {base_id}/{table_name}")
        
        # Initialize API
        api = Api(api_key)
        
        # Get table
        table = api.table(base_id, table_name)
        
        # Test with a limited query first
        records = table.all(max_records=5)
        
        elapsed = time.time() - start_time
        
        if records:
            st.success(f"✅ Connection successful! Retrieved {len(records)} sample records in {elapsed:.2f}s")
            
            # Show record details for debugging
            st.write("Sample record fields:", list(records[0]['fields'].keys()))
            
            return True
        else:
            st.warning(f"⚠️ Connection successful but no records found in table (took {elapsed:.2f}s)")
            return True
            
    except Exception as e:
        st.error(f"❌ Connection failed: {str(e)}")
        st.info("Troubleshooting tips:")
        st.info("1. Check your API key - make sure it's valid and has access to the table")
        st.info("2. Verify the Base ID is correct")
        st.info("3. Confirm the table name matches exactly (case sensitive)")
        return False

# Create sidebar for settings
st.sidebar.title("Airtable Connection Settings")

api_key = st.sidebar.text_input("Airtable API Key", type="password")
base_id = st.sidebar.text_input("Base ID", value="appri2CgCoIiuZWq3")
table_name = st.sidebar.text_input("Table Name", value="Leads")

# Main page
st.title("Airtable Connection Test")
st.write("This utility tests your connection to Airtable and helps diagnose any issues.")

if st.button("Test Connection"):
    if not api_key or not base_id or not table_name:
        st.error("Please provide all required fields")
    else:
        success = test_airtable_connection(api_key, base_id, table_name)
        
        if success:
            st.info("Now trying to retrieve all records...")
            try:
                api = Api(api_key)
                table = api.table(base_id, table_name)
                all_records = table.all()
                
                st.success(f"✅ Successfully retrieved all {len(all_records)} records!")
                
                # Try to convert to dataframe
                st.info("Converting to DataFrame...")
                data = []
                for r in all_records:
                    try:
                        item = r['fields'].copy()
                        item['id'] = r['id']
                        data.append(item)
                    except Exception as e:
                        st.error(f"Error processing record: {str(e)}")
                
                df = pd.DataFrame(data)
                st.success(f"✅ Successfully created DataFrame with shape: {df.shape}")
                
                # Show sample of data
                st.write("Sample data:")
                st.dataframe(df.head())
                
            except Exception as e:
                st.error(f"❌ Error retrieving all records: {str(e)}")

st.markdown("---")
st.info("If all tests pass but the main application still has issues, check the data_storage.py file for any issues with caching or validation.")
