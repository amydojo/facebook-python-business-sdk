
"""
Airtable Connection Fixer
This script diagnoses and fixes common Airtable authentication issues
"""
import os
import streamlit as st
import requests
from pyairtable import Api
import time
import json

def fix_airtable_connection():
    st.set_page_config(page_title="Airtable Connection Fixer", layout="wide")
    st.title("🔧 Airtable Connection Fixer")
    
    # Get credentials
    with st.sidebar:
        st.header("Connection Settings")
        api_key = st.text_input("Airtable API Key", type="password", 
                              help="Your Airtable Personal Access Token (PAT)")
        
        base_id = st.text_input("Base ID", value="appri2CgCoIiuZWq3",
                             help="Your Airtable base ID (from URL)")
        
        table_name = st.text_input("Table Name", value="Leads",
                                help="Name of table to query (case sensitive)")
        
        if st.button("Save to Session"):
            st.session_state.api_key = api_key
            st.session_state.base_id = base_id
            st.session_state.leads_table_name = table_name
            st.success("Saved to session!")
    
    # Check API key format
    if api_key:
        if api_key.startswith("pat"):
            st.success("✅ API key format looks correct (Personal Access Token)")
        elif api_key.startswith("key"):
            st.warning("⚠️ Using legacy API key format - consider upgrading to Personal Access Token")
        else:
            st.error("❌ API key format doesn't match expected patterns")
            st.info("Airtable API keys should start with 'pat' (new format) or 'key' (legacy format)")
    
    # Test connection tab
    tab1, tab2, tab3 = st.tabs(["Basic Test", "Advanced Test", "Fix Connection"])
    
    with tab1:
        st.header("Basic Connection Test")
        
        if st.button("Test Basic Connection"):
            if not api_key or not base_id or not table_name:
                st.error("Please provide API key, base ID, and table name")
                return
            
            # Direct HTTP request test
            st.subheader("Direct HTTP Request")
            try:
                url = f"https://api.airtable.com/v0/{base_id}/{table_name}"
                headers = {
                    'Authorization': f'Bearer {api_key}',
                    'Content-Type': 'application/json'
                }
                
                with st.spinner("Testing direct HTTP connection..."):
                    response = requests.get(url, headers=headers, params={'maxRecords': 1})
                
                if response.status_code == 200:
                    st.success(f"✅ Connection successful! (Status: {response.status_code})")
                    data = response.json()
                    if 'records' in data and len(data['records']) > 0:
                        st.write(f"Retrieved {len(data['records'])} record(s)")
                        with st.expander("View sample record"):
                            st.json(data['records'][0])
                    else:
                        st.info("Table exists but no records found")
                elif response.status_code == 401:
                    st.error(f"❌ Unauthorized: Invalid API key (Status: {response.status_code})")
                    st.info("Fix: Check that your API key is correct and has access to this base")
                elif response.status_code == 404:
                    st.error(f"❌ Not Found: Base ID or table name incorrect (Status: {response.status_code})")
                    st.info("Fix: Verify your base ID and table name")
                else:
                    st.error(f"❌ Connection failed (Status: {response.status_code})")
                    st.code(response.text)
            except Exception as e:
                st.error(f"❌ Connection error: {str(e)}")
    
    with tab2:
        st.header("Advanced Diagnostics")
        
        if st.button("Run Advanced Tests"):
            if not api_key or not base_id or not table_name:
                st.error("Please provide API key, base ID, and table name")
                return
            
            # Test API limits
            st.subheader("Rate Limiting Test")
            try:
                success_count = 0
                rate_limit_hit = False
                
                with st.spinner("Testing rate limits..."):
                    for i in range(5):
                        url = f"https://api.airtable.com/v0/{base_id}/{table_name}"
                        headers = {'Authorization': f'Bearer {api_key}'}
                        response = requests.get(url, headers=headers, params={'maxRecords': 1})
                        
                        if response.status_code == 200:
                            success_count += 1
                        elif response.status_code == 429:
                            st.warning(f"⚠️ Rate limit hit on request {i+1}")
                            rate_limit_hit = True
                            break
                        time.sleep(0.2)  # Small delay between requests
                
                if success_count == 5:
                    st.success("✅ Rate limit test passed (5/5 successful requests)")
                elif success_count > 0:
                    st.warning(f"⚠️ Partial success: {success_count}/5 requests succeeded")
                    if rate_limit_hit:
                        st.info("You hit Airtable's rate limit (5 requests/second). Add delays between requests.")
                else:
                    st.error("❌ All requests failed!")
            
            except Exception as e:
                st.error(f"❌ Rate limit test error: {str(e)}")
            
            # Test metadata access
            st.subheader("Table Schema Test")
            try:
                schema_url = f"https://api.airtable.com/v0/meta/bases/{base_id}/tables"
                headers = {'Authorization': f'Bearer {api_key}'}
                
                with st.spinner("Retrieving table schema..."):
                    response = requests.get(schema_url, headers=headers)
                
                if response.status_code == 200:
                    st.success("✅ Schema access successful!")
                    schema = response.json()
                    
                    # Find our table
                    found_tables = []
                    for table in schema.get('tables', []):
                        found_tables.append(table['name'])
                        if table['name'] == table_name:
                            st.write(f"✅ Found table: {table_name}")
                            with st.expander("View table schema"):
                                st.json(table)
                            break
                    else:
                        st.error(f"❌ Table '{table_name}' not found in schema!")
                        st.write("Available tables:")
                        for name in found_tables:
                            st.write(f"- {name}")
                
                elif response.status_code == 401:
                    st.error("❌ Unauthorized: API key doesn't have schema access permission")
                    st.info("Fix: Make sure your API key has 'data.records:read' and 'schema.bases:read' scopes")
                else:
                    st.error(f"❌ Schema access failed: {response.status_code}")
                    st.code(response.text)
            except Exception as e:
                st.error(f"❌ Schema test error: {str(e)}")
            
            # Test PyAirtable
            st.subheader("PyAirtable Library Test")
            try:
                with st.spinner("Testing PyAirtable library..."):
                    api = Api(api_key)
                    table = api.table(base_id, table_name)
                    records = table.all(max_records=1)
                
                st.success(f"✅ PyAirtable connection successful! Retrieved {len(records)} record(s)")
                if records:
                    with st.expander("View sample record"):
                        st.json(records[0])
            except Exception as e:
                st.error(f"❌ PyAirtable error: {str(e)}")
                st.code(f"Error type: {type(e).__name__}")
                
                if "401" in str(e):
                    st.info("Fix: Your API key is invalid or doesn't have access to this base")
                elif "404" in str(e):
                    st.info("Fix: The base ID or table name is incorrect")
    
    with tab3:
        st.header("Fix Connection")
        
        st.info("Common issues and solutions:")
        
        with st.expander("1. Invalid API Key"):
            st.write("""
            **Problem**: 401 Unauthorized errors indicate an invalid API key or insufficient permissions.
            
            **Solution**:
            1. Generate a new Personal Access Token (PAT) in Airtable
            2. Ensure it has the correct scopes:
               - `data.records:read`
               - `schema.bases:read`
            3. Enter the new PAT in the sidebar
            """)
        
        with st.expander("2. Incorrect Base ID or Table Name"):
            st.write("""
            **Problem**: 404 Not Found errors indicate incorrect base ID or table name.
            
            **Solution**:
            1. Check your Airtable base URL: `https://airtable.com/{BASE_ID}/{TABLE_ID}/...`
            2. Confirm the table name is exact (case-sensitive)
            3. Try retrieving the schema to see all available tables
            """)
        
        with st.expander("3. Rate Limiting Issues"):
            st.write("""
            **Problem**: 429 Too Many Requests indicates you've hit Airtable's rate limits.
            
            **Solution**:
            1. Add delays between requests (0.2-1 second)
            2. Implement caching in your application
            3. Add exponential backoff for retries
            """)
        
        with st.expander("4. Fix in code"):
            st.code("""
# Example connection with retry logic
def get_airtable_data(api_key, base_id, table_name, max_retries=3):
    api = Api(api_key)
    table = api.table(base_id, table_name)
    
    retries = 0
    while retries < max_retries:
        try:
            records = table.all()
            return records
        except Exception as e:
            if "429" in str(e):  # Rate limit
                sleep_time = (2 ** retries) * 0.5  # Exponential backoff
                time.sleep(sleep_time)
                retries += 1
            else:
                raise  # Re-raise other errors
    
    raise Exception("Max retries exceeded")
            """, language="python")
        
        # Save connection details to file
        if st.button("Save Connection Details to File"):
            try:
                connection_info = {
                    "api_key": api_key,
                    "base_id": base_id,
                    "leads_table_name": table_name
                }
                
                with open('.credentials.json', 'w') as f:
                    json.dump(connection_info, f)
                
                st.success("✅ Connection details saved to .credentials.json!")
                st.info("Your API key is saved securely and will be used by the app")
            except Exception as e:
                st.error(f"Failed to save connection details: {str(e)}")

if __name__ == "__main__":
    fix_airtable_connection()
