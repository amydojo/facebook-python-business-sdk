"""
Key-Value Store Cache Manager
Intelligent caching system using Replit's built-in database for enhanced performance
"""

import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
import hashlib
import logging
from dataclasses import dataclass, asdict

# Import Replit's Key-Value Store
try:
    from replit import db
    KV_AVAILABLE = True
except ImportError:
    # Fallback for development/testing
    KV_AVAILABLE = False
    class MockDB:
        def __init__(self):
            self._data = {}
        def __setitem__(self, key, value):
            self._data[key] = value
        def __getitem__(self, key):
            return self._data[key]
        def get(self, key, default=None):
            return self._data.get(key, default)
        def __contains__(self, key):
            return key in self._data
        def __delitem__(self, key):
            if key in self._data:
                del self._data[key]
        def prefix(self, prefix_str):
            return [k for k in self._data.keys() if k.startswith(prefix_str)]
        def keys(self):
            return self._data.keys()
    db = MockDB()

logger = logging.getLogger(__name__)

@dataclass
class CacheEntry:
    """Cache entry with metadata for intelligent management"""
    data: Any
    timestamp: float
    ttl_seconds: int
    source: str
    data_hash: str
    access_count: int = 0
    last_access: float = None

class KVCacheManager:
    """Advanced cache manager using Replit's Key-Value Store"""
    
    def __init__(self):
        self.enabled = KV_AVAILABLE
        self.default_ttl = 300  # 5 minutes default
        self.cache_stats = {
            'hits': 0,
            'misses': 0,
            'writes': 0,
            'evictions': 0
        }
        
        # Initialize cache metadata if not exists
        if not self._get_cache_metadata():
            self._init_cache_metadata()
    
    def _get_cache_key(self, namespace: str, key: str) -> str:
        """Generate standardized cache key"""
        return f"cache:{namespace}:{key}"
    
    def _get_metadata_key(self) -> str:
        """Get cache metadata key"""
        return "cache:metadata"
    
    def _get_cache_metadata(self) -> Dict:
        """Get cache metadata"""
        if not self.enabled:
            return {}
        return db.get(self._get_metadata_key(), {})
    
    def _update_cache_metadata(self, metadata: Dict):
        """Update cache metadata"""
        if self.enabled:
            db[self._get_metadata_key()] = metadata
    
    def _init_cache_metadata(self):
        """Initialize cache metadata"""
        metadata = {
            'created_at': time.time(),
            'total_entries': 0,
            'last_cleanup': time.time(),
            'stats': self.cache_stats.copy()
        }
        self._update_cache_metadata(metadata)
    
    def _calculate_data_hash(self, data: Any) -> str:
        """Calculate hash of data for change detection"""
        try:
            data_str = json.dumps(data, sort_keys=True, default=str)
            return hashlib.md5(data_str.encode()).hexdigest()
        except Exception:
            return str(hash(str(data)))
    
    def set(self, namespace: str, key: str, data: Any, 
            ttl_seconds: Optional[int] = None, source: str = "unknown") -> bool:
        """Store data in cache with intelligent metadata"""
        
        if not self.enabled:
            return False
        
        try:
            cache_key = self._get_cache_key(namespace, key)
            ttl = ttl_seconds or self.default_ttl
            
            # Create cache entry
            entry = CacheEntry(
                data=data,
                timestamp=time.time(),
                ttl_seconds=ttl,
                source=source,
                data_hash=self._calculate_data_hash(data),
                access_count=0,
                last_access=time.time()
            )
            
            # Store in KV database
            db[cache_key] = asdict(entry)
            
            # Update metadata
            metadata = self._get_cache_metadata()
            metadata['total_entries'] = metadata.get('total_entries', 0) + 1
            metadata['stats']['writes'] = metadata['stats'].get('writes', 0) + 1
            self._update_cache_metadata(metadata)
            
            self.cache_stats['writes'] += 1
            logger.info(f"Cached data: {namespace}:{key} (TTL: {ttl}s)")
            return True
            
        except Exception as e:
            logger.error(f"Cache set error: {e}")
            return False
    
    def get(self, namespace: str, key: str) -> Optional[Any]:
        """Retrieve data from cache with automatic expiration"""
        
        if not self.enabled:
            return None
        
        try:
            cache_key = self._get_cache_key(namespace, key)
            
            if cache_key not in db:
                self.cache_stats['misses'] += 1
                return None
            
            entry_dict = db[cache_key]
            entry = CacheEntry(**entry_dict)
            
            # Check if expired
            if self._is_expired(entry):
                self._evict_entry(cache_key)
                self.cache_stats['misses'] += 1
                return None
            
            # Update access statistics
            entry.access_count += 1
            entry.last_access = time.time()
            db[cache_key] = asdict(entry)
            
            self.cache_stats['hits'] += 1
            logger.debug(f"Cache hit: {namespace}:{key}")
            return entry.data
            
        except Exception as e:
            logger.error(f"Cache get error: {e}")
            self.cache_stats['misses'] += 1
            return None
    
    def _is_expired(self, entry: CacheEntry) -> bool:
        """Check if cache entry is expired"""
        return time.time() - entry.timestamp > entry.ttl_seconds
    
    def _evict_entry(self, cache_key: str):
        """Remove expired entry from cache"""
        try:
            if cache_key in db:
                del db[cache_key]
                self.cache_stats['evictions'] += 1
                logger.debug(f"Evicted expired cache entry: {cache_key}")
        except Exception as e:
            logger.error(f"Cache eviction error: {e}")
    
    def invalidate(self, namespace: str, key: Optional[str] = None) -> int:
        """Invalidate cache entries by namespace or specific key"""
        
        if not self.enabled:
            return 0
        
        evicted_count = 0
        
        try:
            if key:
                # Invalidate specific key
                cache_key = self._get_cache_key(namespace, key)
                if cache_key in db:
                    del db[cache_key]
                    evicted_count = 1
            else:
                # Invalidate entire namespace
                prefix = f"cache:{namespace}:"
                for cache_key in db.prefix(prefix):
                    del db[cache_key]
                    evicted_count += 1
            
            self.cache_stats['evictions'] += evicted_count
            logger.info(f"Invalidated {evicted_count} cache entries for {namespace}")
            
        except Exception as e:
            logger.error(f"Cache invalidation error: {e}")
        
        return evicted_count
    
    def cleanup_expired(self) -> int:
        """Remove all expired cache entries"""
        
        if not self.enabled:
            return 0
        
        evicted_count = 0
        
        try:
            # Get all cache keys
            cache_keys = [k for k in db.keys() if str(k).startswith("cache:") and k != self._get_metadata_key()]
            
            for cache_key in cache_keys:
                try:
                    entry_dict = db[cache_key]
                    entry = CacheEntry(**entry_dict)
                    
                    if self._is_expired(entry):
                        del db[cache_key]
                        evicted_count += 1
                        
                except Exception:
                    # Invalid entry, remove it
                    del db[cache_key]
                    evicted_count += 1
            
            # Update metadata
            metadata = self._get_cache_metadata()
            metadata['last_cleanup'] = time.time()
            metadata['total_entries'] = max(0, metadata.get('total_entries', 0) - evicted_count)
            self._update_cache_metadata(metadata)
            
            self.cache_stats['evictions'] += evicted_count
            logger.info(f"Cleaned up {evicted_count} expired cache entries")
            
        except Exception as e:
            logger.error(f"Cache cleanup error: {e}")
        
        return evicted_count
    
    def get_stats(self) -> Dict[str, Any]:
        """Get comprehensive cache statistics"""
        
        total_requests = self.cache_stats['hits'] + self.cache_stats['misses']
        hit_rate = (self.cache_stats['hits'] / total_requests * 100) if total_requests > 0 else 0
        
        metadata = self._get_cache_metadata()
        
        return {
            'enabled': self.enabled,
            'hit_rate_percentage': round(hit_rate, 2),
            'total_requests': total_requests,
            'cache_hits': self.cache_stats['hits'],
            'cache_misses': self.cache_stats['misses'],
            'cache_writes': self.cache_stats['writes'],
            'cache_evictions': self.cache_stats['evictions'],
            'total_entries': metadata.get('total_entries', 0),
            'last_cleanup': metadata.get('last_cleanup', 0),
            'created_at': metadata.get('created_at', 0)
        }
    
    def smart_cache_key(self, base_key: str, **params) -> str:
        """Generate intelligent cache key based on parameters"""
        
        # Sort parameters for consistent key generation
        sorted_params = sorted(params.items())
        param_str = "_".join(f"{k}:{v}" for k, v in sorted_params)
        
        if param_str:
            return f"{base_key}_{param_str}"
        return base_key
    
    def cache_with_fallback(self, namespace: str, key: str, 
                           fetch_function: callable, ttl_seconds: Optional[int] = None,
                           force_refresh: bool = False) -> Any:
        """Cache with automatic fallback to fetch function"""
        
        # Check cache first (unless forced refresh)
        if not force_refresh:
            cached_data = self.get(namespace, key)
            if cached_data is not None:
                return cached_data
        
        # Fetch fresh data
        try:
            fresh_data = fetch_function()
            if fresh_data is not None:
                self.set(namespace, key, fresh_data, ttl_seconds, source="fetch_function")
            return fresh_data
        except Exception as e:
            logger.error(f"Fetch function error: {e}")
            # Return cached data even if expired as last resort
            if not force_refresh:
                return self.get(namespace, key)
            return None
    
    def batch_set(self, namespace: str, data_dict: Dict[str, Any], 
                  ttl_seconds: Optional[int] = None, source: str = "batch") -> int:
        """Batch store multiple entries efficiently"""
        
        success_count = 0
        for key, data in data_dict.items():
            if self.set(namespace, key, data, ttl_seconds, source):
                success_count += 1
        
        logger.info(f"Batch cached {success_count}/{len(data_dict)} entries in {namespace}")
        return success_count
    
    def get_cache_size(self) -> Dict[str, int]:
        """Get cache size information"""
        
        if not self.enabled:
            return {'total_keys': 0, 'cache_keys': 0}
        
        try:
            all_keys = list(db.keys())
            cache_keys = [k for k in all_keys if str(k).startswith("cache:")]
            
            return {
                'total_keys': len(all_keys),
                'cache_keys': len(cache_keys)
            }
            
        except Exception as e:
            logger.error(f"Cache size calculation error: {e}")
            return {'total_keys': 0, 'cache_keys': 0}

# Global cache manager instance
cache_manager = KVCacheManager()

# Convenience functions for common operations
def cache_transactions(date_range: str, transactions: List[Dict], ttl: int = 600) -> bool:
    """Cache transaction data with date range key"""
    key = cache_manager.smart_cache_key("transactions", date_range=date_range)
    return cache_manager.set("airtable", key, transactions, ttl, "transactions_api")

def get_cached_transactions(date_range: str) -> Optional[List[Dict]]:
    """Get cached transaction data"""
    key = cache_manager.smart_cache_key("transactions", date_range=date_range)
    return cache_manager.get("airtable", key)

def cache_leads(date_range: str, leads: List[Dict], ttl: int = 600) -> bool:
    """Cache lead data with date range key"""
    key = cache_manager.smart_cache_key("leads", date_range=date_range)
    return cache_manager.set("airtable", key, leads, ttl, "leads_api")

def get_cached_leads(date_range: str) -> Optional[List[Dict]]:
    """Get cached lead data"""
    key = cache_manager.smart_cache_key("leads", date_range=date_range)
    return cache_manager.get("airtable", key)

def cache_meta_insights(date_range: str, insights: Dict, ttl: int = 300) -> bool:
    """Cache Meta insights data"""
    key = cache_manager.smart_cache_key("meta_insights", date_range=date_range)
    return cache_manager.set("meta", key, insights, ttl, "meta_api")

def get_cached_meta_insights(date_range: str) -> Optional[Dict]:
    """Get cached Meta insights data"""
    key = cache_manager.smart_cache_key("meta_insights", date_range=date_range)
    return cache_manager.get("meta", key)

def invalidate_date_range_cache(date_range: str):
    """Invalidate all cached data for a specific date range"""
    evicted = 0
    evicted += cache_manager.invalidate("airtable", cache_manager.smart_cache_key("transactions", date_range=date_range))
    evicted += cache_manager.invalidate("airtable", cache_manager.smart_cache_key("leads", date_range=date_range))
    evicted += cache_manager.invalidate("meta", cache_manager.smart_cache_key("meta_insights", date_range=date_range))
    return evicted

# Export for use in other modules
__all__ = [
    'KVCacheManager', 'cache_manager', 'CacheEntry',
    'cache_transactions', 'get_cached_transactions',
    'cache_leads', 'get_cached_leads',
    'cache_meta_insights', 'get_cached_meta_insights',
    'invalidate_date_range_cache'
]