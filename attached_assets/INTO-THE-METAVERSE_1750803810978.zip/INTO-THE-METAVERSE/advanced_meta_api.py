"""
Ultra Godmode Meta Marketing API Implementation
Advanced strategic analysis with comprehensive metrics and beautiful user-centered design
"""
import requests
import json
import time
import pandas as pd
import streamlit as st
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

class UltraMetaAPI:
    """Advanced Meta Marketing API with strategic analysis capabilities"""
    
    def __init__(self, access_token: str, ad_account_id: str):
        self.access_token = access_token
        self.ad_account_id = ad_account_id if ad_account_id.startswith('act_') else f"act_{ad_account_id}"
        self.base_url = "https://graph.facebook.com/v22.0"
        
        # Advanced metrics configuration
        self.core_metrics = [
            'impressions', 'clicks', 'ctr', 'unique_clicks', 'reach', 'frequency',
            'spend', 'cpc', 'cpm', 'cpp', 'cost_per_unique_click',
            'actions', 'action_values', 'conversions', 'conversion_values',
            'purchase_roas', 'cost_per_action_type', 'video_play_actions'
        ]
        
        self.engagement_metrics = [
            'post_engagements', 'page_engagements', 'link_clicks', 
            'post_reactions', 'comments', 'shares', 'video_views',
            'video_p25_watched_actions', 'video_p50_watched_actions',
            'video_p75_watched_actions', 'video_p100_watched_actions'
        ]
        
        self.conversion_metrics = [
            'actions', 'action_values', 'conversions', 'conversion_values',
            'cost_per_action_type', 'cost_per_conversion', 'purchase_roas'
        ]
    
    def get_ultra_account_insights(self, date_range: Dict, breakdowns: List[str] = None) -> Tuple[bool, Dict]:
        """Get comprehensive account-level insights with advanced breakdowns"""
        
        all_metrics = self.core_metrics + self.engagement_metrics + self.conversion_metrics
        unique_metrics = list(set(all_metrics))
        
        params = {
            'access_token': self.access_token,
            'level': 'account',
            'time_range': json.dumps(date_range),
            'fields': ','.join(unique_metrics),
            'limit': 1000,
            'action_attribution_windows': '1d_click,7d_click,28d_click',
            'action_report_time': 'conversion'
        }
        
        if breakdowns:
            params['breakdowns'] = ','.join(breakdowns)
        
        try:
            response = requests.get(f"{self.base_url}/{self.ad_account_id}/insights", params=params)
            
            if response.status_code == 200:
                data = response.json()
                return True, {
                    'data': data.get('data', []),
                    'summary': self._calculate_summary_metrics(data.get('data', [])),
                    'metadata': {
                        'account_id': self.ad_account_id,
                        'date_range': date_range,
                        'breakdowns': breakdowns,
                        'total_records': len(data.get('data', []))
                    }
                }
            else:
                return False, {'error': f"API Error: {response.status_code} - {response.text}"}
                
        except Exception as e:
            return False, {'error': f"Request failed: {str(e)}"}
    
    def get_campaign_hierarchy_insights(self, date_range: Dict) -> Tuple[bool, Dict]:
        """Get comprehensive insights across the entire campaign hierarchy"""
        
        hierarchy_data = {
            'campaigns': [],
            'adsets': [],
            'ads': [],
            'creatives': []
        }
        
        # Get campaign insights
        success, campaign_data = self._get_level_insights('campaign', date_range)
        if success:
            hierarchy_data['campaigns'] = campaign_data.get('data', [])
        
        # Get ad set insights
        success, adset_data = self._get_level_insights('adset', date_range)
        if success:
            hierarchy_data['adsets'] = adset_data.get('data', [])
        
        # Get ad insights
        success, ad_data = self._get_level_insights('ad', date_range)
        if success:
            hierarchy_data['ads'] = ad_data.get('data', [])
        
        # Get creative performance
        success, creative_data = self.get_creative_performance_insights(date_range)
        if success:
            hierarchy_data['creatives'] = creative_data.get('data', [])
        
        return True, {
            'hierarchy': hierarchy_data,
            'analysis': self._analyze_hierarchy_performance(hierarchy_data),
            'recommendations': self._generate_strategic_recommendations(hierarchy_data)
        }
    
    def get_advanced_breakdown_insights(self, date_range: Dict) -> Tuple[bool, Dict]:
        """Get insights with advanced breakdowns for strategic analysis"""
        
        breakdown_configs = [
            {
                'name': 'demographic_performance',
                'breakdowns': ['age', 'gender'],
                'description': 'Performance by age and gender'
            },
            {
                'name': 'device_performance', 
                'breakdowns': ['device_platform', 'platform_position'],
                'description': 'Performance by device and placement'
            },
            {
                'name': 'temporal_performance',
                'breakdowns': ['hourly_stats_aggregated_by_advertiser_time_zone'],
                'description': 'Performance by hour of day'
            },
            {
                'name': 'geographic_performance',
                'breakdowns': ['region', 'country'],
                'description': 'Performance by geographic location'
            }
        ]
        
        breakdown_results = {}
        
        for config in breakdown_configs:
            success, data = self.get_ultra_account_insights(date_range, config['breakdowns'])
            if success:
                breakdown_results[config['name']] = {
                    'data': data,
                    'description': config['description']
                }
        
        return True, {
            'breakdowns': breakdown_results,
            'insights': self._analyze_breakdown_patterns(breakdown_results)
        }
    
    def get_creative_performance_insights(self, date_range: Dict) -> Tuple[bool, Dict]:
        """Get detailed creative performance with previews and analysis"""
        
        # Get ads with creative details
        ads_params = {
            'access_token': self.access_token,
            'fields': 'id,name,adset_id,campaign_id,creative{id,name,title,body,image_url,video_id,object_story_spec},status,configured_status',
            'limit': 100
        }
        
        try:
            ads_response = requests.get(f"{self.base_url}/{self.ad_account_id}/ads", params=ads_params)
            
            if ads_response.status_code != 200:
                return False, {'error': f"Ads API Error: {ads_response.status_code}"}
            
            ads_data = ads_response.json().get('data', [])
            
            # Get performance data for these ads
            ad_ids = [ad['id'] for ad in ads_data]
            creative_performance = []
            
            # Batch process ads for performance metrics
            batch_size = 50
            for i in range(0, len(ad_ids), batch_size):
                batch_ids = ad_ids[i:i + batch_size]
                
                insights_params = {
                    'access_token': self.access_token,
                    'level': 'ad',
                    'time_range': json.dumps(date_range),
                    'fields': ','.join(self.core_metrics),
                    'filtering': json.dumps([{
                        'field': 'ad.id',
                        'operator': 'IN',
                        'value': batch_ids
                    }])
                }
                
                insights_response = requests.get(
                    f"{self.base_url}/{self.ad_account_id}/insights", 
                    params=insights_params
                )
                
                if insights_response.status_code == 200:
                    insights_data = insights_response.json().get('data', [])
                    creative_performance.extend(insights_data)
            
            # Combine creative details with performance
            enriched_creatives = self._enrich_creative_data(ads_data, creative_performance)
            
            return True, {
                'data': enriched_creatives,
                'analysis': self._analyze_creative_performance(enriched_creatives),
                'top_performers': self._identify_top_creative_performers(enriched_creatives)
            }
            
        except Exception as e:
            return False, {'error': f"Creative insights failed: {str(e)}"}
    
    def get_attribution_analysis(self, date_range: Dict) -> Tuple[bool, Dict]:
        """Advanced attribution analysis across different windows"""
        
        attribution_windows = ['1d_click', '7d_click', '28d_click', '1d_view', '7d_view']
        attribution_results = {}
        
        for window in attribution_windows:
            params = {
                'access_token': self.access_token,
                'level': 'campaign',
                'time_range': json.dumps(date_range),
                'fields': 'campaign_name,spend,actions,action_values,conversions,conversion_values',
                'action_attribution_windows': window,
                'action_report_time': 'conversion'
            }
            
            try:
                response = requests.get(f"{self.base_url}/{self.ad_account_id}/insights", params=params)
                
                if response.status_code == 200:
                    data = response.json()
                    attribution_results[window] = data.get('data', [])
                    
            except Exception as e:
                st.warning(f"Attribution analysis failed for {window}: {str(e)}")
        
        return True, {
            'attribution_data': attribution_results,
            'analysis': self._analyze_attribution_impact(attribution_results)
        }
    
    def _get_level_insights(self, level: str, date_range: Dict) -> Tuple[bool, Dict]:
        """Get insights for a specific level (campaign, adset, ad)"""
        
        params = {
            'access_token': self.access_token,
            'level': level,
            'time_range': json.dumps(date_range),
            'fields': ','.join(self.core_metrics),
            'limit': 1000
        }
        
        try:
            response = requests.get(f"{self.base_url}/{self.ad_account_id}/insights", params=params)
            
            if response.status_code == 200:
                return True, response.json()
            else:
                return False, {'error': f"{level} insights failed: {response.status_code}"}
                
        except Exception as e:
            return False, {'error': f"{level} insights error: {str(e)}"}
    
    def _calculate_summary_metrics(self, data: List[Dict]) -> Dict:
        """Calculate high-level summary metrics"""
        if not data:
            return {}
        
        # Aggregate core metrics
        summary = {
            'total_spend': sum(float(item.get('spend', 0)) for item in data),
            'total_impressions': sum(int(item.get('impressions', 0)) for item in data),
            'total_clicks': sum(int(item.get('clicks', 0)) for item in data),
            'total_reach': sum(int(item.get('reach', 0)) for item in data)
        }
        
        # Calculate derived metrics
        if summary['total_impressions'] > 0:
            summary['overall_ctr'] = (summary['total_clicks'] / summary['total_impressions']) * 100
        
        if summary['total_clicks'] > 0:
            summary['overall_cpc'] = summary['total_spend'] / summary['total_clicks']
        
        if summary['total_impressions'] > 0:
            summary['overall_cpm'] = (summary['total_spend'] / summary['total_impressions']) * 1000
        
        return summary
    
    def _analyze_hierarchy_performance(self, hierarchy_data: Dict) -> Dict:
        """Analyze performance patterns across the campaign hierarchy"""
        
        analysis = {
            'top_campaigns': [],
            'underperforming_adsets': [],
            'high_potential_ads': [],
            'optimization_opportunities': []
        }
        
        # Analyze campaigns
        campaigns = hierarchy_data.get('campaigns', [])
        if campaigns:
            # Sort by ROAS or spend efficiency
            campaigns_with_roas = []
            for campaign in campaigns:
                spend = float(campaign.get('spend', 0))
                actions = campaign.get('actions', [])
                revenue = sum(float(action.get('value', 0)) for action in actions if action.get('action_type') == 'purchase')
                roas = revenue / spend if spend > 0 else 0
                
                campaigns_with_roas.append({
                    **campaign,
                    'calculated_roas': roas,
                    'calculated_revenue': revenue
                })
            
            # Top performers
            analysis['top_campaigns'] = sorted(
                campaigns_with_roas, 
                key=lambda x: x['calculated_roas'], 
                reverse=True
            )[:5]
        
        return analysis
    
    def _generate_strategic_recommendations(self, hierarchy_data: Dict) -> List[Dict]:
        """Generate strategic recommendations based on performance data"""
        
        recommendations = []
        
        campaigns = hierarchy_data.get('campaigns', [])
        adsets = hierarchy_data.get('adsets', [])
        
        # Budget reallocation recommendations
        if campaigns:
            high_roas_campaigns = [c for c in campaigns if self._calculate_roas(c) > 3.0]
            low_roas_campaigns = [c for c in campaigns if self._calculate_roas(c) < 1.0]
            
            if high_roas_campaigns and low_roas_campaigns:
                recommendations.append({
                    'type': 'budget_reallocation',
                    'priority': 'high',
                    'title': 'Reallocate Budget to High-ROAS Campaigns',
                    'description': f'Move budget from {len(low_roas_campaigns)} underperforming campaigns to {len(high_roas_campaigns)} high-ROAS campaigns',
                    'potential_impact': 'Increase overall ROAS by 25-40%'
                })
        
        # Audience expansion recommendations
        if adsets:
            high_ctr_adsets = [a for a in adsets if float(a.get('ctr', 0)) > 2.0]
            if high_ctr_adsets:
                recommendations.append({
                    'type': 'audience_expansion',
                    'priority': 'medium',
                    'title': 'Expand High-CTR Audiences',
                    'description': f'Scale {len(high_ctr_adsets)} high-performing ad sets with lookalike audiences',
                    'potential_impact': 'Increase reach by 50-100% while maintaining efficiency'
                })
        
        return recommendations
    
    def _enrich_creative_data(self, ads_data: List[Dict], performance_data: List[Dict]) -> List[Dict]:
        """Combine creative details with performance metrics"""
        
        # Create performance lookup
        performance_lookup = {item['ad_id']: item for item in performance_data}
        
        enriched = []
        for ad in ads_data:
            ad_id = ad['id']
            performance = performance_lookup.get(ad_id, {})
            
            creative = ad.get('creative', {})
            
            enriched_item = {
                'ad_id': ad_id,
                'ad_name': ad.get('name', ''),
                'campaign_id': ad.get('campaign_id', ''),
                'adset_id': ad.get('adset_id', ''),
                'creative_id': creative.get('id', ''),
                'creative_title': creative.get('title', ''),
                'creative_body': creative.get('body', ''),
                'image_url': creative.get('image_url', ''),
                'video_id': creative.get('video_id', ''),
                **performance  # Add all performance metrics
            }
            
            enriched.append(enriched_item)
        
        return enriched
    
    def _analyze_creative_performance(self, creative_data: List[Dict]) -> Dict:
        """Analyze creative performance patterns"""
        
        if not creative_data:
            return {}
        
        # Analyze by creative type
        image_ads = [c for c in creative_data if c.get('image_url') and not c.get('video_id')]
        video_ads = [c for c in creative_data if c.get('video_id')]
        
        analysis = {
            'creative_type_performance': {
                'image_ads': {
                    'count': len(image_ads),
                    'avg_ctr': self._calculate_avg_metric(image_ads, 'ctr'),
                    'avg_cpc': self._calculate_avg_metric(image_ads, 'cpc')
                },
                'video_ads': {
                    'count': len(video_ads),
                    'avg_ctr': self._calculate_avg_metric(video_ads, 'ctr'),
                    'avg_cpc': self._calculate_avg_metric(video_ads, 'cpc')
                }
            }
        }
        
        return analysis
    
    def _identify_top_creative_performers(self, creative_data: List[Dict]) -> List[Dict]:
        """Identify top-performing creatives"""
        
        if not creative_data:
            return []
        
        # Sort by CTR and filter for sufficient impressions
        filtered_creatives = [
            c for c in creative_data 
            if int(c.get('impressions', 0)) > 1000
        ]
        
        top_performers = sorted(
            filtered_creatives,
            key=lambda x: float(x.get('ctr', 0)),
            reverse=True
        )[:10]
        
        return top_performers
    
    def _analyze_breakdown_patterns(self, breakdown_results: Dict) -> Dict:
        """Analyze patterns in breakdown data"""
        
        insights = {}
        
        for breakdown_name, breakdown_data in breakdown_results.items():
            data = breakdown_data.get('data', {}).get('data', [])
            
            if data:
                insights[breakdown_name] = {
                    'top_performer': max(data, key=lambda x: float(x.get('ctr', 0))),
                    'total_records': len(data),
                    'avg_ctr': sum(float(item.get('ctr', 0)) for item in data) / len(data)
                }
        
        return insights
    
    def _analyze_attribution_impact(self, attribution_data: Dict) -> Dict:
        """Analyze the impact of different attribution windows"""
        
        analysis = {}
        
        for window, data in attribution_data.items():
            if data:
                total_conversions = sum(
                    sum(float(action.get('value', 0)) for action in item.get('actions', []))
                    for item in data
                )
                
                analysis[window] = {
                    'total_conversions': total_conversions,
                    'campaigns_with_conversions': len([
                        item for item in data 
                        if any(action.get('action_type') == 'purchase' for action in item.get('actions', []))
                    ])
                }
        
        return analysis
    
    def _calculate_roas(self, campaign: Dict) -> float:
        """Calculate ROAS for a campaign"""
        spend = float(campaign.get('spend', 0))
        if spend == 0:
            return 0
        
        actions = campaign.get('actions', [])
        revenue = sum(
            float(action.get('value', 0)) 
            for action in actions 
            if action.get('action_type') == 'purchase'
        )
        
        return revenue / spend
    
    def _calculate_avg_metric(self, data: List[Dict], metric: str) -> float:
        """Calculate average of a metric across data points"""
        if not data:
            return 0
        
        values = [float(item.get(metric, 0)) for item in data if item.get(metric)]
        return sum(values) / len(values) if values else 0