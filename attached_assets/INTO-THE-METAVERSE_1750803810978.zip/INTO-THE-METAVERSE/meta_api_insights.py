"""
Meta Marketing API Insights Integration

This module provides robust implementations for fetching and processing insights
data from the Meta Marketing API following the official documentation:
https://developers.facebook.com/docs/marketing-api/insights
"""

import os
import json
import time
import requests
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

class MetaInsights:
    """
    Class for fetching comprehensive advertising data using the Meta Marketing API.
    Implements best practices from official documentation.
    """
    
    def __init__(self, access_token=None, ad_account_id=None, pixel_id=None):
        """Initialize with Meta credentials"""
        self.access_token = access_token or os.environ.get("META_ACCESS_TOKEN")
        self.ad_account_id = ad_account_id or os.environ.get("META_AD_ACCOUNT_ID")
        self.pixel_id = pixel_id or os.environ.get("META_PIXEL_ID")
        
        # Format account ID if needed
        if self.ad_account_id and not self.ad_account_id.startswith('act_'):
            self.ad_account_id = f"act_{self.ad_account_id}"
        
        # API version
        self.api_version = "v22.0"
        self.base_url = f"https://graph.facebook.com/{self.api_version}"
        
        # Default fields for different request types
        self.campaign_fields = [
            "id", "name", "objective", "status", "daily_budget", "lifetime_budget", 
            "bid_strategy", "budget_remaining", "buying_type", "configured_status",
            "created_time", "effective_status", "start_time", "stop_time", "updated_time"
        ]
        
        self.adset_fields = [
            "id", "name", "campaign_id", "status", "daily_budget", "lifetime_budget", 
            "bid_amount", "bid_strategy", "billing_event", "optimization_goal", 
            "targeting", "created_time", "effective_status", "start_time", "end_time"
        ]
        
        self.ad_fields = [
            "id", "name", "adset_id", "campaign_id", "status", "creative", 
            "effective_status", "created_time", "updated_time"
        ]
        
        self.insights_fields = [
            "campaign_id", "campaign_name", "adset_id", "adset_name", "ad_id", "ad_name",
            "impressions", "reach", "clicks", "spend", "cpc", "cpm", "cpp", "ctr", "frequency",
            "quality_ranking", "engagement_rate_ranking", "conversion_rate_ranking",
            "website_ctr", "objective", "conversions", "cost_per_conversion", 
            "conversion_values", "cost_per_15_sec_video_view", "video_p25_watched_actions",
            "video_p50_watched_actions", "video_p75_watched_actions", "video_p100_watched_actions",
            "video_avg_time_watched_actions", "inline_link_clicks", "inline_post_engagement",
            "unique_clicks", "unique_ctr", "action_values", "actions"
        ]
        
        # Error handling configuration
        self.max_retries = 3
        self.retry_delay = 5  # seconds
    
    def _make_request(self, url, params, method="GET"):
        """Make API request with retry and error handling"""
        retries = 0
        while retries < self.max_retries:
            try:
                if method == "GET":
                    response = requests.get(url, params=params)
                elif method == "POST":
                    response = requests.post(url, data=params)
                else:
                    return {"error": f"Unsupported method: {method}"}
                
                # Check if request was successful
                if response.status_code == 200:
                    return response.json()
                else:
                    error_message = f"Error: {response.status_code} - {response.text}"
                    print(error_message)
                    
                    # Check for rate limiting
                    if response.status_code == 429:
                        wait_time = int(response.headers.get('Retry-After', self.retry_delay))
                        print(f"Rate limited. Waiting {wait_time} seconds.")
                        time.sleep(wait_time)
                    else:
                        # For other errors, increase wait time with each retry
                        time.sleep(self.retry_delay * (retries + 1))
                    
                    retries += 1
            except Exception as e:
                error_message = f"Request error: {str(e)}"
                print(error_message)
                time.sleep(self.retry_delay)
                retries += 1
        
        return {"error": "Max retries reached"}
    
    def get_campaigns(self, status_filter=None):
        """
        Fetch campaigns with detailed attributes
        
        Args:
            status_filter (str): Filter campaigns by status (ACTIVE, PAUSED, etc)
            
        Returns:
            tuple: (status dict, campaigns data)
        """
        if not self.access_token or not self.ad_account_id:
            return {"error": "Missing access token or ad account ID"}, None
        
        url = f"{self.base_url}/{self.ad_account_id}/campaigns"
        
        params = {
            'access_token': self.access_token,
            'fields': ','.join(self.campaign_fields),
            'limit': 100  # Maximum number of campaigns to retrieve
        }
        
        # Add status filter if provided
        if status_filter:
            params['filtering'] = json.dumps([{
                'field': 'effective_status',
                'operator': 'IN',
                'value': [status_filter]
            }])
        
        # Make request
        data = self._make_request(url, params)
        
        if 'error' in data:
            return {"error": data['error']}, None
        
        return {"success": True}, data
    
    def get_adsets(self, campaign_id=None):
        """
        Fetch ad sets with detailed attributes
        
        Args:
            campaign_id (str): Optional campaign ID to filter ad sets
            
        Returns:
            tuple: (status dict, adsets data)
        """
        if not self.access_token or not self.ad_account_id:
            return {"error": "Missing access token or ad account ID"}, None
        
        # Set the proper endpoint depending on whether filtering by campaign
        if campaign_id:
            url = f"{self.base_url}/{campaign_id}/adsets"
        else:
            url = f"{self.base_url}/{self.ad_account_id}/adsets"
        
        params = {
            'access_token': self.access_token,
            'fields': ','.join(self.adset_fields),
            'limit': 500  # Maximum number of adsets to retrieve
        }
        
        # Make request
        data = self._make_request(url, params)
        
        if 'error' in data:
            return {"error": data['error']}, None
        
        return {"success": True}, data
    
    def get_ads(self, adset_id=None):
        """
        Fetch ads with detailed attributes
        
        Args:
            adset_id (str): Optional ad set ID to filter ads
            
        Returns:
            tuple: (status dict, ads data)
        """
        if not self.access_token or not self.ad_account_id:
            return {"error": "Missing access token or ad account ID"}, None
        
        # Set the proper endpoint depending on whether filtering by adset
        if adset_id:
            url = f"{self.base_url}/{adset_id}/ads"
        else:
            url = f"{self.base_url}/{self.ad_account_id}/ads"
        
        params = {
            'access_token': self.access_token,
            'fields': ','.join(self.ad_fields),
            'limit': 1000  # Maximum number of ads to retrieve
        }
        
        # Make request
        data = self._make_request(url, params)
        
        if 'error' in data:
            return {"error": data['error']}, None
        
        return {"success": True}, data
    
    def get_insights(self, 
                    level="account", 
                    entity_id=None,
                    date_preset=None, 
                    time_range=None, 
                    time_increment=None,
                    fields=None,
                    breakdowns=None,
                    action_breakdowns=None,
                    filtering=None):
        """
        Get comprehensive insights data with flexible parameters
        
        Args:
            level (str): Data aggregation level: account, campaign, adset, or ad
            entity_id (str): ID of entity to get insights for (defaults to ad account)
            date_preset (str): Predefined date range (last_7d, last_30d, etc.)
            time_range (dict): Custom time range: {'since':'YYYY-MM-DD', 'until':'YYYY-MM-DD'}
            time_increment (str): Time series data increment (1, 7, monthly, etc.)
            fields (list): List of insight fields to request (overrides defaults)
            breakdowns (list): Dimensions to break down the data by (age, gender, etc.)
            action_breakdowns (list): Action breakdowns (action_type, action_target_id, etc.)
            filtering (list): Filtering criteria
            
        Returns:
            tuple: (status dict, insights data)
        """
        if not self.access_token:
            return {"error": "Missing access token"}, None
        
        # Determine entity ID and endpoint
        if not entity_id:
            if level == "account":
                entity_id = self.ad_account_id
            else:
                return {"error": f"Entity ID required for level: {level}"}, None
        
        url = f"{self.base_url}/{entity_id}/insights"
        
        # Prepare parameters
        params = {
            'access_token': self.access_token,
            'level': level,
            'limit': 500  # Maximum number of results to retrieve
        }
        
        # Add fields
        insight_fields = fields if fields else self.insights_fields
        params['fields'] = ','.join(insight_fields)
        
        # Add date parameters
        if date_preset:
            params['date_preset'] = date_preset
        elif time_range:
            params['time_range'] = json.dumps(time_range)
        else:
            # Default to last 30 days if not specified
            now = datetime.now()
            thirty_days_ago = now - timedelta(days=30)
            params['time_range'] = json.dumps({
                'since': thirty_days_ago.strftime('%Y-%m-%d'),
                'until': now.strftime('%Y-%m-%d')
            })
        
        # Add time increment if provided
        if time_increment:
            params['time_increment'] = time_increment
        
        # Add breakdowns if provided
        if breakdowns:
            if isinstance(breakdowns, list):
                params['breakdowns'] = ','.join(breakdowns)
            else:
                params['breakdowns'] = breakdowns
        
        # Add action breakdowns if provided
        if action_breakdowns:
            if isinstance(action_breakdowns, list):
                params['action_breakdowns'] = ','.join(action_breakdowns)
            else:
                params['action_breakdowns'] = action_breakdowns
        
        # Add filtering if provided
        if filtering:
            params['filtering'] = json.dumps(filtering)
        
        # Make request
        data = self._make_request(url, params)
        
        if 'error' in data:
            return {"error": data['error']}, None
        
        return {"success": True}, data
    
    def get_demographics_insights(self, entity_id=None, entity_type="account", time_range=None):
        """
        Get demographic breakdowns for insights
        
        Args:
            entity_id (str): Entity ID to get insights for
            entity_type (str): Type of entity (account, campaign, adset, ad)
            time_range (dict): Custom time range: {'since':'YYYY-MM-DD', 'until':'YYYY-MM-DD'}
            
        Returns:
            tuple: (status dict, demographics data)
        """
        # Use ad account ID if no entity ID provided
        if not entity_id:
            entity_id = self.ad_account_id
        
        # Define demographics breakdowns
        demographic_breakdowns = [
            ['age', 'gender'],
            ['country'],
            ['region'],
            ['device_platform']
        ]
        
        # Define fields to retrieve
        fields = [
            'impressions', 'reach', 'clicks', 'spend', 'cpc', 'ctr', 
            'frequency', 'conversions', 'cost_per_conversion'
        ]
        
        # Get insights for each breakdown
        results = {}
        
        for breakdown in demographic_breakdowns:
            status, data = self.get_insights(
                level=entity_type,
                entity_id=entity_id,
                time_range=time_range,
                fields=fields,
                breakdowns=breakdown
            )
            
            if 'success' in status and data:
                # Store results by breakdown type
                key = '_'.join(breakdown)
                results[key] = data
        
        if results:
            return {"success": True}, results
        else:
            return {"error": "Could not fetch demographic insights"}, None
    
    def get_campaign_performance_over_time(self, campaign_id=None, time_increment="1", time_range=None):
        """
        Get campaign performance data over time with daily or weekly increments
        
        Args:
            campaign_id (str): Campaign ID to analyze, or None for account level
            time_increment (str): Time increment ("1" for daily, "7" for weekly, etc.)
            time_range (dict): Custom time range: {'since':'YYYY-MM-DD', 'until':'YYYY-MM-DD'}
            
        Returns:
            tuple: (status dict, performance data)
        """
        entity_id = campaign_id if campaign_id else self.ad_account_id
        entity_type = "campaign" if campaign_id else "account"
        
        # Get time series data
        status, data = self.get_insights(
            level=entity_type,
            entity_id=entity_id,
            time_range=time_range,
            time_increment=time_increment,
            fields=[
                'date_start', 'date_stop', 'impressions', 'reach', 'clicks', 
                'spend', 'cpc', 'ctr', 'conversions', 'cost_per_conversion'
            ]
        )
        
        return status, data
    
    def get_creative_performance(self, time_range=None):
        """
        Get performance data broken down by creative type
        
        Args:
            time_range (dict): Custom time range: {'since':'YYYY-MM-DD', 'until':'YYYY-MM-DD'}
            
        Returns:
            tuple: (status dict, creative performance data)
        """
        # First, get all ads with creative details
        status, ads_data = self.get_ads()
        if 'error' in status or not ads_data or 'data' not in ads_data:
            return status, None
        
        # Get the ad IDs to analyze
        ad_ids = [ad['id'] for ad in ads_data['data'] if 'id' in ad]
        
        # Get creative types from ad data
        creative_types = {}
        for ad in ads_data['data']:
            if 'creative' in ad and 'id' in ad:
                # Determine creative type (this is simplified - real implementation would inspect creative details)
                creative_type = "Unknown"
                if 'effective_object_story_id' in ad['creative']:
                    creative_type = "Image" if 'image_url' in ad['creative'] else "Unknown"
                    creative_type = "Video" if 'video_id' in ad['creative'] else creative_type
                    creative_type = "Carousel" if 'multi_share_optimized' in ad['creative'] else creative_type
                
                creative_types[ad['id']] = creative_type
        
        # Get performance data for each ad
        ad_performance = {}
        for ad_id in ad_ids:
            status, data = self.get_insights(
                level="ad",
                entity_id=ad_id,
                time_range=time_range,
                fields=[
                    'impressions', 'clicks', 'spend', 'cpc', 'ctr', 
                    'conversions', 'cost_per_conversion', 'reach', 'frequency'
                ]
            )
            
            if 'success' in status and data and 'data' in data and data['data']:
                ad_performance[ad_id] = data['data'][0]
        
        # Combine creative type with performance data
        result = []
        for ad_id, performance in ad_performance.items():
            creative_type = creative_types.get(ad_id, "Unknown")
            result.append({
                'ad_id': ad_id,
                'creative_type': creative_type,
                'performance': performance
            })
        
        return {"success": True}, result
    
    def get_audience_performance(self, time_range=None):
        """
        Get performance data broken down by targeting criteria
        
        Args:
            time_range (dict): Custom time range: {'since':'YYYY-MM-DD', 'until':'YYYY-MM-DD'}
            
        Returns:
            tuple: (status dict, audience performance data)
        """
        # Get performance by demographics
        status, demo_data = self.get_demographics_insights(time_range=time_range)
        
        # Get performance by placements
        status, placement_data = self.get_insights(
            level="account",
            entity_id=self.ad_account_id,
            time_range=time_range,
            fields=[
                'impressions', 'clicks', 'spend', 'cpc', 'ctr', 
                'conversions', 'cost_per_conversion'
            ],
            breakdowns=['publisher_platform', 'platform_position']
        )
        
        # Combine results
        results = {
            'demographics': demo_data if 'success' in status else None,
            'placements': placement_data if 'success' in status and placement_data else None
        }
        
        return {"success": True}, results
    
    def get_lookalike_performance(self, time_range=None):
        """
        Analyze performance of lookalike audiences
        
        Args:
            time_range (dict): Custom time range: {'since':'YYYY-MM-DD', 'until':'YYYY-MM-DD'}
            
        Returns:
            tuple: (status dict, lookalike performance data)
        """
        # Get all ad sets first
        status, adsets_data = self.get_adsets()
        if 'error' in status or not adsets_data or 'data' not in adsets_data:
            return status, None
        
        # Find ad sets with lookalike audiences
        lookalike_adsets = []
        for adset in adsets_data['data']:
            if 'targeting' in adset and 'flexible_spec' in adset['targeting']:
                flexible_specs = adset['targeting']['flexible_spec']
                
                # Check if this is a list or dict
                if isinstance(flexible_specs, list):
                    for spec in flexible_specs:
                        if 'lookalike_audience' in spec:
                            lookalike_adsets.append({
                                'adset_id': adset['id'],
                                'name': adset['name'],
                                'ratio': spec.get('lookalike_expansion_ratio', 'unknown')
                            })
                elif isinstance(flexible_specs, dict):
                    if 'lookalike_audience' in flexible_specs:
                        lookalike_adsets.append({
                            'adset_id': adset['id'],
                            'name': adset['name'],
                            'ratio': flexible_specs.get('lookalike_expansion_ratio', 'unknown')
                        })
        
        # Get performance for these ad sets
        results = []
        for adset in lookalike_adsets:
            status, data = self.get_insights(
                level="adset",
                entity_id=adset['adset_id'],
                time_range=time_range,
                fields=[
                    'impressions', 'reach', 'clicks', 'spend', 'cpc', 'ctr', 
                    'conversions', 'cost_per_conversion'
                ]
            )
            
            if 'success' in status and data and 'data' in data and data['data']:
                performance = data['data'][0]
                results.append({
                    'adset_id': adset['adset_id'],
                    'name': adset['name'],
                    'lookalike_ratio': adset['ratio'],
                    'performance': performance
                })
        
        return {"success": True}, results

    def process_insights_to_dataframe(self, insights_data):
        """
        Process raw insights data into a Pandas DataFrame for analysis
        
        Args:
            insights_data (dict): Raw insights data from the API
            
        Returns:
            pd.DataFrame: Processed data in DataFrame format
        """
        if not insights_data or 'data' not in insights_data:
            return pd.DataFrame()
        
        # Extract data records
        records = insights_data['data']
        
        # Handle no records
        if not records:
            return pd.DataFrame()
        
        # Convert to DataFrame
        df = pd.DataFrame(records)
        
        # Process date columns
        for date_col in ['date_start', 'date_stop']:
            if date_col in df.columns:
                df[date_col] = pd.to_datetime(df[date_col])
        
        # Process numeric columns
        numeric_cols = ['impressions', 'reach', 'clicks', 'spend', 'cpc', 'cpm', 'ctr', 'frequency']
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        
        # Process complex structures like actions and action_values
        if 'actions' in df.columns:
            # Extract specific action types into separate columns
            action_types = ['link_click', 'post_engagement', 'purchase', 'lead', 'page_engagement']
            
            for action_type in action_types:
                col_name = f"{action_type}_actions"
                df[col_name] = df['actions'].apply(
                    lambda x: next((int(float(action['value'])) for action in x if isinstance(x, list) and 
                                    'action_type' in action and action['action_type'] == action_type), 0)
                    if isinstance(x, list) else 0
                )
        
        return df
        
    def get_attribution_data(self, time_range=None):
        """
        Get attribution data for different attribution models
        
        Args:
            time_range (dict): Custom time range: {'since':'YYYY-MM-DD', 'until':'YYYY-MM-DD'}
            
        Returns:
            tuple: (status dict, attribution data)
        """
        # Attribution models to compare
        attribution_models = ['skan_click', 'impression', 'click']
        
        results = {}
        for model in attribution_models:
            # Set attribution window for each model
            if model == 'skan_click':
                action_attribution_windows = ['1d_click']
            elif model == 'impression':
                action_attribution_windows = ['1d_view', '7d_click']
            else:  # click model
                action_attribution_windows = ['7d_click']
            
            status, data = self.get_insights(
                level="account",
                entity_id=self.ad_account_id,
                time_range=time_range,
                fields=[
                    'impressions', 'clicks', 'spend', 'actions', 'action_values'
                ],
                action_breakdowns=['action_type'],
                params={'action_attribution_windows': action_attribution_windows}
            )
            
            if 'success' in status and data:
                results[model] = data
        
        return {"success": True}, results

def get_meta_ad_insights(date_range=None):
    """
    Convenience function to get comprehensive Meta ad insights
    
    Args:
        date_range (dict): Date range in format {'since': 'YYYY-MM-DD', 'until': 'YYYY-MM-DD'}
        
    Returns:
        dict: Consolidated insights data
    """
    # Initialize insights client
    insights = MetaInsights()
    
    # Prepare results container
    results = {
        'account_insights': None,
        'campaign_insights': None,
        'demographics': None,
        'creative_performance': None,
        'audience_performance': None
    }
    
    # Get account-level insights
    status, account_data = insights.get_insights(
        level="account", 
        time_range=date_range,
        time_increment="1"  # Daily data
    )
    if 'success' in status and account_data:
        results['account_insights'] = insights.process_insights_to_dataframe(account_data)
    
    # Get campaign-level insights
    status, campaign_data = insights.get_insights(
        level="campaign", 
        time_range=date_range
    )
    if 'success' in status and campaign_data:
        results['campaign_insights'] = insights.process_insights_to_dataframe(campaign_data)
    
    # Get demographic breakdowns
    status, demo_data = insights.get_demographics_insights(time_range=date_range)
    if 'success' in status and demo_data:
        results['demographics'] = demo_data
    
    # Get creative performance data
    status, creative_data = insights.get_creative_performance(time_range=date_range)
    if 'success' in status and creative_data:
        results['creative_performance'] = creative_data
    
    # Get audience performance data
    status, audience_data = insights.get_audience_performance(time_range=date_range)
    if 'success' in status and audience_data:
        results['audience_performance'] = audience_data
    
    return results