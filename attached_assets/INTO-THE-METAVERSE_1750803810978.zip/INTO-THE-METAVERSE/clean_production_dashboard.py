"""
Clean Production Meta Marketing Dashboard
Streamlined version with ad set and individual creative level analysis
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import os
import requests
from datetime import datetime, timedelta
from pyairtable import Api

# Configure page
st.set_page_config(
    page_title="Meta Marketing Dashboard", 
    page_icon="🎯",
    layout="wide"
)

def get_meta_advertising_data(start_date: str, end_date: str):
    """Get Meta advertising data from API"""
    try:
        access_token = os.getenv('META_ACCESS_TOKEN')
        ad_account_id = os.getenv('META_AD_ACCOUNT_ID')
        
        if not access_token or not ad_account_id:
            st.error(f"Missing credentials - Token: {'✓' if access_token else '✗'}, Account ID: {'✓' if ad_account_id else '✗'}")
            return None
        
        # Ensure proper account ID format
        if not ad_account_id.startswith('act_'):
            ad_account_id = f"act_{ad_account_id}"
            
        url = f"https://graph.facebook.com/v18.0/{ad_account_id}/insights"
        params = {
            'access_token': access_token,
            'time_range': f'{{"since":"{start_date}","until":"{end_date}"}}',
            'fields': 'campaign_name,spend,impressions,clicks,ctr,cpm,reach,frequency',
            'level': 'campaign',
            'limit': 100
        }
        
        st.info(f"Connecting to Meta API: {url}")
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            campaigns = data.get('data', [])
            if campaigns:
                st.success(f"✅ Connected to Meta API - Loaded {len(campaigns)} campaigns")
                return {
                    'success': True,
                    'campaigns': campaigns,
                    'total_spend': sum(float(c.get('spend', 0)) for c in campaigns)
                }
            else:
                st.warning("API connected but no campaign data found for selected date range")
                return None
        else:
            st.error(f"Meta API Error {response.status_code}: {response.text}")
            return None
            
    except Exception as e:
        st.error(f"Meta API Connection Error: {str(e)}")
        return None

def get_detailed_ad_performance(start_date: str, end_date: str):
    """Get detailed ad set and individual ad performance"""
    try:
        access_token = os.getenv('META_ACCESS_TOKEN')
        ad_account_id = os.getenv('META_AD_ACCOUNT_ID')
        
        if not access_token or not ad_account_id:
            return generate_sample_breakdown()
        
        # Ensure proper account ID format
        if not ad_account_id.startswith('act_'):
            ad_account_id = f"act_{ad_account_id}"
            
        detailed_performance = {
            'success': True,
            'adsets': [],
            'ads': []
        }
        
        # Get ad set level data
        try:
            url = f"https://graph.facebook.com/v18.0/{ad_account_id}/insights"
            params = {
                'access_token': access_token,
                'time_range': f'{{"since":"{start_date}","until":"{end_date}"}}',
                'fields': 'campaign_name,adset_name,spend,impressions,clicks,ctr,cpc,cpm',
                'level': 'adset',
                'limit': 100
            }
            
            response = requests.get(url, params=params)
            if response.status_code == 200:
                data = response.json()
                detailed_performance['adsets'] = data.get('data', [])
                st.success(f"Loaded {len(detailed_performance['adsets'])} ad sets")
            else:
                st.warning(f"Ad set API error {response.status_code}: {response.text}")
        except Exception as e:
            st.error(f"Ad set data error: {e}")
        
        # Get individual ad level data
        try:
            url = f"https://graph.facebook.com/v18.0/{ad_account_id}/insights"
            params = {
                'access_token': access_token,
                'time_range': f'{{"since":"{start_date}","until":"{end_date}"}}',
                'fields': 'campaign_name,adset_name,ad_name,spend,impressions,clicks,ctr,cpc,cpm',
                'level': 'ad',
                'limit': 200
            }
            
            response = requests.get(url, params=params)
            if response.status_code == 200:
                data = response.json()
                detailed_performance['ads'] = data.get('data', [])
                st.success(f"Loaded {len(detailed_performance['ads'])} individual ads")
            else:
                st.warning(f"Individual ad API error {response.status_code}: {response.text}")
        except Exception as e:
            st.error(f"Individual ad data error: {e}")
        
        # Return live data if we got any, otherwise fallback
        if detailed_performance['adsets'] or detailed_performance['ads']:
            return detailed_performance
        else:
            st.info("No live data found, showing sample data structure")
            return generate_sample_breakdown()
        
    except Exception as e:
        st.error(f"Detailed performance error: {e}")
        return generate_sample_breakdown()

def generate_sample_breakdown():
    """Generate sample ad set and creative breakdown for demonstration"""
    import random
    
    campaigns = [
        {"name": "Smooth MD - Anti-Aging Campaign", "spend": 2450.50, "impressions": 45000, "clicks": 890},
        {"name": "Smooth MD - Laser Treatment Campaign", "spend": 1890.75, "impressions": 32000, "clicks": 720},
        {"name": "Smooth MD - Botox Special Campaign", "spend": 3200.25, "impressions": 58000, "clicks": 1150}
    ]
    
    adsets = []
    ads = []
    
    for campaign in campaigns:
        # Generate 2-3 ad sets per campaign
        num_adsets = random.randint(2, 3)
        for i in range(num_adsets):
            adset_spend = campaign["spend"] / num_adsets * random.uniform(0.7, 1.3)
            adset_impressions = int(campaign["impressions"] / num_adsets * random.uniform(0.8, 1.2))
            adset_clicks = int(campaign["clicks"] / num_adsets * random.uniform(0.6, 1.4))
            
            adset = {
                "campaign_name": campaign["name"],
                "adset_name": f"{campaign['name']} - AdSet {i+1}",
                "spend": round(adset_spend, 2),
                "impressions": adset_impressions,
                "clicks": adset_clicks,
                "ctr": round((adset_clicks / adset_impressions * 100), 2) if adset_impressions > 0 else 0,
                "cpc": round((adset_spend / adset_clicks), 2) if adset_clicks > 0 else 0,
                "cpm": round((adset_spend / adset_impressions * 1000), 2) if adset_impressions > 0 else 0
            }
            adsets.append(adset)
            
            # Generate 2-4 ads per ad set
            num_ads = random.randint(2, 4)
            for j in range(num_ads):
                ad_spend = adset_spend / num_ads * random.uniform(0.5, 1.5)
                ad_impressions = int(adset_impressions / num_ads * random.uniform(0.7, 1.3))
                ad_clicks = int(adset_clicks / num_ads * random.uniform(0.6, 1.4))
                
                ad = {
                    "campaign_name": campaign["name"],
                    "adset_name": adset["adset_name"],
                    "ad_name": f"{adset['adset_name']} - Creative {j+1}",
                    "spend": round(ad_spend, 2),
                    "impressions": ad_impressions,
                    "clicks": ad_clicks,
                    "ctr": round((ad_clicks / ad_impressions * 100), 2) if ad_impressions > 0 else 0,
                    "cpc": round((ad_spend / ad_clicks), 2) if ad_clicks > 0 else 0,
                    "cpm": round((ad_spend / ad_impressions * 1000), 2) if ad_impressions > 0 else 0
                }
                ads.append(ad)
    
    return {
        'success': True,
        'adsets': adsets,
        'ads': ads
    }

def load_airtable_leads():
    """Load lead data from Airtable"""
    try:
        api_key = os.getenv('AIRTABLE_API_KEY')
        base_id = os.getenv('AIRTABLE_BASE_ID')
        
        if not api_key or not base_id:
            return pd.DataFrame()
        
        api = Api(api_key)
        table = api.table(base_id, 'Leads')
        
        records = table.all()
        
        leads_data = []
        for record in records:
            fields = record['fields']
            leads_data.append({
                'id': record['id'],
                'name': fields.get('Name', ''),
                'phone': fields.get('Phone', ''),
                'email': fields.get('Email', ''),
                'source': fields.get('Source', ''),
                'brand': fields.get('Brand', ''),
                'inbound_date': fields.get('Inbound', ''),
                'overall_status': fields.get('Overall Status', ''),
                'booking_status': fields.get('Booking Status', ''),
                'show_status': fields.get('Show Status', ''),
                'consult_status': fields.get('Consult Status', ''),
                'close_status': fields.get('Close Status', '')
            })
        
        df = pd.DataFrame(leads_data)
        
        # Filter for Meta/Facebook leads
        if not df.empty:
            meta_leads = df[df['source'].str.lower().isin(['meta', 'facebook', 'instagram'])].copy()
            return meta_leads
        
        return df
        
    except Exception as e:
        st.error(f"Airtable leads error: {e}")
        return pd.DataFrame()

def load_airtable_transactions():
    """Load transaction/revenue data from Airtable"""
    try:
        api_key = os.getenv('AIRTABLE_API_KEY')
        base_id = os.getenv('AIRTABLE_BASE_ID')
        
        if not api_key or not base_id:
            return pd.DataFrame()
        
        api = Api(api_key)
        
        # Try different table names for transactions
        table_names = ['Transactions', 'Social Media', 'Revenue', 'Sales']
        
        for table_name in table_names:
            try:
                table = api.table(base_id, table_name)
                records = table.all()
                
                transactions_data = []
                for record in records:
                    fields = record['fields']
                    transactions_data.append({
                        'id': record['id'],
                        'customer_name': fields.get('Customer Name', fields.get('Name', '')),
                        'phone': fields.get('Phone', ''),
                        'email': fields.get('Email', ''),
                        'service': fields.get('Service', fields.get('Treatment', '')),
                        'amount': fields.get('Amount', fields.get('Revenue', fields.get('Total', 0))),
                        'date': fields.get('Date', fields.get('Transaction Date', '')),
                        'status': fields.get('Status', 'Completed'),
                        'source': fields.get('Source', 'Meta')
                    })
                
                df = pd.DataFrame(transactions_data)
                if not df.empty:
                    return df
                    
            except Exception:
                continue
        
        return pd.DataFrame()
        
    except Exception as e:
        st.error(f"Airtable transactions error: {e}")
        return pd.DataFrame()

def calculate_funnel_metrics(leads_df):
    """Calculate lead funnel conversion metrics"""
    if leads_df.empty:
        return {}
    
    total_leads = len(leads_df)
    
    # Count leads at each funnel stage
    booked_leads = len(leads_df[leads_df['booking_status'].str.contains('Booked|Confirmed|Scheduled', case=False, na=False)])
    showed_leads = len(leads_df[leads_df['show_status'].str.contains('Showed|Completed|Attended', case=False, na=False)])
    consulted_leads = len(leads_df[leads_df['consult_status'].str.contains('Consulted|Completed|Done', case=False, na=False)])
    closed_leads = len(leads_df[leads_df['close_status'].str.contains('Closed|Won|Converted|Paid', case=False, na=False)])
    
    # Calculate conversion rates
    booking_rate = (booked_leads / total_leads * 100) if total_leads > 0 else 0
    show_rate = (showed_leads / booked_leads * 100) if booked_leads > 0 else 0
    consult_rate = (consulted_leads / showed_leads * 100) if showed_leads > 0 else 0
    close_rate = (closed_leads / consulted_leads * 100) if consulted_leads > 0 else 0
    
    return {
        'total_leads': total_leads,
        'booked_leads': booked_leads,
        'showed_leads': showed_leads,
        'consulted_leads': consulted_leads,
        'closed_leads': closed_leads,
        'booking_rate': booking_rate,
        'show_rate': show_rate,
        'consult_rate': consult_rate,
        'close_rate': close_rate,
        'overall_conversion_rate': (closed_leads / total_leads * 100) if total_leads > 0 else 0
    }

def match_leads_to_revenue(leads_df, transactions_df):
    """Match leads to actual revenue transactions"""
    if leads_df.empty or transactions_df.empty:
        return leads_df, 0
    
    # Match by phone number (primary) and email (secondary)
    leads_with_revenue = leads_df.copy()
    leads_with_revenue['revenue'] = 0
    leads_with_revenue['transaction_count'] = 0
    
    total_attributed_revenue = 0
    
    for idx, lead in leads_df.iterrows():
        lead_phone = str(lead.get('phone', '')).strip()
        lead_email = str(lead.get('email', '')).strip().lower()
        
        # Find matching transactions
        phone_matches = transactions_df[transactions_df['phone'].astype(str).str.strip() == lead_phone] if lead_phone else pd.DataFrame()
        email_matches = transactions_df[transactions_df['email'].astype(str).str.strip().str.lower() == lead_email] if lead_email else pd.DataFrame()
        
        # Combine matches
        all_matches = pd.concat([phone_matches, email_matches]).drop_duplicates()
        
        if not all_matches.empty:
            try:
                revenue = sum([float(x) for x in all_matches['amount'] if pd.notna(x) and str(x).replace('.','').replace('-','').isdigit()])
                leads_with_revenue.at[idx, 'revenue'] = revenue
                leads_with_revenue.at[idx, 'transaction_count'] = len(all_matches)
                total_attributed_revenue += revenue
            except:
                pass
    
    return leads_with_revenue, total_attributed_revenue

def create_funnel_visualization(funnel_metrics):
    """Create conversion funnel chart"""
    if not funnel_metrics:
        return None
    
    stages = ['Leads', 'Booked', 'Showed', 'Consulted', 'Closed']
    values = [
        funnel_metrics['total_leads'],
        funnel_metrics['booked_leads'],
        funnel_metrics['showed_leads'],
        funnel_metrics['consulted_leads'],
        funnel_metrics['closed_leads']
    ]
    
    fig = go.Figure(go.Funnel(
        y=stages,
        x=values,
        textposition="inside",
        textinfo="value+percent initial",
        opacity=0.8,
        marker={
            "color": ["#3366cc", "#dc3912", "#ff9900", "#109618", "#990099"],
            "line": {"width": 2, "color": "white"}
        }
    ))
    
    fig.update_layout(
        title="Meta Lead Conversion Funnel",
        height=400,
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    
    return fig

def create_roas_gauge(roas_value):
    """Create ROAS gauge chart"""
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=roas_value,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': "ROAS"},
        delta={'reference': 3.0},
        gauge={
            'axis': {'range': [None, 10]},
            'bar': {'color': '#00ff88'},
            'steps': [
                {'range': [0, 2], 'color': '#ff4444'},
                {'range': [2, 4], 'color': '#ffaa00'},
                {'range': [4, 10], 'color': '#00ff44'}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 3.0
            }
        }
    ))
    
    fig.update_layout(height=300, paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
    
    return fig

def calculate_performance_score(ctr, cpc, impressions, max_impressions):
    """Calculate performance score for ads"""
    try:
        ctr_score = float(ctr) * 0.4
        cpc_efficiency = (1 / (float(cpc) + 0.01)) * 0.3 if cpc > 0 else 0
        volume_score = (float(impressions) / float(max_impressions)) * 0.3 if max_impressions > 0 else 0
        return round((ctr_score + cpc_efficiency + volume_score) * 100, 1)
    except:
        return 0

def main():
    st.title("🎯 Comprehensive Meta Marketing Dashboard")
    st.markdown("**Complete Attribution: Ad Spend → Leads → Revenue**")
    
    # Date range selection
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Start Date", datetime.now().date() - timedelta(days=7))
    with col2:
        end_date = st.date_input("End Date", datetime.now().date())
    
    start_str = start_date.strftime('%Y-%m-%d')
    end_str = end_date.strftime('%Y-%m-%d')
    
    # Load all data sources
    with st.spinner("Loading comprehensive attribution data..."):
        meta_data = get_meta_advertising_data(start_str, end_str)
        detailed_performance = get_detailed_ad_performance(start_str, end_str)
        leads_df = load_airtable_leads()
        transactions_df = load_airtable_transactions()
    
    # Complete Attribution Analysis
    st.header("📊 Complete Attribution Analysis")
    
    if meta_data and meta_data.get('campaigns'):
        # Calculate attribution metrics
        leads_with_revenue, attributed_revenue = match_leads_to_revenue(leads_df, transactions_df)
        funnel_metrics = calculate_funnel_metrics(leads_df)
        
        campaigns = meta_data['campaigns']
        total_spend = sum(float(c.get('spend', 0)) for c in campaigns)
        total_impressions = sum(int(c.get('impressions', 0)) for c in campaigns)
        total_clicks = sum(int(c.get('clicks', 0)) for c in campaigns)
        
        # Calculate ROAS and efficiency metrics
        roas = (attributed_revenue / total_spend) if total_spend > 0 else 0
        net_profit = attributed_revenue - total_spend
        cost_per_conversion = (total_spend / funnel_metrics.get('closed_leads', 1)) if funnel_metrics.get('closed_leads', 0) > 0 else 0
        
        st.success("✅ Connected to Meta API - Showing live attribution data")
        
        # Key Attribution Metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Ad Spend", f"${total_spend:,.2f}")
        with col2:
            st.metric("Attributed Revenue", f"${attributed_revenue:,.2f}")
        with col3:
            st.metric("ROAS", f"{roas:.2f}x", delta=f"{roas - 3:.2f}x vs target")
        with col4:
            st.metric("Net Profit", f"${net_profit:,.2f}", delta=f"${net_profit:,.0f}")
        
        # Lead Funnel Metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Meta Leads", f"{funnel_metrics.get('total_leads', 0):,}")
        with col2:
            st.metric("Conversions", f"{funnel_metrics.get('closed_leads', 0):,}")
        with col3:
            st.metric("Conversion Rate", f"{funnel_metrics.get('overall_conversion_rate', 0):.1f}%")
        with col4:
            st.metric("Cost per Conversion", f"${cost_per_conversion:,.2f}")
        
        # Visualizations
        col1, col2 = st.columns(2)
        
        with col1:
            if funnel_metrics:
                funnel_fig = create_funnel_visualization(funnel_metrics)
                if funnel_fig:
                    st.plotly_chart(funnel_fig, use_container_width=True)
        
        with col2:
            roas_fig = create_roas_gauge(roas)
            st.plotly_chart(roas_fig, use_container_width=True)
        
        # Revenue Attribution Details
        if not leads_with_revenue.empty:
            revenue_leads = leads_with_revenue[leads_with_revenue['revenue'] > 0]
            if not revenue_leads.empty:
                st.subheader("💰 Revenue Attribution Details")
                
                revenue_summary = []
                for _, lead in revenue_leads.iterrows():
                    revenue_summary.append({
                        "Lead Name": lead.get('name', 'Unknown'),
                        "Phone": lead.get('phone', 'N/A'),
                        "Revenue": f"${lead.get('revenue', 0):,.2f}",
                        "Transactions": int(lead.get('transaction_count', 0)),
                        "Status": lead.get('overall_status', 'Unknown')
                    })
                
                st.dataframe(pd.DataFrame(revenue_summary), use_container_width=True)
                st.success(f"Successfully attributed ${attributed_revenue:,.2f} in revenue to {len(revenue_leads)} Meta leads")
    else:
        # Use sample data to demonstrate functionality
        campaigns = [
            {"campaign_name": "Smooth MD - Anti-Aging Campaign", "spend": "2450.50", "impressions": "45000", "clicks": "890"},
            {"campaign_name": "Smooth MD - Laser Treatment Campaign", "spend": "1890.75", "impressions": "32000", "clicks": "720"},
            {"campaign_name": "Smooth MD - Botox Special Campaign", "spend": "3200.25", "impressions": "58000", "clicks": "1150"}
        ]
        total_spend = sum(float(c.get('spend', 0)) for c in campaigns)
        total_impressions = sum(int(c.get('impressions', 0)) for c in campaigns)
        total_clicks = sum(int(c.get('clicks', 0)) for c in campaigns)
        st.info("📊 Demo mode - Add META_ACCESS_TOKEN for live attribution")
        
        # Demo metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Spend", f"${total_spend:,.2f}")
        with col2:
            st.metric("Total Impressions", f"{total_impressions:,}")
        with col3:
            st.metric("Total Clicks", f"{total_clicks:,}")
        with col4:
            avg_ctr = (total_clicks / total_impressions * 100) if total_impressions > 0 else 0
            st.metric("Average CTR", f"{avg_ctr:.2f}%")
    
    # Campaign Performance Breakdown
    st.header("📱 Live Campaign Performance")
    
    if meta_data and meta_data.get('campaigns'):
        campaign_data = []
        for campaign in meta_data['campaigns']:
            campaign_data.append({
                "Campaign": campaign.get('campaign_name', 'Unknown'),
                "Spend": f"${float(campaign.get('spend', 0)):,.2f}",
                "Impressions": f"{int(campaign.get('impressions', 0)):,}",
                "Clicks": f"{int(campaign.get('clicks', 0)):,}",
                "CTR": f"{float(campaign.get('ctr', 0)):.2f}%",
                "CPM": f"${float(campaign.get('cpm', 0)):,.2f}"
            })
        
        if campaign_data:
            st.dataframe(pd.DataFrame(campaign_data), use_container_width=True)
    
    # Ad Set Level Analysis
    if detailed_performance.get('adsets'):
        st.header("🎨 Ad Set Performance Breakdown")
        
        adsets = detailed_performance['adsets']
        
        # Convert to display format
        adset_data = []
        for adset in adsets:
            adset_data.append({
                "Ad Set": adset.get('adset_name', 'Unknown'),
                "Campaign": adset.get('campaign_name', 'Unknown'),
                "Spend ($)": float(adset.get('spend', 0)),
                "Impressions": int(adset.get('impressions', 0)),
                "Clicks": int(adset.get('clicks', 0)),
                "CTR (%)": float(adset.get('ctr', 0)),
                "CPC ($)": float(adset.get('cpc', 0)),
                "CPM ($)": float(adset.get('cpm', 0))
            })
        
        # Sort by spend
        adset_data.sort(key=lambda x: x["Spend ($)"], reverse=True)
        
        # Display top 10 ad sets
        st.write("**Top Ad Sets by Spend:**")
        
        for i, adset in enumerate(adset_data[:10]):
            with st.expander(f"#{i+1} {adset['Ad Set'][:50]}... - ${adset['Spend ($)']:.2f}"):
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Impressions", f"{adset['Impressions']:,}")
                with col2:
                    st.metric("Clicks", f"{adset['Clicks']:,}")
                with col3:
                    st.metric("CTR", f"{adset['CTR (%)']:.2f}%")
                with col4:
                    st.metric("CPC", f"${adset['CPC ($)']:.2f}")
    
    # Individual Ad Creative Analysis
    if detailed_performance.get('ads'):
        st.header("🎭 Individual Ad Creative Performance")
        
        ads = detailed_performance['ads']
        
        # Calculate performance scores
        max_impressions = max(int(ad.get('impressions', 0)) for ad in ads) if ads else 1
        
        ad_data = []
        for ad in ads:
            ctr = float(ad.get('ctr', 0))
            cpc = float(ad.get('cpc', 0))
            impressions = int(ad.get('impressions', 0))
            
            performance_score = calculate_performance_score(ctr, cpc, impressions, max_impressions)
            
            ad_data.append({
                "Ad Creative": ad.get('ad_name', 'Unknown'),
                "Ad Set": ad.get('adset_name', 'Unknown'),
                "Campaign": ad.get('campaign_name', 'Unknown'),
                "Spend ($)": float(ad.get('spend', 0)),
                "Impressions": impressions,
                "Clicks": int(ad.get('clicks', 0)),
                "CTR (%)": ctr,
                "CPC ($)": cpc,
                "CPM ($)": float(ad.get('cpm', 0)),
                "Performance Score": performance_score
            })
        
        # Sort by performance score
        ad_data.sort(key=lambda x: x["Performance Score"], reverse=True)
        
        # Display top performers
        st.subheader("🟢 Top Performing Creatives")
        top_performers = ad_data[:5]
        
        for i, ad in enumerate(top_performers):
            with st.expander(f"#{i+1} {ad['Ad Creative'][:40]}... - Score: {ad['Performance Score']}"):
                col1, col2, col3, col4, col5 = st.columns(5)
                with col1:
                    st.metric("Spend", f"${ad['Spend ($)']:.2f}")
                with col2:
                    st.metric("Impressions", f"{ad['Impressions']:,}")
                with col3:
                    st.metric("CTR", f"{ad['CTR (%)']:.2f}%")
                with col4:
                    st.metric("CPC", f"${ad['CPC ($)']:.2f}")
                with col5:
                    st.metric("Score", f"{ad['Performance Score']}")
        
        # Display underperformers
        st.subheader("🔴 Underperforming Creatives (Need Optimization)")
        bottom_performers = [ad for ad in ad_data if ad['Performance Score'] < 20][-5:]
        
        if bottom_performers:
            for i, ad in enumerate(bottom_performers):
                with st.expander(f"⚠️ {ad['Ad Creative'][:40]}... - Score: {ad['Performance Score']}"):
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("CTR", f"{ad['CTR (%)']:.2f}%", delta=f"{ad['CTR (%)'] - 2:.2f}% vs avg")
                    with col2:
                        st.metric("CPC", f"${ad['CPC ($)']:.2f}")
                    with col3:
                        st.metric("Impressions", f"{ad['Impressions']:,}")
                    
                    st.warning("**Recommendations:** Consider updating creative, testing new copy, or adjusting targeting")
        else:
            st.success("All creatives are performing well!")
        
        # Performance insights
        st.subheader("📊 Creative Performance Insights")
        
        col1, col2 = st.columns(2)
        with col1:
            avg_performance = sum(ad['Performance Score'] for ad in ad_data) / len(ad_data)
            st.metric("Average Performance Score", f"{avg_performance:.1f}")
            
            high_performers = len([ad for ad in ad_data if ad['Performance Score'] > 30])
            st.metric("High Performing Ads", f"{high_performers}")
        
        with col2:
            best_ctr = max(ad['CTR (%)'] for ad in ad_data)
            st.metric("Best CTR", f"{best_ctr:.2f}%")
            
            lowest_cpc = min(ad['CPC ($)'] for ad in ad_data if ad['CPC ($)'] > 0)
            st.metric("Lowest CPC", f"${lowest_cpc:.2f}")

if __name__ == "__main__":
    main()