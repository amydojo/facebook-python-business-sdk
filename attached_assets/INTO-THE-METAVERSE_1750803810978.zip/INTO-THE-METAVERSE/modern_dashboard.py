"""
Modern Marketing Intelligence Dashboard
Beautiful UI inspired by premium dashboard design with crystal clear creative gallery
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import os
from typing import Optional, Dict, List, Tuple
import numpy as np

# Page configuration
st.set_page_config(
    page_title="Marketing Intelligence Dashboard",
    page_icon="🎨",
    layout="wide",
    initial_sidebar_state="collapsed"
)

def apply_modern_styling():
    """Modern UI styling inspired by premium dashboard design"""
    st.markdown("""
    <style>
    /* Modern Dashboard Theme - Inspired by Reference UI */
    .stApp {
        background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
        color: #1e293b;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    
    /* Header Styling */
    .main-header {
        background: rgba(255,255,255,0.95);
        backdrop-filter: blur(20px);
        border-radius: 20px;
        padding: 25px 35px;
        margin-bottom: 30px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.3);
    }
    
    /* Modern Card Styling */
    .modern-card {
        background: rgba(255,255,255,0.95);
        backdrop-filter: blur(20px);
        border-radius: 20px;
        padding: 25px;
        margin: 15px 0;
        box-shadow: 0 8px 30px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.3);
        transition: all 0.3s ease;
    }
    
    .modern-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 15px 45px rgba(0,0,0,0.12);
    }
    
    /* Metric Cards - Premium Style */
    .stMetric {
        background: rgba(255,255,255,0.95);
        backdrop-filter: blur(20px);
        border-radius: 18px;
        padding: 20px;
        box-shadow: 0 8px 30px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.3);
    }
    
    /* Creative Gallery Cards */
    .creative-card {
        background: rgba(255,255,255,0.95);
        backdrop-filter: blur(20px);
        border-radius: 18px;
        padding: 20px;
        margin: 10px;
        box-shadow: 0 8px 30px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.3);
        transition: all 0.3s ease;
        overflow: hidden;
    }
    
    .creative-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 15px 45px rgba(0,0,0,0.15);
    }
    
    /* Performance Status Badges */
    .performance-viral {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: white;
        padding: 6px 16px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        display: inline-block;
    }
    
    .performance-high {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
        color: white;
        padding: 6px 16px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        display: inline-block;
    }
    
    .performance-solid {
        background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        color: white;
        padding: 6px 16px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        display: inline-block;
    }
    
    .performance-needs {
        background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
        color: white;
        padding: 6px 16px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        display: inline-block;
    }
    
    /* Activity Chart Style */
    .activity-chart {
        background: rgba(255,255,255,0.95);
        backdrop-filter: blur(20px);
        border-radius: 20px;
        padding: 25px;
        box-shadow: 0 8px 30px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.3);
    }
    
    /* Button Styling */
    .stButton > button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 12px;
        padding: 10px 20px;
        font-weight: 600;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
    }
    
    /* Select Box Styling */
    .stSelectbox > div > div {
        background: rgba(255,255,255,0.95);
        border-radius: 12px;
        border: 1px solid rgba(255,255,255,0.3);
        backdrop-filter: blur(20px);
    }
    
    /* Tab Styling */
    .stTabs [data-baseweb="tab-list"] {
        background: rgba(255,255,255,0.95);
        border-radius: 16px;
        padding: 8px;
        margin-bottom: 25px;
        backdrop-filter: blur(20px);
        box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    }
    
    .stTabs [data-baseweb="tab"] {
        border-radius: 12px;
        padding: 10px 20px;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    /* Hide Streamlit Branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    
    /* Custom Progress Indicators */
    .progress-ring {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 50%;
        width: 60px;
        height: 60px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 700;
        font-size: 14px;
    }
    </style>
    """, unsafe_allow_html=True)

# REMOVED: def load_sample_data():
    """Load sample data for demonstration"""
    try:
        # Sample lead data
        leads_data = {
            'Contact Source': ['Meta'] * 50 + ['Facebook AD'] * 30 + ['Instagram AD'] * 25,
            'Overall Status': ['Closed'] * 15 + ['Deposit Paid'] * 10 + ['Scheduled'] * 20 + ['Lead'] * 60,
            'Consult Status': ['Scheduled'] * 25 + ['Arrived'] * 15 + ['No Show'] * 35,
            'Brand': ['Smooth MD'] * 105,
            'fldAnzFEtflKfcrcB': [f'lead{i}@email.com' for i in range(105)],
            'Date': pd.date_range('2024-01-01', periods=105, freq='D').tolist()
        }
        
        leads_df = pd.DataFrame(leads_data)
        
        # Sample transaction data
        trans_data = {
            'fldSUAaKeDSuOsr2c': [2500, 3200, 1800, 4500, 2100, 3800, 2900, 4200, 1950, 3600] * 3,
            'Client': [f'lead{i}@email.com' for i in range(30)]
        }
        
        trans_df = pd.DataFrame(trans_data)
        
        return leads_df, trans_df, "Sample data loaded successfully"
        
    except Exception as e:
        return pd.DataFrame(), pd.DataFrame(), f"Error loading data: {str(e)}"

def filter_meta_leads(df):
    """Filter to only Meta leads"""
    if df.empty:
        return df
    
    # Filter for Meta/Facebook/Instagram sources
    meta_sources = ['Meta', 'Facebook AD', 'Instagram AD']
    if 'Contact Source' in df.columns:
        return df[df['Contact Source'].isin(meta_sources)]
    
    return df

def calculate_metrics(leads_df, trans_df):
    """Calculate key performance metrics"""
    try:
        # Basic lead metrics
        total_leads = len(leads_df)
        
        # Booked leads (Scheduled or Arrived)
        booked_statuses = ['Scheduled', 'Arrived']
        if 'Consult Status' in leads_df.columns:
            booked_count = len(leads_df[leads_df['Consult Status'].isin(booked_statuses)])
        else:
            booked_count = 0
        
        # Conversion rate
        conversion_rate = (booked_count / total_leads * 100) if total_leads > 0 else 0
        
        # Revenue calculations
        if not trans_df.empty and 'fldSUAaKeDSuOsr2c' in trans_df.columns:
            total_revenue = trans_df['fldSUAaKeDSuOsr2c'].sum()
            avg_transaction = trans_df['fldSUAaKeDSuOsr2c'].mean()
        else:
            total_revenue = 0
            avg_transaction = 0
        
        # ROAS calculation (assuming $10k spend)
        estimated_spend = 10000
        roas = (total_revenue / estimated_spend) if total_revenue > 0 else 0
        
        return {
            'total_leads': total_leads,
            'booked_leads': booked_count,
            'conversion_rate': round(conversion_rate, 1),
            'total_revenue': total_revenue,
            'avg_transaction': round(avg_transaction, 2),
            'roas': round(roas, 1)
        }
        
    except Exception as e:
        st.error(f"Error calculating metrics: {e}")
        return {
            'total_leads': 0,
            'booked_leads': 0,
            'conversion_rate': 0.0,
            'total_revenue': 0.0,
            'avg_transaction': 0.0,
            'roas': 0.0
        }

def create_creative_gallery(leads_df):
    """Create beautiful interactive creative gallery"""
    st.markdown("### 🎨 Interactive Creative Performance Gallery")
    
    # Creative filtering controls
    col1, col2, col3 = st.columns(3)
    
    with col1:
        sort_option = st.selectbox("Sort by:", 
            ["Performance Score", "CTR", "ROAS", "Cost/Lead", "Leads Generated"])
    
    with col2:
        show_count = st.selectbox("Show:", 
            ["Top 12", "Top 20", "All Creatives"])
    
    with col3:
        performance_filter = st.selectbox("Performance:", 
            ["All Performance", "High Performers", "Solid Performers", "Needs Optimization"])
    
    # Sample creative data for demonstration
    creative_data = []
    for i in range(20):
        performance_score = np.random.uniform(1, 5)
        creative_data.append({
            'name': f'Creative {i+1}',
            'performance_score': performance_score,
            'ctr': np.random.uniform(0.5, 3.5),
            'roas': np.random.uniform(1.0, 6.0),
            'cost_per_lead': np.random.uniform(20, 80),
            'leads': np.random.randint(5, 50),
            'campaign_name': f'Campaign {np.random.randint(1, 6)}',
            'image_url': f'https://via.placeholder.com/300x200/667eea/ffffff?text=Creative+{i+1}',
            'title': f'Smooth MD Beauty Treatment {i+1}',
            'body': f'Transform your look with our premium treatments. Limited time offer!'
        })
    
    creative_df = pd.DataFrame(creative_data)
    
    # Sort creatives
    if sort_option == "Performance Score":
        sorted_creatives = creative_df.nlargest(16, 'performance_score')
    elif sort_option == "CTR":
        sorted_creatives = creative_df.nlargest(16, 'ctr')
    elif sort_option == "ROAS":
        sorted_creatives = creative_df.nlargest(16, 'roas')
    elif sort_option == "Cost/Lead":
        sorted_creatives = creative_df.nsmallest(16, 'cost_per_lead')
    else:
        sorted_creatives = creative_df.nlargest(16, 'leads')
    
    # Limit display count
    if show_count == "Top 12":
        sorted_creatives = sorted_creatives.head(12)
    elif show_count == "Top 20":
        sorted_creatives = sorted_creatives.head(20)
    
    st.markdown("---")
    
    # Display creative cards in beautiful grid
    cols_per_row = 4
    for i in range(0, len(sorted_creatives), cols_per_row):
        cols = st.columns(cols_per_row)
        
        for j, col in enumerate(cols):
            idx = i + j
            if idx < len(sorted_creatives):
                creative = sorted_creatives.iloc[idx]
                
                with col:
                    # Performance status
                    psych_score = creative['performance_score']
                    if psych_score >= 4.0:
                        status_class = "performance-viral"
                        status_emoji = "🔥"
                        status_text = "VIRAL POTENTIAL"
                    elif psych_score >= 3.0:
                        status_class = "performance-high" 
                        status_emoji = "⚡"
                        status_text = "HIGH PERFORMER"
                    elif psych_score >= 2.0:
                        status_class = "performance-solid"
                        status_emoji = "📈"
                        status_text = "SOLID PERFORMER"
                    else:
                        status_class = "performance-needs"
                        status_emoji = "🔄"
                        status_text = "NEEDS OPTIMIZATION"
                    
                    # Creative card
                    st.markdown(f"""
                    <div class="creative-card">
                        <div style="text-align: center; margin-bottom: 15px;">
                            <span style="font-size: 24px;">{status_emoji}</span>
                            <br>
                            <span class="{status_class}">{status_text}</span>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    # Display image
                    try:
                        st.image(creative['image_url'], use_container_width=True,
                                caption=f"Score: {creative['performance_score']:.1f}⭐")
                    except:
                        st.markdown(f"""
                        <div style="
                            height: 200px; 
                            background: linear-gradient(45deg, #667eea 0%, #764ba2 100%);
                            border-radius: 12px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            color: white;
                            font-size: 18px;
                            font-weight: 600;
                        ">🎨 {creative['name']}</div>
                        """, unsafe_allow_html=True)
                    
                    # Metrics display
                    st.markdown(f"""
                    <div style="
                        margin: 15px 0; 
                        padding: 15px; 
                        background: rgba(255,255,255,0.7); 
                        border-radius: 12px;
                        backdrop-filter: blur(10px);
                    ">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                            <span style="color: #10b981; font-weight: 600;">CTR: {creative['ctr']:.2f}%</span>
                            <span style="color: #3b82f6; font-weight: 600;">ROAS: {creative['roas']:.1f}x</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                            <span style="color: #f59e0b; font-weight: 600;">Leads: {creative['leads']}</span>
                            <span style="color: #ef4444; font-weight: 600;">Cost: ${creative['cost_per_lead']:.0f}</span>
                        </div>
                        <div style="text-align: center; margin-top: 10px;">
                            <small style="color: #6b7280; font-weight: 500;">
                                {'🎯 High Engagement' if creative['ctr'] > 2.0 else '📊 Standard Appeal'} • 
                                {'💰 Cost Efficient' if creative['cost_per_lead'] < 50 else '💸 Premium Cost'}
                            </small>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    # Creative preview
                    st.markdown(f"""
                    <div style="
                        margin-top: 10px; 
                        padding: 12px; 
                        background: rgba(0,0,0,0.05); 
                        border-radius: 8px;
                    ">
                        <strong style="color: #1e293b; font-size: 13px;">{creative['title'][:35]}{'...' if len(creative['title']) > 35 else ''}</strong><br>
                        <em style="color: #64748b; font-size: 12px;">{creative['body'][:45]}{'...' if len(creative['body']) > 45 else ''}</em>
                    </div>
                    """, unsafe_allow_html=True)

def create_performance_chart(leads_df):
    """Create beautiful performance trend chart"""
    # Sample data for demonstration
    months = ['Jan 2024', 'Feb 2024', 'Mar 2024', 'Apr 2024', 'May 2024']
    leads = [45, 52, 48, 61, 58]
    conversions = [12, 18, 15, 22, 20]
    
    fig = go.Figure()
    
    # Leads line
    fig.add_trace(go.Scatter(
        x=months,
        y=leads,
        mode='lines+markers',
        name='Total Leads',
        line=dict(color='#667eea', width=3),
        marker=dict(size=8, color='#667eea')
    ))
    
    # Conversions line
    fig.add_trace(go.Scatter(
        x=months,
        y=conversions,
        mode='lines+markers',
        name='Conversions',
        line=dict(color='#10b981', width=3),
        marker=dict(size=8, color='#10b981')
    ))
    
    fig.update_layout(
        title="Performance Trend",
        xaxis_title="Month",
        yaxis_title="Count",
        height=400,
        plot_bgcolor='rgba(255,255,255,0.95)',
        paper_bgcolor='rgba(255,255,255,0.95)',
        font=dict(family="Inter, sans-serif"),
        title_font_size=20,
        title_font_color='#1e293b'
    )
    
    return fig

def main():
    """Main application"""
    apply_modern_styling()
    
    # Header
    st.markdown("""
    <div class="main-header">
        <h1 style="
            margin: 0;
            font-size: 32px;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        ">🎨 Marketing Intelligence Dashboard</h1>
        <p style="
            margin: 8px 0 0 0;
            color: #64748b;
            font-size: 16px;
            font-weight: 500;
        ">Beautiful analytics with crystal clear creative performance insights</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Load data
# REMOVED:     leads_df, trans_df, status = load_sample_data()
    
    # Filter to Meta leads only
    meta_leads = filter_meta_leads(leads_df)
    
    # Calculate metrics
    metrics = calculate_metrics(meta_leads, trans_df)
    
    # Key Metrics
    st.markdown("### 📊 Key Performance Metrics")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Meta Leads", f"{metrics['total_leads']:,}")
    
    with col2:
        st.metric("Booked Consultations", f"{metrics['booked_leads']:,}")
    
    with col3:
        st.metric("Conversion Rate", f"{metrics['conversion_rate']}%")
    
    with col4:
        st.metric("Total Revenue", f"${metrics['total_revenue']:,.0f}")
    
    # Performance Chart
    st.markdown("### 📈 Performance Trends")
    chart = create_performance_chart(meta_leads)
    st.plotly_chart(chart, use_container_width=True)
    
    # Creative Gallery
    create_creative_gallery(meta_leads)
    
    # Status info
    st.info(f"📊 Dashboard Status: {status}")
    
    # Note about connecting real data
    st.markdown("""
    ---
    💡 **Connect Your Real Data**: To see your actual Meta ad creatives and performance data in this beautiful interface, 
    please provide your Meta API access token and Airtable API key in the sidebar or environment variables.
    """)

if __name__ == "__main__":
    main()