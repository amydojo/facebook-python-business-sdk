import os
import streamlit as st
import pandas as pd
import numpy as np
import json
import hashlib
import time
import requests
from datetime import datetime, timedelta
import base64
from pyairtable import Api, Base, Table
import plotly.graph_objects as go
import plotly.express as px
from design_system import (
    styled_header, card, status_indicator, 
    section_divider, badge, icon_text, 
    COLORS, TYPOGRAPHY, SPACING, BORDER_RADIUS
)
from data_utils import (
    filter_smooth_md_meta_data, 
    fix_date_columns,
    safe_is_booked,
    safe_is_converted,
    calculate_metrics
)

# Page config and setup
st.set_page_config(
    page_title="Ad Command Center", 
    page_icon="📊", 
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if "initialized" not in st.session_state:
    st.session_state.initialized = True
    st.session_state.active_tab = "dashboard"
    st.session_state.leads_df = None
    st.session_state.transactions_df = None
    st.session_state.last_refresh = None
    
    # Default credentials (these can be overridden)
    st.session_state.airtable_api_key = os.environ.get("AIRTABLE_API_KEY", "")
    st.session_state.base_id = "appri2CgCoIiuZWq3"
    st.session_state.leads_table_name = "Leads"
    st.session_state.transactions_table_name = "Transactions"
    st.session_state.meta_access_token = os.environ.get("META_ACCESS_TOKEN", "")
    st.session_state.pixel_id = os.environ.get("META_PIXEL_ID", "")
    st.session_state.zapier_webhook = ""
    st.session_state.openai_api_key = os.environ.get("OPENAI_API_KEY", "")

# Utility functions
def load_airtable_data(api_key, base_id, table_name):
    """
    Load data from Airtable table
    
    Args:
        api_key (str): Airtable API key
        base_id (str): Airtable base ID
        table_name (str): Table name
        
    Returns:
        pd.DataFrame: DataFrame with table data
    """
    try:
        api = Api(api_key)
        table = api.table(base_id, table_name)
        records = table.all()
        
        if not records:
            st.info(f"No records found in the {table_name} table.")
            return pd.DataFrame()
        
        # Convert Airtable records to DataFrame
        rows = []
        for record in records:
            row = record['fields'].copy()
            row['id'] = record['id']
            rows.append(row)
        
        df = pd.DataFrame(rows)
        
        # Debug column names to help identify the structure
        print(f"{table_name} DataFrame Columns: {df.columns}")
        
        if not df.empty:
            # Map column names to expected format if needed
            column_mapping = {
                # Add specific mappings if needed
            }
            
            for old_col, new_col in column_mapping.items():
                if old_col in df.columns and new_col not in df.columns:
                    df[new_col] = df[old_col]
                    
        # Ensure required columns exist for common operations
        required_cols = {"leads": ["Source", "Status"], 
                       "transactions": ["Revenue"]}
        
        if "lead" in table_name.lower():
            # Ensure we have a date column (prioritizing Inbound as requested)
            df = fix_date_columns(df, target_column='Date')
        elif "transaction" in table_name.lower():
            # For transactions, ensure we have a date column
            df = fix_date_columns(df, target_column='Date')
        
        return df
    except Exception as e:
        st.error(f"Error loading Airtable data from {table_name}: {e}")
        return pd.DataFrame()

def update_airtable_record(api_key, base_id, table_name, record_id, fields):
    """
    Update an Airtable record
    
    Args:
        api_key (str): Airtable API key
        base_id (str): Airtable base ID
        table_name (str): Table name
        record_id (str): Record ID to update
        fields (dict): Fields to update
        
    Returns:
        bool: Success status
    """
    try:
        api = Api(api_key)
        table = api.table(base_id, table_name)
        table.update(record_id, fields)
        return True
    except Exception as e:
        st.error(f"Error updating Airtable record: {e}")
        return False

def hash_data(data):
    """Hash data to protect privacy"""
    if not data:
        return None
    data_str = str(data).lower().strip()
    return hashlib.sha256(data_str.encode()).hexdigest()

def send_meta_conversion_event(access_token, pixel_id, event_name, user_data, 
                               lead_row=None, event_time=None, source_url=None, 
                               custom_data=None):
    """
    Send conversion event to Meta Conversion API
    
    Args:
        access_token (str): Meta API access token
        pixel_id (str): Meta Pixel ID
        event_name (str): Event name (e.g., "Lead", "Purchase")
        user_data (dict): Hashed user data (email, phone, etc.)
        lead_row (pd.Series, optional): Lead data row
        event_time (int, optional): Event time as Unix timestamp
        source_url (str, optional): Source URL
        custom_data (dict, optional): Custom event data
        
    Returns:
        tuple: (success (bool), message (str))
    """
    try:
        if not access_token or not pixel_id:
            return False, "Missing Meta access token or pixel ID"
        
        # Prepare the event time
        if not event_time:
            event_time = int(time.time())
            
        # Prepare the event data
        event_data = {
            "event_name": event_name,
            "event_time": event_time,
            "action_source": "website",
            "user_data": user_data
        }
        
        # Add source URL if provided
        if source_url:
            event_data["event_source_url"] = source_url
            
        # Add custom data if provided
        if custom_data:
            event_data["custom_data"] = custom_data
        
        # Prepare the API request data
        api_data = {
            "data": [event_data],
            "access_token": access_token
        }
        
        # Send the request to Meta Conversion API
        api_endpoint = f"https://graph.facebook.com/v22.0/{pixel_id}/events"
        response = requests.post(api_endpoint, json=api_data)
        
        # Check if the request was successful
        if response.status_code == 200:
            result = response.json()
            if "events_received" in result and result["events_received"] > 0:
                return True, f"Event '{event_name}' sent successfully"
            else:
                return False, f"Event sent but not received: {result}"
        else:
            return False, f"Error sending event: {response.text}"
    except Exception as e:
        return False, f"Error sending Meta conversion event: {e}"

def get_csv_download_link(df):
    """Generate a link to download the dataframe as CSV"""
    csv = df.to_csv(index=False)
    b64 = base64.b64encode(csv.encode()).decode()
    href = f'<a href="data:file/csv;base64,{b64}" download="data.csv">Download CSV</a>'
    return href

def safe_metric_value(value):
    """Ensures metric values are properly formatted and never None"""
    if pd.isna(value) or value is None:
        return 0
    if isinstance(value, (int, float)):
        return value
    try:
        return float(value)
    except (ValueError, TypeError):
        return 0

# Sidebar
with st.sidebar:
    st.title("CAPI Command Center")
    st.markdown("---")
    
    # Navigation
    st.subheader("Navigation")
    sidebar_tabs = {
        "dashboard": "📊 Dashboard",
        "insights": "🔍 Strategic Insights",
        "settings": "⚙️ Settings"
    }
    
    for tab_id, tab_name in sidebar_tabs.items():
        if st.button(tab_name, key=f"btn_{tab_id}"):
            st.session_state.active_tab = tab_id
    
    st.markdown("---")
    
    # Data refresh and authentication
    with st.expander("Data Refresh & Auth", expanded=False):
        st.write("Last refresh: " + 
                (st.session_state.last_refresh.strftime("%Y-%m-%d %H:%M:%S") 
                 if st.session_state.last_refresh else "Never"))
        
        if st.button("Refresh Data Now"):
            with st.spinner("Loading data from Airtable..."):
                # Load leads data
                leads_df = load_airtable_data(
                    st.session_state.airtable_api_key, 
                    st.session_state.base_id, 
                    st.session_state.leads_table_name
                )
                
                # Load transactions data
                transactions_df = load_airtable_data(
                    st.session_state.airtable_api_key, 
                    st.session_state.base_id, 
                    st.session_state.transactions_table_name
                )
                
                # Filter to only get Smooth MD Meta leads
                if not leads_df.empty:
                    filtered_leads = filter_smooth_md_meta_data(leads_df)
                    st.session_state.leads_df = filtered_leads
                else:
                    st.session_state.leads_df = pd.DataFrame()
                    
                # For transactions, just store as is for now
                st.session_state.transactions_df = transactions_df
                
                # Update last refresh time
                st.session_state.last_refresh = datetime.now()
                
                # Show success message
                st.success(f"Data refreshed: {len(st.session_state.leads_df)} leads loaded")
                # Force rerun to update UI
                st.rerun()

# Main content area
def render_dashboard_tab():
    """Render the dashboard tab content"""
    styled_header("Smooth MD Meta Leads Dashboard")
    
    # Initialize all metrics with default values
    metrics = {'leads_count': 0, 'booked_count': 0, 'converted_count': 0, 
               'booking_rate': 0, 'conversion_rate': 0}
    
    # Calculate metrics using filtered data if available
    if st.session_state.leads_df is not None and not st.session_state.leads_df.empty:
        metrics = calculate_metrics(st.session_state.leads_df)
    
    # Display metrics in a nice grid
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Total Leads", f"{metrics['leads_count']:,}")
        
    with col2:
        st.metric("Booked Consultations", 
                 f"{metrics['booked_count']:,}",
                 f"{metrics['booking_rate']:.1f}%")
        
    with col3:
        st.metric("Converted Leads", 
                 f"{metrics['converted_count']:,}",
                 f"{metrics['conversion_rate']:.1f}%")
    
    # Add lead funnel and other charts
    st.markdown("### Lead Funnel")
    if st.session_state.leads_df is not None and not st.session_state.leads_df.empty:
        # Create funnel data
        funnel_data = {
            "Leads": metrics['leads_count'],
            "Booked": metrics['booked_count'],
            "Converted": metrics['converted_count']
        }
        
        # Create funnel chart
        fig = go.Figure(go.Funnel(
            y=list(funnel_data.keys()),
            x=list(funnel_data.values()),
            textinfo="value+percent initial",
            marker={"color": ["#3366CC", "#6699CC", "#99CCFF"]}
        ))
        
        fig.update_layout(
            title="Smooth MD Meta Leads Funnel",
            margin=dict(l=40, r=40, t=40, b=40)
        )
        
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No data available for funnel visualization.")
    
    # Recent Leads section
    st.markdown("### Recent Smooth MD Meta Leads")
    if st.session_state.leads_df is not None and not st.session_state.leads_df.empty:
        # Display recent leads in a table
        recent_leads = st.session_state.leads_df.copy()
        
        # Select relevant columns for display
        display_columns = ["Name", "Email", "Phone", "Source", "Status", "Date"]
        available_cols = [col for col in display_columns if col in recent_leads.columns]
        
        if not available_cols:
            # Fallback to first few columns
            available_cols = list(recent_leads.columns[:5])
        
        # Sort by date if available
        if "Date" in recent_leads.columns:
            recent_leads = recent_leads.sort_values("Date", ascending=False)
        
        # Show the most recent leads
        st.dataframe(recent_leads[available_cols].head(10), use_container_width=True)
    else:
        st.info("No leads data available.")

def render_insights_tab():
    """Render the strategic insights tab"""
    styled_header("Strategic Insights")
    
    if st.session_state.leads_df is None or st.session_state.leads_df.empty:
        st.warning("No leads data available to generate insights. Please refresh the data.")
        return
        
    # KPI section
    st.subheader("Key Performance Indicators")
    cols = st.columns(4)
    
    # Calculate advanced metrics
    total_leads = len(st.session_state.leads_df)
    
    # Calculate lead statuses
    lead_status_counts = st.session_state.leads_df['Status'].fillna('Unknown').value_counts()
    lead_status_counts = lead_status_counts.to_dict()
    
    # Determine most common statuses
    if lead_status_counts:
        most_common_status = max(lead_status_counts.items(), key=lambda x: x[1])[0]
    else:
        most_common_status = "N/A"
    
    # Display KPIs
    with cols[0]:
        st.metric("Total Meta Leads", f"{total_leads:,}")
    
    with cols[1]:
        booking_rate = 0
        booked_count = sum(safe_is_booked(row) for _, row in st.session_state.leads_df.iterrows())
        if total_leads > 0:
            booking_rate = (booked_count / total_leads) * 100
        st.metric("Booking Rate", f"{booking_rate:.1f}%")
    
    with cols[2]:
        conversion_rate = 0
        converted_count = sum(safe_is_converted(row) for _, row in st.session_state.leads_df.iterrows())
        if total_leads > 0:
            conversion_rate = (converted_count / total_leads) * 100
        st.metric("Conversion Rate", f"{conversion_rate:.1f}%")
    
    with cols[3]:
        st.metric("Most Common Status", most_common_status)
    
    # Lead source analysis
    st.subheader("Lead Source Analysis")
    
    # Get source breakdown
    if 'Source' in st.session_state.leads_df.columns:
        source_counts = st.session_state.leads_df['Source'].fillna('Unknown').value_counts()
        
        # Create pie chart
        fig = px.pie(
            values=source_counts.values,
            names=source_counts.index,
            title="Leads by Source",
            color_discrete_sequence=px.colors.sequential.Blues
        )
        fig.update_traces(textposition='inside', textinfo='percent+label')
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Source data not available for visualization.")
    
    # Lead quality analysis
    st.subheader("Lead Quality Analysis")
    
    if 'Status' in st.session_state.leads_df.columns:
        # Create status breakdown chart
        status_counts = st.session_state.leads_df['Status'].fillna('Unknown').value_counts()
        
        fig = px.bar(
            x=status_counts.index,
            y=status_counts.values,
            title="Leads by Status",
            labels={'x': 'Status', 'y': 'Count'},
            color=status_counts.values,
            color_continuous_scale='Blues'
        )
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Status data not available for visualization.")

def render_settings_tab():
    """Render the settings tab"""
    styled_header("Settings")
    
    # Data connection settings
    st.subheader("Data Connection")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Airtable Connection")
        
        # Airtable API Key (use password field for security)
        st.session_state.airtable_api_key = st.text_input(
            "Airtable API Key",
            value=st.session_state.airtable_api_key,
            type="password"
        )
        
        # Base ID
        st.session_state.base_id = st.text_input(
            "Airtable Base ID",
            value=st.session_state.base_id
        )
        
        # Leads Table Name
        st.session_state.leads_table_name = st.text_input(
            "Leads Table Name",
            value=st.session_state.leads_table_name
        )
        
        # Transactions Table Name
        st.session_state.transactions_table_name = st.text_input(
            "Transactions Table Name",
            value=st.session_state.transactions_table_name
        )
    
    with col2:
        st.markdown("#### Meta Conversion API")
        
        # Meta Access Token (use password field for security)
        st.session_state.meta_access_token = st.text_input(
            "Meta Access Token",
            value=st.session_state.meta_access_token,
            type="password"
        )
        
        # Meta Pixel ID
        st.session_state.pixel_id = st.text_input(
            "Meta Pixel ID",
            value=st.session_state.pixel_id
        )
        
        # Test connection button
        if st.button("Test Meta Connection"):
            if not st.session_state.meta_access_token or not st.session_state.pixel_id:
                st.error("Meta access token and Pixel ID are required")
            else:
                # Test the connection with a dummy event
# REMOVED:                 test_data = {
                    "em": ["test@example.com"]
                }
                
                success, message = send_meta_conversion_event(
                    st.session_state.meta_access_token,
                    st.session_state.pixel_id,
                    "TestEvent",
# REMOVED:                     test_data
                )
                
                if success:
                    st.success(message)
                else:
                    st.error(message)
    
    # Save settings button
    if st.button("Save Settings"):
        # Settings are already saved in session state
        st.success("Settings saved successfully")

def main():
    # Load data on first run if not already loaded
    if (st.session_state.leads_df is None or st.session_state.transactions_df is None) and st.session_state.airtable_api_key:
        with st.spinner("Loading data from Airtable..."):
            # Load leads data
            leads_df = load_airtable_data(
                st.session_state.airtable_api_key, 
                st.session_state.base_id, 
                st.session_state.leads_table_name
            )
            
            # Load transactions data
            transactions_df = load_airtable_data(
                st.session_state.airtable_api_key, 
                st.session_state.base_id, 
                st.session_state.transactions_table_name
            )
            
            # Filter to only get Smooth MD Meta leads
            if not leads_df.empty:
                filtered_leads = filter_smooth_md_meta_data(leads_df)
                st.session_state.leads_df = filtered_leads
            else:
                st.session_state.leads_df = pd.DataFrame()
                
            # For transactions, just store as is for now
            st.session_state.transactions_df = transactions_df
            
            # Update last refresh time
            st.session_state.last_refresh = datetime.now()
    
    # Render the active tab
    if st.session_state.active_tab == "dashboard":
        render_dashboard_tab()
    elif st.session_state.active_tab == "insights":
        render_insights_tab()
    elif st.session_state.active_tab == "settings":
        render_settings_tab()

# Run the app
if __name__ == "__main__":
    main()