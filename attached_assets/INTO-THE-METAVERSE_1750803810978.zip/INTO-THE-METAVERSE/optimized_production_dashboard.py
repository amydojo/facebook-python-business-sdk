"""
Optimized Production Dashboard
Real data only - no mock or placeholder data
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import os
import requests
from datetime import datetime, timedelta
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Campaign Analytics",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

def apply_production_styling():
    """Production-ready styling with mobile optimization"""
    st.markdown("""
    <style>
    .stApp {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    }
    
    .main .block-container {
        padding: 1rem;
        max-width: 100%;
    }
    
    @media (min-width: 768px) {
        .main .block-container {
            padding: 2rem;
            max-width: 1400px;
        }
    }
    
    .metric-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(20px);
        border-radius: 16px;
        padding: 20px;
        margin: 12px 0;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        border: 0.5px solid rgba(0, 0, 0, 0.05);
    }
    
    .status-success { border-left: 4px solid #34c759; }
    .status-error { border-left: 4px solid #ff3b30; }
    .status-warning { border-left: 4px solid #ff9500; }
    
    #MainMenu, footer, header, .stDeployButton {
        visibility: hidden;
    }
    </style>
    """, unsafe_allow_html=True)

class RealDataManager:
    """Manages only authentic data connections"""
    
    def __init__(self):
        self.meta_data = {}
        self.connection_status = {}
    
    def load_meta_insights(self):
        """Load authentic Meta campaign data"""
        try:
            access_token = os.getenv('META_ACCESS_TOKEN')
            ad_account_id = os.getenv('META_AD_ACCOUNT_ID')
            
            if not access_token or not ad_account_id:
                self.connection_status['meta'] = "Credentials required"
                return False
            
            url = f"https://graph.facebook.com/v18.0/act_{ad_account_id}/insights"
            params = {
                'access_token': access_token,
                'fields': 'spend,impressions,clicks,actions,cost_per_action_type,cpm,cpc,ctr',
                'date_preset': 'last_30d',
                'limit': 50
            }
            
            response = requests.get(url, params=params, timeout=15)
            
            if response.status_code == 200:
                data = response.json()
                insights = data.get('data', [])
                
                if insights:
                    # Calculate real metrics from authentic data
                    total_spend = sum(float(insight.get('spend', 0)) for insight in insights)
                    total_impressions = sum(int(insight.get('impressions', 0)) for insight in insights)
                    total_clicks = sum(int(insight.get('clicks', 0)) for insight in insights)
                    
                    self.meta_data = {
                        'total_spend': total_spend,
                        'total_impressions': total_impressions,
                        'total_clicks': total_clicks,
                        'avg_cpm': sum(float(insight.get('cpm', 0)) for insight in insights) / len(insights),
                        'avg_cpc': sum(float(insight.get('cpc', 0)) for insight in insights) / len(insights),
                        'avg_ctr': sum(float(insight.get('ctr', 0)) for insight in insights) / len(insights),
                        'insights_count': len(insights),
                        'raw_insights': insights
                    }
                    
                    self.connection_status['meta'] = "Connected - Real data loaded"
                    logger.info(f"Meta data loaded: ${total_spend:,.2f} spend, {total_impressions:,} impressions")
                    return True
                else:
                    self.connection_status['meta'] = "No insights available"
                    return False
            else:
                self.connection_status['meta'] = f"API Error: {response.status_code}"
                return False
                
        except Exception as e:
            self.connection_status['meta'] = f"Connection failed: {str(e)}"
            logger.error(f"Meta API error: {e}")
            return False
    
    def test_airtable_connection(self):
        """Test Airtable connection without loading data"""
        try:
            from pyairtable import Api
            
            airtable_key = os.getenv('AIRTABLE_API_KEY')
            if not airtable_key:
                self.connection_status['airtable'] = "API key required"
                return False
            
            api = Api(airtable_key)
            table = api.table('appwPsfAb2ZmWqhJD', 'tblhU4gONxgdA5jTF')
            test_records = table.all(max_records=1)
            
            if test_records:
                self.connection_status['airtable'] = "Connected - Ready for revenue data"
                return True
            else:
                self.connection_status['airtable'] = "Connected - No data found"
                return False
                
        except Exception as e:
            error_msg = str(e)
            if "INVALID_PERMISSIONS" in error_msg:
                self.connection_status['airtable'] = "Permissions needed - Update API key access"
            elif "MODEL_NOT_FOUND" in error_msg:
                self.connection_status['airtable'] = "Table access required"
            else:
                self.connection_status['airtable'] = "Connection issue"
            return False

def create_meta_performance_chart(meta_data):
    """Create performance chart from real Meta data"""
    if not meta_data or not meta_data.get('raw_insights'):
        return None
    
    insights = meta_data['raw_insights']
    
    # Extract daily data if available
    dates = []
    spends = []
    impressions = []
    
    for insight in insights:
        # If date_start is available, use it; otherwise use index
        date_key = insight.get('date_start', f"Day {len(dates) + 1}")
        dates.append(date_key)
        spends.append(float(insight.get('spend', 0)))
        impressions.append(int(insight.get('impressions', 0)))
    
    fig = go.Figure()
    
    # Add spend trace
    fig.add_trace(go.Scatter(
        x=dates,
        y=spends,
        mode='lines+markers',
        name='Daily Spend ($)',
        line=dict(color='#007AFF', width=3),
        marker=dict(size=8)
    ))
    
    # Add impressions on secondary y-axis
    fig.add_trace(go.Scatter(
        x=dates,
        y=impressions,
        mode='lines+markers',
        name='Impressions',
        yaxis='y2',
        line=dict(color='#34C759', width=3),
        marker=dict(size=8)
    ))
    
    fig.update_layout(
        title="Meta Campaign Performance (Real Data)",
        xaxis_title="Date",
        yaxis_title="Spend ($)",
        yaxis2=dict(
            title="Impressions",
            overlaying='y',
            side='right'
        ),
        height=400,
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(family='-apple-system, BlinkMacSystemFont, sans-serif')
    )
    
    return fig

def main():
    """Main application with real data only"""
    
    apply_production_styling()
    
    # Header
    st.title("📊 Campaign Analytics Dashboard")
    st.markdown("**Real-time performance data from your marketing campaigns**")
    
    # Initialize data manager
    data_manager = RealDataManager()
    
    # Load real data
    with st.spinner("Loading authentic campaign data..."):
        meta_success = data_manager.load_meta_insights()
        airtable_tested = data_manager.test_airtable_connection()
    
    # Connection status
    st.subheader("🔗 Data Connections")
    
    col1, col2 = st.columns(2)
    
    with col1:
        meta_status = data_manager.connection_status.get('meta', 'Unknown')
        if 'Connected' in meta_status:
            st.markdown(f'<div class="metric-card status-success"><strong>Meta API:</strong> {meta_status}</div>', 
                       unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="metric-card status-error"><strong>Meta API:</strong> {meta_status}</div>', 
                       unsafe_allow_html=True)
    
    with col2:
        airtable_status = data_manager.connection_status.get('airtable', 'Unknown')
        if 'Connected' in airtable_status:
            st.markdown(f'<div class="metric-card status-success"><strong>Airtable:</strong> {airtable_status}</div>', 
                       unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="metric-card status-warning"><strong>Airtable:</strong> {airtable_status}</div>', 
                       unsafe_allow_html=True)
    
    # Display real Meta metrics if available
    if meta_success and data_manager.meta_data:
        st.subheader("📈 Meta Campaign Metrics (Real Data)")
        
        meta_data = data_manager.meta_data
        
        # Key metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                "Total Spend",
                f"${meta_data['total_spend']:,.2f}",
                help="Authentic spend data from Meta API"
            )
        
        with col2:
            st.metric(
                "Impressions",
                f"{meta_data['total_impressions']:,}",
                help="Real impression data from your campaigns"
            )
        
        with col3:
            st.metric(
                "Clicks",
                f"{meta_data['total_clicks']:,}",
                help="Actual clicks from Meta campaigns"
            )
        
        with col4:
            ctr = meta_data['avg_ctr']
            st.metric(
                "Avg CTR",
                f"{ctr:.2f}%",
                help="Click-through rate from real campaign data"
            )
        
        # Performance chart
        st.subheader("📊 Campaign Performance Trend")
        chart = create_meta_performance_chart(meta_data)
        if chart:
            st.plotly_chart(chart, use_container_width=True)
        
        # Detailed metrics
        st.subheader("💰 Cost Metrics")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Avg CPM", f"${meta_data['avg_cpm']:.2f}")
        
        with col2:
            st.metric("Avg CPC", f"${meta_data['avg_cpc']:.2f}")
        
        with col3:
            insights_count = meta_data['insights_count']
            st.metric("Data Points", f"{insights_count}")
        
        # Revenue calculation placeholder
        st.subheader("💵 Revenue Analysis")
        st.info("Revenue data will be calculated once Airtable connection is established with proper permissions.")
        
        if 'Permissions needed' in airtable_status:
            st.warning("Update your Airtable API key permissions to access transaction data for ROAS calculations.")
        
    else:
        st.error("Meta API connection required to display campaign metrics.")
        st.info("Please verify your Meta API credentials to access real campaign data.")
    
    # Data integrity notice
    st.markdown("---")
    st.markdown("**Data Integrity:** This dashboard displays only authentic data from your connected APIs. No mock or placeholder data is used.")

if __name__ == "__main__":
    main()