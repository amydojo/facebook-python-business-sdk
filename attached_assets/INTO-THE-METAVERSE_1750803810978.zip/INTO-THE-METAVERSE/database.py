"""
Database module for storing and retrieving data for the Ad Command Center
"""
import os
import pandas as pd
import psycopg2
import time
from datetime import datetime
from psycopg2.extras import execute_batch

# Get database connection details from environment
DATABASE_URL = os.environ.get("DATABASE_URL")

def get_db_connection():
    """
    Get a connection to the PostgreSQL database
    
    Returns:
        connection: PostgreSQL database connection
    """
    try:
        conn = psycopg2.connect(DATABASE_URL)
        return conn
    except Exception as e:
        print(f"Error connecting to database: {e}")
        return None

def store_leads(leads_df):
    """
    Store leads data in the database
    
    Args:
        leads_df (pd.DataFrame): DataFrame containing lead data
        
    Returns:
        int: Number of leads stored
    """
    if leads_df is None or leads_df.empty:
        print("No leads data to store")
        return 0
    
    conn = get_db_connection()
    if not conn:
        return 0
    
    try:
        # Clean and prepare data
        leads_df = leads_df.copy()
        
        # Map DataFrame columns to database columns
        required_columns = [
            'id', 'Phone', 'Email', 'Brand', 'Contact Source', 
            'Original Location', 'Scheduled Location', 'Overall Status',
            'Service', 'Inbound', 'Consult', 'Closed'
        ]
        
        # Create missing columns with None
        for col in required_columns:
            if col not in leads_df.columns:
                leads_df[col] = None
        
        # Prepare data for batch insertion
        lead_data = []
        for _, row in leads_df.iterrows():
            # Convert date fields to proper format and handle NaN values
            inbound_date = None
            if 'Inbound' in row and pd.notna(row['Inbound']):
                try:
                    inbound_date = pd.to_datetime(row['Inbound'])
                except:
                    inbound_date = None
                    
            consult_date = None
            if 'Consult' in row and pd.notna(row['Consult']):
                try:
                    consult_date = pd.to_datetime(row['Consult'])
                except:
                    consult_date = None
                    
            closed_date = None
            if 'Closed' in row and pd.notna(row['Closed']):
                try:
                    closed_date = pd.to_datetime(row['Closed'])
                except:
                    closed_date = None
                
            # Handle service field which might be a list
            service = row.get('Service')
            if isinstance(service, list):
                service = ', '.join(service)
                
            lead_data.append((
                str(row.get('id', row.get('ID', ''))),  # Ensure it's a string
                row.get('Phone'),
                row.get('Email'),
                row.get('Brand'),
                row.get('Contact Source'),
                row.get('Original Location'),
                row.get('Scheduled Location'),
                row.get('Overall Status'),
                service,
                inbound_date,
                consult_date,
                closed_date,
                datetime.now(),
                datetime.now()
            ))
        
        # Insert data in batches
        cursor = conn.cursor()
        
        # First, clear existing data to avoid duplicates
        cursor.execute("DELETE FROM leads")
        
        # Insert new data
        insert_query = """
        INSERT INTO leads (
            id, phone, email, brand, contact_source, 
            original_location, scheduled_location, overall_status,
            service, inbound_date, consultation_date, closing_date,
            created_at, updated_at
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (id) DO UPDATE SET
            phone = EXCLUDED.phone,
            email = EXCLUDED.email,
            brand = EXCLUDED.brand,
            contact_source = EXCLUDED.contact_source,
            original_location = EXCLUDED.original_location,
            scheduled_location = EXCLUDED.scheduled_location,
            overall_status = EXCLUDED.overall_status,
            service = EXCLUDED.service,
            inbound_date = EXCLUDED.inbound_date,
            consultation_date = EXCLUDED.consultation_date,
            closing_date = EXCLUDED.closing_date,
            updated_at = CURRENT_TIMESTAMP
        """
        
        execute_batch(cursor, insert_query, lead_data, page_size=1000)
        
        # Record sync in log
        log_query = """
        INSERT INTO sync_log (data_source, last_sync_time, record_count, status)
        VALUES (%s, %s, %s, %s)
        """
        cursor.execute(log_query, ("leads", datetime.now(), len(lead_data), "success"))
        
        conn.commit()
        return len(lead_data)
    
    except Exception as e:
        print(f"Error storing leads data: {e}")
        if conn:
            conn.rollback()
        
        # Log error
        try:
            cursor = conn.cursor()
            log_query = """
            INSERT INTO sync_log (data_source, last_sync_time, record_count, status, error_message)
            VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(log_query, ("leads", datetime.now(), 0, "error", str(e)))
            conn.commit()
        except:
            pass
            
        return 0
    
    finally:
        if conn:
            conn.close()

def store_transactions(transactions_df):
    """
    Store transactions data in the database
    
    Args:
        transactions_df (pd.DataFrame): DataFrame containing transaction data
        
    Returns:
        int: Number of transactions stored
    """
    if transactions_df is None or transactions_df.empty:
        print("No transactions data to store")
        return 0
    
    conn = get_db_connection()
    if not conn:
        return 0
    
    try:
        # Clean and prepare data
        transactions_df = transactions_df.copy()
        
        # Map DataFrame columns to database columns
        required_columns = [
            'id', 'ID', 'Amount', 'Payment Type', 'Status',
            'Services Purchased', 'Date'
        ]
        
        # Create missing columns with None
        for col in required_columns:
            if col not in transactions_df.columns:
                transactions_df[col] = None
        
        # Prepare data for batch insertion
        transaction_data = []
        for _, row in transactions_df.iterrows():
            # Handle date field
            transaction_date = None
            if 'Date' in row and pd.notna(row['Date']):
                try:
                    transaction_date = pd.to_datetime(row['Date'])
                except:
                    transaction_date = None
                    
            # Fix for foreign key constraint - we'll use a dummy lead_id if not found
            # This prevents the foreign key error while still allowing the transaction to be stored
            transaction_id = str(row.get('id', ''))
            lead_id = row.get('ID')
            
            # Skip transactions without IDs
            if not transaction_id:
                continue
                
            # Handle amount field
            amount = 0
            if 'Amount' in row and pd.notna(row['Amount']):
                try:
                    amount = float(row['Amount'])
                except:
                    amount = 0
                    
            # Handle service field which might be a list
            services = row.get('Services Purchased')
            if isinstance(services, list):
                services = ', '.join(services)
                
            transaction_data.append((
                transaction_id,
                lead_id,  # this is the lead_id reference
                amount,
                row.get('Payment Type'),
                row.get('Status'),
                services,
                transaction_date,
                datetime.now(),
                datetime.now()
            ))
        
        # Insert data in batches
        cursor = conn.cursor()
        
        # First, clear existing data to avoid duplicates
        cursor.execute("DELETE FROM transactions")
        
        # Insert new data
        insert_query = """
        INSERT INTO transactions (
            id, lead_id, amount, payment_type, status,
            services_purchased, transaction_date, created_at, updated_at
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (id) DO UPDATE SET
            lead_id = EXCLUDED.lead_id,
            amount = EXCLUDED.amount,
            payment_type = EXCLUDED.payment_type,
            status = EXCLUDED.status,
            services_purchased = EXCLUDED.services_purchased,
            transaction_date = EXCLUDED.transaction_date,
            updated_at = CURRENT_TIMESTAMP
        """
        
        execute_batch(cursor, insert_query, transaction_data, page_size=1000)
        
        # Record sync in log
        log_query = """
        INSERT INTO sync_log (data_source, last_sync_time, record_count, status)
        VALUES (%s, %s, %s, %s)
        """
        cursor.execute(log_query, ("transactions", datetime.now(), len(transaction_data), "success"))
        
        conn.commit()
        return len(transaction_data)
    
    except Exception as e:
        print(f"Error storing transactions data: {e}")
        if conn:
            conn.rollback()
        
        # Log error
        try:
            cursor = conn.cursor()
            log_query = """
            INSERT INTO sync_log (data_source, last_sync_time, record_count, status, error_message)
            VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(log_query, ("transactions", datetime.now(), 0, "error", str(e)))
            conn.commit()
        except:
            pass
            
        return 0
    
    finally:
        if conn:
            conn.close()

def store_campaign_data(campaigns, insights):
    """
    Store Meta campaign data in the database
    
    Args:
        campaigns (list): List of campaign dictionaries
        insights (list): List of campaign insight dictionaries
        
    Returns:
        tuple: (campaign_count, insight_count)
    """
    if not campaigns:
        print("No campaign data to store")
        return (0, 0)
    
    conn = get_db_connection()
    if not conn:
        return (0, 0)
    
    campaign_count = 0
    insight_count = 0
    
    try:
        cursor = conn.cursor()
        
        # Store campaigns
        campaign_data = []
        for campaign in campaigns:
            campaign_data.append((
                campaign.get('id'),
                campaign.get('name'),
                campaign.get('status'),
                campaign.get('objective'),
                campaign.get('created_time'),
                campaign.get('start_time'),
                campaign.get('stop_time'),
                campaign.get('daily_budget'),
                campaign.get('lifetime_budget'),
                datetime.now()
            ))
        
        insert_campaign_query = """
        INSERT INTO campaigns (
            id, name, status, objective, created_time,
            start_time, stop_time, daily_budget, lifetime_budget, last_sync_time
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (id) DO UPDATE SET
            name = EXCLUDED.name,
            status = EXCLUDED.status,
            objective = EXCLUDED.objective,
            created_time = EXCLUDED.created_time,
            start_time = EXCLUDED.start_time,
            stop_time = EXCLUDED.stop_time,
            daily_budget = EXCLUDED.daily_budget,
            lifetime_budget = EXCLUDED.lifetime_budget,
            last_sync_time = CURRENT_TIMESTAMP
        """
        
        execute_batch(cursor, insert_campaign_query, campaign_data, page_size=100)
        campaign_count = len(campaign_data)
        
        # Store insights
        if insights:
            # Clear old insights
            cursor.execute("DELETE FROM campaign_insights")
            
            insight_data = []
            for insight in insights:
                insight_data.append((
                    insight.get('campaign_id'),
                    insight.get('date_start'),
                    insight.get('date_stop'),
                    insight.get('impressions'),
                    insight.get('clicks'),
                    insight.get('spend'),
                    insight.get('cpc'),
                    insight.get('ctr'),
                    insight.get('reach'),
                    insight.get('frequency'),
                    datetime.now()
                ))
            
            insert_insight_query = """
            INSERT INTO campaign_insights (
                campaign_id, date_start, date_stop, impressions,
                clicks, spend, cpc, ctr, reach, frequency, last_sync_time
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            
            execute_batch(cursor, insert_insight_query, insight_data, page_size=100)
            insight_count = len(insight_data)
        
        # Record sync in log
        log_query = """
        INSERT INTO sync_log (data_source, last_sync_time, record_count, status)
        VALUES (%s, %s, %s, %s)
        """
        cursor.execute(log_query, ("meta_campaigns", datetime.now(), campaign_count, "success"))
        
        conn.commit()
        return (campaign_count, insight_count)
    
    except Exception as e:
        print(f"Error storing campaign data: {e}")
        if conn:
            conn.rollback()
        
        # Log error
        try:
            cursor = conn.cursor()
            log_query = """
            INSERT INTO sync_log (data_source, last_sync_time, record_count, status, error_message)
            VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(log_query, ("meta_campaigns", datetime.now(), 0, "error", str(e)))
            conn.commit()
        except:
            pass
            
        return (0, 0)
    
    finally:
        if conn:
            conn.close()

def get_leads(filters=None):
    """
    Get leads data from the database
    
    Args:
        filters (dict, optional): Filters to apply (e.g., brand, date range)
        
    Returns:
        pd.DataFrame: DataFrame containing lead data
    """
    conn = get_db_connection()
    if not conn:
        return pd.DataFrame()
    
    try:
        query = "SELECT * FROM leads"
        params = []
        
        # Apply filters if provided
        if filters:
            where_clauses = []
            
            if 'brand' in filters and filters['brand']:
                where_clauses.append("brand = %s")
                params.append(filters['brand'])
            
            if 'contact_source' in filters and filters['contact_source']:
                where_clauses.append("contact_source ILIKE %s")
                params.append(f"%{filters['contact_source']}%")
            
            if 'date_from' in filters and filters['date_from']:
                where_clauses.append("inbound_date >= %s")
                params.append(filters['date_from'])
            
            if 'date_to' in filters and filters['date_to']:
                where_clauses.append("inbound_date <= %s")
                params.append(filters['date_to'])
            
            if where_clauses:
                query += " WHERE " + " AND ".join(where_clauses)
        
        # Execute query
        return pd.read_sql_query(query, conn, params=params)
    
    except Exception as e:
        print(f"Error getting leads data: {e}")
        return pd.DataFrame()
    
    finally:
        if conn:
            conn.close()

def get_transactions(filters=None):
    """
    Get transactions data from the database
    
    Args:
        filters (dict, optional): Filters to apply
        
    Returns:
        pd.DataFrame: DataFrame containing transaction data
    """
    conn = get_db_connection()
    if not conn:
        return pd.DataFrame()
    
    try:
        query = """
        SELECT t.*, l.brand, l.contact_source, l.overall_status, l.service
        FROM transactions t
        LEFT JOIN leads l ON t.lead_id = l.id
        """
        params = []
        
        # Apply filters if provided
        if filters:
            where_clauses = []
            
            if 'lead_id' in filters and filters['lead_id']:
                where_clauses.append("t.lead_id = %s")
                params.append(filters['lead_id'])
            
            if 'brand' in filters and filters['brand']:
                where_clauses.append("l.brand = %s")
                params.append(filters['brand'])
            
            if 'date_from' in filters and filters['date_from']:
                where_clauses.append("t.transaction_date >= %s")
                params.append(filters['date_from'])
            
            if 'date_to' in filters and filters['date_to']:
                where_clauses.append("t.transaction_date <= %s")
                params.append(filters['date_to'])
            
            if where_clauses:
                query += " WHERE " + " AND ".join(where_clauses)
        
        # Execute query
        return pd.read_sql_query(query, conn, params=params)
    
    except Exception as e:
        print(f"Error getting transactions data: {e}")
        return pd.DataFrame()
    
    finally:
        if conn:
            conn.close()

def get_campaign_data(date_from=None, date_to=None):
    """
    Get campaign data from the database
    
    Args:
        date_from (str, optional): Start date filter
        date_to (str, optional): End date filter
        
    Returns:
        tuple: (campaigns_df, insights_df)
    """
    conn = get_db_connection()
    if not conn:
        return (pd.DataFrame(), pd.DataFrame())
    
    try:
        # Get campaigns
        campaign_query = "SELECT * FROM campaigns"
        campaigns_df = pd.read_sql_query(campaign_query, conn)
        
        # Get insights with date filters
        insight_query = """
        SELECT * FROM campaign_insights
        """
        params = []
        
        if date_from or date_to:
            where_clauses = []
            
            if date_from:
                where_clauses.append("date_start >= %s")
                params.append(date_from)
            
            if date_to:
                where_clauses.append("date_stop <= %s")
                params.append(date_to)
            
            if where_clauses:
                insight_query += " WHERE " + " AND ".join(where_clauses)
        
        # Execute query
        insights_df = pd.read_sql_query(insight_query, conn, params=params)
        
        return (campaigns_df, insights_df)
    
    except Exception as e:
        print(f"Error getting campaign data: {e}")
        return (pd.DataFrame(), pd.DataFrame())
    
    finally:
        if conn:
            conn.close()

def get_last_sync_time(data_source):
    """
    Get the last sync time for a specific data source
    
    Args:
        data_source (str): Data source name ('leads', 'transactions', 'meta_campaigns')
        
    Returns:
        datetime: Last sync time or None if no sync found
    """
    conn = get_db_connection()
    if not conn:
        return None
    
    try:
        cursor = conn.cursor()
        query = """
        SELECT last_sync_time FROM sync_log
        WHERE data_source = %s AND status = 'success'
        ORDER BY last_sync_time DESC
        LIMIT 1
        """
        cursor.execute(query, (data_source,))
        result = cursor.fetchone()
        
        if result:
            return result[0]
        return None
    
    except Exception as e:
        print(f"Error getting last sync time: {e}")
        return None
    
    finally:
        if conn:
            conn.close()

def should_refresh_data(data_source, max_age_minutes=60):
    """
    Check if data should be refreshed based on last sync time
    
    Args:
        data_source (str): Data source name
        max_age_minutes (int): Maximum age in minutes before refresh needed
        
    Returns:
        bool: True if refresh is needed, False otherwise
    """
    last_sync = get_last_sync_time(data_source)
    if not last_sync:
        return True
    
    age_in_minutes = (datetime.now() - last_sync).total_seconds() / 60
    return age_in_minutes > max_age_minutes