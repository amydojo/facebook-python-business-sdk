#!/usr/bin/env python3
"""
Restore connection with updated API key
"""

import os
import sys
sys.path.append('.')

# Set the new API key
os.environ['AIRTABLE_API_KEY'] = 'patRpwfhYlGferLE8.17a89cf5c31e4ef29041a67a4b28ca4058bb443779beb0dd4352ad999b186cdd'

# Import and reinitialize the connector
from unified_production_connector import UnifiedProductionConnector

# Create fresh connector instance
print("Creating fresh connector instance...")
new_connector = UnifiedProductionConnector()

# Test data loading
print("Testing data loading...")

# Test transactions
tx_result = new_connector.load_transactions('2025-06-01', '2025-06-17')
print(f"Transactions: success={tx_result.success}, count={tx_result.count}")
if not tx_result.success:
    print(f"  Error: {tx_result.error}")

# Test leads
lead_result = new_connector.load_leads('2025-06-01', '2025-06-17')
print(f"Leads: success={lead_result.success}, count={lead_result.count}")
if not lead_result.success:
    print(f"  Error: {lead_result.error}")

if tx_result.success and lead_result.success:
    print("\n✓ Data access fully restored!")
    
    # Test Meta lead identification
    from advanced_lead_matcher import advanced_lead_matcher
    
    meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data or [])
    print(f"✓ Meta leads identified: {len(meta_leads)}")
    
    # Test transaction matching
    matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
        meta_leads, tx_result.data or []
    )
    
    matched_count = len([l for l in matched_leads if l['matched_transactions']])
    total_revenue = matching_stats.get('total_matched_revenue', 0)
    
    print(f"✓ Lead matching complete: {matched_count} matched leads")
    print(f"✓ Revenue attribution: ${total_revenue:,.2f}")
    
    print("\nDashboard ready for live data!")
    
else:
    print("\n✗ Connection issues remain - checking connector state...")
    print(f"Table info: {new_connector.table_info}")