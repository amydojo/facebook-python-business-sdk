#!/usr/bin/env python3
"""
Direct Airtable Connection Test
Tests connection and discovers table structure for base appH4MePHS6qLsk5z
"""

import os
from pyairtable import Api
import json

def test_airtable_connection():
    api_key = os.getenv('AIRTABLE_API_KEY')
    base_id = os.getenv('AIRTABLE_BASE_ID', 'appH4MePHS6qLsk5z')
    
    print(f"Testing Airtable connection...")
    print(f"Base ID: {base_id}")
    print(f"API Key present: {'Yes' if api_key else 'No'}")
    print()
    
    if not api_key:
        print("ERROR: No AIRTABLE_API_KEY found")
        return
    
    api = Api(api_key)
    
    # Test common table names
    table_names = [
        'Leads', 'leads', 'Lead', 'lead',
        'Transactions', 'transactions', 'Transaction', 'transaction', 
        'Social Media', 'social media', 'SocialMedia', 'socialmedia',
        'Revenue', 'revenue', 'Sales', 'sales',
        'Contacts', 'contacts', 'Contact', 'contact',
        'Customers', 'customers', 'Customer', 'customer'
    ]
    
    found_tables = []
    
    for table_name in table_names:
        try:
            print(f"Testing table: {table_name}")
            table = api.table(base_id, table_name)
            records = table.all(max_records=2)
            
            if records:
                print(f"✅ SUCCESS: Found '{table_name}' with {len(records)} records")
                
                # Show field structure
                fields = list(records[0]['fields'].keys())
                print(f"   Fields: {', '.join(fields)}")
                
                # Show sample data
                print(f"   Sample record:")
                for key, value in records[0]['fields'].items():
                    print(f"     {key}: {value}")
                print()
                
                found_tables.append({
                    'name': table_name,
                    'fields': fields,
                    'sample': records[0]['fields']
                })
            
        except Exception as e:
            error_msg = str(e)
            if "INVALID_PERMISSIONS" in error_msg:
                print(f"❌ PERMISSION ERROR: {table_name}")
            elif "NOT_FOUND" in error_msg:
                print(f"⚠️  NOT FOUND: {table_name}")
            else:
                print(f"❌ ERROR: {table_name} - {error_msg}")
    
    print(f"\nSUMMARY: Found {len(found_tables)} accessible tables")
    
    # Analyze for lead data
    lead_tables = []
    for table in found_tables:
        fields_lower = [f.lower() for f in table['fields']]
        lead_indicators = ['name', 'phone', 'email', 'source', 'status']
        score = sum(1 for indicator in lead_indicators if any(indicator in field for field in fields_lower))
        
        if score >= 2:
            lead_tables.append((table['name'], score))
    
    if lead_tables:
        print(f"\nLEAD DATA CANDIDATES:")
        for name, score in sorted(lead_tables, key=lambda x: x[1], reverse=True):
            print(f"  {name} (score: {score}/5)")
    
    # Analyze for transaction data
    transaction_tables = []
    for table in found_tables:
        fields_lower = [f.lower() for f in table['fields']]
        transaction_indicators = ['amount', 'revenue', 'total', 'price', 'payment']
        score = sum(1 for indicator in transaction_indicators if any(indicator in field for field in fields_lower))
        
        if score >= 1:
            transaction_tables.append((table['name'], score))
    
    if transaction_tables:
        print(f"\nTRANSACTION DATA CANDIDATES:")
        for name, score in sorted(transaction_tables, key=lambda x: x[1], reverse=True):
            print(f"  {name} (score: {score}/5)")
    
    return found_tables

if __name__ == "__main__":
    test_airtable_connection()