"""
Advanced Connection Manager
Future-proof data connection system with circuit breakers, connection pooling, and intelligent error recovery
"""

import time
import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable, Union
from dataclasses import dataclass, field
from enum import Enum
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import hashlib
from pyairtable import Api
import requests
from config_manager import get_config

logger = logging.getLogger(__name__)

class ConnectionState(Enum):
    CLOSED = "closed"
    HALF_OPEN = "half_open" 
    OPEN = "open"

@dataclass
class CircuitBreakerConfig:
    """Circuit breaker configuration"""
    failure_threshold: int = 5
    recovery_timeout: int = 60
    expected_exception: type = Exception
    half_open_max_calls: int = 3

@dataclass
class ConnectionMetrics:
    """Connection performance metrics"""
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    average_response_time: float = 0.0
    last_success: Optional[datetime] = None
    last_failure: Optional[datetime] = None
    consecutive_failures: int = 0
    consecutive_successes: int = 0

class CircuitBreaker:
    """Advanced circuit breaker implementation for connection resilience"""
    
    def __init__(self, config: CircuitBreakerConfig):
        self.config = config
        self.state = ConnectionState.CLOSED
        self.failure_count = 0
        self.last_failure_time = None
        self.half_open_calls = 0
        self._lock = threading.Lock()
    
    def __call__(self, func: Callable) -> Callable:
        def wrapper(*args, **kwargs):
            with self._lock:
                if self.state == ConnectionState.OPEN:
                    if self._should_attempt_reset():
                        self.state = ConnectionState.HALF_OPEN
                        self.half_open_calls = 0
                    else:
                        raise Exception(f"Circuit breaker OPEN - service unavailable")
                
                if self.state == ConnectionState.HALF_OPEN:
                    if self.half_open_calls >= self.config.half_open_max_calls:
                        raise Exception(f"Circuit breaker HALF_OPEN - max calls exceeded")
                    self.half_open_calls += 1
            
            try:
                result = func(*args, **kwargs)
                self._on_success()
                return result
            except self.config.expected_exception as e:
                self._on_failure()
                raise e
        
        return wrapper
    
    def _should_attempt_reset(self) -> bool:
        return (
            self.last_failure_time and 
            time.time() - self.last_failure_time >= self.config.recovery_timeout
        )
    
    def _on_success(self):
        with self._lock:
            self.failure_count = 0
            self.state = ConnectionState.CLOSED
            self.half_open_calls = 0
    
    def _on_failure(self):
        with self._lock:
            self.failure_count += 1
            self.last_failure_time = time.time()
            
            if self.failure_count >= self.config.failure_threshold:
                self.state = ConnectionState.OPEN

class ExponentialBackoff:
    """Exponential backoff with jitter for retry logic"""
    
    def __init__(self, base_delay: float = 1.0, max_delay: float = 60.0, 
                 max_retries: int = 5, jitter: bool = True):
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.max_retries = max_retries
        self.jitter = jitter
    
    def execute(self, func: Callable, *args, **kwargs) -> Any:
        """Execute function with exponential backoff retry"""
        last_exception = None
        
        for attempt in range(self.max_retries + 1):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                
                if attempt == self.max_retries:
                    break
                
                delay = min(self.base_delay * (2 ** attempt), self.max_delay)
                
                if self.jitter:
                    import random
                    delay *= (0.5 + random.random() * 0.5)
                
                logger.warning(f"Attempt {attempt + 1} failed, retrying in {delay:.2f}s: {e}")
                time.sleep(delay)
        
        raise last_exception

class ConnectionPool:
    """Thread-safe connection pool for Airtable API connections"""
    
    def __init__(self, api_key: str, max_connections: int = 10):
        self.api_key = api_key
        self.max_connections = max_connections
        self._pool = []
        self._lock = threading.Lock()
        self._created_connections = 0
    
    def get_connection(self) -> Api:
        """Get connection from pool or create new one"""
        with self._lock:
            if self._pool:
                return self._pool.pop()
            
            if self._created_connections < self.max_connections:
                self._created_connections += 1
                return Api(self.api_key)
            
            # Wait for connection to be returned
            pass
        
        # Fallback: create new connection
        return Api(self.api_key)
    
    def return_connection(self, connection: Api):
        """Return connection to pool"""
        with self._lock:
            if len(self._pool) < self.max_connections:
                self._pool.append(connection)

class AdvancedConnectionManager:
    """Future-proof connection manager with advanced resilience patterns"""
    
    def __init__(self):
        self.config = get_config()
        self.api_key = self.config.get('airtable', {}).get('api_key')
        self.base_id = self.config.get('airtable', {}).get('base_id')
        
        # Initialize connection components
        self.connection_pool = ConnectionPool(self.api_key) if self.api_key else None
        self.backoff = ExponentialBackoff()
        
        # Circuit breakers for different endpoints
        self.circuit_breakers = {
            'transactions': CircuitBreaker(CircuitBreakerConfig()),
            'leads': CircuitBreaker(CircuitBreakerConfig()),
            'meta': CircuitBreaker(CircuitBreakerConfig())
        }
        
        # Performance metrics
        self.metrics = {
            'transactions': ConnectionMetrics(),
            'leads': ConnectionMetrics(),
            'meta': ConnectionMetrics()
        }
        
        # Executor for parallel operations
        self.executor = ThreadPoolExecutor(max_workers=5)
        
        logger.info("Advanced Connection Manager initialized with resilience patterns")
    
    def _update_metrics(self, endpoint: str, success: bool, response_time: float):
        """Update connection metrics"""
        metrics = self.metrics[endpoint]
        metrics.total_requests += 1
        
        if success:
            metrics.successful_requests += 1
            metrics.consecutive_successes += 1
            metrics.consecutive_failures = 0
            metrics.last_success = datetime.now()
        else:
            metrics.failed_requests += 1
            metrics.consecutive_failures += 1
            metrics.consecutive_successes = 0
            metrics.last_failure = datetime.now()
        
        # Update average response time (exponential moving average)
        if metrics.average_response_time == 0:
            metrics.average_response_time = response_time
        else:
            metrics.average_response_time = (metrics.average_response_time * 0.8) + (response_time * 0.2)
    
    def _validate_table_access(self, table_name: str) -> Dict[str, Any]:
        """Validate table access with minimal API call"""
        if not self.api_key or not self.base_id:
            return {
                'success': False,
                'error': 'Missing API credentials',
                'error_type': 'CONFIGURATION_ERROR'
            }
        
        try:
            connection = self.connection_pool.get_connection()
            table = connection.table(self.base_id, table_name)
            
            # Minimal query to test access
            records = table.all(max_records=1)
            
            self.connection_pool.return_connection(connection)
            
            return {
                'success': True,
                'accessible': True,
                'record_count': len(records)
            }
            
        except Exception as e:
            error_str = str(e)
            error_type = self._classify_error(error_str)
            
            return {
                'success': False,
                'error': error_str,
                'error_type': error_type,
                'accessible': False
            }
    
    def _classify_error(self, error_str: str) -> str:
        """Classify error types for intelligent handling"""
        error_lower = error_str.lower()
        
        if '403' in error_str or 'forbidden' in error_lower:
            return 'PERMISSION_ERROR'
        elif '404' in error_str or 'not found' in error_lower:
            return 'RESOURCE_NOT_FOUND'
        elif '401' in error_str or 'unauthorized' in error_lower:
            return 'AUTHENTICATION_ERROR'
        elif '429' in error_str or 'rate limit' in error_lower:
            return 'RATE_LIMIT_ERROR'
        elif 'timeout' in error_lower or 'connection' in error_lower:
            return 'NETWORK_ERROR'
        else:
            return 'UNKNOWN_ERROR'
    
    def _get_fallback_table_mapping(self) -> Dict[str, str]:
        """Get fallback table mappings with intelligent discovery"""
        
        # Primary table mappings
        primary_mappings = {
            'transactions': 'Social Media',
            'leads': 'Leads'
        }
        
        # Alternative mappings to try
        alternative_mappings = {
            'transactions': ['Transactions', 'Sales', 'Revenue', 'Payments'],
            'leads': ['Lead', 'Prospects', 'Customers', 'Contacts']
        }
        
        validated_mappings = {}
        
        for data_type, primary_table in primary_mappings.items():
            # Try primary mapping first
            validation = self._validate_table_access(primary_table)
            if validation['success']:
                validated_mappings[data_type] = primary_table
                continue
            
            # Try alternatives
            for alt_table in alternative_mappings.get(data_type, []):
                validation = self._validate_table_access(alt_table)
                if validation['success']:
                    validated_mappings[data_type] = alt_table
                    logger.info(f"Using alternative table mapping: {data_type} -> {alt_table}")
                    break
            
            if data_type not in validated_mappings:
                logger.error(f"No accessible table found for {data_type}")
        
        return validated_mappings
    
    @CircuitBreaker(CircuitBreakerConfig())
    def load_data_with_resilience(self, data_type: str, table_name: str, 
                                  filters: Optional[Dict] = None) -> Dict[str, Any]:
        """Load data with full resilience patterns"""
        
        def _load_data():
            start_time = time.time()
            
            try:
                connection = self.connection_pool.get_connection()
                table = connection.table(self.base_id, table_name)
                
                if filters:
                    # Apply filters if provided
                    records = table.all(**filters)
                else:
                    records = table.all()
                
                self.connection_pool.return_connection(connection)
                
                response_time = time.time() - start_time
                self._update_metrics(data_type, True, response_time)
                
                return {
                    'success': True,
                    'data': records,
                    'count': len(records),
                    'response_time': response_time,
                    'source': 'airtable_api'
                }
                
            except Exception as e:
                response_time = time.time() - start_time
                self._update_metrics(data_type, False, response_time)
                
                error_type = self._classify_error(str(e))
                
                return {
                    'success': False,
                    'error': str(e),
                    'error_type': error_type,
                    'response_time': response_time
                }
        
        # Execute with exponential backoff
        return self.backoff.execute(_load_data)
    
    def diagnose_connection_issues(self) -> Dict[str, Any]:
        """Comprehensive connection diagnostics"""
        
        diagnostics = {
            'timestamp': datetime.now().isoformat(),
            'overall_status': 'unknown',
            'api_key_configured': bool(self.api_key),
            'base_id_configured': bool(self.base_id),
            'table_access': {},
            'circuit_breaker_states': {},
            'performance_metrics': {},
            'recommendations': []
        }
        
        if not self.api_key:
            diagnostics['overall_status'] = 'critical'
            diagnostics['recommendations'].append('Configure Airtable API key')
            return diagnostics
        
        if not self.base_id:
            diagnostics['overall_status'] = 'critical'
            diagnostics['recommendations'].append('Configure Airtable base ID')
            return diagnostics
        
        # Test table access
        test_tables = {
            'transactions': 'Social Media',
            'leads': 'Leads'
        }
        
        accessible_tables = 0
        
        for data_type, table_name in test_tables.items():
            validation = self._validate_table_access(table_name)
            diagnostics['table_access'][data_type] = validation
            
            if validation.get('success'):
                accessible_tables += 1
        
        # Circuit breaker states
        for endpoint, breaker in self.circuit_breakers.items():
            diagnostics['circuit_breaker_states'][endpoint] = breaker.state.value
        
        # Performance metrics
        for endpoint, metrics in self.metrics.items():
            success_rate = (
                (metrics.successful_requests / metrics.total_requests * 100) 
                if metrics.total_requests > 0 else 0
            )
            
            diagnostics['performance_metrics'][endpoint] = {
                'success_rate': round(success_rate, 2),
                'average_response_time': round(metrics.average_response_time, 3),
                'consecutive_failures': metrics.consecutive_failures,
                'total_requests': metrics.total_requests
            }
        
        # Overall status determination
        if accessible_tables == len(test_tables):
            diagnostics['overall_status'] = 'healthy'
        elif accessible_tables > 0:
            diagnostics['overall_status'] = 'degraded'
            diagnostics['recommendations'].append('Some tables are inaccessible - check permissions')
        else:
            diagnostics['overall_status'] = 'critical'
            diagnostics['recommendations'].append('No tables accessible - verify API key and base ID')
        
        return diagnostics
    
    def auto_heal_connections(self) -> Dict[str, Any]:
        """Attempt automatic healing of connection issues"""
        
        healing_results = {
            'actions_taken': [],
            'tables_discovered': {},
            'healing_successful': False
        }
        
        # Reset circuit breakers
        for endpoint, breaker in self.circuit_breakers.items():
            if breaker.state != ConnectionState.CLOSED:
                breaker.state = ConnectionState.CLOSED
                breaker.failure_count = 0
                healing_results['actions_taken'].append(f'Reset {endpoint} circuit breaker')
        
        # Discover alternative table mappings
        discovered_mappings = self._get_fallback_table_mapping()
        healing_results['tables_discovered'] = discovered_mappings
        
        if discovered_mappings:
            healing_results['healing_successful'] = True
            healing_results['actions_taken'].append('Discovered alternative table mappings')
        
        return healing_results
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get comprehensive health status"""
        return {
            'connection_manager': 'operational',
            'circuit_breakers': {
                endpoint: breaker.state.value 
                for endpoint, breaker in self.circuit_breakers.items()
            },
            'performance_summary': {
                endpoint: {
                    'requests': metrics.total_requests,
                    'success_rate': (
                        metrics.successful_requests / metrics.total_requests * 100
                        if metrics.total_requests > 0 else 0
                    ),
                    'avg_response_time': metrics.average_response_time
                }
                for endpoint, metrics in self.metrics.items()
            },
            'last_updated': datetime.now().isoformat()
        }

# Global instance
connection_manager = AdvancedConnectionManager()

# Export key functions
__all__ = [
    'AdvancedConnectionManager', 'connection_manager', 'CircuitBreaker', 
    'ExponentialBackoff', 'ConnectionPool'
]