"""
Design system for the Ad Command Center - ensuring visual consistency throughout the app
"""
import streamlit as st

# Color palette
COLORS = {
    "primary": "#0066CC",
    "secondary": "#6C757D",
    "success": "#28A745",
    "danger": "#DC3545",
    "warning": "#FFC107",
    "info": "#17A2B8",
    "light": "#F8F9FA",
    "dark": "#343A40",
    "white": "#FFFFFF",
    "muted": "#6C757D",
    "border": "#DEE2E6",
    "shadow": "rgba(0, 0, 0, 0.05)"
}

# Typography
TYPOGRAPHY = {
    "h1": "28px",
    "h2": "24px",
    "h3": "20px",
    "h4": "18px",
    "body": "16px",
    "small": "14px",
    "xs": "12px"
}

# Spacing
SPACING = {
    "xs": "4px",
    "sm": "8px",
    "md": "16px",
    "lg": "24px",
    "xl": "32px",
    "xxl": "48px"
}

# Border radius
BORDER_RADIUS = {
    "sm": "4px",
    "md": "8px",
    "lg": "12px",
    "pill": "9999px"
}

def styled_header(text, level=1):
    """Render styled header with consistent branding"""
    if level == 1:
        st.markdown(f"""
        <h1 style='font-size: {TYPOGRAPHY["h1"]}; 
                  color: {COLORS["dark"]}; 
                  margin-bottom: {SPACING["md"]}; 
                  font-weight: 600;'>
            {text}
        </h1>
        """, unsafe_allow_html=True)
    elif level == 2:
        st.markdown(f"""
        <h2 style='font-size: {TYPOGRAPHY["h2"]}; 
                  color: {COLORS["dark"]}; 
                  margin-bottom: {SPACING["sm"]}; 
                  font-weight: 500;'>
            {text}
        </h2>
        """, unsafe_allow_html=True)
    elif level == 3:
        st.markdown(f"""
        <h3 style='font-size: {TYPOGRAPHY["h3"]}; 
                  color: {COLORS["dark"]}; 
                  margin-bottom: {SPACING["sm"]}; 
                  font-weight: 500;'>
            {text}
        </h3>
        """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <h4 style='font-size: {TYPOGRAPHY["h4"]}; 
                  color: {COLORS["dark"]}; 
                  margin-bottom: {SPACING["xs"]}; 
                  font-weight: 500;'>
            {text}
        </h4>
        """, unsafe_allow_html=True)

def card(content_function, title=None, padding=SPACING["lg"], 
         border_radius=BORDER_RADIUS["md"], with_shadow=True):
    """
    Create a styled card component with consistent design
    
    Args:
        content_function: Function that renders content inside the card
        title: Optional title for the card
        padding: Padding size from the SPACING scale 
        border_radius: Border radius from the BORDER_RADIUS scale
        with_shadow: Whether to add a shadow to the card
    """
    shadow_style = f"box-shadow: 0 4px 6px {COLORS['shadow']};" if with_shadow else ""
    
    st.markdown(f"""
    <div style='background-color: {COLORS["white"]}; 
                padding: {padding}; 
                border-radius: {border_radius}; 
                border: 1px solid {COLORS["border"]};
                margin-bottom: {SPACING["md"]};
                {shadow_style}'>
    """, unsafe_allow_html=True)
    
    if title:
        st.markdown(f"""
        <h3 style='font-size: {TYPOGRAPHY["h3"]}; 
                  color: {COLORS["dark"]}; 
                  margin-bottom: {SPACING["md"]}; 
                  font-weight: 500;'>
            {title}
        </h3>
        """, unsafe_allow_html=True)
    
    content_function()
    
    st.markdown("</div>", unsafe_allow_html=True)

def status_indicator(text, status_type="success"):
    """Display a colored status indicator with text"""
    color = COLORS[status_type]
    
    st.markdown(f"""
    <div style='display: inline-flex; 
                align-items: center; 
                background-color: {color}25; 
                color: {color}; 
                padding: {SPACING["xs"]} {SPACING["sm"]}; 
                border-radius: {BORDER_RADIUS["pill"]}; 
                font-size: {TYPOGRAPHY["small"]};
                border: 1px solid {color}33;'>
        <span style='height: 8px; 
                     width: 8px; 
                     border-radius: 50%; 
                     background-color: {color}; 
                     margin-right: {SPACING["xs"]};'></span>
        {text}
    </div>
    """, unsafe_allow_html=True)

def section_divider(text=None):
    """Create a section divider with optional text"""
    if text:
        st.markdown(f"""
        <div style='display: flex; 
                    align-items: center; 
                    margin: {SPACING["lg"]} 0;'>
            <div style='flex-grow: 1; 
                        height: 1px; 
                        background-color: {COLORS["border"]};'></div>
            <span style='padding: 0 {SPACING["md"]}; 
                        color: {COLORS["muted"]}; 
                        font-size: {TYPOGRAPHY["small"]};'>
                {text}
            </span>
            <div style='flex-grow: 1; 
                        height: 1px; 
                        background-color: {COLORS["border"]};'></div>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div style='height: 1px; 
                    background-color: {COLORS["border"]}; 
                    margin: {SPACING["lg"]} 0;'></div>
        """, unsafe_allow_html=True)

def badge(text, badge_type="primary", size="sm"):
    """Display a badge with consistent styling"""
    color = COLORS[badge_type]
    font_size = TYPOGRAPHY["xs"] if size == "sm" else TYPOGRAPHY["small"]
    padding = f'{SPACING["xs"]} {SPACING["sm"]}' if size == "sm" else f'{SPACING["sm"]} {SPACING["md"]}'
    
    st.markdown(f"""
    <span style='background-color: {color}; 
                 color: white; 
                 padding: {padding}; 
                 border-radius: {BORDER_RADIUS["pill"]}; 
                 font-size: {font_size}; 
                 font-weight: 500;'>
        {text}
    </span>
    """, unsafe_allow_html=True)

def icon_text(icon, text, color="primary", size="md"):
    """Display text with an icon prefix"""
    text_color = COLORS[color]
    font_size = TYPOGRAPHY[size]
    
    st.markdown(f"""
    <div style='display: flex; 
                align-items: center; 
                color: {text_color}; 
                font-size: {font_size};'>
        <span style='margin-right: {SPACING["xs"]};'>{icon}</span>
        {text}
    </div>
    """, unsafe_allow_html=True)