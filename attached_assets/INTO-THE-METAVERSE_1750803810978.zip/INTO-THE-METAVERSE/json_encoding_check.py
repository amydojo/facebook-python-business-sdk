
"""
Test script to verify proper JSON encoding for Meta API parameters
"""
import json
from datetime import datetime, timedelta

def test_meta_api_params():
    # Sample date range
    end_date = datetime.now()
    start_date = end_date - timedelta(days=90)
    
    date_format = "%Y-%m-%d"
    date_range = {
        "since": start_date.strftime(date_format),
        "until": end_date.strftime(date_format)
    }
    
    # Incorrect way - string concatenation or replacement
    incorrect_format = str(date_range).replace("'", "\"")
    
    # Correct way - using json.dumps()
    correct_format = json.dumps(date_range)
    
    print("Date Range Dictionary:")
    print(date_range)
    print("\nIncorrect formatting (string manipulation):")
    print(incorrect_format)
    print("\nCorrect formatting (json.dumps):")
    print(correct_format)
    
    # Example params
    fields = ["impressions", "clicks", "spend"]
    params = {
        "access_token": "sample_token",
        "fields": ",".join(fields),
        "level": "ad",
        "time_range": json.dumps(date_range),  # Properly encoded as JSON string
        "limit": "500"
    }
    
    print("\nComplete params with properly encoded time_range:")
    print(params)

if __name__ == "__main__":
    test_meta_api_params()
