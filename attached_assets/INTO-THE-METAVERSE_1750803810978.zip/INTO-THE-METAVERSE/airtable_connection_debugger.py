
"""
Comprehensive Airtable Connection Debugger
This utility diagnoses Airtable connection issues with detailed error reporting
"""
import os
import json
import streamlit as st
import pandas as pd
from pyairtable import Api
import time
import traceback
import requests
import hashlib

def run_airtable_diagnostics():
    st.set_page_config(page_title="Airtable Connection Debugger", layout="wide")
    st.title("🔍 Airtable Connection Diagnostics")
    
    with st.sidebar:
        st.header("Connection Settings")
        api_key = st.text_input("Airtable API Key", type="password", 
                              help="Your Airtable Personal Access Token (PAT)")
        
        base_id = st.text_input("Base ID", value="appri2CgCoIiuZWq3",
                             help="Your Airtable base ID (from URL)")
        
        table_name = st.text_input("Table Name", value="Leads",
                                help="Name of table to query (case sensitive)")
    
    # Main diagnostics
    tab1, tab2, tab3 = st.tabs(["Connection Test", "Data Inspection", "Cache Diagnostics"])
    
    with tab1:
        st.header("🔌 Connection Test")
        
        if st.button("Run Basic Connection Test"):
            with st.spinner("Testing Airtable connection..."):
                run_basic_connection_test(api_key, base_id, table_name)
        
        if st.button("Run Advanced Connection Test"):
            with st.spinner("Running comprehensive diagnostics..."):
                run_advanced_connection_test(api_key, base_id, table_name)
    
    with tab2:
        st.header("🔍 Data Inspection")
        
        if st.button("Inspect Table Schema"):
            with st.spinner("Fetching table schema..."):
                inspect_table_schema(api_key, base_id, table_name)
        
        if st.button("Fetch Sample Records"):
            with st.spinner("Fetching sample records..."):
                fetch_sample_records(api_key, base_id, table_name)
    
    with tab3:
        st.header("💾 Cache Diagnostics")
        
        if st.button("Test Cache Key Generation"):
            st.subheader("Cache Key Generation Test")
            test_cache_key_generation()
        
        if st.button("Clear Cache Directory"):
            st.subheader("Cache Directory Cleanup")
            clear_cache_directory()

def run_basic_connection_test(api_key, base_id, table_name):
    """Run basic connection test to Airtable"""
    if not api_key or not base_id or not table_name:
        st.error("Please provide all connection parameters.")
        return
    
    try:
        st.info("Initializing Airtable API...")
        start_time = time.time()
        api = Api(api_key)
        table = api.table(base_id, table_name)
        
        st.info("Attempting to fetch first record...")
        records = table.all(max_records=1)
        
        elapsed = time.time() - start_time
        
        if records:
            st.success(f"✅ Connection successful ({elapsed:.2f}s)")
            st.json(records[0])
        else:
            st.warning(f"⚠️ Connection succeeded but no records found ({elapsed:.2f}s)")
        
    except Exception as e:
        st.error(f"❌ Connection failed: {str(e)}")
        st.expander("Detailed Error").code(traceback.format_exc())
        
        # Specific error analysis
        error_str = str(e).lower()
        if "401" in error_str:
            st.error("Authentication Error: Your API key appears to be invalid.")
        elif "404" in error_str:
            st.error("Not Found Error: The base ID or table name is incorrect.")
        elif "unhashable" in error_str:
            st.error("Cache Key Error: Unhashable type error in data processing.")
            st.info("This error comes from the `_get_cache_key` method when trying to hash a dictionary.")

def run_advanced_connection_test(api_key, base_id, table_name):
    """Run advanced connection diagnostics"""
    if not api_key or not base_id or not table_name:
        st.error("Please provide all connection parameters.")
        return
    
    try:
        # Test API key format
        st.subheader("API Key Validation")
        if api_key.startswith('pat'):
            st.success("✅ API key format is valid (Personal Access Token)")
        elif api_key.startswith('key'):
            st.warning("⚠️ Using legacy API key format - consider upgrading to Personal Access Token")
        else:
            st.error("❌ API key format doesn't match expected patterns")
        
        # Test direct HTTP request
        st.subheader("Direct HTTP Request Test")
        url = f"https://api.airtable.com/v0/{base_id}/{table_name}"
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        
        start_time = time.time()
        response = requests.get(url, headers=headers, params={'maxRecords': 1})
        http_elapsed = time.time() - start_time
        
        st.write(f"Response Status: {response.status_code} ({http_elapsed:.2f}s)")
        
        if response.status_code == 200:
            st.success("✅ Direct HTTP request succeeded")
            data = response.json()
            st.write(f"Records returned: {len(data.get('records', []))}")
            
            if data.get('records'):
                with st.expander("Sample Record Structure"):
                    st.json(data['records'][0])
        else:
            st.error(f"❌ Direct HTTP request failed: {response.status_code}")
            with st.expander("Response Details"):
                st.write(response.text)
        
        # Test with pyairtable library
        st.subheader("PyAirtable Library Test")
        start_time = time.time()
        api = Api(api_key)
        table = api.table(base_id, table_name)
        records = table.all(max_records=5)
        py_elapsed = time.time() - start_time
        
        if records:
            st.success(f"✅ PyAirtable library test succeeded ({py_elapsed:.2f}s)")
            st.write(f"Records returned: {len(records)}")
        else:
            st.warning(f"⚠️ PyAirtable returned no records ({py_elapsed:.2f}s)")
        
        # Network latency test
        st.subheader("Network Latency Test")
        latencies = []
        for i in range(3):
            start = time.time()
            requests.get(f"https://api.airtable.com/v0", headers=headers)
            latency = (time.time() - start) * 1000  # ms
            latencies.append(latency)
        
        avg_latency = sum(latencies) / len(latencies)
        st.write(f"Average latency: {avg_latency:.2f}ms")
        
        if avg_latency < 300:
            st.success("✅ Network latency is good")
        elif avg_latency < 1000:
            st.warning("⚠️ Network latency is moderate")
        else:
            st.error("❌ Network latency is high")
    
    except Exception as e:
        st.error(f"❌ Advanced diagnostics failed: {str(e)}")
        st.expander("Detailed Error").code(traceback.format_exc())

def inspect_table_schema(api_key, base_id, table_name):
    """Inspect Airtable table schema"""
    if not api_key or not base_id:
        st.error("Please provide API key and base ID.")
        return
    
    try:
        # Get meta information
        schema_url = f"https://api.airtable.com/v0/meta/bases/{base_id}/tables"
        headers = {'Authorization': f'Bearer {api_key}'}
        
        response = requests.get(schema_url, headers=headers)
        
        if response.status_code == 200:
            schema = response.json()
            
            # Find our table
            target_table = None
            available_tables = []
            
            for table in schema.get('tables', []):
                available_tables.append(table['name'])
                if table['name'] == table_name:
                    target_table = table
                    break
            
            if target_table:
                st.success(f"✅ Table '{table_name}' found!")
                st.write(f"Table ID: {target_table['id']}")
                
                # Show field information
                fields_df = pd.DataFrame([
                    {
                        'Field Name': field['name'],
                        'Field Type': field['type'],
                        'Description': field.get('description', '')
                    }
                    for field in target_table.get('fields', [])
                ])
                
                st.subheader("Table Fields")
                st.dataframe(fields_df)
                
                # Show column types that might cause issues
                complex_fields = []
                for field in target_table.get('fields', []):
                    if field['type'] in ['multipleRecordLinks', 'multipleAttachments', 'multipleSelects']:
                        complex_fields.append(field['name'])
                
                if complex_fields:
                    st.warning("⚠️ Fields with complex types that might cause issues:")
                    for field in complex_fields:
                        st.write(f"- {field}")
            else:
                st.error(f"❌ Table '{table_name}' not found!")
                st.info("Available tables in this base:")
                for table in available_tables:
                    st.write(f"• {table}")
        else:
            st.error(f"❌ Failed to get schema: {response.status_code}")
            st.write(response.text)
    
    except Exception as e:
        st.error(f"❌ Schema inspection failed: {str(e)}")
        st.expander("Detailed Error").code(traceback.format_exc())

def fetch_sample_records(api_key, base_id, table_name):
    """Fetch and analyze sample records"""
    if not api_key or not base_id or not table_name:
        st.error("Please provide all connection parameters.")
        return
    
    try:
        api = Api(api_key)
        table = api.table(base_id, table_name)
        records = table.all(max_records=10)
        
        if not records:
            st.warning("No records found in the table.")
            return
        
        st.success(f"✅ Retrieved {len(records)} records for analysis")
        
        # Convert to DataFrame
        data = []
        for r in records:
            try:
                item = r['fields'].copy()
                item['id'] = r['id']
                data.append(item)
            except Exception as e:
                st.error(f"Error processing record: {str(e)}")
        
        df = pd.DataFrame(data)
        
        # Display sample
        st.subheader("Sample Data")
        st.dataframe(df)
        
        # Analyze data types
        st.subheader("Data Type Analysis")
        type_info = {}
        for col in df.columns:
            try:
                column_types = set(type(x).__name__ for x in df[col] if pd.notna(x))
                type_info[col] = {
                    'Column': col,
                    'Types': ', '.join(column_types),
                    'Has Complex Types': any(t in ['dict', 'list'] for t in column_types),
                    'Null Count': df[col].isna().sum()
                }
            except:
                type_info[col] = {
                    'Column': col,
                    'Types': 'Error analyzing',
                    'Has Complex Types': True,
                    'Null Count': 'Unknown'
                }
        
        types_df = pd.DataFrame(list(type_info.values()))
        st.dataframe(types_df)
        
        # Check for problematic columns
        complex_cols = [col for col, info in type_info.items() if info['Has Complex Types']]
        if complex_cols:
            st.warning("⚠️ Columns with complex types that might cause caching issues:")
            for col in complex_cols:
                st.write(f"- {col}")
            
            st.info("These complex types can cause 'unhashable type' errors when used in cache keys.")
    
    except Exception as e:
        st.error(f"❌ Data analysis failed: {str(e)}")
        st.expander("Detailed Error").code(traceback.format_exc())

def test_cache_key_generation():
    """Test cache key generation with various parameter types"""
    examples = [
        {"name": "Simple string", "source": "test_source", "params": "simple_string"},
        {"name": "Integer", "source": "test_source", "params": 42},
        {"name": "Simple dict", "source": "test_source", "params": {"key": "value"}},
        {"name": "Nested dict", "source": "test_source", "params": {"key": {"nested": "value"}}},
        {"name": "List", "source": "test_source", "params": [1, 2, 3]},
        {"name": "Dict with list", "source": "test_source", "params": {"key": [1, 2, 3]}},
        {"name": "Time range", "source": "meta_insights", "params": {
            "time_range": {"since": "2023-01-01", "until": "2023-01-31"}
        }}
    ]
    
    st.write("Testing cache key generation with different parameter types")
    results = []
    
    for example in examples:
        try:
            # Original method
            orig_key = None
            try:
                orig_key = original_get_cache_key(example["source"], example["params"])
            except Exception as e:
                orig_key = f"ERROR: {str(e)}"
            
            # Fixed method
            fixed_key = None
            try:
                fixed_key = fixed_get_cache_key(example["source"], example["params"])
            except Exception as e:
                fixed_key = f"ERROR: {str(e)}"
            
            results.append({
                "Test Case": example["name"],
                "Parameters": str(example["params"]),
                "Original Method": orig_key,
                "Fixed Method": fixed_key,
                "Success": "❌" if "ERROR" in orig_key else "✅"
            })
        except Exception as e:
            results.append({
                "Test Case": example["name"],
                "Parameters": str(example["params"]),
                "Original Method": f"EXCEPTION: {str(e)}",
                "Fixed Method": "Not tested",
                "Success": "❌"
            })
    
    st.table(pd.DataFrame(results))
    
    # Detailed analysis of the problematic case
    st.subheader("Detailed Analysis of Time Range Parameter")
    time_range_params = {"time_range": {"since": "2023-01-01", "until": "2023-01-31"}}
    
    st.code(f"Parameter: {json.dumps(time_range_params, indent=2)}")
    st.write("This is the type of parameter that causes the 'unhashable type: dict' error.")
    st.write("The fixed implementation uses JSON serialization to handle nested dictionaries.")

def original_get_cache_key(source, params=None):
    """Original cache key generation method (problematic)"""
    if params:
        # Convert params to a string safely, handling nested dicts/lists
        try:
            # Handle the case where params might contain unhashable types
            if isinstance(params, dict):
                # Convert dict to a stable string representation without sorting
                param_items = []
                for k in sorted(params.keys()):
                    param_items.append(f"{k}:{params[k]}")
                param_str = ",".join(param_items)
            else:
                param_str = str(params)
        except Exception as e:
            # Simple fallback that works with any type
            param_str = str(hash(str(params)))
            raise Exception(f"Cache key generation error: {str(e)}")
        
        return hashlib.md5(f"{source}_{param_str}".encode()).hexdigest()
    return hashlib.md5(source.encode()).hexdigest()

def fixed_get_cache_key(source, params=None):
    """Fixed cache key generation method"""
    if not params:
        return hashlib.md5(source.encode()).hexdigest()
    
    # Convert params to a stable string representation
    try:
        # Handle dictionary parameters
        if isinstance(params, dict):
            # Use JSON serialization for consistent representation
            param_str = json.dumps(params, sort_keys=True)
        else:
            # For non-dictionaries, just use string representation
            param_str = str(params)
        
        return hashlib.md5(f"{source}_{param_str}".encode()).hexdigest()
        
    except Exception as e:
        # Fallback for any serialization errors
        import random
        random_suffix = random.randint(1, 100000)
        raise Exception(f"Cache key generation error: {str(e)}")

def clear_cache_directory():
    """Clear the cache directory"""
    import os
    import shutil
    
    cache_dir = "data_cache"
    
    if os.path.exists(cache_dir):
        file_count = len([f for f in os.listdir(cache_dir) if f.endswith('.pkl')])
        shutil.rmtree(cache_dir)
        os.makedirs(cache_dir)
        st.success(f"✅ Cleared {file_count} files from cache directory")
    else:
        os.makedirs(cache_dir)
        st.info("Cache directory was empty or didn't exist. Created fresh directory.")

if __name__ == "__main__":
    run_airtable_diagnostics()
