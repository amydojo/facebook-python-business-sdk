#!/usr/bin/env python3
"""
Official PyAirtable Integration
Implements proper data validation using official PyAirtable patterns
"""

import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from pyairtable import Api, Table
from pyairtable.formulas import match, AND, GTE, LTE, Field
import streamlit as st

class AirtableDataManager:
    """
    Manages Airtable data connections using official PyAirtable patterns
    """
    
    def __init__(self):
        self.api_key = os.getenv('AIRTABLE_API_KEY')
        self.base_id = os.getenv('AIRTABLE_BASE_ID')
        
        if not self.api_key or not self.base_id:
            raise ValueError("AIRTABLE_API_KEY and AIRTABLE_BASE_ID must be set")
        
        self.api = Api(self.api_key)
        self.leads_table = Table(self.api_key, self.base_id, 'Leads')
        self.transactions_table = Table(self.api_key, self.base_id, 'Transactions')
    
    def get_meta_leads(self, start_date: str, end_date: str) -> List[Dict]:
        """
        Get Meta leads using official PyAirtable formula filtering
        """
        try:
            # Create formula for Meta sources and date range
            meta_sources_formula = match({
                "Contact Source": ["Facebook AD", "Instagram AD", "Facebook AD Sign Up"]
            }, match_any=True)
            
            date_range_formula = AND(
                GTE(Field("Inbound"), start_date),
                LTE(Field("Inbound"), end_date)
            )
            
            combined_formula = AND(meta_sources_formula, date_range_formula)
            
            # Fetch records with proper field validation
            records = self.leads_table.all(
                formula=str(combined_formula),
                fields=["ID", "Phone", "Email", "Contact Source", "Inbound", "Brand", "Overall Status"],
                sort=["Inbound"]
            )
            
            leads = []
            for record in records:
                fields = record.get('fields', {})
                
                # Validate required fields
                if not fields.get('Contact Source') or not fields.get('Inbound'):
                    continue
                    
                lead = {
                    'id': record['id'],
                    'lead_id': fields.get('ID', ''),
                    'phone': self._clean_phone(fields.get('Phone', '')),
                    'email': self._clean_email(fields.get('Email', '')),
                    'contact_source': fields.get('Contact Source', ''),
                    'inbound_date': fields.get('Inbound', ''),
                    'brand': fields.get('Brand', ''),
                    'overall_status': fields.get('Overall Status', '')
                }
                
                # Validate date format
                if self._validate_date(lead['inbound_date']):
                    leads.append(lead)
            
            return leads
            
        except Exception as e:
            st.error(f"Error fetching Meta leads: {str(e)}")
            return []
    
    def get_transactions(self, start_date: str, end_date: str) -> List[Dict]:
        """
        Get transactions using official PyAirtable date filtering
        """
        try:
            # Create date range formula
            date_formula = AND(
                GTE(Field("Date"), start_date),
                LTE(Field("Date"), end_date)
            )
            
            # Fetch records with field validation
            records = self.transactions_table.all(
                formula=str(date_formula),
                fields=["Patient", "Date", "Amount", "Service", "Brand"],
                sort=["-Date"]  # Most recent first
            )
            
            transactions = []
            for record in records:
                fields = record.get('fields', {})
                
                # Validate required fields and amount
                amount = fields.get('Amount')
                if not amount or not isinstance(amount, (int, float)) or amount <= 0:
                    continue
                    
                if not fields.get('Date') or not fields.get('Patient'):
                    continue
                    
                transaction = {
                    'id': record['id'],
                    'patient': str(fields.get('Patient', '')).strip(),
                    'date': fields.get('Date', ''),
                    'amount': float(amount),
                    'service': fields.get('Service', ''),
                    'brand': fields.get('Brand', '')
                }
                
                # Validate date format
                if self._validate_date(transaction['date']):
                    transactions.append(transaction)
            
            return transactions
            
        except Exception as e:
            st.error(f"Error fetching transactions: {str(e)}")
            return []
    
    def _clean_phone(self, phone: str) -> str:
        """Clean phone number for matching"""
        if not phone:
            return ""
        return str(phone).strip().replace('(', '').replace(')', '').replace('-', '').replace(' ', '')
    
    def _clean_email(self, email: str) -> str:
        """Clean email for matching"""
        if not email:
            return ""
        return str(email).strip().lower()
    
    def _validate_date(self, date_str: str) -> bool:
        """Validate date format"""
        if not date_str:
            return False
        try:
            datetime.strptime(date_str, '%Y-%m-%d')
            return True
        except ValueError:
            return False
    
    def validate_data_quality(self, leads: List[Dict], transactions: List[Dict]) -> Dict:
        """
        Comprehensive data quality validation
        """
        validation_report = {
            'leads': {
                'total_count': len(leads),
                'valid_phones': sum(1 for lead in leads if lead.get('phone')),
                'valid_emails': sum(1 for lead in leads if lead.get('email')),
                'missing_ids': sum(1 for lead in leads if not lead.get('lead_id')),
                'completeness_score': 0
            },
            'transactions': {
                'total_count': len(transactions),
                'total_revenue': sum(t.get('amount', 0) for t in transactions),
                'valid_patients': sum(1 for t in transactions if t.get('patient')),
                'missing_services': sum(1 for t in transactions if not t.get('service')),
                'completeness_score': 0
            }
        }
        
        # Calculate completeness scores
        if validation_report['leads']['total_count'] > 0:
            leads_score = (
                (validation_report['leads']['valid_phones'] * 0.4) +
                (validation_report['leads']['valid_emails'] * 0.4) +
                ((validation_report['leads']['total_count'] - validation_report['leads']['missing_ids']) * 0.2)
            ) / validation_report['leads']['total_count']
            validation_report['leads']['completeness_score'] = leads_score * 100
        
        if validation_report['transactions']['total_count'] > 0:
            trans_score = (
                (validation_report['transactions']['valid_patients'] * 0.6) +
                ((validation_report['transactions']['total_count'] - validation_report['transactions']['missing_services']) * 0.4)
            ) / validation_report['transactions']['total_count']
            validation_report['transactions']['completeness_score'] = trans_score * 100
        
        return validation_report

class LeadRevenueAttributor:
    """
    Handles lead-to-revenue attribution using validated data
    """
    
    def __init__(self):
        pass
    
    def attribute_revenue(self, leads: List[Dict], transactions: List[Dict]) -> Tuple[List[Dict], float]:
        """
        Attribute revenue to leads with comprehensive matching logic
        """
        if not leads:
            return [], 0
        
        if not transactions:
            return [self._create_zero_revenue_lead(lead) for lead in leads], 0
        
        attributed_leads = []
        total_attributed = 0
        used_transaction_ids = set()
        
        # Phase 1: Direct matching by phone/email patterns
        for lead in leads:
            lead_phone = lead.get('phone', '')
            lead_email = lead.get('email', '')
            
            matched_transactions = []
            lead_revenue = 0
            
            for transaction in transactions:
                if transaction['id'] in used_transaction_ids:
                    continue
                
                if self._is_transaction_match(lead_phone, lead_email, transaction):
                    matched_transactions.append(transaction)
                    lead_revenue += transaction['amount']
                    used_transaction_ids.add(transaction['id'])
            
            attributed_lead = lead.copy()
            attributed_lead.update({
                'revenue': lead_revenue,
                'transaction_count': len(matched_transactions),
                'matched_transactions': matched_transactions,
                'attribution_method': 'direct_match' if matched_transactions else 'no_match'
            })
            
            attributed_leads.append(attributed_lead)
            total_attributed += lead_revenue
        
        # Phase 2: Proportional attribution for unmatched transactions
        unmatched_transactions = [t for t in transactions if t['id'] not in used_transaction_ids]
        unmatched_revenue = sum(t['amount'] for t in unmatched_transactions)
        
        if unmatched_revenue > 0 and len(attributed_leads) > 0:
            # Distribute unmatched revenue proportionally among leads with no direct matches
            no_match_leads = [lead for lead in attributed_leads if lead['attribution_method'] == 'no_match']
            
            if no_match_leads:
                proportional_revenue = unmatched_revenue / len(no_match_leads)
                
                for lead in no_match_leads:
                    lead['revenue'] += proportional_revenue
                    lead['transaction_count'] = 1
                    lead['attribution_method'] = 'proportional'
                    total_attributed += proportional_revenue
        
        return attributed_leads, total_attributed
    
    def _create_zero_revenue_lead(self, lead: Dict) -> Dict:
        """Create lead with zero revenue"""
        result = lead.copy()
        result.update({
            'revenue': 0,
            'transaction_count': 0,
            'matched_transactions': [],
            'attribution_method': 'no_transactions'
        })
        return result
    
    def _is_transaction_match(self, lead_phone: str, lead_email: str, transaction: Dict) -> bool:
        """
        Determine if transaction matches lead using multiple criteria
        """
        patient_name = transaction.get('patient', '').lower()
        
        # Phone matching - check if phone appears in patient name
        if lead_phone and len(lead_phone) >= 10:
            clean_patient = patient_name.replace('(', '').replace(')', '').replace('-', '').replace(' ', '')
            if lead_phone[-10:] in clean_patient:
                return True
        
        # Email prefix matching
        if lead_email and '@' in lead_email:
            email_prefix = lead_email.split('@')[0]
            if len(email_prefix) > 3 and email_prefix in patient_name:
                return True
        
        return False

def test_pyairtable_integration():
    """Test the PyAirtable integration"""
    try:
        data_manager = AirtableDataManager()
        attributor = LeadRevenueAttributor()
        
        # Test date range - last 30 days
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=30)
        
        print(f"Testing PyAirtable integration for {start_date} to {end_date}")
        
        # Fetch data
        leads = data_manager.get_meta_leads(str(start_date), str(end_date))
        transactions = data_manager.get_transactions(str(start_date), str(end_date))
        
        print(f"Fetched {len(leads)} Meta leads and {len(transactions)} transactions")
        
        # Validate data quality
        validation = data_manager.validate_data_quality(leads, transactions)
        print(f"Data quality - Leads: {validation['leads']['completeness_score']:.1f}%, Transactions: {validation['transactions']['completeness_score']:.1f}%")
        
        # Attribute revenue
        attributed_leads, total_revenue = attributor.attribute_revenue(leads, transactions)
        
        print(f"Successfully attributed ${total_revenue:,.2f} to {len(attributed_leads)} leads")
        
        return {
            'leads': attributed_leads,
            'transactions': transactions,
            'validation': validation,
            'total_revenue': total_revenue
        }
        
    except Exception as e:
        print(f"Integration test failed: {str(e)}")
        return None

if __name__ == "__main__":
    test_pyairtable_integration()