"""
Attribution Integration Test
Validates that the attribution module integrates properly with the existing dashboard
"""

import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import sys

# Set environment for testing
os.environ["ENABLE_ATTRIBUTION"] = "true"

# Test the attribution module imports
try:
    from attribution import AttributionModels, build_journeys, calculate_attribution_roas
    print("✓ Attribution module imported successfully")
except ImportError as e:
    print(f"✗ Attribution import failed: {e}")
    sys.exit(1)

def create_test_data():
    """Create realistic test data mimicking Smooth MD leads and transactions"""
    
    # Create test leads data
    leads_data = []
    for i in range(50):
        lead_data = {
            'lead_id': f'lead_{i}',
            'Phone': f'555-{1000+i}',
            'Email': f'lead{i}@test.com',
            'Source': 'Facebook' if i % 3 == 0 else ('Instagram' if i % 3 == 1 else 'Google'),
            'Inbound': datetime.now() - timedelta(days=np.random.randint(1, 30)),
            'Overall Status': 'Converted' if i % 5 == 0 else ('Consulted' if i % 4 == 0 else 'Lead'),
            'Brand': 'Smooth MD',
            'timestamp': datetime.now() - timedelta(days=np.random.randint(1, 30))
        }
        leads_data.append(lead_data)
    
    # Create test transactions data
    transactions_data = []
    converted_leads = [i for i in range(50) if i % 5 == 0]  # Every 5th lead converted
    
    for i, lead_idx in enumerate(converted_leads):
        transaction_data = {
            'lead_id': f'lead_{lead_idx}',
            'Phone': f'555-{1000+lead_idx}',
            'Email': f'lead{lead_idx}@test.com',
            'Amount': np.random.randint(1500, 5000),
            'Service': 'CoolSculpting' if i % 2 == 0 else 'Laser Treatment',
            'Date': datetime.now() - timedelta(days=np.random.randint(1, 25)),
            'revenue_amount': np.random.randint(1500, 5000),
            'channel': 'Facebook' if lead_idx % 3 == 0 else ('Instagram' if lead_idx % 3 == 1 else 'Google')
        }
        transactions_data.append(transaction_data)
    
    return pd.DataFrame(leads_data), pd.DataFrame(transactions_data)

def test_attribution_models():
    """Test all attribution models with sample data"""
    
    print("\n=== Testing Attribution Models ===")
    
    # Create sample journeys data
    journeys_data = [
        {
            'conversion_id': 'conv_1',
            'channel_sequence': ['meta_facebook', 'email', 'meta_facebook'],
            'revenue_amount': 2500.0
        },
        {
            'conversion_id': 'conv_2',
            'channel_sequence': ['google_ads', 'meta_instagram'],
            'revenue_amount': 3000.0
        },
        {
            'conversion_id': 'conv_3',
            'channel_sequence': ['meta_facebook'],
            'revenue_amount': 1800.0
        }
    ]
    
    journeys_df = pd.DataFrame(journeys_data)
    
    # Test each attribution model
    models_to_test = [
        ('first_touch', AttributionModels.first_touch),
        ('last_touch', AttributionModels.last_touch),
        ('linear', AttributionModels.linear_attribution),
        ('position_based', lambda df: AttributionModels.position_based(df, 0.4, 0.4)),
        ('time_decay', lambda df: AttributionModels.time_decay(df, 7)),
        ('markov_chain', AttributionModels.markov_chain_attribution)
    ]
    
    for model_name, model_func in models_to_test:
        try:
            result = model_func(journeys_df)
            if not result.empty:
                print(f"✓ {model_name} model: {len(result)} attribution records")
            else:
                print(f"⚠ {model_name} model: No results")
        except Exception as e:
            print(f"✗ {model_name} model failed: {e}")

def test_journey_building():
    """Test journey building with realistic data"""
    
    print("\n=== Testing Journey Building ===")
    
    leads_df, transactions_df = create_test_data()
    
    # Merge leads and transactions (simplified)
    merged_df = pd.merge(
        leads_df, 
        transactions_df, 
        on=['lead_id', 'Phone', 'Email'], 
        how='inner'
    )
    
    if not merged_df.empty:
        print(f"✓ Created merged dataset with {len(merged_df)} records")
        
        # Test journey building
        try:
            journeys_df = build_journeys(merged_df)
            if not journeys_df.empty:
                print(f"✓ Built {len(journeys_df)} customer journeys")
                
                # Display sample journey
                if len(journeys_df) > 0:
                    sample_journey = journeys_df.iloc[0]
                    print(f"  Sample journey: {sample_journey['channel_sequence']} → ${sample_journey['revenue_amount']}")
            else:
                print("⚠ No journeys built from merged data")
                
        except Exception as e:
            print(f"✗ Journey building failed: {e}")
    else:
        print("✗ No merged data available for journey building")

def test_attribution_roas():
    """Test ROAS calculation with attribution results"""
    
    print("\n=== Testing Attribution ROAS ===")
    
    # Sample credit data
    credit_data = [
        {'conversion_id': 'conv_1', 'channel': 'meta_facebook', 'credit_fraction': 0.6},
        {'conversion_id': 'conv_1', 'channel': 'email', 'credit_fraction': 0.4},
        {'conversion_id': 'conv_2', 'channel': 'meta_facebook', 'credit_fraction': 1.0},
    ]
    
    # Sample journey data
    journey_data = [
        {'conversion_id': 'conv_1', 'channel_sequence': ['meta_facebook', 'email'], 'revenue_amount': 2500.0},
        {'conversion_id': 'conv_2', 'channel_sequence': ['meta_facebook'], 'revenue_amount': 3000.0},
    ]
    
    # Sample spend data
    spend_data = [
        {'channel': 'meta_facebook', 'spend': 1000.0},
        {'channel': 'email', 'spend': 200.0},
    ]
    
    credit_df = pd.DataFrame(credit_data)
    journeys_df = pd.DataFrame(journey_data)
    spend_df = pd.DataFrame(spend_data)
    
    try:
        attribution_results = calculate_attribution_roas(credit_df, journeys_df, spend_df)
        
        if not attribution_results.empty:
            print(f"✓ Attribution ROAS calculated for {len(attribution_results)} channels")
            
            for _, row in attribution_results.iterrows():
                channel = row['channel']
                revenue = row['attributed_revenue']
                spend = row['spend']
                roas = row['roas']
                print(f"  {channel}: ${revenue:.0f} revenue, ${spend:.0f} spend, {roas:.2f}x ROAS")
        else:
            print("⚠ No attribution ROAS results")
            
    except Exception as e:
        print(f"✗ Attribution ROAS calculation failed: {e}")

def test_error_handling():
    """Test error handling with edge cases"""
    
    print("\n=== Testing Error Handling ===")
    
    # Test with empty data
    empty_df = pd.DataFrame()
    
    try:
        result = AttributionModels.first_touch(pd.DataFrame(columns=['conversion_id', 'channel_sequence', 'revenue_amount']))
        print("✓ Empty data handling: First touch")
    except Exception as e:
        print(f"✗ Empty data handling failed: {e}")
    
    # Test with missing columns
    try:
        bad_df = pd.DataFrame({'wrong_col': [1, 2, 3]})
        AttributionModels.first_touch(bad_df)
        print("⚠ Missing column validation should have failed")
    except ValueError:
        print("✓ Missing column validation works")
    except Exception as e:
        print(f"✗ Unexpected error: {e}")

def run_integration_test():
    """Run complete integration test"""
    
    print("Attribution Integration Test")
    print("=" * 50)
    
    test_attribution_models()
    test_journey_building()
    test_attribution_roas()
    test_error_handling()
    
    print("\n" + "=" * 50)
    print("Integration test completed")

if __name__ == "__main__":
    run_integration_test()