# Airtable Permissions Setup Guide

## Current Issue
Your Meta API is working perfectly ($1,902.46 spend), but Airtable is showing:
`INVALID_PERMISSIONS_OR_MODEL_NOT_FOUND`

## Steps to Fix Airtable Access

### Method 1: Update Current API Key Permissions
1. Go to https://airtable.com/create/tokens
2. Find your existing API token
3. Click "Edit" on your token
4. Under "Scopes", ensure these are checked:
   - `data.records:read`
   - `data.records:write` 
   - `schema.bases:read`

5. Under "Access", ensure your base is selected:
   - Base: `appwPsfAb2ZmWqhJD` (your LeadsCRM base)
   - Tables: Select "Leads" and "Transactions" tables

6. Save the updated permissions

### Method 2: Create New API Token (Recommended)
1. Go to https://airtable.com/create/tokens
2. Click "Create new token"
3. Name it: "Dashboard Access Token"
4. Add these scopes:
   - `data.records:read`
   - `data.records:write`
   - `schema.bases:read`

5. Add your base access:
   - Click "Add a base"
   - Select your base: `appwPsfAb2ZmWqhJD`
   - Select tables: "Leads" and "Transactions"

6. Click "Create token"
7. Copy the new token (starts with `pat...`)

## What This Will Unlock
Once permissions are updated, your dashboard will show:
- Real Meta spend: $1,902.46 ✓ (already working)
- Actual transaction revenue amounts
- Accurate ROAS calculations
- Lead-to-revenue conversion tracking

## Test Your New Token
I can test the new token immediately once you provide it to ensure it works correctly.