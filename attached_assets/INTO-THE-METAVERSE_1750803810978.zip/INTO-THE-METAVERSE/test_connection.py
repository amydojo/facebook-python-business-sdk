#!/usr/bin/env python3
"""Test the reliable data connector"""

from reliable_data_connector import ReliableDataConnector
from datetime import date, timedelta

def main():
    # Test the reliable data connector
    connector = ReliableDataConnector()
    
    # Get connection status
    status = connector.get_connection_status()
    print('Connection Status Report:')
    for key, value in status.items():
        print(f'{key}: {value}')
    
    # Test data loading for last 30 days
    end_date = date.today().strftime('%Y-%m-%d')
    start_date = (date.today() - timedelta(days=30)).strftime('%Y-%m-%d')
    
    print(f'\nTesting data loading for {start_date} to {end_date}...')
    
    # Test transaction data
    trans_data = connector.load_transaction_data(start_date, end_date)
    if trans_data.get('error'):
        print(f'Transaction Error: {trans_data["error"]}')
    else:
        print(f'Transactions: {trans_data.get("transaction_count", 0)} records, ${trans_data.get("total_revenue", 0):,.2f} revenue')
    
    # Test leads data
    leads_data = connector.load_leads_data(start_date, end_date)
    if leads_data.get('error'):
        print(f'Leads Error: {leads_data["error"]}')
    else:
        print(f'Leads: {leads_data.get("total_leads", 0)} total, {leads_data.get("converted_leads", 0)} converted')

if __name__ == "__main__":
    main()