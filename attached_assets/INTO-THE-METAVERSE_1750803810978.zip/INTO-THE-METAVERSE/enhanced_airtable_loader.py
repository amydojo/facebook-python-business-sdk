"""
Enhanced Airtable Data Loader
Optimized for your exact API structure with proper data cleaning
"""
import pandas as pd
import streamlit as st
from pyairtable import Api
from datetime import datetime
import numpy as np

def load_leads_data_clean(api_key, base_id='appri2CgCoIiuZWq3', table_name='Leads'):
    """
    Load leads data with proper cleaning for Smooth MD Meta leads only
    """
    try:
        # Initialize Airtable API
        api = Api(api_key)
        table = api.table(base_id, table_name)
        
        # Get all records
        records = table.all()
        
        if not records:
            return pd.DataFrame()
        
        # Convert to DataFrame
        data = []
        for record in records:
            row = record['fields'].copy()
            row['airtable_record_id'] = record['id']
            data.append(row)
        
        df = pd.DataFrame(data)
        
        # Clean complex data types that cause serialization issues
        for col in df.columns:
            if df[col].dtype == 'object':
                # Handle complex objects safely
                def clean_value(x):
                    try:
                        if x is None:
                            return ''
                        elif isinstance(x, list):
                            return ', '.join(str(item) for item in x)
                        elif isinstance(x, dict):
                            return str(x.get('name', x.get('email', str(x))))
                        else:
                            return str(x)
                    except:
                        return str(x) if x is not None else ''
                
                df[col] = df[col].apply(clean_value)
                # Force string conversion to prevent Arrow errors
                df[col] = df[col].astype(str)
        
        # Filter for Smooth MD only
        brand_col = 'flddGiLa7lQ0nodBz'  # Brand field
        if brand_col in df.columns:
            df = df[df[brand_col] == 'Smooth M.D.'].copy()
        
        # Filter for Meta sources only
        source_col = 'fldBUfZjdVhhJpRRA'  # Contact Source field
        if source_col in df.columns:
            meta_sources = ['Facebook AD', 'Instagram AD', 'Facebook AD Sign Up']
            df = df[df[source_col].isin(meta_sources)].copy()
        
        # Add computed status fields
        df['is_booked'] = False
        df['is_converted'] = False
        
        # Calculate booking status
        consult_status_col = 'fldSKhUarguxwbUHy'  # Consult Status
        if consult_status_col in df.columns:
            df['is_booked'] = df[consult_status_col].isin(['Arrived', 'Scheduled'])
        
        # Calculate conversion status
        overall_status_col = 'fldsMq5UysgZe3rin'  # Overall Status
        if overall_status_col in df.columns:
            df['is_converted'] = df[overall_status_col].isin(['Closed', 'Deposit Paid', 'Installment Plan'])
        
        # Add transaction_amount column for compatibility with dashboard functions
        df['transaction_amount'] = 0.0
        
        st.success(f"✅ Loaded {len(df)} Smooth MD leads from Meta sources")
        return df
        
    except Exception as e:
        st.error(f"Error loading leads data: {str(e)}")
        return pd.DataFrame()

def load_transactions_data_clean(api_key, base_id='appri2CgCoIiuZWq3', table_name='Transactions'):
    """
    Load transactions data with proper cleaning
    """
    try:
        # Initialize Airtable API
        api = Api(api_key)
        table = api.table(base_id, table_name)
        
        # Get all records
        records = table.all()
        
        if not records:
            return pd.DataFrame()
        
        # Convert to DataFrame
        data = []
        for record in records:
            row = record['fields'].copy()
            row['airtable_record_id'] = record['id']
            data.append(row)
        
        df = pd.DataFrame(data)
        
        # Clean complex data types
        for col in df.columns:
            if df[col].dtype == 'object':
                # Handle complex objects safely
                def clean_value(x):
                    try:
                        if x is None:
                            return ''
                        elif isinstance(x, list):
                            return ', '.join(str(item) for item in x)
                        elif isinstance(x, dict):
                            return str(x.get('name', x.get('email', str(x))))
                        else:
                            return str(x)
                    except:
                        return str(x) if x is not None else ''
                
                df[col] = df[col].apply(clean_value)
                # Force string conversion to prevent Arrow errors
                df[col] = df[col].astype(str)
        
        # Ensure Amount field is numeric
        amount_col = 'fldUIvamoBDCIayd3'  # Amount field
        if amount_col in df.columns:
            df[amount_col] = pd.to_numeric(df[amount_col], errors='coerce').fillna(0)
        
        st.success(f"✅ Loaded {len(df)} transaction records")
        return df
        
    except Exception as e:
        st.error(f"Error loading transactions data: {str(e)}")
        return pd.DataFrame()

def calculate_real_roas_metrics(leads_df, transactions_df, meta_spend):
    """
    Calculate real ROAS metrics using actual transaction data
    """
    if leads_df.empty:
        return {
            'total_leads': 0,
            'booked_leads': 0,
            'converted_leads': 0,
            'leads_with_revenue': 0,
            'total_revenue': 0,
            'roas': 0,
            'roi': 0,
            'cost_per_lead': 0,
            'cost_per_conversion': 0,
            'revenue_per_lead': 0
        }
    
    # Basic lead metrics
    total_leads = len(leads_df)
    booked_leads = leads_df['is_booked'].sum()
    converted_leads = leads_df['is_converted'].sum()
    
    # Revenue calculation
    total_revenue = 0
    leads_with_revenue = 0
    
    if not transactions_df.empty:
        # Match transactions to leads using the link field
        link_col = 'fldP2jAWtabHOpFhQ'  # ID link field
        amount_col = 'fldUIvamoBDCIayd3'  # Amount field
        
        if link_col in transactions_df.columns and amount_col in transactions_df.columns:
            # Get lead record IDs
            lead_record_ids = leads_df['airtable_record_id'].tolist()
            
            # Find matching transactions
            matched_transactions = transactions_df[
                transactions_df[link_col].str.contains('|'.join(lead_record_ids), na=False)
            ]
            
            if not matched_transactions.empty:
                total_revenue = matched_transactions[amount_col].sum()
                leads_with_revenue = len(matched_transactions[link_col].unique())
    
    # Calculate financial metrics
    roas = total_revenue / meta_spend if meta_spend > 0 else 0
    roi = ((total_revenue - meta_spend) / meta_spend * 100) if meta_spend > 0 else 0
    cost_per_lead = meta_spend / total_leads if total_leads > 0 else 0
    cost_per_conversion = meta_spend / converted_leads if converted_leads > 0 else 0
    revenue_per_lead = total_revenue / total_leads if total_leads > 0 else 0
    
    return {
        'total_leads': total_leads,
        'booked_leads': booked_leads,
        'converted_leads': converted_leads,
        'leads_with_revenue': leads_with_revenue,
        'total_revenue': total_revenue,
        'meta_spend': meta_spend,
        'booking_rate': (booked_leads / total_leads * 100) if total_leads > 0 else 0,
        'conversion_rate': (converted_leads / total_leads * 100) if total_leads > 0 else 0,
        'revenue_rate': (leads_with_revenue / total_leads * 100) if total_leads > 0 else 0,
        'roas': roas,
        'roi': roi,
        'cost_per_lead': cost_per_lead,
        'cost_per_conversion': cost_per_conversion,
        'revenue_per_lead': revenue_per_lead
    }

def create_brand_breakdown(leads_df):
    """
    Create performance breakdown by brand, location, and service
    """
    breakdowns = {}
    
    if leads_df.empty:
        return breakdowns
    
    # Brand breakdown
    brand_col = 'flddGiLa7lQ0nodBz'  # Brand
    if brand_col in leads_df.columns:
        brand_breakdown = leads_df.groupby(brand_col).agg({
            'is_booked': 'sum',
            'is_converted': 'sum'
        }).reset_index()
        brand_breakdown.columns = ['Brand', 'Booked', 'Converted']
        breakdowns['brand'] = brand_breakdown
    
    # Location breakdown
    location_col = 'fldzZY4vUX0nNBKL1'  # Scheduled Location
    if location_col in leads_df.columns:
        location_breakdown = leads_df.groupby(location_col).agg({
            'is_booked': 'sum',
            'is_converted': 'sum'
        }).reset_index()
        location_breakdown.columns = ['Location', 'Booked', 'Converted']
        breakdowns['location'] = location_breakdown
    
    # Service breakdown
    service_col = 'fldkOezyuypk702fU'  # Service
    if service_col in leads_df.columns:
        # Handle multiple services per lead
        service_data = []
        for _, row in leads_df.iterrows():
            services = str(row[service_col]).split(', ') if pd.notna(row[service_col]) else ['Unknown']
            for service in services:
                service_data.append({
                    'Service': service.strip(),
                    'Booked': row['is_booked'],
                    'Converted': row['is_converted']
                })
        
        if service_data:
            service_df = pd.DataFrame(service_data)
            service_breakdown = service_df.groupby('Service').agg({
                'Booked': 'sum',
                'Converted': 'sum'
            }).reset_index()
            breakdowns['service'] = service_breakdown
    
    return breakdowns