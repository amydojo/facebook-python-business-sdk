#!/usr/bin/env python3
"""
Fix table access by discovering actual table names in the new base
"""

import os
from pyairtable import Api
import json

def discover_tables():
    """Discover all accessible tables in the base"""
    
    api_key = os.getenv('AIRTABLE_API_KEY')
    base_id = os.getenv('AIRTABLE_BASE_ID')
    
    if not api_key or not base_id:
        print("Missing API credentials")
        return {}
    
    api = Api(api_key)
    
    # Try to get base schema (may not work with all API keys)
    try:
        base = api.base(base_id)
        tables = base.schema().tables
        table_names = [table.name for table in tables]
        print(f"Found tables via schema: {table_names}")
        return {name: True for name in table_names}
    except:
        print("Schema access not available, trying common names...")
    
    # Fallback: try common table names
    common_names = [
        'Transactions', 'Social Media', 'Sales', 'Revenue', 'Payments',
        'Leads', 'Lead', 'Prospects', 'Customers', 'Contacts',
        'Orders', 'Bookings', 'Appointments', 'Clients'
    ]
    
    accessible = {}
    
    for name in common_names:
        try:
            table = api.table(base_id, name)
            records = table.all(max_records=1)
            accessible[name] = True
            
            if records:
                fields = list(records[0]['fields'].keys())
                print(f"✓ {name}: {len(fields)} fields - {', '.join(fields[:5])}")
            else:
                print(f"✓ {name}: accessible but empty")
                
        except Exception as e:
            if "NOT_FOUND" in str(e) or "404" in str(e):
                continue  # Table doesn't exist
            else:
                print(f"✗ {name}: {e}")
    
    return accessible

def update_connector_config(accessible_tables):
    """Update the connector with correct table names"""
    
    # Find best matches for transactions and leads
    transaction_tables = []
    lead_tables = []
    
    for table_name in accessible_tables:
        name_lower = table_name.lower()
        
        if any(keyword in name_lower for keyword in ['transaction', 'social', 'sale', 'revenue', 'payment']):
            transaction_tables.append(table_name)
        elif any(keyword in name_lower for keyword in ['lead', 'contact', 'prospect', 'customer']):
            lead_tables.append(table_name)
    
    config = {
        'transactions': transaction_tables,
        'leads': lead_tables
    }
    
    print(f"\nRecommended table mapping:")
    print(f"Transactions: {transaction_tables}")
    print(f"Leads: {lead_tables}")
    
    return config

if __name__ == "__main__":
    print("Discovering tables in base...")
    tables = discover_tables()
    
    if tables:
        config = update_connector_config(tables)
        
        # Write config to file
        with open('table_config.json', 'w') as f:
            json.dump(config, f, indent=2)
        
        print(f"\nConfig saved to table_config.json")
    else:
        print("No tables found - check API permissions")