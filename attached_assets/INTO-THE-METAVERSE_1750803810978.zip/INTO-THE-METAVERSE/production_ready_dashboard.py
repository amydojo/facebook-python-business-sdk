"""
Production-Ready Meta Marketing Dashboard
Optimized for deployment with accurate Smooth MD attribution
"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
from unified_production_connector import unified_connector
from advanced_lead_matcher import advanced_lead_matcher
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def apply_production_styling():
    """Apply clean production styling"""
    st.markdown("""
    <style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }
    
    .metric-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        border-left: 4px solid #667eea;
        margin-bottom: 1rem;
    }
    
    .metric-value {
        font-size: 2rem;
        font-weight: bold;
        color: #333;
        margin-bottom: 0.5rem;
    }
    
    .metric-label {
        color: #666;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    .status-good { color: #28a745; font-weight: bold; }
    .status-warning { color: #ffc107; font-weight: bold; }
    .status-error { color: #dc3545; font-weight: bold; }
    </style>
    """, unsafe_allow_html=True)

@st.cache_data(ttl=300)
def load_production_data(start_date: str, end_date: str):
    """Load and process data for production use"""
    
    # Load raw data
    transaction_result = unified_connector.load_transactions(start_date, end_date)
    lead_result = unified_connector.load_leads(start_date, end_date)
    
    if not transaction_result.success or not lead_result.success:
        return None
    
    # Process leads with Smooth MD filtering
    meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data or [])
    
    # Match transactions to leads
    matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
        meta_leads, transaction_result.data or []
    )
    
    # Calculate performance metrics
    estimated_spend = len(meta_leads) * 45  # Conservative estimate
    performance_metrics = advanced_lead_matcher.calculate_performance_metrics(
        matched_leads, estimated_spend
    )
    
    return {
        'matched_leads': matched_leads,
        'matching_stats': matching_stats,
        'performance_metrics': performance_metrics,
        'meta_leads_count': len(meta_leads),
        'raw_stats': {
            'total_transactions': transaction_result.count,
            'total_leads': lead_result.count,
            'load_time': transaction_result.response_time + lead_result.response_time
        }
    }

def display_main_kpis(performance_metrics):
    """Display main KPI metrics"""
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        revenue = performance_metrics.get('total_revenue', 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">${revenue:,.2f}</div>
            <div class="metric-label">Total Revenue</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        roas = performance_metrics.get('roas', 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{roas:.2f}x</div>
            <div class="metric-label">ROAS</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        leads = performance_metrics.get('total_leads', 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{leads:,}</div>
            <div class="metric-label">Meta Leads</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        conversion_rate = performance_metrics.get('conversion_rate', 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{conversion_rate:.1f}%</div>
            <div class="metric-label">Conversion Rate</div>
        </div>
        """, unsafe_allow_html=True)

def display_performance_charts(performance_metrics, matching_stats):
    """Display performance visualizations"""
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Conversion funnel
        funnel_data = {
            'Stage': ['Meta Leads', 'Booked', 'Converted', 'Revenue'],
            'Count': [
                performance_metrics.get('total_leads', 0),
                performance_metrics.get('booked_leads', 0),
                performance_metrics.get('converted_leads', 0),
                performance_metrics.get('revenue_generating_leads', 0)
            ]
        }
        
        fig = go.Figure(go.Funnel(
            y=funnel_data['Stage'],
            x=funnel_data['Count'],
            textinfo="value+percent initial",
            marker={"color": ["#667eea", "#764ba2", "#f093fb", "#f5576c"]}
        ))
        
        fig.update_layout(
            title="Conversion Funnel",
            height=400,
            showlegend=False
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Attribution quality gauge
        attribution_rate = matching_stats.get('attribution_rate', 0)
        
        fig = go.Figure(go.Indicator(
            mode="gauge+number+delta",
            value=attribution_rate,
            domain={'x': [0, 1], 'y': [0, 1]},
            title={'text': "Attribution Quality"},
            delta={'reference': 80},
            gauge={
                'axis': {'range': [None, 100]},
                'bar': {'color': "#667eea"},
                'steps': [
                    {'range': [0, 30], 'color': "lightgray"},
                    {'range': [30, 60], 'color': "yellow"},
                    {'range': [60, 100], 'color': "lightgreen"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 80
                }
            }
        ))
        
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)

def display_secondary_metrics(performance_metrics):
    """Display secondary performance metrics"""
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        booking_rate = performance_metrics.get('booking_rate', 0)
        st.metric("Booking Rate", f"{booking_rate:.1f}%")
    
    with col2:
        avg_order_value = performance_metrics.get('average_order_value', 0)
        st.metric("Average Order Value", f"${avg_order_value:,.2f}")
    
    with col3:
        cost_per_lead = performance_metrics.get('cost_per_lead', 0)
        st.metric("Cost Per Lead", f"${cost_per_lead:.2f}")
    
    with col4:
        cost_per_conversion = performance_metrics.get('cost_per_conversion', 0)
        st.metric("Cost Per Conversion", f"${cost_per_conversion:.2f}")

def display_system_status(data_results):
    """Display system status for production monitoring"""
    
    st.markdown("### System Status")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        health_status = unified_connector.get_health_status()
        
        if health_status['api_connected']:
            st.markdown('<div class="status-good">✓ API Connected</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="status-error">✗ API Disconnected</div>', unsafe_allow_html=True)
    
    with col2:
        raw_stats = data_results.get('raw_stats', {})
        load_time = raw_stats.get('load_time', 0)
        
        if load_time < 30:
            st.markdown('<div class="status-good">✓ Fast Load Time</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="status-warning">⚠ Slow Load Time</div>', unsafe_allow_html=True)
        
        st.metric("Load Time", f"{load_time:.1f}s")
    
    with col3:
        matching_stats = data_results.get('matching_stats', {})
        attribution_rate = matching_stats.get('attribution_rate', 0)
        
        if attribution_rate >= 60:
            st.markdown('<div class="status-good">✓ High Attribution</div>', unsafe_allow_html=True)
        elif attribution_rate >= 30:
            st.markdown('<div class="status-warning">⚠ Medium Attribution</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="status-error">✗ Low Attribution</div>', unsafe_allow_html=True)

def main():
    """Main production dashboard application"""
    
    st.set_page_config(
        page_title="Meta Marketing Dashboard",
        page_icon="📊",
        layout="wide",
        initial_sidebar_state="collapsed"
    )
    
    # Apply styling
    apply_production_styling()
    
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>Meta Marketing Dashboard</h1>
        <p>Smooth MD Attribution & Performance Analytics</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Date range controls
    col1, col2, col3 = st.columns([2, 2, 1])
    
    with col1:
        start_date = st.date_input(
            "Start Date",
            value=datetime.now().date() - timedelta(days=30),
            max_value=datetime.now().date()
        )
    
    with col2:
        end_date = st.date_input(
            "End Date",
            value=datetime.now().date(),
            max_value=datetime.now().date()
        )
    
    with col3:
        if st.button("Refresh Data"):
            st.cache_data.clear()
            st.rerun()
    
    # Convert dates
    start_date_str = start_date.strftime('%Y-%m-%d')
    end_date_str = end_date.strftime('%Y-%m-%d')
    
    # Load and display data
    try:
        with st.spinner("Loading performance data..."):
            data_results = load_production_data(start_date_str, end_date_str)
        
        if not data_results:
            st.error("Failed to load data. Please check your connection and try again.")
            return
        
        performance_metrics = data_results['performance_metrics']
        matching_stats = data_results['matching_stats']
        
        # Main KPIs
        display_main_kpis(performance_metrics)
        
        st.markdown("---")
        
        # Performance charts
        display_performance_charts(performance_metrics, matching_stats)
        
        st.markdown("---")
        
        # Secondary metrics
        st.markdown("### Detailed Performance Metrics")
        display_secondary_metrics(performance_metrics)
        
        st.markdown("---")
        
        # System status
        display_system_status(data_results)
        
        # Auto-refresh option
        if st.checkbox("Auto-refresh every 5 minutes"):
            st.rerun()
    
    except Exception as e:
        logger.error(f"Dashboard error: {str(e)}")
        st.error(f"An error occurred while loading the dashboard: {str(e)}")
        st.info("Please refresh the page or contact support if the issue persists.")

if __name__ == "__main__":
    main()