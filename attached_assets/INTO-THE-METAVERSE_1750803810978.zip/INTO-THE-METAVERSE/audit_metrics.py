#!/usr/bin/env python3
"""
Comprehensive Metrics Audit
Verify all calculations and data filtering for accuracy
"""

import requests
from datetime import datetime, timedelta

def audit_all_metrics():
    api_key = 'patRpwfhYlGferLE8.17a89cf5c31e4ef29041a67a4b28ca4058bb443779beb0dd4352ad999b186cdd'
    base_id = 'appH4MePHS6qLsk5z'
    headers = {'Authorization': f'Bearer {api_key}'}
    
    print("=== COMPREHENSIVE METRICS AUDIT ===\n")
    
    # Test date range (last 7 days)
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=7)
    print(f"Date range: {start_date} to {end_date}")
    
    # 1. Audit Leads Data
    print("\n1. LEADS AUDIT")
    print("-" * 40)
    
    leads_response = requests.get(f'https://api.airtable.com/v0/{base_id}/Leads', headers=headers)
    if leads_response.status_code == 200:
        all_leads = leads_response.json().get('records', [])
        print(f"Total leads in database: {len(all_leads)}")
        
        # Filter Meta leads
        meta_leads = []
        for record in all_leads:
            fields = record['fields']
            contact_source = fields.get('Contact Source', '')
            if contact_source in ['Facebook AD', 'Facebook AD Sign Up', 'Instagram AD']:
                # Check date filtering
                inbound_date_str = fields.get('Inbound', '')
                if inbound_date_str:
                    try:
                        inbound_date = datetime.strptime(inbound_date_str, '%Y-%m-%d').date()
                        if start_date <= inbound_date <= end_date:
                            meta_leads.append({
                                'id': fields.get('ID', ''),
                                'contact_source': contact_source,
                                'inbound_date': inbound_date_str,
                                'phone': fields.get('Phone', ''),
                                'email': fields.get('Email', ''),
                                'consult_status': fields.get('Consult Status', ''),
                                'scheduled_location': fields.get('Scheduled Location', '')
                            })
                    except ValueError:
                        # Include leads without valid dates
                        meta_leads.append({
                            'id': fields.get('ID', ''),
                            'contact_source': contact_source,
                            'inbound_date': inbound_date_str,
                            'phone': fields.get('Phone', ''),
                            'email': fields.get('Email', ''),
                            'consult_status': fields.get('Consult Status', ''),
                            'scheduled_location': fields.get('Scheduled Location', '')
                        })
        
        print(f"Meta leads (all time): {len([r for r in all_leads if r['fields'].get('Contact Source') in ['Facebook AD', 'Facebook AD Sign Up', 'Instagram AD']])}")
        print(f"Meta leads (date filtered): {len(meta_leads)}")
        
        # Analyze funnel
        scheduled = sum(1 for lead in meta_leads if lead['scheduled_location'] and lead['scheduled_location'] != 'Pending')
        consulted = sum(1 for lead in meta_leads if 'completed' in str(lead['consult_status']).lower() or 'done' in str(lead['consult_status']).lower())
        
        print(f"Scheduled: {scheduled}")
        print(f"Consulted: {consulted}")
        
    # 2. Audit Transactions Data
    print("\n2. TRANSACTIONS AUDIT")
    print("-" * 40)
    
    trans_response = requests.get(f'https://api.airtable.com/v0/{base_id}/Transactions', headers=headers)
    if trans_response.status_code == 200:
        all_transactions = trans_response.json().get('records', [])
        print(f"Total transactions in database: {len(all_transactions)}")
        
        # Filter by date range
        date_filtered_transactions = []
        total_revenue = 0
        
        for record in all_transactions:
            fields = record['fields']
            transaction_date_str = fields.get('Date', '')
            amount = fields.get('Amount', 0)
            
            if transaction_date_str:
                try:
                    transaction_date = datetime.strptime(transaction_date_str, '%Y-%m-%d').date()
                    if start_date <= transaction_date <= end_date:
                        if isinstance(amount, (int, float)) and amount > 0:
                            date_filtered_transactions.append({
                                'patient': fields.get('Patient', ''),
                                'date': transaction_date_str,
                                'amount': amount,
                                'payment_type': fields.get('Payment Type', ''),
                                'status': fields.get('Status', '')
                            })
                            total_revenue += amount
                except ValueError:
                    pass
        
        print(f"Transactions (date filtered): {len(date_filtered_transactions)}")
        print(f"Total revenue (date filtered): ${total_revenue:,.2f}")
        
        # Show sample transactions
        print(f"\nSample transactions:")
        for i, trans in enumerate(date_filtered_transactions[:3]):
            print(f"  {i+1}. {trans['patient']}: ${trans['amount']} on {trans['date']}")
    
    # 3. Attribution Analysis
    print("\n3. ATTRIBUTION AUDIT")
    print("-" * 40)
    
    if meta_leads and date_filtered_transactions:
        print(f"Meta leads for attribution: {len(meta_leads)}")
        print(f"Revenue for attribution: ${total_revenue:,.2f}")
        
        # Simple attribution - distribute revenue among Meta leads
        avg_revenue_per_lead = total_revenue / len(meta_leads) if len(meta_leads) > 0 else 0
        print(f"Average revenue per Meta lead: ${avg_revenue_per_lead:,.2f}")
        
        # Calculate ROAS (need Meta spend data)
        print(f"\nTo calculate ROAS, need Meta ad spend for period {start_date} to {end_date}")
    
    print("\n=== AUDIT COMPLETE ===")

if __name__ == "__main__":
    audit_all_metrics()