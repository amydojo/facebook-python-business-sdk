"""
Debug Brand Filtering Tool
Identifies and fixes brand filtering issues for accurate Smooth MD attribution
"""

import streamlit as st
from unified_production_connector import unified_connector
from advanced_lead_matcher import advanced_lead_matcher
from datetime import datetime, timedelta

def debug_brand_patterns():
    """Debug brand pattern matching with real data"""
    
    st.markdown("## Brand Pattern Debugging")
    
    # Load sample data
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    lead_result = unified_connector.load_leads(start_date, end_date)
    
    if not lead_result.success:
        st.error("Failed to load leads data")
        return
    
    # Extract all unique brand values
    brand_values = set()
    meta_sources = set()
    
    for lead in lead_result.data[:100]:  # Sample first 100
        fields = lead.get('fields', {})
        brand = fields.get('Brand', '')
        source = fields.get('Contact Source', '')
        
        if brand:
            brand_values.add(brand)
        if source:
            meta_sources.add(source)
    
    st.markdown("### Unique Brand Values Found:")
    for brand in sorted(brand_values):
        st.write(f"- '{brand}'")
    
    st.markdown("### Unique Contact Sources Found:")
    for source in sorted(meta_sources):
        st.write(f"- '{source}'")
    
    # Test current patterns
    st.markdown("### Current Pattern Testing")
    
    smooth_patterns = ['smooth md', 'smooth m.d.', 'smooth m.d', 'smoothmd']
    meta_patterns = ['facebook ad', 'instagram ad', 'meta', 'fb', 'ig', 'facebook ads', 'instagram ads', 'meta ads']
    
    smooth_matches = []
    meta_source_matches = []
    
    for brand in brand_values:
        brand_lower = brand.lower()
        if any(pattern in brand_lower for pattern in smooth_patterns):
            smooth_matches.append(brand)
    
    for source in meta_sources:
        source_lower = source.lower()
        if any(pattern in source_lower for pattern in meta_patterns):
            meta_source_matches.append(source)
    
    st.markdown("**Smooth MD Brand Matches:**")
    for brand in smooth_matches:
        st.success(f"✓ '{brand}'")
    
    st.markdown("**Meta Source Matches:**")
    for source in meta_source_matches:
        st.success(f"✓ '{source}'")

def test_lead_identification():
    """Test the actual lead identification process"""
    
    st.markdown("## Lead Identification Testing")
    
    # Load data
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    lead_result = unified_connector.load_leads(start_date, end_date)
    
    if not lead_result.success:
        st.error("Failed to load leads data")
        return
    
    # Test with first 50 leads
    test_leads = lead_result.data[:50]
    
    st.write(f"Testing with {len(test_leads)} sample leads...")
    
    # Manual filtering test
    smooth_md_meta_leads = []
    dr_vigor_meta_leads = []
    other_leads = []
    
    for lead in test_leads:
        fields = lead.get('fields', {})
        brand = fields.get('Brand', '').lower()
        source = fields.get('Contact Source', '').lower()
        
        # Check if Meta source
        is_meta_source = any(pattern in source for pattern in ['facebook ad', 'instagram ad', 'meta', 'fb', 'ig'])
        
        if is_meta_source:
            if 'smooth' in brand:
                smooth_md_meta_leads.append({
                    'brand': fields.get('Brand', ''),
                    'source': fields.get('Contact Source', ''),
                    'email': fields.get('Email', ''),
                    'status': fields.get('Overall Status', '')
                })
            elif 'vigor' in brand:
                dr_vigor_meta_leads.append({
                    'brand': fields.get('Brand', ''),
                    'source': fields.get('Contact Source', ''),
                    'email': fields.get('Email', ''),
                    'status': fields.get('Overall Status', '')
                })
            else:
                other_leads.append({
                    'brand': fields.get('Brand', ''),
                    'source': fields.get('Contact Source', ''),
                    'email': fields.get('Email', ''),
                    'status': fields.get('Overall Status', '')
                })
    
    # Display results
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Smooth MD Meta Leads", len(smooth_md_meta_leads))
        if smooth_md_meta_leads:
            st.markdown("**Sample Smooth MD Leads:**")
            for i, lead in enumerate(smooth_md_meta_leads[:3]):
                st.write(f"{i+1}. {lead['brand']} | {lead['source']}")
    
    with col2:
        st.metric("Dr. Vigor Meta Leads", len(dr_vigor_meta_leads))
        if dr_vigor_meta_leads:
            st.markdown("**Sample Dr. Vigor Leads:**")
            for i, lead in enumerate(dr_vigor_meta_leads[:3]):
                st.write(f"{i+1}. {lead['brand']} | {lead['source']}")
    
    with col3:
        st.metric("Other Meta Leads", len(other_leads))
        if other_leads:
            st.markdown("**Sample Other Leads:**")
            for i, lead in enumerate(other_leads[:3]):
                st.write(f"{i+1}. {lead['brand']} | {lead['source']}")
    
    return smooth_md_meta_leads, dr_vigor_meta_leads

def compare_current_vs_corrected():
    """Compare current attribution vs corrected Smooth MD only"""
    
    st.markdown("## Attribution Comparison")
    
    # Load data
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    lead_result = unified_connector.load_leads(start_date, end_date)
    transaction_result = unified_connector.load_transactions(start_date, end_date)
    
    if not lead_result.success or not transaction_result.success:
        st.error("Failed to load data")
        return
    
    # Current system (includes Dr. Vigor)
    current_meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data)
    current_matched, current_stats = advanced_lead_matcher.match_transactions_to_leads(
        current_meta_leads, transaction_result.data
    )
    
    # Manual Smooth MD only filtering
    smooth_only_leads = []
    for lead in lead_result.data:
        fields = lead.get('fields', {})
        brand = fields.get('Brand', '').lower()
        source = fields.get('Contact Source', '').lower()
        
        # Check if Meta source AND Smooth MD brand
        is_meta = any(pattern in source for pattern in ['facebook ad', 'instagram ad', 'meta', 'fb', 'ig'])
        is_smooth = 'smooth' in brand and 'vigor' not in brand
        
        if is_meta and is_smooth:
            smooth_only_leads.append(lead)
    
    # Process smooth-only leads through the matcher
    smooth_meta_leads = advanced_lead_matcher.identify_meta_leads(smooth_only_leads)
    smooth_matched, smooth_stats = advanced_lead_matcher.match_transactions_to_leads(
        smooth_meta_leads, transaction_result.data
    )
    
    # Display comparison
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### Current System (Mixed)")
        st.metric("Meta Leads", len(current_meta_leads))
        st.metric("Matched Leads", len([l for l in current_matched if l['matched_transactions']]))
        st.metric("Revenue", f"${current_stats.get('total_matched_revenue', 0):,.2f}")
        st.metric("Attribution Rate", f"{current_stats.get('attribution_rate', 0):.1f}%")
    
    with col2:
        st.markdown("### Corrected (Smooth MD Only)")
        st.metric("Meta Leads", len(smooth_meta_leads))
        st.metric("Matched Leads", len([l for l in smooth_matched if l['matched_transactions']]))
        st.metric("Revenue", f"${smooth_stats.get('total_matched_revenue', 0):,.2f}")
        st.metric("Attribution Rate", f"{smooth_stats.get('attribution_rate', 0):.1f}%")
    
    # Show the difference
    revenue_diff = smooth_stats.get('total_matched_revenue', 0) - current_stats.get('total_matched_revenue', 0)
    lead_diff = len(smooth_meta_leads) - len(current_meta_leads)
    
    st.markdown("### Impact of Correction")
    st.metric("Revenue Difference", f"${revenue_diff:,.2f}", delta=revenue_diff)
    st.metric("Lead Count Difference", lead_diff, delta=lead_diff)
    
    return smooth_stats

def generate_fixed_implementation():
    """Generate the corrected implementation code"""
    
    st.markdown("## Fixed Implementation")
    
    st.markdown("### Issue Identified:")
    st.error("Current brand patterns still allow Dr. Vigor leads to be included in Smooth MD attribution")
    
    st.markdown("### Solution:")
    st.code("""
# Update the brand filtering in advanced_lead_matcher.py

def _is_smooth_brand(self, brand: str) -> bool:
    \"\"\"Check if brand is Smooth MD only (exclude Dr. Vigor)\"\"\"
    if not brand:
        return False
    brand_lower = brand.lower()
    
    # Must contain 'smooth' but NOT 'vigor'
    has_smooth = any(pattern in brand_lower for pattern in ['smooth md', 'smooth m.d.', 'smoothmd'])
    has_vigor = 'vigor' in brand_lower
    
    return has_smooth and not has_vigor
    """, language='python')
    
    st.markdown("### Additional Debugging:")
    st.code("""
# Add logging to track filtering
if is_meta and is_smooth:
    logger.info(f"Matched Smooth MD lead: {brand} | {contact_source}")
elif is_meta and not is_smooth:
    logger.debug(f"Filtered out non-Smooth lead: {brand} | {contact_source}")
    """, language='python')

def main():
    """Main debugging application"""
    
    st.set_page_config(
        page_title="Brand Filtering Debug",
        page_icon="🔧",
        layout="wide"
    )
    
    st.title("🔧 Brand Filtering Debug Tool")
    st.markdown("**Debugging Smooth MD attribution accuracy**")
    
    # Run debugging steps
    debug_brand_patterns()
    
    st.markdown("---")
    
    smooth_leads, vigor_leads = test_lead_identification()
    
    st.markdown("---")
    
    corrected_stats = compare_current_vs_corrected()
    
    st.markdown("---")
    
    generate_fixed_implementation()
    
    # Summary
    if corrected_stats:
        st.markdown("## Summary")
        st.success(f"Corrected Smooth MD attribution: ${corrected_stats.get('total_matched_revenue', 0):,.2f}")
        st.info("The current system needs the brand filtering fix to show accurate Smooth MD only attribution")

if __name__ == "__main__":
    main()