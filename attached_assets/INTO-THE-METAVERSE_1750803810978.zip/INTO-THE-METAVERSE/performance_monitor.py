"""
Advanced Performance Monitoring System
Real-time performance tracking and optimization
"""

import time
import psutil
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import streamlit as st

class PerformanceMonitor:
    """Advanced performance monitoring and optimization"""
    
    def __init__(self):
        self.metrics: Dict[str, List[float]] = {}
        self.system_metrics: Dict[str, Any] = {}
        self.performance_thresholds = {
            'response_time': 2.0,  # seconds
            'memory_usage': 80.0,   # percentage
            'cpu_usage': 80.0,      # percentage
            'cache_hit_rate': 80.0  # percentage
        }
        self.monitoring_active = False
        self.monitor_thread: Optional[threading.Thread] = None
    
    def start_monitoring(self) -> None:
        """Start continuous performance monitoring"""
        if not self.monitoring_active:
            self.monitoring_active = True
            self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
            self.monitor_thread.start()
    
    def stop_monitoring(self) -> None:
        """Stop performance monitoring"""
        self.monitoring_active = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=1)
    
    def _monitor_loop(self) -> None:
        """Continuous monitoring loop"""
        while self.monitoring_active:
            try:
                self._collect_system_metrics()
                time.sleep(10)  # Collect metrics every 10 seconds
            except Exception as e:
                st.error(f"Performance monitoring error: {e}")
    
    def _collect_system_metrics(self) -> None:
        """Collect system performance metrics"""
        try:
            # CPU and memory metrics
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            
            self.system_metrics.update({
                'cpu_usage': cpu_percent,
                'memory_usage': memory.percent,
                'memory_available': memory.available / (1024**3),  # GB
                'timestamp': datetime.now()
            })
            
            # Disk metrics
            disk = psutil.disk_usage('.')
            self.system_metrics['disk_usage'] = (disk.used / disk.total) * 100
            
        except Exception as e:
            st.error(f"System metrics collection error: {e}")
    
    def track_operation(self, operation: str, duration: float) -> None:
        """Track operation performance"""
        if operation not in self.metrics:
            self.metrics[operation] = []
        
        self.metrics[operation].append(duration)
        
        # Keep only recent metrics (last 100 operations)
        if len(self.metrics[operation]) > 100:
            self.metrics[operation] = self.metrics[operation][-100:]
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get comprehensive performance summary"""
        summary = {
            'system_health': self._assess_system_health(),
            'operation_performance': self._analyze_operation_performance(),
            'recommendations': self._generate_performance_recommendations()
        }
        
        return summary
    
    def _assess_system_health(self) -> str:
        """Assess overall system health"""
        if not self.system_metrics:
            return "Unknown"
        
        cpu_ok = self.system_metrics.get('cpu_usage', 0) < self.performance_thresholds['cpu_usage']
        memory_ok = self.system_metrics.get('memory_usage', 0) < self.performance_thresholds['memory_usage']
        
        if cpu_ok and memory_ok:
            return "Excellent"
        elif cpu_ok or memory_ok:
            return "Good"
        else:
            return "Needs Attention"
    
    def _analyze_operation_performance(self) -> Dict[str, Any]:
        """Analyze operation performance patterns"""
        analysis = {}
        
        for operation, durations in self.metrics.items():
            if durations:
                analysis[operation] = {
                    'avg_duration': sum(durations) / len(durations),
                    'max_duration': max(durations),
                    'min_duration': min(durations),
                    'total_operations': len(durations)
                }
        
        return analysis
    
    def _generate_performance_recommendations(self) -> List[str]:
        """Generate performance optimization recommendations"""
        recommendations = []
        
        # Check system metrics
        if self.system_metrics.get('memory_usage', 0) > 80:
            recommendations.append("Consider implementing memory cleanup routines")
        
        if self.system_metrics.get('cpu_usage', 0) > 80:
            recommendations.append("Consider optimizing CPU-intensive operations")
        
        # Check operation performance
        for operation, durations in self.metrics.items():
            if durations:
                avg_duration = sum(durations) / len(durations)
                if avg_duration > self.performance_thresholds['response_time']:
                    recommendations.append(f"Optimize {operation} - average {avg_duration:.2f}s")
        
        return recommendations

# Global performance monitor
performance_monitor = PerformanceMonitor()
