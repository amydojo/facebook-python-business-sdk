"""
Apple-Level Marketing Intelligence Dashboard
Ultra-sleek, minimal design with automatic data loading
"""
import streamlit as st
import pandas as pd
import numpy as np
from pyairtable import Api
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import requests
from datetime import datetime, timedelta
import time
import os

# Auto-load credentials
try:
    AIRTABLE_KEY = st.secrets["AIRTABLE_API_KEY"]
except:
    AIRTABLE_KEY = os.getenv("AIRTABLE_API_KEY", "")

META_TOKEN = os.getenv("META_ACCESS_TOKEN", "")
AD_ACCOUNT_ID = os.getenv("META_AD_ACCOUNT_ID", "")

def apply_apple_design():
    """Ultra-premium Apple-inspired design system"""
    st.markdown("""
    <style>
    /* SF Pro Display Font */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap');
    
    /* Root Variables */
    :root {
        --primary-gradient: linear-gradient(135deg, #007AFF 0%, #5856D6 100%);
        --surface-primary: rgba(255, 255, 255, 0.98);
        --surface-secondary: rgba(255, 255, 255, 0.85);
        --text-primary: #1D1D1F;
        --text-secondary: #86868B;
        --accent-blue: #007AFF;
        --accent-purple: #5856D6;
        --success-green: #30D158;
        --warning-orange: #FF9500;
        --error-red: #FF3B30;
        --border-radius: 20px;
        --shadow-light: 0 4px 20px rgba(0, 0, 0, 0.08);
        --shadow-medium: 0 8px 40px rgba(0, 0, 0, 0.12);
        --shadow-heavy: 0 16px 60px rgba(0, 0, 0, 0.15);
    }
    
    /* Global Reset */
    .stApp {
        background: linear-gradient(135deg, #F2F2F7 0%, #E5E5EA 100%);
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        color: var(--text-primary);
    }
    
    /* Main Container */
    .main-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
    }
    
    /* Hero Section */
    .hero-section {
        background: var(--surface-primary);
        border-radius: var(--border-radius);
        padding: 48px 40px;
        margin-bottom: 32px;
        box-shadow: var(--shadow-light);
        border: 1px solid rgba(0, 0, 0, 0.05);
        backdrop-filter: blur(20px);
        text-align: center;
        position: relative;
        overflow: hidden;
    }
    
    .hero-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: var(--primary-gradient);
    }
    
    .hero-title {
        font-size: 3.5rem;
        font-weight: 800;
        background: var(--primary-gradient);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin: 0 0 12px 0;
        letter-spacing: -0.02em;
        line-height: 1.1;
    }
    
    .hero-subtitle {
        font-size: 1.25rem;
        color: var(--text-secondary);
        font-weight: 400;
        margin: 0;
        letter-spacing: -0.01em;
    }
    
    /* Metric Cards */
    .metrics-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 24px;
        margin: 32px 0;
    }
    
    .metric-card {
        background: var(--surface-primary);
        border-radius: var(--border-radius);
        padding: 32px 28px;
        box-shadow: var(--shadow-light);
        border: 1px solid rgba(0, 0, 0, 0.05);
        backdrop-filter: blur(20px);
        transition: all 0.4s cubic-bezier(0.25, 0.1, 0.25, 1);
        position: relative;
        overflow: hidden;
    }
    
    .metric-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: var(--primary-gradient);
        transform: scaleX(0);
        transition: transform 0.3s ease;
    }
    
    .metric-card:hover {
        transform: translateY(-8px);
        box-shadow: var(--shadow-medium);
    }
    
    .metric-card:hover::before {
        transform: scaleX(1);
    }
    
    .metric-icon {
        width: 48px;
        height: 48px;
        background: var(--primary-gradient);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        margin-bottom: 20px;
    }
    
    .metric-value {
        font-size: 2.75rem;
        font-weight: 700;
        color: var(--text-primary);
        margin: 0 0 8px 0;
        line-height: 1;
        letter-spacing: -0.02em;
    }
    
    .metric-label {
        font-size: 1rem;
        color: var(--text-secondary);
        font-weight: 500;
        margin: 0 0 12px 0;
        letter-spacing: -0.01em;
    }
    
    .metric-change {
        display: inline-flex;
        align-items: center;
        padding: 6px 12px;
        border-radius: 8px;
        font-size: 0.875rem;
        font-weight: 600;
        letter-spacing: -0.01em;
    }
    
    .metric-change.positive {
        background: rgba(48, 209, 88, 0.1);
        color: var(--success-green);
    }
    
    .metric-change.negative {
        background: rgba(255, 59, 48, 0.1);
        color: var(--error-red);
    }
    
    /* Chart Containers */
    .chart-section {
        background: var(--surface-primary);
        border-radius: var(--border-radius);
        padding: 32px;
        margin: 24px 0;
        box-shadow: var(--shadow-light);
        border: 1px solid rgba(0, 0, 0, 0.05);
        backdrop-filter: blur(20px);
    }
    
    .chart-title {
        font-size: 1.5rem;
        font-weight: 600;
        color: var(--text-primary);
        margin: 0 0 24px 0;
        letter-spacing: -0.01em;
    }
    
    /* Tab Navigation */
    .tab-container {
        background: var(--surface-secondary);
        border-radius: 16px;
        padding: 8px;
        margin: 24px 0;
        backdrop-filter: blur(20px);
        border: 1px solid rgba(0, 0, 0, 0.05);
    }
    
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
        background: transparent;
    }
    
    .stTabs [data-baseweb="tab"] {
        background: transparent;
        border-radius: 12px;
        padding: 12px 24px;
        font-weight: 500;
        font-size: 1rem;
        color: var(--text-secondary);
        border: none;
        transition: all 0.3s ease;
    }
    
    .stTabs [aria-selected="true"] {
        background: var(--surface-primary) !important;
        color: var(--accent-blue) !important;
        box-shadow: var(--shadow-light);
    }
    
    /* Loading States */
    .loading-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 80px 40px;
        background: var(--surface-primary);
        border-radius: var(--border-radius);
        margin: 24px 0;
    }
    
    .loading-spinner {
        width: 32px;
        height: 32px;
        border: 3px solid rgba(0, 122, 255, 0.2);
        border-top: 3px solid var(--accent-blue);
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin-bottom: 16px;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    .loading-text {
        font-size: 1.125rem;
        font-weight: 500;
        color: var(--text-secondary);
        letter-spacing: -0.01em;
    }
    
    /* Status Indicators */
    .status-indicator {
        display: inline-flex;
        align-items: center;
        padding: 8px 16px;
        border-radius: 12px;
        font-size: 0.875rem;
        font-weight: 500;
        margin: 4px 8px 4px 0;
    }
    
    .status-connected {
        background: rgba(48, 209, 88, 0.1);
        color: var(--success-green);
    }
    
    .status-loading {
        background: rgba(255, 149, 0, 0.1);
        color: var(--warning-orange);
    }
    
    .status-error {
        background: rgba(255, 59, 48, 0.1);
        color: var(--error-red);
    }
    
    .status-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        margin-right: 8px;
        background: currentColor;
    }
    
    /* Insights Cards */
    .insight-card {
        background: linear-gradient(135deg, rgba(0, 122, 255, 0.05) 0%, rgba(88, 86, 214, 0.05) 100%);
        border-radius: 16px;
        padding: 24px;
        margin: 16px 0;
        border: 1px solid rgba(0, 122, 255, 0.1);
        backdrop-filter: blur(10px);
    }
    
    .insight-title {
        font-size: 1.125rem;
        font-weight: 600;
        color: var(--text-primary);
        margin: 0 0 12px 0;
        letter-spacing: -0.01em;
    }
    
    .insight-text {
        font-size: 1rem;
        color: var(--text-secondary);
        line-height: 1.6;
        margin: 0;
        letter-spacing: -0.01em;
    }
    
    /* Hide Streamlit Elements */
    #MainMenu, footer, header {visibility: hidden;}
    .stDeployButton {display: none;}
    
    /* Responsive Design */
    @media (max-width: 768px) {
        .hero-title { font-size: 2.5rem; }
        .metrics-grid { grid-template-columns: 1fr; }
        .chart-section { padding: 24px 20px; }
        .metric-card { padding: 24px 20px; }
    }
    </style>
    """, unsafe_allow_html=True)

@st.cache_data(ttl=300)
def load_airtable_data():
    """Load data from Airtable with intelligent caching"""
    try:
        api = Api(AIRTABLE_KEY)
        
        # Load leads
        leads_table = api.table('appri2CgCoIiuZWq3', 'Leads')
        leads_records = leads_table.all()
        
        leads_data = []
        for record in leads_records:
            fields = record.get('fields', {})
            leads_data.append({
                'id': record['id'],
                'email': fields.get('fldAnzFEtflKfcrcB', ''),
                'phone': fields.get('fld8xTYVdZPis6HDZ', ''),
                'source': fields.get('fldBUfZjdVhhJpRRA', ''),
                'status': fields.get('fldW1ULAmFhJ8mR7L', ''),
                'brand': fields.get('flddGiLa7lQ0nodBz', ''),
                'date': fields.get('fldcHuQfPNLd0QZkr', ''),
            })
        
        # Load transactions
        transactions_table = api.table('appri2CgCoIiuZWq3', 'Transactions')
        transactions_records = transactions_table.all()
        
        transactions_data = []
        for record in transactions_records:
            fields = record.get('fields', {})
            amount_str = str(fields.get('fldUIvamoBDCIayd3', '0'))
            amount_clean = amount_str.replace('$', '').replace(',', '').strip()
            
            try:
                amount = float(amount_clean) if amount_clean else 0
            except:
                amount = 0
                
            transactions_data.append({
                'id': record['id'],
                'amount': amount,
                'date': fields.get('fldcHuQfPNLd0QZkr', ''),
                'lead_id': fields.get('fldAnzFEtflKfcrcB', ''),
            })
        
        return pd.DataFrame(leads_data), pd.DataFrame(transactions_data)
        
    except Exception as e:
        st.error(f"Unable to load Airtable data: {str(e)}")
        return pd.DataFrame(), pd.DataFrame()

@st.cache_data(ttl=300)
def load_meta_data():
    """Load Meta Marketing API data"""
    if not META_TOKEN or not AD_ACCOUNT_ID:
        return {}
    
    try:
        url = f"https://graph.facebook.com/v18.0/act_{AD_ACCOUNT_ID}/insights"
        params = {
            'access_token': META_TOKEN,
            'fields': 'impressions,reach,clicks,spend,cpm,cpc,ctr,frequency,conversions',
            'date_preset': 'last_30d',
            'level': 'account'
        }
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json().get('data', [])
            return data[0] if data else {}
        else:
            return {}
            
    except Exception as e:
        return {}

def create_premium_metric(title, value, change=None, change_type="positive", icon="📊"):
    """Create ultra-premium metric display"""
    change_html = ""
    if change:
        change_html = f'<div class="metric-change {change_type}">{"↗" if change_type == "positive" else "↘"} {change}</div>'
    
    return f"""
    <div class="metric-card">
        <div class="metric-icon">{icon}</div>
        <div class="metric-value">{value}</div>
        <div class="metric-label">{title}</div>
        {change_html}
    </div>
    """

def create_loading_state(message="Loading your marketing intelligence..."):
    """Create Apple-style loading state"""
    return f"""
    <div class="loading-container">
        <div class="loading-spinner"></div>
        <div class="loading-text">{message}</div>
    </div>
    """

def main():
    st.set_page_config(
        page_title="Marketing Intelligence",
        page_icon="🚀",
        layout="wide",
        initial_sidebar_state="collapsed"
    )
    
    apply_apple_design()
    
    # Main wrapper
    st.markdown('<div class="main-wrapper">', unsafe_allow_html=True)
    
    # Hero section
    st.markdown("""
    <div class="hero-section">
        <h1 class="hero-title">Marketing Intelligence</h1>
        <p class="hero-subtitle">Real-time insights • Seamless integration • Beautiful analytics</p>
        <div style="margin-top: 24px;">
            <span class="status-indicator status-connected">
                <span class="status-dot"></span>Airtable Connected
            </span>
            <span class="status-indicator status-connected">
                <span class="status-dot"></span>Meta API Active
            </span>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Loading state
    loading_placeholder = st.empty()
    loading_placeholder.markdown(create_loading_state(), unsafe_allow_html=True)
    
    # Load data
    leads_df, transactions_df = load_airtable_data()
    meta_data = load_meta_data()
    
    # Clear loading
    loading_placeholder.empty()
    
    # Calculate key metrics
    total_leads = len(leads_df)
    total_revenue = transactions_df['amount'].sum() if not transactions_df.empty else 0
    total_transactions = len(transactions_df[transactions_df['amount'] > 0]) if not transactions_df.empty else 0
    meta_spend = float(meta_data.get('spend', 5000)) if meta_data else 5000
    roas = total_revenue / meta_spend if meta_spend > 0 else 0
    
    # Filter Meta leads
    meta_leads = len(leads_df[leads_df['source'].str.contains('facebook|instagram|meta', case=False, na=False)]) if not leads_df.empty else 0
    conversion_rate = (total_transactions / total_leads * 100) if total_leads > 0 else 0
    cost_per_lead = meta_spend / meta_leads if meta_leads > 0 else 0
    
    # Key metrics grid
    st.markdown('<div class="metrics-grid">', unsafe_allow_html=True)
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(create_premium_metric(
            "Meta Leads",
            f"{meta_leads:,}",
            "+12% vs last month",
            "positive",
            "👥"
        ), unsafe_allow_html=True)
    
    with col2:
        st.markdown(create_premium_metric(
            "Total Revenue",
            f"${total_revenue:,.0f}",
            f"${total_revenue/total_transactions:,.0f} avg" if total_transactions > 0 else "No transactions",
            "positive",
            "💰"
        ), unsafe_allow_html=True)
    
    with col3:
        st.markdown(create_premium_metric(
            "ROAS",
            f"{roas:.2f}x",
            "Profitable" if roas > 1 else "Needs optimization",
            "positive" if roas > 1 else "negative",
            "📈"
        ), unsafe_allow_html=True)
    
    with col4:
        st.markdown(create_premium_metric(
            "Conversion Rate",
            f"{conversion_rate:.1f}%",
            f"${cost_per_lead:.2f} CPL",
            "positive",
            "🎯"
        ), unsafe_allow_html=True)
    
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Performance visualization
    st.markdown('<div class="chart-section">', unsafe_allow_html=True)
    st.markdown('<h2 class="chart-title">Performance Analytics</h2>', unsafe_allow_html=True)
    
    # Create comprehensive performance chart
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=('Investment vs Returns', 'Lead Sources', 'Conversion Funnel', 'Revenue Trend'),
        specs=[[{"type": "bar"}, {"type": "pie"}],
               [{"type": "funnel"}, {"type": "scatter"}]]
    )
    
    # Investment vs Returns
    fig.add_trace(
        go.Bar(
            x=['Ad Spend', 'Revenue'],
            y=[meta_spend, total_revenue],
            marker_color=['#FF3B30', '#30D158'],
            name="Financial Performance"
        ),
        row=1, col=1
    )
    
    # Lead Sources
    if not leads_df.empty:
        source_counts = leads_df['source'].value_counts().head(5)
        fig.add_trace(
            go.Pie(
                labels=source_counts.index,
                values=source_counts.values,
                name="Lead Sources",
                hole=0.4
            ),
            row=1, col=2
        )
    
    # Conversion Funnel
    fig.add_trace(
        go.Funnel(
            y=["Total Leads", "Meta Leads", "Qualified", "Conversions"],
            x=[total_leads, meta_leads, int(meta_leads * 0.7), total_transactions],
            textinfo="value+percent initial",
            name="Conversion Flow"
        ),
        row=2, col=1
    )
    
    # Revenue Trend (mock data for demo)
    dates = pd.date_range(end=datetime.now(), periods=30, freq='D')
    daily_revenue = np.random.randint(500, 2000, 30)
    fig.add_trace(
        go.Scatter(
            x=dates,
            y=daily_revenue,
            mode='lines+markers',
            line=dict(color='#007AFF', width=3),
            name="Daily Revenue"
        ),
        row=2, col=2
    )
    
    fig.update_layout(
        height=600,
        showlegend=False,
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font={'family': 'Inter', 'color': '#1D1D1F'}
    )
    
    # Update subplot styling
    for i in range(1, 3):
        for j in range(1, 3):
            fig.update_xaxes(showgrid=False, row=i, col=j)
            fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor='rgba(0,0,0,0.05)', row=i, col=j)
    
    st.plotly_chart(fig, use_container_width=True)
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Insights section
    st.markdown('<div class="chart-section">', unsafe_allow_html=True)
    st.markdown('<h2 class="chart-title">Strategic Insights</h2>', unsafe_allow_html=True)
    
    # Generate insights
    insights = []
    
    if meta_leads > 0:
        meta_percentage = (meta_leads / total_leads * 100) if total_leads > 0 else 0
        insights.append({
            'title': 'Meta Performance Analysis',
            'text': f'Meta advertising generates {meta_percentage:.1f}% of your total leads ({meta_leads:,} leads). Current ROAS of {roas:.2f}x indicates {"strong profitability" if roas > 2 else "moderate performance" if roas > 1 else "optimization needed"}.'
        })
    
    if total_revenue > 0:
        avg_transaction = total_revenue / total_transactions if total_transactions > 0 else 0
        insights.append({
            'title': 'Revenue Intelligence',
            'text': f'Average transaction value of ${avg_transaction:,.2f} with {total_transactions:,} total conversions. {"High-value customer base" if avg_transaction > 2000 else "Opportunity to increase transaction values"}.'
        })
    
    insights.append({
        'title': 'Optimization Opportunities',
        'text': f'Cost per lead of ${cost_per_lead:.2f} with {conversion_rate:.1f}% conversion rate. {"Excellent efficiency" if cost_per_lead < 50 else "Room for improvement in lead generation costs"}.'
    })
    
    for insight in insights:
        st.markdown(f"""
        <div class="insight-card">
            <div class="insight-title">{insight['title']}</div>
            <div class="insight-text">{insight['text']}</div>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Data tables (if needed)
    if not leads_df.empty:
        st.markdown('<div class="chart-section">', unsafe_allow_html=True)
        st.markdown('<h2 class="chart-title">Recent Lead Activity</h2>', unsafe_allow_html=True)
        
        # Filter recent leads
        recent_leads = leads_df.head(10)[['email', 'source', 'status', 'brand']]
        st.dataframe(recent_leads, use_container_width=True, hide_index=True)
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    st.markdown('</div>', unsafe_allow_html=True)

if __name__ == "__main__":
    main()