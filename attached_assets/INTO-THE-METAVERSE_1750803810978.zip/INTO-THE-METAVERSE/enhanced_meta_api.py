"""
Enhanced Meta Marketing API Implementation
Following strict API best practices from Meta documentation
"""
import os
import time
import json
import requests
import pandas as pd
from datetime import datetime, timedelta
import logging
import streamlit as st

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('meta_api')

class EnhancedMetaAPI:
    """
    Optimized implementation of Meta Marketing API focusing on best practices
    - Batch requests for performance
    - Proper pagination handling 
    - Field expansion for optimization
    - Comprehensive error handling
    - Rate limit management
    """
    
    def __init__(self, access_token=None, ad_account_id=None):
        """Initialize with Meta credentials"""
        self.access_token = access_token or os.environ.get("META_ACCESS_TOKEN")
        self.ad_account_id = ad_account_id or os.environ.get("META_AD_ACCOUNT_ID")
        
        # Initialize API settings
        self.api_version = "v22.0"  # Latest stable version
        self.base_url = f"https://graph.facebook.com/{self.api_version}"
        
        # Rate limiting settings
        self.max_rate = 100  # API calls per hour
        self.call_timestamps = []
        self.retry_delay = 3  # Seconds
        self.max_retries = 3
        
        # Standardize field sets for different object types
        self.standard_campaign_fields = [
            "id", "name", "status", "objective", "created_time", 
            "start_time", "stop_time", "updated_time", "daily_budget",
            "lifetime_budget", "budget_remaining", "buying_type",
            "bid_strategy", "pacing_type", "special_ad_categories"
        ]
        
        self.standard_adset_fields = [
            "id", "name", "status", "campaign_id", "created_time", 
            "start_time", "end_time", "updated_time", "daily_budget",
            "lifetime_budget", "budget_remaining", "targeting", 
            "bid_amount", "bid_strategy", "billing_event", "optimization_goal"
        ]
        
        self.standard_ad_fields = [
            "id", "name", "status", "adset_id", "campaign_id", "created_time",
            "updated_time", "creative", "tracking_specs", "conversion_specs",
            "effective_status", "preview_url"
        ]
        
        self.standard_insights_fields = [
            "campaign_id", "campaign_name", "adset_id", "adset_name", 
            "ad_id", "ad_name", "date_start", "date_stop", 
            "impressions", "reach", "frequency", "clicks", "ctr", 
            "spend", "cpm", "cpp", "cpc", "actions", "action_values",
            "conversions", "conversion_values", "cost_per_action_type",
            "cost_per_conversion", "unique_clicks", "unique_ctr"
        ]
        
    def _manage_rate_limit(self):
        """
        Manage API rate limiting with the sliding window algorithm
        """
        # Get current time
        current_time = time.time()
        
        # Remove timestamps older than 1 hour
        hour_ago = current_time - 3600
        self.call_timestamps = [ts for ts in self.call_timestamps if ts > hour_ago]
        
        # Check if we're at rate limit
        if len(self.call_timestamps) >= self.max_rate:
            # Calculate sleep time - time until oldest timestamp is 1 hour old
            oldest_timestamp = min(self.call_timestamps)
            sleep_time = max(0, (oldest_timestamp + 3600) - current_time)
            
            if sleep_time > 0:
                logger.warning(f"Rate limit reached, pausing for {sleep_time:.2f} seconds")
                time.sleep(sleep_time)
        
        # Add current timestamp
        self.call_timestamps.append(current_time)
    
    def _make_request(self, url, params, method="GET"):
        """
        Make API request with comprehensive error handling and retries
        
        Args:
            url (str): API endpoint URL
            params (dict): Request parameters
            method (str): HTTP method (GET or POST)
            
        Returns:
            dict: API response data or error
        """
        # Check rate limit before making request
        self._manage_rate_limit()
        
        # Track retries
        retries = 0
        delay = self.retry_delay
        
        while retries <= self.max_retries:
            try:
                # Make the request
                if method == "GET":
                    response = requests.get(url, params=params, timeout=30)
                else:
                    response = requests.post(url, data=params, timeout=30)
                
                # Check if response is valid JSON
                try:
                    data = response.json()
                except Exception as e:
                    logger.error(f"Invalid JSON response: {e}")
                    data = {"error": {"message": f"Invalid JSON response: {str(e)}"}}
                
                # Check for API errors
                if "error" in data:
                    error_message = data["error"].get("message", "Unknown API error")
                    error_code = data["error"].get("code", 0)
                    error_type = data["error"].get("type", "UnknownError")
                    
                    # Handle different error types
                    if error_code == 17 or error_code == 4:  # Rate limit
                        logger.warning(f"Rate limit error: {error_message}. Retrying after backoff.")
                        time.sleep(delay)
                        retries += 1
                        delay *= 2  # Exponential backoff
                        continue
                    elif error_code == 190:  # Auth error
                        logger.error(f"Authentication error: {error_message}")
                        return {"error": "authentication", "message": error_message}
                    elif error_code == 100 or error_type == "GraphMethodException":
                        logger.error(f"Invalid API parameters: {error_message}")
                        return {"error": "parameters", "message": error_message}
                    else:
                        # For other errors, retry with backoff
                        logger.warning(f"API error {error_code}: {error_message}. Retrying.")
                        time.sleep(delay)
                        retries += 1
                        delay *= 2
                        continue
                
                # Check HTTP status
                if response.status_code != 200:
                    logger.warning(f"HTTP error {response.status_code}. Retrying.")
                    time.sleep(delay)
                    retries += 1
                    delay *= 2
                    continue
                
                # If we got here, request was successful
                return data
                
            except Exception as e:
                logger.error(f"Request error: {str(e)}")
                time.sleep(delay)
                retries += 1
                delay *= 2
        
        # If we exhausted retries
        return {"error": "max_retries", "message": "Maximum retries reached"}
    
    def _handle_pagination(self, initial_response):
        """
        Handle cursor-based pagination for Meta API
        
        Args:
            initial_response (dict): Initial API response with pagination info
            
        Returns:
            list: Combined data from all pages
        """
        # Check if response is valid
        if not isinstance(initial_response, dict) or "data" not in initial_response:
            return initial_response
            
        # Get initial data
        all_data = initial_response.get("data", [])
        
        # Check for pagination
        if "paging" in initial_response and "cursors" in initial_response["paging"]:
            next_cursor = initial_response["paging"].get("cursors", {}).get("after")
            
            # Get base URL and parameters from initial response paging URL
            if "next" in initial_response["paging"]:
                next_url = initial_response["paging"]["next"]
                
                # Extract URL and parameters
                base_url = next_url.split("?")[0]
                
                # Continue fetching data while we have a next cursor
                while next_cursor:
                    # Prepare parameters for next page
                    params = {
                        "access_token": self.access_token,
                        "after": next_cursor
                    }
                    
                    # Make request for next page
                    logger.info(f"Fetching next page with cursor: {next_cursor[:10]}...")
                    next_page = self._make_request(base_url, params)
                    
                    # Check for errors
                    if "error" in next_page or "status" in next_page and next_page["status"] == "error":
                        logger.error(f"Error in pagination: {next_page.get('message', '')}")
                        break
                        
                    # Add data to results
                    if "data" in next_page and next_page["data"]:
                        all_data.extend(next_page["data"])
                        
                    # Get next cursor
                    if "paging" in next_page and "cursors" in next_page["paging"]:
                        next_cursor = next_page["paging"].get("cursors", {}).get("after")
                    else:
                        next_cursor = None
        
        return all_data
    
    def get_campaigns(self):
        """
        Get all campaigns for the ad account
        
        Returns:
            list: Campaign data list
        """
        url = f"{self.base_url}/{self.ad_account_id}/campaigns"
        
        params = {
            'access_token': self.access_token,
            'fields': ','.join(self.standard_campaign_fields),
            'limit': 100  # Maximum allowed by API
        }
        
        response = self._make_request(url, params)
        
        # Handle pagination
        if 'data' in response:
            campaigns = response['data']
            
            # Get pagination cursor if available
            if 'paging' in response and 'cursors' in response['paging']:
                after_cursor = response['paging']['cursors'].get('after')
                
                while after_cursor:
                    # Add cursor to params
                    params['after'] = after_cursor
                    
                    # Make next request
                    next_response = self._make_request(url, params)
                    
                    if 'data' in next_response and next_response['data']:
                        campaigns.extend(next_response['data'])
                        
                        # Update cursor for next page
                        if 'paging' in next_response and 'cursors' in next_response['paging']:
                            after_cursor = next_response['paging']['cursors'].get('after')
                        else:
                            break
                    else:
                        break
            
            return campaigns
        
        # If data not in response
        return []
    
    def get_campaign_insights(self, date_range=None):
        """
        Get insights data for all campaigns
        
        Args:
            date_range (dict): Date range in format {'since': 'YYYY-MM-DD', 'until': 'YYYY-MM-DD'}
            
        Returns:
            list: List of campaign insights
        """
        # Set default date range if not provided
        if not date_range:
            today = datetime.now()
            start_date = today - timedelta(days=90)
            date_range = {
                'since': start_date.strftime('%Y-%m-%d'),
                'until': today.strftime('%Y-%m-%d')
            }
            
        url = f"{self.base_url}/{self.ad_account_id}/insights"
        
        params = {
            'access_token': self.access_token,
            'fields': ','.join(self.standard_insights_fields),
            'level': 'campaign',
            'time_range': json.dumps(date_range),
            'limit': 100  # Maximum allowed by API
        }
        
        all_insights = []
        
        try:
            response = self._make_request(url, params)
            
            if 'data' in response:
                all_insights.extend(response['data'])
                
                # Handle pagination for large datasets
                while 'paging' in response and 'next' in response['paging']:
                    next_url = response['paging']['next']
                    response = requests.get(next_url).json()
                    
                    if 'data' in response:
                        all_insights.extend(response['data'])
                    else:
                        break
            
            # Post-process insights for easier use
            for insight in all_insights:
                # Convert string values to appropriate types
                if 'impressions' in insight:
                    insight['impressions'] = int(insight.get('impressions', 0))
                if 'clicks' in insight:
                    insight['clicks'] = int(insight.get('clicks', 0))
                if 'spend' in insight:
                    insight['spend'] = float(insight.get('spend', 0))
                if 'ctr' in insight:
                    insight['ctr'] = float(insight.get('ctr', 0))
                if 'cpc' in insight:
                    insight['cpc'] = float(insight.get('cpc', 0)) if insight.get('cpc') else 0
                    
            return all_insights
            
        except Exception as e:
            logger.error(f"Error getting campaign insights: {e}")
            return []
        
    def get_adsets(self, campaign_id=None):
        """
        Get ad sets for the account or for a specific campaign
        
        Args:
            campaign_id (str, optional): Campaign ID to filter by
            
        Returns:
            list: Ad set data
        """
        # Determine base object for the request
        if campaign_id:
            url = f"{self.base_url}/{campaign_id}/adsets"
        else:
            url = f"{self.base_url}/{self.ad_account_id}/adsets"
        
        params = {
            'access_token': self.access_token,
            'fields': ','.join(self.standard_adset_fields),
            'limit': 100
        }
        
        response = self._make_request(url, params)
        
        # Handle pagination
        if 'data' in response:
            return self._handle_pagination(response)
        
        return []
    
    def get_ads(self, adset_id=None):
        """
        Get ads for the account or for a specific ad set
        
        Args:
            adset_id (str, optional): Ad set ID to filter by
            
        Returns:
            list: Ad data
        """
        # Determine base object for the request
        if adset_id:
            url = f"{self.base_url}/{adset_id}/ads"
        else:
            url = f"{self.base_url}/{self.ad_account_id}/ads"
        
        params = {
            'access_token': self.access_token,
            'fields': ','.join(self.standard_ad_fields),
            'limit': 100
        }
        
        response = self._make_request(url, params)
        
        # Handle pagination
        if 'data' in response:
            return self._handle_pagination(response)
        
        return []
    
    def get_ad_creatives(self, ad_id=None):
        """
        Get ad creatives for an ad or for the account
        
        Args:
            ad_id (str, optional): Ad ID to get creative for
            
        Returns:
            list: Creative data
        """
        # Determine base object for the request
        if ad_id:
            url = f"{self.base_url}/{ad_id}/adcreatives"
        else:
            url = f"{self.base_url}/{self.ad_account_id}/adcreatives"
        
        params = {
            'access_token': self.access_token,
            'fields': 'id,name,title,body,image_url,video_id,url_tags,object_story_spec',
            'limit': 100
        }
        
        response = self._make_request(url, params)
        
        # Handle pagination
        if 'data' in response:
            return self._handle_pagination(response)
        
        return []
    
    def get_campaign_metadata(self, campaign_id):
        """
        Get detailed metadata for a specific campaign
        
        Args:
            campaign_id (str): Campaign ID
            
        Returns:
            dict: Campaign metadata
        """
        url = f"{self.base_url}/{campaign_id}"
        
        params = {
            'access_token': self.access_token,
            'fields': ','.join(self.standard_campaign_fields)
        }
        
        response = self._make_request(url, params)
        return response

# Function to get meta data for backward compatibility
def get_meta_data(access_token, account_id, date_range=None):
    """
    Get comprehensive Meta data including campaigns, ad sets, ads, and insights
    
    Args:
        access_token (str): Meta API access token
        account_id (str): Ad account ID
        date_range (dict, optional): Date range for insights
        
    Returns:
        dict: Consolidated Meta data
    """
    # Initialize API
    if not account_id.startswith('act_'):
        account_id = f"act_{account_id}"
        
    api = EnhancedMetaAPI(access_token=access_token, ad_account_id=account_id)
    
    # Get data
    campaigns = api.get_campaigns()
    adsets = []
    ads = []
    creatives = []
    insights = []
    
    # Get insights with date range
    if campaigns:
        insights = api.get_campaign_insights(date_range=date_range)
        
        # Get ad sets, ads, and creatives for each campaign
        for campaign in campaigns:
            campaign_adsets = api.get_adsets(campaign_id=campaign['id'])
            adsets.extend(campaign_adsets)
            
            for adset in campaign_adsets:
                adset_ads = api.get_ads(adset_id=adset['id'])
                ads.extend(adset_ads)
                
                for ad in adset_ads:
                    ad_creatives = api.get_ad_creatives(ad_id=ad['id'])
                    creatives.extend(ad_creatives)
    
    # Return consolidated data
    return {
        "status": "success",
        "campaigns": campaigns,
        "adsets": adsets,
        "ads": ads,
        "creatives": creatives,
        "insights": insights,
        "counts": {
            "campaigns": len(campaigns),
            "adsets": len(adsets),
            "ads": len(ads),
            "creatives": len(creatives),
            "insights": len(insights)
        }
    }