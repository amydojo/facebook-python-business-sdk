"""
SMS notification functionality for the CAPI Command Center
"""

import os
from twilio.rest import Client

# Environment variables for Twilio
TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN")
TWILIO_PHONE_NUMBER = os.environ.get("TWILIO_PHONE_NUMBER")


def send_sms_notification(to_phone_number, message):
    """
    Send an SMS notification using Twilio
    
    Args:
        to_phone_number (str): The recipient's phone number in E.164 format
        message (str): The message content to send
        
    Returns:
        tuple: (success (bool), message (str))
    """
    # Check if Twilio credentials are available
    if not TWILIO_ACCOUNT_SID or not TWILIO_AUTH_TOKEN or not TWILIO_PHONE_NUMBER:
        return False, "Twilio credentials not configured"
    
    try:
        # Initialize Twilio client
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        
        # Send the SMS
        message = client.messages.create(
            body=message,
            from_=TWILIO_PHONE_NUMBER,
            to=to_phone_number
        )
        
        # Return success and SID
        return True, f"SMS sent successfully (SID: {message.sid})"
    
    except Exception as e:
        # Return error
        return False, f"Error sending SMS: {str(e)}"


def format_phone_for_twilio(phone_number):
    """
    Format a phone number for use with Twilio (E.164 format)
    
    Args:
        phone_number (str): The phone number to format
        
    Returns:
        str: The formatted phone number or None if invalid
    """
    if not phone_number:
        return None
        
    # Remove any non-numeric characters
    digits_only = ''.join(filter(str.isdigit, phone_number))
    
    # Check if we have a valid number of digits for a US number
    if len(digits_only) == 10:
        # Add US country code (+1)
        return f"+1{digits_only}"
    elif len(digits_only) == 11 and digits_only.startswith('1'):
        # Already has US country code
        return f"+{digits_only}"
    else:
        # Invalid format
        return None


def send_abandoned_lead_notification(lead_data, staff_phone=None):
    """
    Send notification for an abandoned lead
    
    Args:
        lead_data (dict): Information about the abandoned lead
        staff_phone (str): Optional override for notification recipient
        
    Returns:
        tuple: (success (bool), message (str))
    """
    # Extract relevant information
    name = lead_data.get('Name', 'Unknown')
    email = lead_data.get('Email', 'Not provided')
    phone = lead_data.get('Phone', 'Not provided')
    service = lead_data.get('Service', 'Unknown service')
    
    # Format the service if it's a list
    if isinstance(service, list):
        service = ', '.join(service)
    
    # Create message
    message = (
        f"⚠️ ABANDONED LEAD ALERT ⚠️\n\n"
        f"Name: {name}\n"
        f"Service: {service}\n"
        f"Contact: {phone}\n"
        f"Email: {email}\n\n"
        f"This lead started but did not complete the booking process. Follow up ASAP!"
    )
    
    # Determine recipient
    recipient = staff_phone if staff_phone else phone
    
    # Format phone for Twilio
    formatted_phone = format_phone_for_twilio(recipient)
    
    if not formatted_phone:
        return False, f"Invalid phone number format: {recipient}"
    
    # Send notification
    return send_sms_notification(formatted_phone, message)