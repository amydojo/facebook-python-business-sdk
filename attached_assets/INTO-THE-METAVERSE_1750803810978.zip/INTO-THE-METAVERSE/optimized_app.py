"""
Optimized MetaPulse Command Center
High-performance dashboard with intelligent caching and date-range awareness
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import logging
import time
from typing import Dict, List, Optional, Any, Tuple
import hashlib

# Page configuration MUST be first
st.set_page_config(
    page_title="MetaPulse Command Center",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="collapsed"
)

from reliable_data_connector import ReliableDataConnector

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OptimizedDataLoader:
    """High-performance data loader with smart caching"""
    
    def __init__(self):
        # Initialize performance tracking
        if 'perf_metrics' not in st.session_state:
            st.session_state.perf_metrics = {
                'load_times': [],
                'cache_hits': 0,
                'api_calls': 0,
                'last_date_range': None
            }
    
    @st.cache_data(ttl=180, max_entries=20)  # 3-minute cache
    def load_transactions_cached(_self, start_date: str, end_date: str) -> Dict:
        """Cached transaction loading with date-range key"""
        start_time = time.time()
        
        connector = ReliableDataConnector()
        result = connector.load_transaction_data(start_date, end_date)
        
        load_time = time.time() - start_time
        st.session_state.perf_metrics['load_times'].append(load_time)
        st.session_state.perf_metrics['api_calls'] += 1
        
        logger.info(f"Loaded transactions in {load_time:.2f}s for {start_date} to {end_date}")
        return result
    
    @st.cache_data(ttl=180, max_entries=20)  # 3-minute cache
    def load_leads_cached(_self, start_date: str, end_date: str) -> Dict:
        """Cached lead loading with date-range key"""
        start_time = time.time()
        
        connector = ReliableDataConnector()
        result = connector.load_lead_data_optimized(start_date, end_date)
        
        load_time = time.time() - start_time
        st.session_state.perf_metrics['load_times'].append(load_time)
        st.session_state.perf_metrics['api_calls'] += 1
        
        logger.info(f"Loaded leads in {load_time:.2f}s for {start_date} to {end_date}")
        return result
    
    def smart_date_handler(self, start_date, end_date) -> Tuple[str, str]:
        """Handle date range changes efficiently"""
        start_str = start_date.strftime('%Y-%m-%d')
        end_str = end_date.strftime('%Y-%m-%d')
        
        current_range = (start_str, end_str)
        last_range = st.session_state.perf_metrics.get('last_date_range')
        
        if last_range != current_range:
            st.session_state.perf_metrics['last_date_range'] = current_range
            logger.info(f"Date range changed: {start_str} to {end_str}")
        else:
            st.session_state.perf_metrics['cache_hits'] += 1
        
        return start_str, end_str
    
    def get_performance_summary(self) -> str:
        """Performance metrics summary"""
        metrics = st.session_state.perf_metrics
        avg_time = sum(metrics['load_times']) / len(metrics['load_times']) if metrics['load_times'] else 0
        cache_ratio = metrics['cache_hits'] / (metrics['api_calls'] + metrics['cache_hits']) if (metrics['api_calls'] + metrics['cache_hits']) > 0 else 0
        
        return f"Avg Load: {avg_time:.1f}s | Cache Hit: {cache_ratio:.1%} | API Calls: {metrics['api_calls']}"

def apply_performance_styling():
    """Optimized styling for fast rendering"""
    st.markdown("""
    <style>
    .stApp {
        background: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    }
    
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 16px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
        box-shadow: 0 8px 32px rgba(102, 126, 234, 0.3);
    }
    
    .metric-container {
        background: white;
        padding: 1.5rem;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        border: 1px solid #e2e8f0;
        margin: 0.5rem 0;
    }
    
    .performance-badge {
        background: #10b981;
        color: white;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.875rem;
        display: inline-block;
    }
    
    .date-control {
        background: white;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1rem;
    }
    
    /* Hide Streamlit elements for performance */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    .stDeployButton {display: none;}
    </style>
    """, unsafe_allow_html=True)

def create_optimized_metrics(transactions_data: Dict, leads_data: Dict) -> None:
    """Display key metrics with minimal processing"""
    col1, col2, col3, col4 = st.columns(4)
    
    # Process data efficiently
    total_revenue = 0
    transaction_count = 0
    if transactions_data.get('success') and transactions_data.get('transactions'):
        transactions = transactions_data['transactions']
        total_revenue = sum(t.get('amount', 0) for t in transactions)
        transaction_count = len(transactions)
    
    total_leads = 0
    if leads_data.get('success'):
        total_leads = leads_data.get('total_leads', 0)
    
    # Calculate derived metrics
    avg_transaction = total_revenue / transaction_count if transaction_count > 0 else 0
    conversion_rate = (transaction_count / total_leads * 100) if total_leads > 0 else 0
    
    with col1:
        st.markdown(f"""
        <div class="metric-container">
            <h3 style="margin:0; color:#1e293b;">${total_revenue:,.0f}</h3>
            <p style="margin:0; color:#64748b;">Total Revenue</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="metric-container">
            <h3 style="margin:0; color:#1e293b;">{total_leads}</h3>
            <p style="margin:0; color:#64748b;">Total Leads</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="metric-container">
            <h3 style="margin:0; color:#1e293b;">${avg_transaction:,.0f}</h3>
            <p style="margin:0; color:#64748b;">Avg Transaction</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown(f"""
        <div class="metric-container">
            <h3 style="margin:0; color:#1e293b;">{conversion_rate:.1f}%</h3>
            <p style="margin:0; color:#64748b;">Conversion Rate</p>
        </div>
        """, unsafe_allow_html=True)

def create_performance_chart(transactions_data: Dict) -> go.Figure:
    """Lightweight performance visualization"""
    fig = go.Figure()
    
    if transactions_data.get('success') and transactions_data.get('transactions'):
        transactions = transactions_data['transactions']
        
        # Group by date efficiently
        daily_revenue = {}
        for transaction in transactions:
            date_str = transaction.get('date', '')[:10]  # Get YYYY-MM-DD
            if date_str:
                daily_revenue[date_str] = daily_revenue.get(date_str, 0) + transaction.get('amount', 0)
        
        if daily_revenue:
            dates = sorted(daily_revenue.keys())
            revenues = [daily_revenue[date] for date in dates]
            
            fig.add_trace(go.Scatter(
                x=dates,
                y=revenues,
                mode='lines+markers',
                name='Daily Revenue',
                line=dict(color='#667eea', width=3),
                marker=dict(size=8, color='#667eea')
            ))
    
    fig.update_layout(
        title="Revenue Performance",
        xaxis_title="Date",
        yaxis_title="Revenue ($)",
        template="plotly_white",
        height=400,
        margin=dict(l=0, r=0, t=40, b=0)
    )
    
    return fig

def main():
    """Optimized main application"""
    apply_performance_styling()
    
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>⚡ MetaPulse Command Center</h1>
        <p>High-Performance Meta Lead Analytics</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize optimized loader
    loader = OptimizedDataLoader()
    
    # Date range controls with session state
    st.markdown('<div class="date-control">', unsafe_allow_html=True)
    col1, col2, col3 = st.columns([2, 2, 3])
    
    with col1:
        start_date = st.date_input(
            "Start Date",
            value=datetime.now() - timedelta(days=30),
            key="opt_start_date"
        )
    
    with col2:
        end_date = st.date_input(
            "End Date", 
            value=datetime.now(),
            key="opt_end_date"
        )
    
    with col3:
        perf_summary = loader.get_performance_summary()
        st.markdown(f'<div class="performance-badge">{perf_summary}</div>', unsafe_allow_html=True)
    
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Smart date handling
    start_str, end_str = loader.smart_date_handler(start_date, end_date)
    
    # Load data with progress indicator
    load_start = time.time()
    
    with st.spinner("Loading optimized data..."):
        # Parallel data loading using cached functions
        transactions_data = loader.load_transactions_cached(start_str, end_str)
        leads_data = loader.load_leads_cached(start_str, end_str)
    
    load_time = time.time() - load_start
    
    # Display load time
    if load_time < 2:
        st.success(f"Data loaded in {load_time:.1f}s")
    elif load_time < 5:
        st.warning(f"Data loaded in {load_time:.1f}s")
    else:
        st.error(f"Slow load: {load_time:.1f}s - check connection")
    
    # Display metrics
    create_optimized_metrics(transactions_data, leads_data)
    
    # Performance chart
    chart_fig = create_performance_chart(transactions_data)
    st.plotly_chart(chart_fig, use_container_width=True)
    
    # Data source status
    st.subheader("Data Sources")
    col1, col2 = st.columns(2)
    
    with col1:
        if transactions_data.get('success'):
            count = len(transactions_data.get('transactions', []))
            st.success(f"Transactions: {count} records loaded")
        else:
            st.error("Transactions: Failed to load")
    
    with col2:
        if leads_data.get('success'):
            count = leads_data.get('total_leads', 0)
            st.success(f"Leads: {count} records loaded") 
        else:
            st.error("Leads: Failed to load")
    
    # Clear cache button for testing
    if st.button("Clear Cache", help="Clear cache to force fresh data load"):
        st.cache_data.clear()
        st.session_state.perf_metrics = {
            'load_times': [],
            'cache_hits': 0,
            'api_calls': 0,
            'last_date_range': None
        }
        st.success("Cache cleared - next load will fetch fresh data")
        st.rerun()

if __name__ == "__main__":
    main()