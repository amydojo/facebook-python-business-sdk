"""
Data Manager for Ad Command Center
Handles loading, caching, and retrieving data from multiple sources
"""
import os
import pandas as pd
import streamlit as st
from datetime import datetime, timedelta
from pyairtable import Api
import time

# Import database module
import database as db

class DataManager:
    """
    Data manager class to handle loading, storing, and retrieving data
    with database caching for faster performance
    """
    
    def __init__(self):
        """Initialize the data manager"""
        self.airtable_api_key = os.environ.get("AIRTABLE_API_KEY", "")
        self.base_id = "appri2CgCoIiuZWq3"
        self.leads_table_name = "Leads"
        self.transactions_table_name = "Transactions"
        self.meta_access_token = os.environ.get("META_ACCESS_TOKEN", "")
        self.meta_ad_account_id = os.environ.get("META_AD_ACCOUNT_ID", "")
        self.pixel_id = os.environ.get("META_PIXEL_ID", "")
        
        # Performance tracking
        self.loading_time = 0
        self.cache_hit_count = 0
        self.api_request_count = 0
    
    def load_all_data(self, force_refresh=False):
        """
        Load all data from sources or database cache
        
        Args:
            force_refresh (bool): Force reload from API sources
            
        Returns:
            bool: Success status
        """
        start_time = time.time()
        
        # Load lead data
        leads_df = self.load_leads_data(force_refresh=force_refresh)
        
        # Load transaction data
        transactions_df = self.load_transactions_data(force_refresh=force_refresh)
        
        # Load Meta campaign data
        campaigns, insights = self.load_meta_campaign_data(force_refresh=force_refresh)
        
        # Store in session state
        st.session_state.leads_df = leads_df
        st.session_state.transactions_df = transactions_df
        st.session_state.campaigns = campaigns
        st.session_state.campaign_insights = insights
        
        # For backward compatibility
        if campaigns:
            st.session_state.campaign_data = campaigns
        
        # Convert insights to DataFrame
        try:
            if insights:
                insights_df = pd.DataFrame(insights)
                st.session_state.campaign_insights_df = insights_df
                st.session_state.insights_df = insights_df
                
                # For backward compatibility, also store as ad_insights
                st.session_state.ad_insights = insights
                st.session_state.ad_insights_df = insights_df
            else:
                st.session_state.campaign_insights_df = pd.DataFrame()
                st.session_state.insights_df = pd.DataFrame()
                st.session_state.ad_insights = []
                st.session_state.ad_insights_df = pd.DataFrame()
        except Exception as e:
            print(f"Error converting insights to DataFrame: {e}")
            st.session_state.campaign_insights_df = pd.DataFrame()
            st.session_state.insights_df = pd.DataFrame()
        
        # Track loading time
        self.loading_time = time.time() - start_time
        st.session_state.loading_time = self.loading_time
        st.session_state.data_loaded = True
        
        # Calculate summary metrics from campaign data
        date_range = {
            'since': (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d'),
            'until': datetime.now().strftime('%Y-%m-%d')
        }
        
        st.session_state.meta_summary = {
            "campaign_count": len(campaigns),
            "active_campaign_count": len([c for c in campaigns if c.get("status") == "ACTIVE"]),
            "date_range": date_range,
            "spend": sum(float(insight.get("spend", 0)) for insight in insights),
            "impressions": sum(int(insight.get("impressions", 0)) for insight in insights),
            "clicks": sum(int(insight.get("clicks", 0)) for insight in insights)
        }
        
        print(f"Data loading completed in {self.loading_time:.2f} seconds")
        print(f"Cache hits: {self.cache_hit_count}, API requests: {self.api_request_count}")
        
        return True
    
    def load_leads_data(self, force_refresh=False):
        """
        Load leads data from Airtable or database cache
        
        Args:
            force_refresh (bool): Force reload from Airtable
            
        Returns:
            pd.DataFrame: DataFrame with leads data
        """
        # Check if we should use cached data
        if not force_refresh and not db.should_refresh_data('leads', max_age_minutes=60):
            print("Using cached leads data from database")
            self.cache_hit_count += 1
            leads_df = db.get_leads(filters={
                'brand': 'Smooth M.D.'
            })
            
            if not leads_df.empty:
                # Ensure critical columns
                if 'Date' not in leads_df.columns and 'Inbound' in leads_df.columns:
                    leads_df['Date'] = pd.to_datetime(leads_df['Inbound'])
                
                print(f"Loaded {len(leads_df)} leads from database cache")
                return leads_df
        
        # Otherwise load from Airtable
        print("Loading leads data from Airtable...")
        self.api_request_count += 1
        
        try:
            api = Api(self.airtable_api_key)
            table = api.table(self.base_id, self.leads_table_name)
            
            # Get all records from the table
            all_records = table.all()
            
            # Convert to DataFrame
            leads_data = []
            for record in all_records:
                record_data = record['fields']
                record_data['id'] = record['id']
                leads_data.append(record_data)
            
            leads_df = pd.DataFrame(leads_data)
            
            # Filter to only Smooth M.D. brand and Meta sources
            if 'Brand' in leads_df.columns:
                print(f"Found brand column: Brand")
                print(f"Unique brand values: {leads_df['Brand'].unique()}")
                leads_df = leads_df[leads_df['Brand'] == 'Smooth M.D.']
                print(f"After Brand filter: {len(leads_df)} records")
            
            # Filter to only Meta sources (Facebook/Instagram)
            if 'Contact Source' in leads_df.columns:
                print(f"Found source column: Contact Source")
                print(f"Unique source values: {leads_df['Contact Source'].unique()}")
                
                # Apply Meta source filter
                meta_sources = ['Facebook AD', 'Instagram AD', 'Facebook AD Sign Up', 'Facebook']
                leads_df = leads_df[leads_df['Contact Source'].isin(meta_sources)]
                print(f"After Source filter: {len(leads_df)} Meta records")
            
            # Ensure Date column exists
            if 'Date' not in leads_df.columns and 'Inbound' in leads_df.columns:
                print("Using Inbound as Date column")
                leads_df['Date'] = pd.to_datetime(leads_df['Inbound'])
            
            # Store in database for future use
            db.store_leads(leads_df)
            
            return leads_df
            
        except Exception as e:
            print(f"Error loading leads data from Airtable: {e}")
            # Try to get from database as fallback
            leads_df = db.get_leads(filters={
                'brand': 'Smooth M.D.'
            })
            return leads_df if not leads_df.empty else pd.DataFrame()
    
    def load_transactions_data(self, force_refresh=False):
        """
        Load transactions data from Airtable or database cache
        
        Args:
            force_refresh (bool): Force reload from Airtable
            
        Returns:
            pd.DataFrame: DataFrame with transactions data
        """
        # Check if we should use cached data
        if not force_refresh and not db.should_refresh_data('transactions', max_age_minutes=60):
            print("Using cached transactions data from database")
            self.cache_hit_count += 1
            transactions_df = db.get_transactions()
            
            if not transactions_df.empty:
                print(f"Loaded {len(transactions_df)} transactions from database cache")
                return transactions_df
        
        # Otherwise load from Airtable
        print("Loading transactions data from Airtable...")
        self.api_request_count += 1
        
        try:
            api = Api(self.airtable_api_key)
            table = api.table(self.base_id, self.transactions_table_name)
            
            # Get all records from the table
            all_records = table.all()
            
            # Convert to DataFrame
            transactions_data = []
            for record in all_records:
                record_data = record['fields']
                record_data['id'] = record['id']
                transactions_data.append(record_data)
            
            transactions_df = pd.DataFrame(transactions_data)
            print(f"Loaded {len(transactions_df)} records from Transactions")
            
            # Store in database for future use
            db.store_transactions(transactions_df)
            
            return transactions_df
            
        except Exception as e:
            print(f"Error loading transactions data from Airtable: {e}")
            # Try to get from database as fallback
            transactions_df = db.get_transactions()
            return transactions_df if not transactions_df.empty else pd.DataFrame()
    
    def load_meta_campaign_data(self, force_refresh=False, date_range=None):
        """
        Load Meta campaign data from API or database cache
        
        Args:
            force_refresh (bool): Force reload from Meta API
            date_range (dict): Date range for insights
            
        Returns:
            tuple: (campaigns, insights)
        """
        # Set default date range if not provided
        if not date_range:
            date_range = {
                'since': (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d'),
                'until': datetime.now().strftime('%Y-%m-%d')
            }
        
        # Check if we should use cached data
        if not force_refresh and not db.should_refresh_data('meta_campaigns', max_age_minutes=120):
            print("Using cached Meta campaign data from database")
            self.cache_hit_count += 1
            
            campaigns_df, insights_df = db.get_campaign_data(
                date_from=date_range['since'],
                date_to=date_range['until']
            )
            
            if not campaigns_df.empty:
                campaigns = campaigns_df.to_dict('records')
                insights = insights_df.to_dict('records') if not insights_df.empty else []
                
                print(f"Loaded {len(campaigns)} campaigns and {len(insights)} insights from database cache")
                return campaigns, insights
        
        # Otherwise load from Meta API
        print("Loading Meta campaign data from API...")
        self.api_request_count += 1
        
        try:
            # Import the enhanced API module
            from enhanced_meta_api import EnhancedMetaAPI
            
            # Initialize Meta API with account ID
            ad_account_id = self.meta_ad_account_id
            if not ad_account_id.startswith('act_'):
                ad_account_id = f"act_{ad_account_id}"
            
            print(f"Initializing Meta API with account ID: {ad_account_id}")
            meta_api = EnhancedMetaAPI(
                access_token=self.meta_access_token,
                ad_account_id=ad_account_id
            )
            
            print("Fetching real campaign data directly from Meta Graph API...")
            
            # Get campaigns
            campaigns = meta_api.get_campaigns()
            if campaigns and len(campaigns) > 0:
                print(f"Successfully retrieved {len(campaigns)} real campaigns from Meta API")
            else:
                print("No campaigns found in Meta API response")
                campaigns = []
            
            # Get campaign insights
            insights = meta_api.get_campaign_insights(date_range=date_range)
            
            # Store in database for future use
            db.store_campaign_data(campaigns, insights)
            
            return campaigns, insights
            
        except Exception as e:
            print(f"Error loading Meta campaign data: {e}")
            # Try to get from database as fallback
            campaigns_df, insights_df = db.get_campaign_data(
                date_from=date_range['since'],
                date_to=date_range['until']
            )
            
            campaigns = campaigns_df.to_dict('records') if not campaigns_df.empty else []
            insights = insights_df.to_dict('records') if not insights_df.empty else []
            
            return campaigns, insights