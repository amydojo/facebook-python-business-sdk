#!/usr/bin/env python3
"""Quick diagnostic script to test lead matching improvements"""

import sys
sys.path.append('.')

from unified_production_connector import unified_connector
from advanced_lead_matcher import advanced_lead_matcher
from datetime import datetime, timedelta

def main():
    # Clear cache
    if hasattr(unified_connector, 'cache'):
        unified_connector.cache.clear()
    
    # Load last 30 days of data
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    
    print(f"Testing with date range: {start_date} to {end_date}")
    
    # Load transactions
    print("\n=== TRANSACTION ANALYSIS ===")
    tx_result = unified_connector.load_transactions(start_date, end_date)
    if tx_result.success:
        transactions = tx_result.data or []
        print(f"Loaded {len(transactions)} transactions")
        
        # Analyze transaction identifiers
        valid_amounts = 0
        with_email = 0
        with_phone = 0
        with_patient_id = 0
        amounts = []
        
        for tx in transactions[:100]:  # Sample first 100
            fields = tx.get('fields', {})
            amount = advanced_lead_matcher._extract_transaction_amount(fields)
            email = advanced_lead_matcher._extract_email(fields)
            phone = advanced_lead_matcher._extract_phone(fields)
            patient_id = advanced_lead_matcher._extract_field_value(fields, ['Patient', 'Patient ID', 'Lead ID', 'ID'])
            
            if amount > 0:
                valid_amounts += 1
                amounts.append(amount)
            if email:
                with_email += 1
            if phone:
                with_phone += 1
            if patient_id:
                with_patient_id += 1
        
        print(f"Transaction field coverage (first 100):")
        print(f"  Valid amounts: {valid_amounts} ({valid_amounts/100*100:.1f}%)")
        print(f"  With email: {with_email} ({with_email/100*100:.1f}%)")
        print(f"  With phone: {with_phone} ({with_phone/100*100:.1f}%)")
        print(f"  With patient ID: {with_patient_id} ({with_patient_id/100*100:.1f}%)")
        if amounts:
            print(f"  Amount range: ${min(amounts):.2f} - ${max(amounts):,.2f}")
    else:
        print(f"Failed to load transactions: {tx_result.error}")
        return
    
    # Load leads
    print("\n=== LEAD ANALYSIS ===")
    lead_result = unified_connector.load_leads(start_date, end_date)
    if lead_result.success:
        leads = lead_result.data or []
        print(f"Loaded {len(leads)} leads")
        
        # Identify Meta leads
        meta_leads = advanced_lead_matcher.identify_meta_leads(leads)
        print(f"Identified {len(meta_leads)} Meta leads")
        
        # Analyze Meta lead identifiers
        smooth_leads = 0
        with_email = 0
        with_phone = 0
        both_identifiers = 0
        
        for lead in meta_leads[:100]:  # Sample first 100
            brand = lead.get('brand', '')
            email = lead.get('email', '')
            phone = lead.get('phone', '')
            
            if advanced_lead_matcher._is_smooth_brand(brand):
                smooth_leads += 1
            if email:
                with_email += 1
            if phone:
                with_phone += 1
            if email and phone:
                both_identifiers += 1
        
        total_sample = min(len(meta_leads), 100)
        print(f"Meta lead field coverage (first {total_sample}):")
        print(f"  Smooth MD leads: {smooth_leads} ({smooth_leads/total_sample*100:.1f}%)")
        print(f"  With email: {with_email} ({with_email/total_sample*100:.1f}%)")
        print(f"  With phone: {with_phone} ({with_phone/total_sample*100:.1f}%)")
        print(f"  With both: {both_identifiers} ({both_identifiers/total_sample*100:.1f}%)")
    else:
        print(f"Failed to load leads: {lead_result.error}")
        return
    
    # Perform matching
    print("\n=== MATCHING ANALYSIS ===")
    matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
        meta_leads, transactions
    )
    
    matched_count = len([l for l in matched_leads if l['matched_transactions']])
    total_revenue = matching_stats.get('total_matched_revenue', 0)
    attribution_rate = matching_stats.get('attribution_rate', 0)
    
    print(f"Matching results:")
    print(f"  Matched leads: {matched_count}")
    print(f"  Total revenue: ${total_revenue:,.2f}")
    print(f"  Attribution rate: {attribution_rate:.1f}%")
    
    # Match method breakdown
    methods = matching_stats.get('match_methods', {})
    print(f"  Match methods:")
    for method, count in methods.items():
        print(f"    {method}: {count}")
    
    # Calculate corrected metrics
    print("\n=== CORRECTED METRICS ===")
    estimated_spend = len(meta_leads) * 45
    roas = total_revenue / estimated_spend if estimated_spend > 0 else 0
    cost_per_conversion = estimated_spend / matched_count if matched_count > 0 else 0
    
    print(f"Performance metrics:")
    print(f"  Meta leads: {len(meta_leads)}")
    print(f"  Matched leads: {matched_count}")
    print(f"  Revenue: ${total_revenue:,.2f}")
    print(f"  Estimated spend: ${estimated_spend:,.2f}")
    print(f"  ROAS: {roas:.2f}x")
    print(f"  Cost per conversion: ${cost_per_conversion:,.2f}")
    print(f"  Attribution rate: {attribution_rate:.1f}%")
    
    # Validation
    print("\n=== VALIDATION ===")
    if matched_count > 4:
        print(f"✓ Improved matching: {matched_count} vs previous 4 leads")
    else:
        print(f"⚠ Still low matching rate: {matched_count} leads")
    
    if cost_per_conversion < 5000:
        print(f"✓ Reasonable cost per conversion: ${cost_per_conversion:.2f}")
    else:
        print(f"⚠ High cost per conversion: ${cost_per_conversion:.2f}")
    
    if 0.5 <= attribution_rate <= 10:
        print(f"✓ Attribution rate in expected range: {attribution_rate:.1f}%")
    else:
        print(f"⚠ Attribution rate outside expected range: {attribution_rate:.1f}%")

if __name__ == "__main__":
    main()