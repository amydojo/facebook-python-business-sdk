
"""
Minimalist Airtable Tester
Ultra-simple testing tool to verify Airtable connection
"""
import streamlit as st
import pandas as pd
from pyairtable import Api
import time
import json
import os

# Configure Streamlit
st.set_page_config(page_title="Simplified Airtable Test", layout="wide")
st.title("🔍 Simple Airtable Connection Tester")
st.write("A no-frills tool to test and validate your Airtable connection")

# Sidebar for credentials
with st.sidebar:
    st.header("Connection Settings")
    
    # API Key input
    api_key = st.text_input("Airtable API Key", 
                          type="password",
                          help="Your Airtable Personal Access Token (pat)")
    
    # Base and table info
    base_id = st.text_input("Base ID", 
                         value="appri2CgCoIiuZWq3",
                         help="Your base ID from Airtable URL")
    
    table_name = st.text_input("Table Name", 
                            value="Leads",
                            help="Exact table name (case-sensitive)")
    
    # Save to session state
    if st.button("Save to Session"):
        st.session_state.api_key = api_key
        st.session_state.base_id = base_id
        st.session_state.leads_table_name = table_name
        st.success("✅ Settings saved to session!")
    
    # Load from credentials file if it exists
    if os.path.exists('.credentials.json'):
        if st.button("Load from File"):
            try:
                with open('.credentials.json', 'r') as f:
                    creds = json.load(f)
                    if 'api_key' in creds:
                        st.session_state.api_key = creds['api_key']
                        st.session_state.base_id = creds.get('base_id', base_id)
                        st.session_state.leads_table_name = creds.get('leads_table_name', table_name)
                        st.success("✅ Credentials loaded!")
            except Exception as e:
                st.error(f"Failed to load credentials: {str(e)}")

# Main content
tab1, tab2 = st.tabs(["Connection Test", "Data Viewer"])

with tab1:
    st.header("Basic Connection Test")
    
    if st.button("Test Connection"):
        # Get credentials (try session state first, then inputs)
        test_api_key = st.session_state.get('api_key', api_key)
        test_base_id = st.session_state.get('base_id', base_id)
        test_table_name = st.session_state.get('leads_table_name', table_name)
        
        if not test_api_key:
            st.error("❌ No API key provided!")
        else:
            try:
                # Show verbose connection attempt
                st.write("Initializing Airtable API...")
                api = Api(test_api_key)
                
                st.write(f"Connecting to base: {test_base_id}")
                st.write(f"Accessing table: {test_table_name}")
                
                # Get the table
                table = api.table(test_base_id, test_table_name)
                
                # Try to fetch a single record
                st.write("Fetching a sample record...")
                start_time = time.time()
                records = table.all(max_records=1)
                elapsed = time.time() - start_time
                
                if records:
                    st.success(f"✅ Connection successful! ({elapsed:.2f}s)")
                    st.write("Fields in first record:", list(records[0]['fields'].keys()))
                    
                    # Show record details
                    with st.expander("Sample Record"):
                        st.json(records[0])
                        
                    # Save working credentials
                    if st.button("Save Working Credentials"):
                        try:
                            with open('.credentials.json', 'w') as f:
                                json.dump({
                                    'api_key': test_api_key,
                                    'base_id': test_base_id,
                                    'leads_table_name': test_table_name
                                }, f)
                            st.success("✅ Credentials saved successfully!")
                        except Exception as e:
                            st.error(f"Failed to save credentials: {str(e)}")
                else:
                    st.warning("Connection successful but no records found")
                    
            except Exception as e:
                st.error(f"❌ Connection failed: {str(e)}")
                
                # Common error handling
                error_str = str(e).lower()
                if "401" in error_str:
                    st.info("🔑 Authentication Error: Your API key is invalid or expired.")
                    st.info("Make sure you're using a valid Personal Access Token (PAT).")
                elif "404" in error_str:
                    st.info("🔍 Not Found Error: The base ID or table name is incorrect.")
                    st.info("Verify the base ID from your Airtable URL and check table name spelling.")
                elif "rate" in error_str or "429" in error_str:
                    st.info("⏱️ Rate Limit Error: You've hit the Airtable API rate limit.")

with tab2:
    st.header("Data Viewer")
    
    max_records = st.slider("Max Records", min_value=1, max_value=100, value=10)
    
    if st.button("Fetch Records"):
        # Get credentials
        view_api_key = st.session_state.get('api_key', api_key)
        view_base_id = st.session_state.get('base_id', base_id)
        view_table_name = st.session_state.get('leads_table_name', table_name)
        
        if not view_api_key:
            st.error("❌ No API key provided!")
        else:
            try:
                # Connect to Airtable
                api = Api(view_api_key)
                table = api.table(view_base_id, view_table_name)
                
                # Fetch records with progress
                with st.spinner(f"Fetching up to {max_records} records..."):
                    records = table.all(max_records=max_records)
                
                # Convert to DataFrame for easy viewing
                if records:
                    # Extract fields from records
                    data = [record['fields'] for record in records]
                    df = pd.DataFrame(data)
                    
                    st.success(f"✅ Successfully fetched {len(records)} records!")
                    st.dataframe(df)
                    
                    # Column info
                    st.write("Columns available:", list(df.columns))
                else:
                    st.warning("No records found in table")
                    
            except Exception as e:
                st.error(f"❌ Failed to fetch records: {str(e)}")

# Footer with troubleshooting tips
st.markdown("---")
with st.expander("Troubleshooting Tips"):
    st.markdown("""
    ### Common Issues:
    
    1. **Authentication Errors (401)**
       - Verify your API key is correct
       - Ensure your key has access to this base
       - For PATs, verify you have the correct permissions
    
    2. **Not Found Errors (404)**
       - Double-check your base ID from the Airtable URL
       - Verify table name is spelled exactly as in Airtable (case-sensitive)
    
    3. **Rate Limiting (429)**
       - Airtable limits to 5 requests/second per base
       - Add delays between requests when making multiple calls
    """)
