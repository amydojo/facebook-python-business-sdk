"""
Dashboard render functions for the CAPI Command Center
"""
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
from design_system import (styled_header, card, status_indicator,
                           section_divider, badge, icon_text, COLORS,
                           TYPOGRAPHY, SPACING, BORDER_RADIUS)
import ai_insights


def render_dashboard_tab(leads_df, transactions_df):
    """Render the dashboard tab content - Overview"""
    styled_header("Command Center Dashboard")

    # Initialize all metrics with default values
    leads_count = 0
    booked_count = 0
    converted_count = 0
    booking_rate = 0
    conversion_rate = 0
    meta_lead_count = 0
    meta_percentage = 0
    total_revenue = 0
    avg_transaction = 0

    # Process Leads Data if available
    if leads_df is not None and not leads_df.empty:
        leads_count = len(leads_df)
        print(leads_count)
        print(leads_df)

        # Add necessary columns if missing (to prevent errors)
        required_cols = ["Source", "Status", "Date", "Contact Source", "Overall Status", "Lead Source"]
        for col in required_cols:
            if col not in leads_df.columns:
                leads_df[col] = None

        # Calculate booking and conversion metrics safely
        try:
            booked_count = sum(1 for _, row in leads_df.iterrows()
                               if is_booked(row))
            booking_rate = (booked_count / leads_count *
                            100) if leads_count > 0 else 0
        except Exception:
            # Use zeros for missing data
            booked_count = 0
            booking_rate = 0

        try:
            converted_count = sum(1 for _, row in leads_df.iterrows()
                                  if is_converted(row))
            conversion_rate = (converted_count / leads_count *
                               100) if leads_count > 0 else 0
        except Exception:
            # Use zeros for missing data
            converted_count = 0
            conversion_rate = 0

        # Calculate Meta leads - using all possible source columns
        try:
            print("Leads DataFrame Columns:", leads_df.columns)
            meta_lead_count = 0
            
            # First try Contact Source column (primary)
            if "Contact Source" in leads_df.columns:
                valid_sources = leads_df["Contact Source"].dropna()
                if not valid_sources.empty:
                    meta_leads = leads_df[
                        leads_df['Contact Source'].str.contains(
                            'facebook|instagram|meta|fb ads', case=False, na=False)]
                    meta_lead_count = len(meta_leads)
            
            # Try Source column if no meta leads found
            if meta_lead_count == 0 and "Source" in leads_df.columns:
                valid_sources = leads_df["Source"].dropna()
                if not valid_sources.empty:
                    meta_leads = leads_df[leads_df['Source'].str.contains(
                        'facebook|instagram|meta|fb ads', case=False, na=False)]
                    meta_lead_count = len(meta_leads)
            
            # Try Other Source columns if still no meta leads found
            if meta_lead_count == 0 and "Lead Source" in leads_df.columns:
                valid_sources = leads_df["Lead Source"].dropna()
                if not valid_sources.empty:
                    meta_leads = leads_df[leads_df['Lead Source'].str.contains(
                        'facebook|instagram|meta|fb ads', case=False, na=False)]
                    meta_lead_count = len(meta_leads)
                    
            # Calculate percentage
            meta_percentage = (meta_lead_count / leads_count * 100) if leads_count > 0 else 0
                
        except Exception as e:
            # Use zeros for missing data
            print(f"Error calculating meta leads: {e}")
            meta_lead_count = 0
            meta_percentage = 0

    # Process Transactions Data if available
    if transactions_df is not None and not transactions_df.empty:
        # Add Revenue column if missing
        if 'Revenue' not in transactions_df.columns:
            transactions_df['Revenue'] = 0

        try:
            # Process revenue data safely
            transactions_df['Revenue'] = pd.to_numeric(
                transactions_df['Revenue'], errors='coerce')
            transactions_df['Revenue'] = transactions_df['Revenue'].fillna(0)

            total_revenue = transactions_df['Revenue'].sum()
            avg_transaction = transactions_df['Revenue'].mean() if len(
                transactions_df) > 0 else 0
        except Exception:
            # Use zeros for missing data
            total_revenue = 0
            avg_transaction = 0

    # Display metrics in cards with elegant styling
    metrics_cols = st.columns(4)

    with metrics_cols[0]:

        def metric_1_content():
            st.metric("Total Leads", f"{leads_count:,}")
            st.caption(f"From all marketing channels")

        card(metric_1_content, title="Lead Generation")

    with metrics_cols[1]:

        def metric_2_content():
            st.metric("Booking Rate",
                      f"{booking_rate:.1f}%",
                      delta=f"{booked_count} Booked")
            st.caption("Leads that booked a consultation")

        card(metric_2_content, title="Lead Qualification")

    with metrics_cols[2]:

        def metric_3_content():
            st.metric("Conversion Rate",
                      f"{conversion_rate:.1f}%",
                      delta=f"{converted_count} Converted")
            st.caption("Leads converted to customers")

        card(metric_3_content, title="Revenue Conversion")

    with metrics_cols[3]:

        def metric_4_content():
            st.metric(
                "Meta Leads",
                f"{meta_lead_count:,}",
                delta=f"{meta_percentage:.1f}%" if leads_count > 0 else "0%")
            st.caption("From Facebook/Instagram Ads")

        card(metric_4_content, title="Meta Attribution")

    # Visualizations
    section_divider("Performance Visualizations")

    chart_cols = st.columns(2)

    with chart_cols[0]:

        def funnel_chart_content():
            # Create funnel data
            funnel_data = {
                "Total Leads": leads_count,
                "Qualified": booked_count,
                "Converted": converted_count
            }

            # Create funnel chart
            fig = go.Figure(
                go.Funnel(
                    y=list(funnel_data.keys()),
                    x=list(funnel_data.values()),
                    textinfo="value+percent initial",
                    marker={
                        "color":
                        [COLORS["primary"], COLORS["success"], COLORS["info"]]
                    }))

            fig.update_layout(height=350,
                              margin=dict(l=20, r=20, t=10, b=20),
                              paper_bgcolor='rgba(0,0,0,0)',
                              plot_bgcolor='rgba(0,0,0,0)')

            st.plotly_chart(fig, use_container_width=True)

        card(funnel_chart_content, title="Lead Conversion Funnel")

    with chart_cols[1]:

        def source_chart_content():
            if "Source" in leads_df.columns and not leads_df["Source"].dropna(
            ).empty:
                try:
                    # Get source counts safely
                    source_counts = leads_df["Source"].value_counts(
                    ).reset_index()
                    source_counts.columns = ["Source", "Count"]
                    source_counts = source_counts.head(6)  # Top 6 sources

                    fig = px.bar(
                        source_counts,
                        x="Source",
                        y="Count",
                        color="Count",
                        color_continuous_scale=px.colors.sequential.Blues,
                        text="Count")

                    fig.update_layout(height=350,
                                      margin=dict(l=20, r=20, t=10, b=20),
                                      coloraxis_showscale=False,
                                      paper_bgcolor='rgba(0,0,0,0)',
                                      plot_bgcolor='rgba(0,0,0,0)')

                    st.plotly_chart(fig, use_container_width=True)
                except Exception:
                    # If visualization fails, show placeholder
                    st.markdown(
                        "Source visualization will appear when data is available"
                    )
            else:
                # Display elegant placeholder
                st.markdown("""
                <div style="height: 200px; display: flex; justify-content: center; align-items: center; color: #888; background: #f7f7f7; border-radius: 5px;">
                    <div style="text-align: center;">
                        <div style="font-size: 24px; margin-bottom: 10px;">📊</div>
                        <div>Lead source visualization will appear here when data is available</div>
                    </div>
                </div>
                """,
                            unsafe_allow_html=True)

        card(source_chart_content, title="Lead Sources")

    # Latest leads and transactions
    section_divider("Recent Activity")

    activity_cols = st.columns(2)

    with activity_cols[0]:

        def recent_leads_content():
            if not leads_df.empty:
                try:
                    # Sort by Date if available, otherwise show most recent first
                    recent_leads = leads_df.sort_values(
                        by='Date', ascending=False
                    ).head(5) if 'Date' in leads_df.columns else leads_df.head(
                        5)

                    for _, lead in recent_leads.iterrows():
                        lead_name = lead.get('Name', 'Lead')
                        lead_status = lead.get('Status', 'New')
                        lead_source = lead.get('Source', 'Unknown')
                        lead_date = lead.get('Date', None)

                        date_display = lead_date.strftime(
                            '%m/%d/%Y') if isinstance(
                                lead_date,
                                (datetime, pd.Timestamp)) else 'Recent'

                        st.markdown(f"""
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px; padding-bottom: 10px; border-bottom: 1px solid {COLORS['border']};">
                            <div>
                                <div style="font-weight: 500;">{lead_name}</div>
                                <div style="font-size: {TYPOGRAPHY['small']}; color: {COLORS['muted']};">{lead_source}</div>
                            </div>
                            <div style="text-align: right;">
                                <div style="font-size: {TYPOGRAPHY['small']}; color: {COLORS['muted']};">{date_display}</div>
                                <div>{get_status_badge(lead_status)}</div>
                            </div>
                        </div>
                        """,
                                    unsafe_allow_html=True)
                except Exception:
                    # Fallback for display issues
                    st.markdown(
                        "Recent leads will appear here when data is available")
            else:
                # Elegant placeholder
                st.markdown("""
                <div style="height: 200px; display: flex; justify-content: center; align-items: center; color: #888; background: #f7f7f7; border-radius: 5px;">
                    <div style="text-align: center;">
                        <div style="font-size: 24px; margin-bottom: 10px;">📋</div>
                        <div>Recent leads will appear here</div>
                    </div>
                </div>
                """,
                            unsafe_allow_html=True)

        card(recent_leads_content, title="Recent Leads")

    with activity_cols[1]:

        def recent_transactions_content():
            if not transactions_df.empty:
                try:
                    # Sort by Transaction_Date if available
                    recent_txs = transactions_df.sort_values(
                        by='Transaction_Date', ascending=False
                    ).head(
                        5
                    ) if 'Transaction_Date' in transactions_df.columns else transactions_df.head(
                        5)

                    for _, tx in recent_txs.iterrows():
                        tx_lead_id = tx.get('Lead_ID', '')
                        tx_amount = tx.get('Revenue', 0)
                        tx_service = tx.get('Service', 'Service')
                        tx_date = tx.get('Transaction_Date', None)

                        # Try to find lead name safely
                        lead_name = "Client"
                        try:
                            if 'id' in leads_df.columns and tx_lead_id in leads_df[
                                    'id'].values:
                                lead_row = leads_df[leads_df['id'] ==
                                                    tx_lead_id].iloc[0]
                                lead_name = lead_row.get('Name', 'Client')
                        except Exception:
                            pass

                        date_display = tx_date.strftime(
                            '%m/%d/%Y') if isinstance(
                                tx_date,
                                (datetime, pd.Timestamp)) else 'Recent'

                        st.markdown(f"""
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px; padding-bottom: 10px; border-bottom: 1px solid {COLORS['border']};">
                            <div>
                                <div style="font-weight: 500;">{lead_name}</div>
                                <div style="font-size: {TYPOGRAPHY['small']}; color: {COLORS['muted']};">{tx_service}</div>
                            </div>
                            <div style="text-align: right;">
                                <div style="font-size: {TYPOGRAPHY['small']}; color: {COLORS['muted']};">{date_display}</div>
                                <div style="font-weight: 500; color: {COLORS['success']};">${tx_amount:,.2f}</div>
                            </div>
                        </div>
                        """,
                                    unsafe_allow_html=True)
                except Exception:
                    # Fallback for display issues
                    st.markdown(
                        "Recent transactions will appear here when data is available"
                    )
            else:
                # Elegant placeholder
                st.markdown("""
                <div style="height: 200px; display: flex; justify-content: center; align-items: center; color: #888; background: #f7f7f7; border-radius: 5px;">
                    <div style="text-align: center;">
                        <div style="font-size: 24px; margin-bottom: 10px;">💰</div>
                        <div>Recent transactions will appear here</div>
                    </div>
                </div>
                """,
                            unsafe_allow_html=True)

        card(recent_transactions_content, title="Recent Transactions")


def render_strategic_insights_tab(leads_df, transactions_df):
    """Render the strategic insights dashboard tab with advanced analytics"""
    styled_header("Strategic Performance Insights", level=1)

    # Handle empty dataframes gracefully
    if leads_df is None or leads_df.empty:
        # Show elegant placeholder instead of error
        st.markdown("""
        <div style="padding: 30px; background: #f7f7f7; border-radius: 10px; text-align: center; margin: 20px 0;">
            <div style="font-size: 36px; margin-bottom: 20px;">✨</div>
            <h3>Strategic Insights</h3>
            <p>Strategic performance insights will appear here when lead data is available.</p>
            <p style="font-size: 14px; color: #888; margin-top: 20px;">Please check your Airtable connection in Settings.</p>
        </div>
        """,
                    unsafe_allow_html=True)
        return

    # Filter to this month
    this_month = datetime.now().month
    this_year = datetime.now().year

    # Time period selector
    time_options = [
        "This Month", "Last Month", "Last 3 Months", "Year to Date", "All Time"
    ]
    period = st.selectbox("Time Period", time_options, index=0)

    # Filter data based on selected time period - with error handling
    try:
        filtered_leads = filter_by_time_period(leads_df, period)
        filtered_transactions = None if transactions_df is None else filter_by_time_period(
            transactions_df, period)
    except Exception:
        # If filtering fails, use original dataframes
        filtered_leads = leads_df
        filtered_transactions = transactions_df

    # Calculate metrics for selected period - with error handling
    try:
        metrics = calculate_strategic_metrics(filtered_leads,
                                              filtered_transactions)
    except Exception:
        # If metrics calculation fails, use default values
        metrics = {
            'cac': 0,
            'cac_trend': None,
            'roas': 0,
            'roas_trend': None,
            'lead_value': 0,
            'lead_value_trend': None,
            'time_to_convert': 0,
            'time_to_convert_trend': None
        }

    # Metrics display - with elegant premium styling
    st.markdown("### Key Performance Indicators")

    metric_cols = st.columns(4)

    with metric_cols[0]:

        def kpi_1_content():
            st.metric("Customer Acquisition Cost (CAC)",
                      f"${metrics['cac']:,.2f}",
                      delta=f"{metrics['cac_trend']:+.1f}%"
                      if metrics['cac_trend'] is not None else None,
                      delta_color="inverse")
            st.caption("Cost to acquire a new customer")

        card(kpi_1_content)

    with metric_cols[1]:

        def kpi_2_content():
            st.metric("Return on Ad Spend (ROAS)",
                      f"{metrics['roas']:.2f}x",
                      delta=f"{metrics['roas_trend']:+.1f}%"
                      if metrics['roas_trend'] is not None else None)
            st.caption("Revenue generated per ad dollar")

        card(kpi_2_content)

    with metric_cols[2]:

        def kpi_3_content():
            st.metric("Avg. Lead Value",
                      f"${metrics['lead_value']:,.2f}",
                      delta=f"{metrics['lead_value_trend']:+.1f}%"
                      if metrics['lead_value_trend'] is not None else None)
            st.caption("Average revenue per lead")

        card(kpi_3_content)

    with metric_cols[3]:

        def kpi_4_content():
            st.metric("Avg. Time to Convert",
                      f"{metrics['time_to_convert']:.1f} days",
                      delta=f"{metrics['time_to_convert_trend']:+.1f} days" if
                      metrics['time_to_convert_trend'] is not None else None,
                      delta_color="inverse")
            st.caption("Days from lead to conversion")

        card(kpi_4_content)

    # AI Insights section if OpenAI key is available
    if 'openai_api_key' in st.session_state and st.session_state.openai_api_key:
        section_divider("AI-Powered Recommendations")

        def ai_insights_content():
            # Get AI recommendations
            with st.spinner("Generating AI insights..."):
                try:
                    recommendations = ai_insights.get_ad_optimization_recommendations(
                        filtered_leads, filtered_transactions)

                    if recommendations:
                        for i, rec in enumerate(recommendations):
                            st.markdown(f"**{i+1}. {rec['title']}**")
                            st.markdown(rec['description'])

                            if i < len(recommendations) - 1:
                                st.markdown("---")
                    else:
                        # Elegant placeholder for no recommendations
                        st.markdown("""
                        <div style="text-align: center; padding: 20px;">
                            <p>AI recommendations will appear when more data is available.</p>
                        </div>
                        """,
                                    unsafe_allow_html=True)
                except Exception:
                    # Elegant error message
                    st.markdown("""
                    <div style="text-align: center; padding: 20px;">
                        <p>AI recommendations are being prepared. Please check back later.</p>
                    </div>
                    """,
                                unsafe_allow_html=True)

        card(ai_insights_content, title="Meta Ad Optimization Recommendations")

    # Advanced visualization
    section_divider("Advanced Metrics")

    chart_cols = st.columns(2)

    with chart_cols[0]:

        def roas_chart_content():
            # Create conversion prediction chart
            try:
                fig = ai_insights.create_roas_prediction_chart(
                    filtered_leads, filtered_transactions)
                st.plotly_chart(fig, use_container_width=True)
            except Exception:
                # Elegant placeholder
                st.markdown("""
                <div style="height: 200px; display: flex; justify-content: center; align-items: center; color: #888; background: #f7f7f7; border-radius: 5px;">
                    <div style="text-align: center;">
                        <div style="font-size: 24px; margin-bottom: 10px;">📈</div>
                        <div>ROAS prediction chart will appear here when more data is available</div>
                    </div>
                </div>
                """,
                            unsafe_allow_html=True)

        card(roas_chart_content, title="ROAS Prediction by Audience")

    with chart_cols[1]:

        def conversion_chart_content():
            # Create time to conversion histogram
            try:
                if 'Date' in filtered_leads.columns and 'Closed_Date' in filtered_leads.columns:
                    # Calculate days to conversion
                    converted_leads = filtered_leads[
                        filtered_leads['Closed_Date'].notna()]

                    if not converted_leads.empty:
                        converted_leads['Days_To_Convert'] = (
                            converted_leads['Closed_Date'] -
                            converted_leads['Date']).dt.days

                        fig = px.histogram(
                            converted_leads,
                            x="Days_To_Convert",
                            nbins=20,
                            color_discrete_sequence=[COLORS["primary"]],
                            labels={"Days_To_Convert": "Days to Conversion"},
                            title="Conversion Timeline Distribution")

                        fig.update_layout(height=350,
                                          margin=dict(l=20, r=20, t=40, b=20),
                                          paper_bgcolor='rgba(0,0,0,0)',
                                          plot_bgcolor='rgba(0,0,0,0)')

                        st.plotly_chart(fig, use_container_width=True)
                        return

                # If we got here, either no data or error - show placeholder
                st.markdown("""
                <div style="height: 200px; display: flex; justify-content: center; align-items: center; color: #888; background: #f7f7f7; border-radius: 5px;">
                    <div style="text-align: center;">
                        <div style="font-size: 24px; margin-bottom: 10px;">📊</div>
                        <div>Conversion timeline visualization will appear here when more data is available</div>
                    </div>
                </div>
                """,
                            unsafe_allow_html=True)
            except Exception:
                # Elegant placeholder
                st.markdown("""
                <div style="height: 200px; display: flex; justify-content: center; align-items: center; color: #888; background: #f7f7f7; border-radius: 5px;">
                    <div style="text-align: center;">
                        <div style="font-size: 24px; margin-bottom: 10px;">📊</div>
                        <div>Conversion timeline visualization will appear here when more data is available</div>
                    </div>
                </div>
                """,
                            unsafe_allow_html=True)

        card(conversion_chart_content, title="Time to Conversion")


def get_status_badge(status):
    """Get HTML for a status badge"""
    status = str(status).lower() if status else "unknown"

    if "convert" in status or "closed" in status:
        color = COLORS["success"]
        bg_color = "rgba(40, 167, 69, 0.1)"
    elif "book" in status or "scheduled" in status or "consult" in status:
        color = COLORS["info"]
        bg_color = "rgba(23, 162, 184, 0.1)"
    elif "new" in status or "lead" in status:
        color = COLORS["primary"]
        bg_color = "rgba(0, 123, 255, 0.1)"
    elif "cancel" in status or "no show" in status:
        color = COLORS["danger"]
        bg_color = "rgba(220, 53, 69, 0.1)"
    else:
        color = COLORS["secondary"]
        bg_color = "rgba(108, 117, 125, 0.1)"

    return f'<span style="display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: {TYPOGRAPHY["small"]}; background-color: {bg_color}; color: {color};">{status.title()}</span>'


def filter_by_time_period(df, period):
    """Filter dataframe by time period"""
    if df is None or df.empty:
        return df

    today = datetime.now()

    # Find a date column
    date_col = None
    for col in ['Date', 'Transaction_Date', 'date', 'Created_Time']:
        if col in df.columns:
            date_col = col
            break

    if date_col is None:
        return df  # No date column found

    # Handle different period selections
    if period == "This Month":
        start_date = datetime(today.year, today.month, 1)
        return df[df[date_col] >= start_date]

    elif period == "Last Month":
        last_month = today.month - 1 if today.month > 1 else 12
        last_month_year = today.year if today.month > 1 else today.year - 1
        start_date = datetime(last_month_year, last_month, 1)

        if last_month == 12:
            end_date = datetime(last_month_year + 1, 1, 1)
        else:
            end_date = datetime(last_month_year, last_month + 1, 1)

        return df[(df[date_col] >= start_date) & (df[date_col] < end_date)]

    elif period == "Last 3 Months":
        three_months_ago = today - timedelta(days=90)
        return df[df[date_col] >= three_months_ago]

    elif period == "Year to Date":
        start_date = datetime(today.year, 1, 1)
        return df[df[date_col] >= start_date]

    else:  # "All Time"
        return df


def calculate_strategic_metrics(leads_df,
                                transactions_df,
                                previous_leads_df=None,
                                ad_spend=5000):
    """Calculate strategic marketing science metrics with advanced insights"""
    # Default metrics
    metrics = {
        'cac': 0,
        'roas': 0,
        'lead_value': 0,
        'time_to_convert': 0,
        'cac_trend': None,
        'roas_trend': None,
        'lead_value_trend': None,
        'time_to_convert_trend': None
    }

    # Return defaults if no data
    if leads_df is None or leads_df.empty:
        return metrics

    # Calculate core metrics safely
    try:
        # Total leads
        total_leads = len(leads_df)

        # Meta leads
        if 'Source' in leads_df.columns:
            meta_leads = leads_df[leads_df['Source'].str.contains(
                'facebook|instagram|meta|fb ads|ig ads', case=False, na=False)]
            meta_lead_count = len(meta_leads)
        else:
            meta_lead_count = 0

        # Calculate conversions
        converted_count = 0
        try:
            converted_count = sum(1 for _, row in leads_df.iterrows()
                                  if is_converted(row))
        except Exception:
            pass

        # Total revenue
        total_revenue = 0
        if transactions_df is not None and not transactions_df.empty and 'Revenue' in transactions_df.columns:
            # Handle non-numeric data
            if not pd.api.types.is_numeric_dtype(transactions_df['Revenue']):
                transactions_df['Revenue'] = pd.to_numeric(
                    transactions_df['Revenue'], errors='coerce')

            total_revenue = transactions_df['Revenue'].sum()

        # Calculate metrics
        metrics[
            'cac'] = ad_spend / total_leads if total_leads > 0 else ad_spend
        metrics['roas'] = total_revenue / ad_spend if ad_spend > 0 else 0
        metrics[
            'lead_value'] = total_revenue / total_leads if total_leads > 0 else 0

        # Time to convert calculation
        if 'Date' in leads_df.columns and 'Closed_Date' in leads_df.columns:
            converted_leads = leads_df[leads_df['Closed_Date'].notna()]
            if not converted_leads.empty:
                # Calculate average days to conversion
                converted_leads['Days_To_Convert'] = (
                    converted_leads['Closed_Date'] -
                    converted_leads['Date']).dt.days
                metrics['time_to_convert'] = converted_leads[
                    'Days_To_Convert'].mean()
    except Exception:
        # If any calculation fails, keep defaults
        pass

    return metrics


def is_booked(lead_row):
    """Check if lead has booked a consultation"""
    try:
        # Check if Consult date exists
        if 'Consult' in lead_row and pd.notna(lead_row.get('Consult')):
            return True
            
        # Check if Scheduled by exists
        if 'Scheduled by:' in lead_row and pd.notna(lead_row.get('Scheduled by:')):
            return True
            
        # Check for Status - looking for Follow Up which indicates engagement
        if 'Status' in lead_row and pd.notna(lead_row.get('Status')):
            status = str(lead_row['Status']).lower()
            return any(keyword in status for keyword in [
                'follow up', 
                'scheduled', 
                'consult',
                'reschedule',
                'consulted'
            ])
            
        # Check for Consult Status
        if 'Consult Status' in lead_row and pd.notna(lead_row.get('Consult Status')):
            status = str(lead_row['Consult Status']).lower()
            return any(keyword in status for keyword in [
                'scheduled', 
                'booked', 
                'confirmed',
                'consulted'
            ])
            
        # Check Overall Status
        if 'Overall Status' in lead_row and pd.notna(lead_row.get('Overall Status')):
            status = str(lead_row['Overall Status']).lower()
            return any(keyword in status for keyword in [
                'follow up', 
                'scheduled', 
                'consult'
            ])
            
        return False
    except Exception as e:
        print(f"Error in is_booked: {e}")
        return False


def is_converted(lead_row):
    """Check if lead has converted to a customer"""
    try:
        # First check Status column with specific values from your Airtable
        if 'Status' in lead_row and pd.notna(lead_row.get('Status')):
            status = str(lead_row['Status']).lower()
            if 'closed' in status:
                return True
        
        # Only then check other attributes
        if isinstance(lead_row, pd.Series):
            # Check for Closed value as a single item (safe for Series)
            if 'Closed' in lead_row.index and pd.notna(lead_row.get('Closed')):
                return True
                
            # Check for Closed By - indicating someone closed the sale
            if 'Closed By' in lead_row.index and pd.notna(lead_row.get('Closed By')):
                return True
                
            # Check for Transactions - indicating a purchase
            if 'Transactions' in lead_row.index and pd.notna(lead_row.get('Transactions')):
                return True
                
            # Check Closing Month or Closing Year - these should be safe for Series
            if 'Closing Month' in lead_row.index and pd.notna(lead_row.get('Closing Month')):
                return True
                
            if 'Closing Year' in lead_row.index and pd.notna(lead_row.get('Closing Year')):
                return True
        
        return False
    except Exception as e:
        print(f"Error in is_converted: {e}")
        return False
