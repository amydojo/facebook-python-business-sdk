"""
Production Quality Control Dashboard
Real-time system monitoring and automated enhancement application
"""

import streamlit as st
import os
import sys
import logging
import traceback
import time
import json
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px

# Configure production logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('system_quality.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ProductionQualityController:
    """Advanced production quality control system"""
    
    def __init__(self):
        self.quality_metrics = {}
        self.enhancement_history = []
        self.critical_alerts = []
        self.performance_baseline = {}
        
    def run_quality_inspection(self) -> Dict:
        """Execute comprehensive quality inspection"""
        
        st.title("🔧 Production Quality Control")
        st.markdown("Real-time system monitoring and automated enhancement")
        st.markdown("---")
        
        # Initialize inspection results
        inspection_results = {
            'timestamp': datetime.now().isoformat(),
            'system_health': self._inspect_system_health(),
            'data_pipeline': self._inspect_data_pipeline(),
            'api_connections': self._inspect_api_connections(),
            'performance_metrics': self._inspect_performance(),
            'security_status': self._inspect_security(),
            'code_quality': self._inspect_code_quality(),
            'user_experience': self._inspect_user_experience()
        }
        
        # Calculate overall quality score
        overall_score = self._calculate_quality_score(inspection_results)
        
        # Display quality dashboard
        self._display_quality_dashboard(inspection_results, overall_score)
        
        # Apply automated enhancements if needed
        if overall_score < 85:
            st.warning("Quality score below threshold. Applying automated enhancements...")
            enhancement_results = self._apply_automated_enhancements(inspection_results)
            st.success(f"Applied {len(enhancement_results)} enhancements")
        
        return inspection_results
    
    def _inspect_system_health(self) -> Dict:
        """Inspect overall system health"""
        
        with st.expander("🏥 System Health Inspection"):
            health_status = {}
            
            # Memory and CPU checks
            try:
                import psutil
                memory = psutil.virtual_memory()
                cpu = psutil.cpu_percent(interval=1)
                
                health_status['memory_usage'] = memory.percent
                health_status['cpu_usage'] = cpu
                health_status['available_memory_gb'] = memory.available / (1024**3)
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Memory Usage", f"{memory.percent:.1f}%", 
                             delta="High" if memory.percent > 80 else "Normal")
                with col2:
                    st.metric("CPU Usage", f"{cpu:.1f}%",
                             delta="High" if cpu > 80 else "Normal")
                with col3:
                    st.metric("Available Memory", f"{memory.available / (1024**3):.1f} GB")
                    
            except ImportError:
                health_status['system_monitoring'] = 'unavailable'
                st.info("System monitoring requires psutil package")
            
            # Disk space checks
            total, used, free = os.statvfs('.').f_blocks, os.statvfs('.').f_blocks - os.statvfs('.').f_bavail, os.statvfs('.').f_bavail
            disk_usage_percent = (used / total) * 100
            
            health_status['disk_usage'] = disk_usage_percent
            health_status['free_space_gb'] = free * os.statvfs('.').f_frsize / (1024**3)
            
            st.metric("Disk Usage", f"{disk_usage_percent:.1f}%",
                     delta="High" if disk_usage_percent > 85 else "Normal")
        
        return health_status
    
    def _inspect_data_pipeline(self) -> Dict:
        """Inspect data pipeline quality and reliability"""
        
        with st.expander("🔄 Data Pipeline Inspection"):
            pipeline_status = {}
            
            # Test data connector
            try:
                from reliable_data_connector import ReliableDataConnector
                connector = ReliableDataConnector()
                
                # Test transaction data loading
                end_date = datetime.now().strftime('%Y-%m-%d')
                start_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
                
                start_time = time.time()
                trans_result = connector.get_transactions(start_date, end_date)
                trans_load_time = time.time() - start_time
                
                pipeline_status['transaction_load_time'] = trans_load_time
                pipeline_status['transaction_success'] = trans_result.get('success', False)
                pipeline_status['transaction_count'] = trans_result.get('transaction_count', 0)
                
                # Test leads data loading
                start_time = time.time()
                leads_result = connector.get_leads(start_date, end_date)
                leads_load_time = time.time() - start_time
                
                pipeline_status['leads_load_time'] = leads_load_time
                pipeline_status['leads_success'] = leads_result.get('success', False)
                pipeline_status['leads_count'] = leads_result.get('total_leads', 0)
                
                # Display metrics
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Transaction Load", f"{trans_load_time:.2f}s",
                             delta="Fast" if trans_load_time < 2 else "Slow")
                with col2:
                    st.metric("Leads Load", f"{leads_load_time:.2f}s",
                             delta="Fast" if leads_load_time < 2 else "Slow")
                with col3:
                    st.metric("Transaction Records", trans_result.get('transaction_count', 0))
                with col4:
                    st.metric("Lead Records", leads_result.get('total_leads', 0))
                
                # Data quality assessment
                if trans_result.get('success') and trans_result.get('transaction_count', 0) > 0:
                    st.success("✅ Transaction pipeline operational")
                else:
                    st.error("❌ Transaction pipeline issues detected")
                    
                if leads_result.get('success') and leads_result.get('total_leads', 0) > 0:
                    st.success("✅ Leads pipeline operational")
                else:
                    st.error("❌ Leads pipeline issues detected")
                    
            except Exception as e:
                pipeline_status['error'] = str(e)
                st.error(f"Pipeline inspection failed: {e}")
                logger.error(f"Data pipeline inspection error: {e}")
        
        return pipeline_status
    
    def _inspect_api_connections(self) -> Dict:
        """Inspect API connection quality"""
        
        with st.expander("🔌 API Connection Inspection"):
            api_status = {}
            
            # Test Airtable API
            try:
                from config_manager import get_config
                config = get_config()
                api_key, base_id, tables = config.get_airtable_config()
                
                if api_key and base_id:
                    from pyairtable import Api
                    api = Api(api_key)
                    
                    start_time = time.time()
                    # Test connection with minimal request
                    try:
                        table = api.table(base_id, tables['transactions'])
                        test_records = table.all(max_records=1)
                        airtable_response_time = time.time() - start_time
                        
                        api_status['airtable_connected'] = True
                        api_status['airtable_response_time'] = airtable_response_time
                        
                        st.success(f"✅ Airtable API - Response: {airtable_response_time:.2f}s")
                        
                    except Exception as e:
                        api_status['airtable_connected'] = False
                        api_status['airtable_error'] = str(e)
                        st.error(f"❌ Airtable API - Error: {e}")
                else:
                    api_status['airtable_configured'] = False
                    st.warning("⚠️ Airtable API not configured")
                
                # Test Meta API
                token, account_id, pixel_id = config.get_meta_config()
                
                if token and account_id:
                    import requests
                    
                    start_time = time.time()
                    try:
                        url = f"https://graph.facebook.com/v18.0/act_{account_id}"
                        response = requests.get(url, params={'access_token': token, 'fields': 'name'})
                        meta_response_time = time.time() - start_time
                        
                        if response.status_code == 200:
                            api_status['meta_connected'] = True
                            api_status['meta_response_time'] = meta_response_time
                            st.success(f"✅ Meta API - Response: {meta_response_time:.2f}s")
                        else:
                            api_status['meta_connected'] = False
                            api_status['meta_error'] = f"HTTP {response.status_code}"
                            st.error(f"❌ Meta API - HTTP {response.status_code}")
                            
                    except Exception as e:
                        api_status['meta_connected'] = False
                        api_status['meta_error'] = str(e)
                        st.error(f"❌ Meta API - Error: {e}")
                else:
                    api_status['meta_configured'] = False
                    st.warning("⚠️ Meta API not configured")
                    
            except Exception as e:
                api_status['config_error'] = str(e)
                st.error(f"Configuration error: {e}")
        
        return api_status
    
    def _inspect_performance(self) -> Dict:
        """Inspect system performance metrics"""
        
        with st.expander("⚡ Performance Inspection"):
            performance_metrics = {}
            
            # Check cache performance
            cache_dir = 'data_cache'
            if os.path.exists(cache_dir):
                cache_files = os.listdir(cache_dir)
                total_cache_size = sum(
                    os.path.getsize(os.path.join(cache_dir, f)) 
                    for f in cache_files if os.path.isfile(os.path.join(cache_dir, f))
                )
                
                performance_metrics['cache_files'] = len(cache_files)
                performance_metrics['cache_size_mb'] = total_cache_size / (1024 * 1024)
                
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Cache Files", len(cache_files))
                with col2:
                    st.metric("Cache Size", f"{total_cache_size / (1024 * 1024):.1f} MB")
                
                if total_cache_size > 100 * 1024 * 1024:  # > 100MB
                    st.warning("⚠️ Cache size is large, consider cleanup")
                else:
                    st.success("✅ Cache size optimal")
            else:
                st.info("ℹ️ No cache directory found")
            
            # Check log files
            log_files = [f for f in os.listdir('.') if f.endswith('.log')]
            if log_files:
                total_log_size = sum(os.path.getsize(f) for f in log_files)
                performance_metrics['log_files'] = len(log_files)
                performance_metrics['log_size_mb'] = total_log_size / (1024 * 1024)
                
                st.metric("Log Files", f"{len(log_files)} files ({total_log_size / (1024 * 1024):.1f} MB)")
        
        return performance_metrics
    
    def _inspect_security(self) -> Dict:
        """Inspect security configuration"""
        
        with st.expander("🔒 Security Inspection"):
            security_status = {}
            
            # Check environment variables
            required_secrets = ['AIRTABLE_API_KEY', 'META_ACCESS_TOKEN', 'META_AD_ACCOUNT_ID', 'META_PIXEL_ID']
            configured_secrets = []
            
            for secret in required_secrets:
                if os.getenv(secret):
                    configured_secrets.append(secret)
                    security_status[f'{secret.lower()}_configured'] = True
                else:
                    security_status[f'{secret.lower()}_configured'] = False
            
            security_score = len(configured_secrets) / len(required_secrets) * 100
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Security Score", f"{security_score:.0f}%")
            with col2:
                st.metric("Configured Secrets", f"{len(configured_secrets)}/{len(required_secrets)}")
            
            # Check for .gitignore
            if os.path.exists('.gitignore'):
                with open('.gitignore', 'r') as f:
                    gitignore_content = f.read()
                    if '.env' in gitignore_content:
                        st.success("✅ .gitignore properly configured")
                        security_status['gitignore_configured'] = True
                    else:
                        st.warning("⚠️ .gitignore missing environment protection")
                        security_status['gitignore_configured'] = False
            else:
                st.warning("⚠️ No .gitignore file found")
                security_status['gitignore_exists'] = False
        
        return security_status
    
    def _inspect_code_quality(self) -> Dict:
        """Inspect code quality metrics"""
        
        with st.expander("💻 Code Quality Inspection"):
            code_metrics = {}
            
            # Count Python files
            py_files = [f for f in os.listdir('.') if f.endswith('.py')]
            code_metrics['python_files'] = len(py_files)
            
            # Analyze main files
            main_files = ['app.py', 'reliable_data_connector.py', 'config_manager.py']
            quality_scores = []
            
            for file_path in main_files:
                if os.path.exists(file_path):
                    with open(file_path, 'r') as f:
                        content = f.read()
                        
                    file_metrics = {
                        'lines': len(content.split('\n')),
                        'has_docstrings': '"""' in content,
                        'has_type_hints': 'from typing import' in content,
                        'has_error_handling': 'try:' in content and 'except' in content,
                        'has_logging': 'logging' in content
                    }
                    
                    # Calculate quality score for this file
                    score = sum([
                        file_metrics['has_docstrings'],
                        file_metrics['has_type_hints'],
                        file_metrics['has_error_handling'],
                        file_metrics['has_logging']
                    ]) / 4 * 100
                    
                    quality_scores.append(score)
                    code_metrics[f'{file_path}_quality'] = score
            
            overall_quality = sum(quality_scores) / len(quality_scores) if quality_scores else 0
            code_metrics['overall_quality'] = overall_quality
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Python Files", len(py_files))
            with col2:
                st.metric("Code Quality", f"{overall_quality:.0f}%")
            with col3:
                if overall_quality > 80:
                    st.success("✅ High Quality")
                elif overall_quality > 60:
                    st.warning("⚠️ Medium Quality")
                else:
                    st.error("❌ Needs Improvement")
        
        return code_metrics
    
    def _inspect_user_experience(self) -> Dict:
        """Inspect user experience factors"""
        
        with st.expander("🎨 User Experience Inspection"):
            ux_metrics = {}
            
            # Check Streamlit configuration
            streamlit_config = '.streamlit/config.toml'
            if os.path.exists(streamlit_config):
                ux_metrics['streamlit_configured'] = True
                st.success("✅ Streamlit configuration present")
            else:
                ux_metrics['streamlit_configured'] = False
                st.warning("⚠️ No Streamlit configuration")
            
            # Check for preview files
            preview_files = ['preview.html', 'preview2.html']
            preview_count = sum(1 for f in preview_files if os.path.exists(f))
            ux_metrics['preview_files'] = preview_count
            
            # Check app.py for UI elements
            if os.path.exists('app.py'):
                with open('app.py', 'r') as f:
                    app_content = f.read()
                
                ui_features = {
                    'custom_css': '<style>' in app_content,
                    'plotly_charts': 'plotly' in app_content,
                    'responsive_design': 'use_container_width=True' in app_content,
                    'error_messages': 'st.error' in app_content,
                    'success_messages': 'st.success' in app_content
                }
                
                ui_score = sum(ui_features.values()) / len(ui_features) * 100
                ux_metrics['ui_score'] = ui_score
                
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("UI Features", f"{sum(ui_features.values())}/{len(ui_features)}")
                with col2:
                    st.metric("UX Score", f"{ui_score:.0f}%")
        
        return ux_metrics
    
    def _calculate_quality_score(self, inspection_results: Dict) -> float:
        """Calculate overall system quality score"""
        
        scores = []
        weights = {
            'system_health': 0.2,
            'data_pipeline': 0.25,
            'api_connections': 0.2,
            'performance_metrics': 0.15,
            'security_status': 0.1,
            'code_quality': 0.05,
            'user_experience': 0.05
        }
        
        # System health score
        health = inspection_results.get('system_health', {})
        health_score = 100
        if health.get('memory_usage', 0) > 80:
            health_score -= 20
        if health.get('cpu_usage', 0) > 80:
            health_score -= 20
        if health.get('disk_usage', 0) > 85:
            health_score -= 30
        scores.append(health_score * weights['system_health'])
        
        # Data pipeline score
        pipeline = inspection_results.get('data_pipeline', {})
        pipeline_score = 0
        if pipeline.get('transaction_success'):
            pipeline_score += 50
        if pipeline.get('leads_success'):
            pipeline_score += 50
        scores.append(pipeline_score * weights['data_pipeline'])
        
        # API connections score
        api = inspection_results.get('api_connections', {})
        api_score = 0
        if api.get('airtable_connected'):
            api_score += 50
        if api.get('meta_connected'):
            api_score += 50
        scores.append(api_score * weights['api_connections'])
        
        # Performance score
        perf = inspection_results.get('performance_metrics', {})
        perf_score = 100  # Default good performance
        if perf.get('cache_size_mb', 0) > 100:
            perf_score -= 20
        scores.append(perf_score * weights['performance_metrics'])
        
        # Security score
        security = inspection_results.get('security_status', {})
        security_score = sum(1 for k, v in security.items() if k.endswith('_configured') and v) / 4 * 100
        scores.append(security_score * weights['security_status'])
        
        # Code quality score
        code = inspection_results.get('code_quality', {})
        code_score = code.get('overall_quality', 80)
        scores.append(code_score * weights['code_quality'])
        
        # UX score
        ux = inspection_results.get('user_experience', {})
        ux_score = ux.get('ui_score', 80)
        scores.append(ux_score * weights['user_experience'])
        
        return sum(scores)
    
    def _display_quality_dashboard(self, results: Dict, overall_score: float):
        """Display comprehensive quality dashboard"""
        
        st.markdown("---")
        st.subheader("📊 Quality Control Dashboard")
        
        # Overall score
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            if overall_score >= 90:
                score_color = "green"
                score_status = "Excellent"
            elif overall_score >= 75:
                score_color = "orange"
                score_status = "Good"
            else:
                score_color = "red"
                score_status = "Needs Work"
            
            st.markdown(f"""
            <div style="background: {score_color}; color: white; padding: 1rem; border-radius: 0.5rem; text-align: center;">
                <h3>Overall Quality</h3>
                <h1>{overall_score:.0f}%</h1>
                <p>{score_status}</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            system_health = results.get('system_health', {})
            memory_usage = system_health.get('memory_usage', 0)
            st.metric("Memory Usage", f"{memory_usage:.1f}%", 
                     delta="High" if memory_usage > 80 else "Normal")
        
        with col3:
            api_status = results.get('api_connections', {})
            connected_apis = sum([
                api_status.get('airtable_connected', False),
                api_status.get('meta_connected', False)
            ])
            st.metric("API Status", f"{connected_apis}/2 Connected")
        
        with col4:
            pipeline_status = results.get('data_pipeline', {})
            pipeline_health = sum([
                pipeline_status.get('transaction_success', False),
                pipeline_status.get('leads_success', False)
            ])
            st.metric("Data Pipeline", f"{pipeline_health}/2 Operational")
        
        # Quality trends chart
        if hasattr(self, 'quality_history'):
            st.subheader("📈 Quality Trends")
            
            # Create trend chart
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=[datetime.now() - timedelta(minutes=i*5) for i in range(len(self.quality_history))],
                y=self.quality_history,
                mode='lines+markers',
                name='Quality Score',
                line=dict(color='#00B49E', width=3)
            ))
            
            fig.update_layout(
                title="System Quality Over Time",
                xaxis_title="Time",
                yaxis_title="Quality Score (%)",
                height=300,
                showlegend=False
            )
            
            st.plotly_chart(fig, use_container_width=True)
    
    def _apply_automated_enhancements(self, inspection_results: Dict) -> List[str]:
        """Apply automated system enhancements"""
        
        enhancements = []
        
        # Cache cleanup if needed
        perf = inspection_results.get('performance_metrics', {})
        if perf.get('cache_size_mb', 0) > 100:
            cache_dir = 'data_cache'
            if os.path.exists(cache_dir):
                cache_files = sorted([
                    os.path.join(cache_dir, f) for f in os.listdir(cache_dir)
                    if os.path.isfile(os.path.join(cache_dir, f))
                ], key=lambda x: os.path.getmtime(x))
                
                # Remove oldest 50% of cache files
                files_to_remove = cache_files[:len(cache_files)//2]
                for file_path in files_to_remove:
                    try:
                        os.remove(file_path)
                        enhancements.append(f"Removed old cache file: {os.path.basename(file_path)}")
                    except OSError:
                        pass
        
        # Create .gitignore if missing
        security = inspection_results.get('security_status', {})
        if not security.get('gitignore_exists', True):
            gitignore_content = """# Environment variables
.env
.env.local
.env.production

# Cache and temporary files
__pycache__/
*.pyc
*.pyo
*.pyd
.Python
data_cache/

# IDE files
.vscode/
.idea/
*.swp
*.swo

# OS files
.DS_Store
Thumbs.db

# Logs
*.log
logs/

# Sensitive files
*.key
*.pem
credentials.json
"""
            try:
                with open('.gitignore', 'w') as f:
                    f.write(gitignore_content)
                enhancements.append("Created .gitignore file")
            except Exception as e:
                logger.error(f"Failed to create .gitignore: {e}")
        
        # Create Streamlit config if missing
        ux = inspection_results.get('user_experience', {})
        if not ux.get('streamlit_configured', True):
            config_dir = '.streamlit'
            if not os.path.exists(config_dir):
                os.makedirs(config_dir)
            
            config_content = """[server]
headless = true
address = "0.0.0.0"
port = 5000
enableCORS = false
enableXsrfProtection = false

[browser]
gatherUsageStats = false

[theme]
primaryColor = "#00B49E"
backgroundColor = "#FFFFFF"
secondaryBackgroundColor = "#F0F3FA"
textColor = "#1A2340"
"""
            try:
                with open(os.path.join(config_dir, 'config.toml'), 'w') as f:
                    f.write(config_content)
                enhancements.append("Created Streamlit configuration")
            except Exception as e:
                logger.error(f"Failed to create Streamlit config: {e}")
        
        return enhancements

def main():
    """Run production quality control"""
    st.set_page_config(
        page_title="Production Quality Control",
        page_icon="🔧",
        layout="wide"
    )
    
    controller = ProductionQualityController()
    results = controller.run_quality_inspection()
    
    # Export results
    if st.sidebar.button("📋 Export Quality Report"):
        report_data = json.dumps(results, indent=2, default=str)
        st.sidebar.download_button(
            label="Download Report",
            data=report_data,
            file_name=f"quality_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            mime="application/json"
        )

if __name__ == "__main__":
    main()