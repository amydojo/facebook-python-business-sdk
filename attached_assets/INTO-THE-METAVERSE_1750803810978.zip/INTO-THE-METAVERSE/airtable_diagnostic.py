"""
Airtable Base Diagnostic Tool
Discovers table names, field structure, and data samples from your Airtable base
"""

import os
import streamlit as st
from pyairtable import Api
import json

def get_airtable_credentials():
    """Get Airtable credentials from environment"""
    return {
        'api_key': os.getenv('AIRTABLE_API_KEY'),
        'base_id': os.getenv('AIRTABLE_BASE_ID', 'appH4MePHS6qLsk5z')
    }

def discover_base_structure():
    """Discover the complete structure of the Airtable base"""
    creds = get_airtable_credentials()
    
    if not creds['api_key'] or not creds['base_id']:
        st.error("Missing Airtable credentials")
        return None
    
    try:
        api = Api(creds['api_key'])
        
        # Try to get base metadata via the API
        st.write(f"🔍 Analyzing base: {creds['base_id']}")
        
        # Common table names to try
        potential_tables = [
            'Leads', 'leads', 'Lead', 'lead',
            'Transactions', 'transactions', 'Transaction', 'transaction',
            'Social Media', 'social media', 'SocialMedia', 'socialmedia',
            'Revenue', 'revenue', 'Sales', 'sales',
            'Contacts', 'contacts', 'Contact', 'contact',
            'Customers', 'customers', 'Customer', 'customer',
            'Clients', 'clients', 'Client', 'client'
        ]
        
        discovered_tables = {}
        
        for table_name in potential_tables:
            try:
                table = api.table(creds['base_id'], table_name)
                
                # Try to get a small sample of records
                records = table.all(max_records=3)
                
                if records:
                    # Get field names from the first record
                    fields = list(records[0]['fields'].keys()) if records else []
                    
                    discovered_tables[table_name] = {
                        'record_count': len(records),
                        'fields': fields,
                        'sample_record': records[0]['fields'] if records else {}
                    }
                    
                    st.success(f"✅ Found table: '{table_name}' with {len(records)} records")
                    
            except Exception as e:
                if "INVALID_PERMISSIONS" not in str(e):
                    st.warning(f"⚠️ Could not access table '{table_name}': {str(e)}")
                continue
        
        return discovered_tables
        
    except Exception as e:
        st.error(f"Base discovery error: {str(e)}")
        return None

def analyze_lead_data_structure(discovered_tables):
    """Analyze which table contains lead data and its structure"""
    lead_indicators = ['name', 'phone', 'email', 'source', 'status', 'inbound', 'date']
    
    lead_candidates = {}
    
    for table_name, table_info in discovered_tables.items():
        fields = [f.lower() for f in table_info['fields']]
        
        # Count how many lead indicators are present
        indicator_count = sum(1 for indicator in lead_indicators if any(indicator in field for field in fields))
        
        if indicator_count >= 3:  # At least 3 lead indicators
            lead_candidates[table_name] = {
                'indicator_score': indicator_count,
                'fields': table_info['fields'],
                'sample': table_info['sample_record']
            }
    
    return lead_candidates

def analyze_transaction_data_structure(discovered_tables):
    """Analyze which table contains transaction/revenue data"""
    transaction_indicators = ['amount', 'revenue', 'total', 'price', 'cost', 'payment', 'transaction']
    
    transaction_candidates = {}
    
    for table_name, table_info in discovered_tables.items():
        fields = [f.lower() for f in table_info['fields']]
        
        # Count how many transaction indicators are present
        indicator_count = sum(1 for indicator in transaction_indicators if any(indicator in field for field in fields))
        
        if indicator_count >= 1:  # At least 1 transaction indicator
            transaction_candidates[table_name] = {
                'indicator_score': indicator_count,
                'fields': table_info['fields'],
                'sample': table_info['sample_record']
            }
    
    return transaction_candidates

def main():
    st.title("🔍 Airtable Base Diagnostic")
    st.write("Discovering your Airtable base structure for Meta attribution integration")
    
    creds = get_airtable_credentials()
    st.write(f"**Base ID:** {creds['base_id']}")
    st.write(f"**API Key:** {'✅ Present' if creds['api_key'] else '❌ Missing'}")
    
    if st.button("🚀 Discover Base Structure"):
        with st.spinner("Analyzing your Airtable base..."):
            discovered_tables = discover_base_structure()
            
            if discovered_tables:
                st.success(f"Discovered {len(discovered_tables)} accessible tables")
                
                # Show all discovered tables
                st.subheader("📋 Discovered Tables")
                for table_name, info in discovered_tables.items():
                    with st.expander(f"Table: {table_name} ({len(info['fields'])} fields)"):
                        st.write("**Fields:**")
                        st.write(", ".join(info['fields']))
                        
                        st.write("**Sample Record:**")
                        st.json(info['sample_record'])
                
                # Analyze for lead data
                st.subheader("👥 Lead Data Analysis")
                lead_candidates = analyze_lead_data_structure(discovered_tables)
                
                if lead_candidates:
                    st.write("**Potential Lead Tables:**")
                    for table_name, info in lead_candidates.items():
                        st.write(f"- **{table_name}** (Score: {info['indicator_score']}/7)")
                        st.write(f"  Fields: {', '.join(info['fields'])}")
                else:
                    st.warning("No clear lead data tables identified")
                
                # Analyze for transaction data
                st.subheader("💰 Transaction Data Analysis")
                transaction_candidates = analyze_transaction_data_structure(discovered_tables)
                
                if transaction_candidates:
                    st.write("**Potential Transaction Tables:**")
                    for table_name, info in transaction_candidates.items():
                        st.write(f"- **{table_name}** (Score: {info['indicator_score']}/7)")
                        st.write(f"  Fields: {', '.join(info['fields'])}")
                else:
                    st.warning("No clear transaction data tables identified")
                
                # Generate configuration recommendations
                st.subheader("⚙️ Configuration Recommendations")
                
                if lead_candidates:
                    best_lead_table = max(lead_candidates.keys(), key=lambda k: lead_candidates[k]['indicator_score'])
                    st.code(f"LEAD_TABLE_NAME = '{best_lead_table}'")
                
                if transaction_candidates:
                    best_transaction_table = max(transaction_candidates.keys(), key=lambda k: transaction_candidates[k]['indicator_score'])
                    st.code(f"TRANSACTION_TABLE_NAME = '{best_transaction_table}'")
                
            else:
                st.error("Could not discover base structure. Check API permissions.")

if __name__ == "__main__":
    main()