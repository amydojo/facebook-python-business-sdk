"""
Object Storage and Data Validation System for Ad Command Center
Provides persistent caching, API performance monitoring, and data accuracy validation
"""
import os
import json
import pickle
import hashlib
import pandas as pd
import streamlit as st
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Tuple
import requests
from pyairtable import Api

class DataStorage:
    """Enhanced object storage with caching and validation"""

    def __init__(self):
        self.cache_dir = "data_cache"
        self.performance_log = "api_performance.json"
        self.validation_log = "data_validation.json"
        self._ensure_directories()

    def _ensure_directories(self):
        """Create necessary directories"""
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)

    def _get_cache_key(self, source: str, params: Dict = None) -> str:
        """Generate cache key from source and parameters"""
        if not params:
            return hashlib.md5(source.encode()).hexdigest()

        # Convert params to a stable string representation
        try:
            # Handle dictionary parameters
            if isinstance(params, dict):
                # Use JSON serialization for consistent representation
                param_str = json.dumps(params, sort_keys=True)
            else:
                # For non-dictionaries, just use string representation
                param_str = str(params)

            return hashlib.md5(f"{source}_{param_str}".encode()).hexdigest()

        except Exception as e:
            # Fallback for any serialization errors
            import random
            random_suffix = random.randint(1, 100000)
            st.warning(f"Cache key generation error: {str(e)}. Using randomized key.")
            return hashlib.md5(f"{source}_{random_suffix}".encode()).hexdigest()

    def _dict_to_str(self, d: Dict) -> str:
        """Helper to convert a dictionary to a stable string representation"""
        if not isinstance(d, dict):
            return str(d)

        parts = []
        for k in sorted(d.keys()):
            v = d[k]
            if isinstance(v, dict):
                v_str = self._dict_to_str(v)
            else:
                v_str = str(v)
            parts.append(f"{k}:{v_str}")

        return "{" + ",".join(parts) + "}"

    def _get_cache_path(self, cache_key: str) -> str:
        """Get full path for cache file"""
        return os.path.join(self.cache_dir, f"{cache_key}.pkl")

    def is_cache_valid(self, cache_key: str, max_age_hours: float = 1.0) -> bool:
        """Check if cached data is still valid"""
        cache_path = self._get_cache_path(cache_key)
        if not os.path.exists(cache_path):
            return False

        file_time = datetime.fromtimestamp(os.path.getmtime(cache_path))
        return datetime.now() - file_time < timedelta(hours=max_age_hours)

    def save_to_cache(self, cache_key: str, data: Any, metadata: Dict = None) -> bool:
        """Save data to cache with metadata"""
        try:
            cache_path = self._get_cache_path(cache_key)
            cache_data = {
                'data': data,
                'metadata': metadata or {},
                'timestamp': datetime.now().isoformat(),
                'version': '1.0'
            }

            with open(cache_path, 'wb') as f:
                pickle.dump(cache_data, f)
            return True
        except Exception as e:
            st.error(f"Cache save error: {str(e)}")
            return False

    def load_from_cache(self, cache_key: str) -> Tuple[Any, Dict]:
        """Load data from cache with metadata"""
        try:
            cache_path = self._get_cache_path(cache_key)
            if not os.path.exists(cache_path):
                return None, {}

            with open(cache_path, 'rb') as f:
                cache_data = pickle.load(f)

            return cache_data.get('data'), cache_data.get('metadata', {})
        except Exception as e:
            st.error(f"Cache load error: {str(e)}")
            return None, {}

    def log_api_performance(self, source: str, response_time: float, 
                          status: str, record_count: int = 0, error: str = None):
        """Log API performance metrics"""
        try:
            log_entry = {
                'timestamp': datetime.now().isoformat(),
                'source': source,
                'response_time': response_time,
                'status': status,
                'record_count': record_count,
                'error': error
            }

            # Load existing log
            performance_data = []
            if os.path.exists(self.performance_log):
                with open(self.performance_log, 'r') as f:
                    performance_data = json.load(f)

            # Add new entry
            performance_data.append(log_entry)

            # Keep only last 1000 entries
            performance_data = performance_data[-1000:]

            # Save updated log
            with open(self.performance_log, 'w') as f:
                json.dump(performance_data, f, indent=2)

        except Exception as e:
            st.warning(f"Performance logging error: {str(e)}")

    def get_api_performance_stats(self, hours: int = 24) -> Dict:
        """Get API performance statistics"""
        try:
            if not os.path.exists(self.performance_log):
                return {}

            with open(self.performance_log, 'r') as f:
                performance_data = json.load(f)

            # Filter to last N hours
            cutoff_time = datetime.now() - timedelta(hours=hours)
            recent_data = [
                entry for entry in performance_data
                if datetime.fromisoformat(entry['timestamp']) > cutoff_time
            ]

            if not recent_data:
                return {}

            # Calculate statistics
            by_source = {}
            for entry in recent_data:
                source = entry['source']
                if source not in by_source:
                    by_source[source] = {
                        'total_calls': 0,
                        'success_calls': 0,
                        'total_response_time': 0,
                        'total_records': 0,
                        'errors': []
                    }

                by_source[source]['total_calls'] += 1
                by_source[source]['total_response_time'] += entry['response_time']
                by_source[source]['total_records'] += entry['record_count']

                if entry['status'] == 'success':
                    by_source[source]['success_calls'] += 1
                elif entry['error']:
                    by_source[source]['errors'].append(entry['error'])

            # Calculate averages and rates
            stats = {}
            for source, data in by_source.items():
                stats[source] = {
                    'total_calls': data['total_calls'],
                    'success_rate': data['success_calls'] / data['total_calls'] * 100,
                    'avg_response_time': data['total_response_time'] / data['total_calls'],
                    'total_records': data['total_records'],
                    'error_count': len(data['errors']),
                    'recent_errors': data['errors'][-3:]  # Last 3 errors
                }

            return stats

        except Exception as e:
            st.error(f"Performance stats error: {str(e)}")
            return {}

class DataValidator:
    """Data accuracy and integrity validation"""

    def __init__(self):
        self.validation_rules = {
            'airtable_leads': {
                'required_columns': ['id'],
                'date_columns': ['Date', 'Inbound', 'Created'],
                'numeric_columns': ['Amount', 'Value'],
                'expected_min_records': 1
            },
            'meta_campaigns': {
                'required_fields': ['id', 'name'],
                'numeric_fields': ['spend', 'impressions', 'clicks'],
                'expected_min_records': 1
            },
            'meta_insights': {
                'required_fields': ['campaign_id', 'spend', 'impressions'],
                'numeric_fields': ['spend', 'impressions', 'clicks', 'ctr', 'cpc'],
                'expected_min_records': 1
            }
        }

    def validate_dataframe(self, df: pd.DataFrame, data_type: str) -> Dict[str, Any]:
        """Validate DataFrame against rules"""
        validation_result = {
            'valid': True,
            'warnings': [],
            'errors': [],
            'stats': {},
            'timestamp': datetime.now().isoformat()
        }

        if df is None or df.empty:
            validation_result['valid'] = False
            validation_result['errors'].append(f"No data found for {data_type}")
            return validation_result

        rules = self.validation_rules.get(data_type, {})

        # Check record count
        min_records = rules.get('expected_min_records', 1)
        if len(df) < min_records:
            validation_result['warnings'].append(
                f"Low record count: {len(df)} (expected >= {min_records})"
            )

        # Check required columns
        required_cols = rules.get('required_columns', [])
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            validation_result['errors'].append(f"Missing required columns: {missing_cols}")
            validation_result['valid'] = False

        # Check date columns
        date_cols = rules.get('date_columns', [])
        for col in date_cols:
            if col in df.columns:
                try:
                    pd.to_datetime(df[col], errors='coerce')
                except Exception as e:
                    validation_result['warnings'].append(f"Date parsing issues in {col}: {str(e)}")

        # Check numeric columns
        numeric_cols = rules.get('numeric_columns', [])
        for col in numeric_cols:
            if col in df.columns:
                non_numeric = df[col].apply(lambda x: not pd.api.types.is_numeric_dtype(type(x)))
                if non_numeric.any():
                    validation_result['warnings'].append(f"Non-numeric values found in {col}")

        # Calculate data quality stats
        validation_result['stats'] = {
            'total_records': len(df),
            'total_columns': len(df.columns),
            'missing_values': df.isnull().sum().sum(),
            'duplicate_records': df.duplicated().sum(),
            'memory_usage_mb': df.memory_usage(deep=True).sum() / 1024 / 1024
        }

        return validation_result

    def validate_api_response(self, response_data: Any, data_type: str) -> Dict[str, Any]:
        """Validate API response data"""
        validation_result = {
            'valid': True,
            'warnings': [],
            'errors': [],
            'stats': {},
            'timestamp': datetime.now().isoformat()
        }

        if not response_data:
            validation_result['valid'] = False
            validation_result['errors'].append(f"Empty response for {data_type}")
            return validation_result

        # For list responses (like Meta API)
        if isinstance(response_data, list):
            if len(response_data) == 0:
                validation_result['warnings'].append(f"Empty list response for {data_type}")

            # Check if all items have required fields
            rules = self.validation_rules.get(data_type, {})
            required_fields = rules.get('required_fields', [])

            for i, item in enumerate(response_data[:10]):  # Check first 10 items
                missing_fields = [field for field in required_fields if field not in item]
                if missing_fields:
                    validation_result['warnings'].append(
                        f"Item {i} missing fields: {missing_fields}"
                    )

        # For dict responses
        elif isinstance(response_data, dict):
            if 'data' in response_data:
                return self.validate_api_response(response_data['data'], data_type)

        validation_result['stats'] = {
            'response_type': type(response_data).__name__,
            'item_count': len(response_data) if isinstance(response_data, (list, dict)) else 1
        }

        return validation_result

# Initialize global storage instance
storage = DataStorage()
validator = DataValidator()