"""
Quality Control Dashboard
Real-time data validation and metric verification system
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import time
from advanced_data_validation import AdvancedDataValidator, ValidationResult, MetricValidation
from reliable_data_connector import ReliableDataConnector
import logging

# Configure page
st.set_page_config(
    page_title="Quality Control Center",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def apply_quality_control_styling():
    """Apply professional quality control styling"""
    st.markdown("""
    <style>
    .stApp {
        background: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    }
    
    .quality-header {
        background: linear-gradient(135deg, #dc2626 0%, #b91c1c 100%);
        padding: 2rem;
        border-radius: 16px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
        box-shadow: 0 8px 32px rgba(220, 38, 38, 0.3);
    }
    
    .validation-card {
        background: white;
        padding: 1.5rem;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        border-left: 4px solid #10b981;
        margin: 1rem 0;
    }
    
    .validation-card.warning {
        border-left-color: #f59e0b;
    }
    
    .validation-card.error {
        border-left-color: #ef4444;
    }
    
    .quality-score {
        background: linear-gradient(135deg, #10b981, #059669);
        color: white;
        padding: 1rem;
        border-radius: 8px;
        text-align: center;
        margin: 0.5rem 0;
    }
    
    .quality-score.warning {
        background: linear-gradient(135deg, #f59e0b, #d97706);
    }
    
    .quality-score.critical {
        background: linear-gradient(135deg, #ef4444, #dc2626);
    }
    
    .metric-validation {
        background: #f0f9ff;
        border: 1px solid #0ea5e9;
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
    }
    
    .status-indicator {
        display: inline-block;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        margin-right: 8px;
    }
    
    .status-success { background-color: #10b981; }
    .status-warning { background-color: #f59e0b; }
    .status-error { background-color: #ef4444; }
    
    /* Hide Streamlit elements */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    .stDeployButton {display: none;}
    </style>
    """, unsafe_allow_html=True)

def display_quality_header():
    """Display the quality control header"""
    st.markdown("""
    <div class="quality-header">
        <h1>🛡️ Quality Control Center</h1>
        <p>Advanced Data Validation & Metric Verification</p>
    </div>
    """, unsafe_allow_html=True)

def display_validation_summary(audit_results: dict):
    """Display comprehensive validation summary"""
    st.subheader("📊 Validation Summary")
    
    overall_score = audit_results.get('overall_quality_score', 0.0)
    
    # Determine quality level
    if overall_score >= 0.95:
        score_class = "quality-score"
        status_text = "EXCELLENT"
        status_color = "success"
    elif overall_score >= 0.85:
        score_class = "quality-score warning"
        status_text = "GOOD"
        status_color = "warning"
    else:
        score_class = "quality-score critical"
        status_text = "NEEDS ATTENTION"
        status_color = "error"
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(f"""
        <div class="{score_class}">
            <h3 style="margin:0;">{overall_score:.1%}</h3>
            <p style="margin:0;">Overall Quality</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        transactions_result = audit_results.get('transactions_validation')
        trans_score = getattr(transactions_result, 'data_quality_score', 0.0) if transactions_result else 0.0
        trans_count = getattr(transactions_result, 'record_count', 0) if transactions_result else 0
        st.markdown(f"""
        <div class="validation-card">
            <h4 style="margin:0; color:#1e293b;">Transactions</h4>
            <p style="margin:0; color:#64748b;">{trans_score:.1%} Quality</p>
            <span class="status-indicator status-{status_color}"></span>{trans_count} Records
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        leads_result = audit_results.get('leads_validation')
        leads_score = getattr(leads_result, 'data_quality_score', 0.0) if leads_result else 0.0
        leads_count = getattr(leads_result, 'record_count', 0) if leads_result else 0
        st.markdown(f"""
        <div class="validation-card">
            <h4 style="margin:0; color:#1e293b;">Leads</h4>
            <p style="margin:0; color:#64748b;">{leads_score:.1%} Quality</p>
            <span class="status-indicator status-{status_color}"></span>{leads_count} Records
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        meta_result = audit_results.get('meta_validation')
        meta_score = getattr(meta_result, 'data_quality_score', 0.0) if meta_result else 0.0
        st.markdown(f"""
        <div class="validation-card">
            <h4 style="margin:0; color:#1e293b;">Meta API</h4>
            <p style="margin:0; color:#64748b;">{meta_score:.1%} Quality</p>
            <span class="status-indicator status-{status_color}"></span>Connected
        </div>
        """, unsafe_allow_html=True)

def display_data_source_validation(audit_results: dict):
    """Display detailed data source validation results"""
    st.subheader("🔍 Data Source Validation")
    
    tab1, tab2, tab3 = st.tabs(["Transactions", "Leads", "Meta API"])
    
    with tab1:
        transactions_result = audit_results.get('transactions_validation')
        if transactions_result:
            display_validation_details("Transaction Data", transactions_result)
        else:
            st.error("Transaction validation not available")
    
    with tab2:
        leads_result = audit_results.get('leads_validation')
        if leads_result:
            display_validation_details("Lead Data", leads_result)
        else:
            st.error("Lead validation not available")
    
    with tab3:
        meta_result = audit_results.get('meta_validation')
        if meta_result:
            display_validation_details("Meta API Data", meta_result)
        else:
            st.error("Meta API validation not available")

def display_validation_details(data_type: str, result: ValidationResult):
    """Display detailed validation results for a data source"""
    
    # Quality score display
    score_class = "validation-card"
    if result.data_quality_score < 0.85:
        score_class += " error"
    elif result.data_quality_score < 0.95:
        score_class += " warning"
    
    st.markdown(f"""
    <div class="{score_class}">
        <h4>{data_type} Quality Assessment</h4>
        <p><strong>Quality Score:</strong> {result.data_quality_score:.1%}</p>
        <p><strong>Confidence:</strong> {result.confidence_score:.1%}</p>
        <p><strong>Records:</strong> {result.record_count:,}</p>
        <p><strong>Coverage:</strong> {result.coverage_percentage:.1f}%</p>
        <p><strong>Validated:</strong> {result.validation_timestamp.strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Issues and warnings
    if result.issues:
        st.error("**Critical Issues Found:**")
        for issue in result.issues:
            st.error(f"• {issue}")
    
    if result.warnings:
        st.warning("**Warnings:**")
        for warning in result.warnings:
            st.warning(f"• {warning}")
    
    if not result.issues and not result.warnings:
        st.success("✅ No issues detected - data quality is excellent")

def display_metric_validation(audit_results: dict):
    """Display metric calculation validation results"""
    st.subheader("📈 Metric Validation")
    
    metric_validations = audit_results.get('metric_validations', [])
    
    if not metric_validations:
        st.warning("No metric validations available")
        return
    
    for validation in metric_validations:
        display_metric_validation_card(validation)

def display_metric_validation_card(validation: MetricValidation):
    """Display individual metric validation card"""
    
    # Determine validation status
    if validation.is_accurate and validation.variance_percentage <= 5.0:
        status_class = "metric-validation"
        status_icon = "✅"
        status_text = "VERIFIED"
    elif validation.variance_percentage <= 10.0:
        status_class = "metric-validation"
        status_icon = "⚠️"
        status_text = "ACCEPTABLE"
    else:
        status_class = "metric-validation"
        status_icon = "❌"
        status_text = "REQUIRES REVIEW"
    
    st.markdown(f"""
    <div class="{status_class}">
        <h4>{status_icon} {validation.metric_name} - {status_text}</h4>
        <p><strong>Calculated Value:</strong> {validation.calculated_value:,.2f}</p>
        <p><strong>Verification Value:</strong> {validation.verification_value:,.2f if validation.verification_value else 'N/A'}</p>
        <p><strong>Variance:</strong> {validation.variance_percentage:.2f}%</p>
        <p><strong>Method:</strong> {validation.calculation_method}</p>
        <p><strong>Sources:</strong> {', '.join(validation.data_sources)}</p>
    </div>
    """, unsafe_allow_html=True)

def display_cross_validation_results(audit_results: dict):
    """Display cross-validation results between data sources"""
    st.subheader("🔗 Cross-Validation Analysis")
    
    cross_validation = audit_results.get('cross_validation', {})
    
    if not cross_validation:
        st.warning("Cross-validation data not available")
        return
    
    # Cross-validation score
    cross_score = cross_validation.get('cross_validation_score', 0.0)
    is_consistent = cross_validation.get('is_consistent', False)
    
    col1, col2 = st.columns(2)
    
    with col1:
        score_class = "quality-score"
        if cross_score < 0.85:
            score_class += " critical"
        elif cross_score < 0.95:
            score_class += " warning"
        
        st.markdown(f"""
        <div class="{score_class}">
            <h3 style="margin:0;">{cross_score:.1%}</h3>
            <p style="margin:0;">Cross-Validation Score</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        consistency_status = "✅ CONSISTENT" if is_consistent else "❌ INCONSISTENT"
        st.markdown(f"""
        <div class="validation-card">
            <h4 style="margin:0;">{consistency_status}</h4>
            <p style="margin:0;">Data Alignment Status</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Cross-validation issues
    issues = cross_validation.get('issues', [])
    warnings = cross_validation.get('warnings', [])
    
    if issues:
        st.error("**Cross-Validation Issues:**")
        for issue in issues:
            st.error(f"• {issue}")
    
    if warnings:
        st.warning("**Cross-Validation Warnings:**")
        for warning in warnings:
            st.warning(f"• {warning}")
    
    # Data alignment metrics
    alignment = cross_validation.get('data_alignment', {})
    if alignment:
        st.info("**Data Alignment Metrics:**")
        st.info(f"• Transaction/Lead Ratio: {alignment.get('transactions_leads_ratio', 0):.3f}")
        st.info(f"• Coverage Alignment: {alignment.get('coverage_alignment', 0):.1f}% difference")

def display_quality_recommendations(audit_results: dict):
    """Display actionable quality improvement recommendations"""
    st.subheader("💡 Quality Improvement Recommendations")
    
    recommendations = audit_results.get('recommendations', [])
    
    if not recommendations:
        st.success("✅ No recommendations - data quality is optimal")
        return
    
    for i, recommendation in enumerate(recommendations, 1):
        st.info(f"**{i}.** {recommendation}")

def create_quality_trend_chart(audit_results: dict):
    """Create quality trend visualization"""
    
    # Create quality trend based on current validation results
    
    transactions_result = audit_results.get('transactions_validation')
    leads_result = audit_results.get('leads_validation')
    meta_result = audit_results.get('meta_validation')
    
    if not any([transactions_result, leads_result, meta_result]):
        return None
    
    # Generate trend data for last 7 days
    dates = [(datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(7, 0, -1)]
    
    fig = go.Figure()
    
    # Add trend lines with safe attribute access
    if transactions_result:
        trans_score = getattr(transactions_result, 'data_quality_score', 0.0)
        fig.add_trace(go.Scatter(
            x=dates,
            y=[trans_score] * 7,
            mode='lines+markers',
            name='Transactions',
            line=dict(color='#10b981', width=3)
        ))
    
    if leads_result:
        leads_score = getattr(leads_result, 'data_quality_score', 0.0)
        fig.add_trace(go.Scatter(
            x=dates,
            y=[leads_score] * 7,
            mode='lines+markers',
            name='Leads',
            line=dict(color='#3b82f6', width=3)
        ))
    
    if meta_result:
        meta_score = getattr(meta_result, 'data_quality_score', 0.0)
        fig.add_trace(go.Scatter(
            x=dates,
            y=[meta_score] * 7,
            mode='lines+markers',
            name='Meta API',
            line=dict(color='#8b5cf6', width=3)
        ))
    
    fig.update_layout(
        title="Data Quality Trends (Last 7 Days)",
        xaxis_title="Date",
        yaxis_title="Quality Score",
        yaxis=dict(range=[0, 1], tickformat='.0%'),
        template="plotly_white",
        height=400
    )
    
    return fig

def main():
    """Main quality control dashboard"""
    apply_quality_control_styling()
    display_quality_header()
    
    # Date range controls
    col1, col2, col3 = st.columns([2, 2, 3])
    
    with col1:
        start_date = st.date_input(
            "Start Date",
            value=datetime.now() - timedelta(days=30),
            key="qc_start_date"
        )
    
    with col2:
        end_date = st.date_input(
            "End Date",
            value=datetime.now(),
            key="qc_end_date"
        )
    
    with col3:
        if st.button("🔍 Run Quality Audit", type="primary"):
            st.session_state.run_audit = True
    
    # Auto-run audit on page load or when requested
    if st.session_state.get('run_audit', True):
        
        # Initialize validator
        validator = AdvancedDataValidator()
        
        # Convert dates to strings
        start_str = start_date.strftime('%Y-%m-%d')
        end_str = end_date.strftime('%Y-%m-%d')
        
        # Run comprehensive audit
        with st.spinner("🔍 Running comprehensive data quality audit..."):
            audit_results = validator.comprehensive_data_audit(start_str, end_str)
        
        # Display results
        display_validation_summary(audit_results)
        
        # Quality trend chart
        trend_chart = create_quality_trend_chart(audit_results)
        if trend_chart:
            st.plotly_chart(trend_chart, use_container_width=True)
        
        # Detailed validation results
        display_data_source_validation(audit_results)
        
        # Metric validation
        display_metric_validation(audit_results)
        
        # Cross-validation
        display_cross_validation_results(audit_results)
        
        # Recommendations
        display_quality_recommendations(audit_results)
        
        # Audit summary
        audit_duration = audit_results.get('audit_duration', 0)
        st.info(f"✅ Quality audit completed in {audit_duration:.1f} seconds")
        
        # Reset run flag
        st.session_state.run_audit = False

if __name__ == "__main__":
    main()