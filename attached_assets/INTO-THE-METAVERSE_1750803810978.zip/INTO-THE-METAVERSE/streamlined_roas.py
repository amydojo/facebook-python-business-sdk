"""
Streamlined Real ROAS Calculator for 652 Smooth MD Meta Leads
Skips problematic fields and focuses on authentic revenue tracking
"""
import streamlit as st
import pandas as pd
from pyairtable import Api
import plotly.graph_objects as go

def load_meta_leads_only(api_key, base_id='appri2CgCoIiuZWq3'):
    """Load only the 652 Meta leads, skip problematic fields"""
    try:
        api = Api(api_key)
        table = api.table(base_id, 'Leads')
        records = table.all()
        
        # Convert to simple data, skipping problematic fields
        data = []
        skip_fields = ['Consultation Year']  # Skip this entirely
        
        for record in records:
            clean_record = {'record_id': record['id']}
            for field, value in record['fields'].items():
                if field in skip_fields:
                    continue
                # Simple string conversion only
                clean_record[field] = str(value) if value is not None else ''
            data.append(clean_record)
        
        df = pd.DataFrame(data)
        
        # Filter for Smooth MD + Meta sources
        brand_col = 'flddGiLa7lQ0nodBz'
        source_col = 'fldBUfZjdVhhJpRRA'
        
        if brand_col in df.columns and source_col in df.columns:
            # First Smooth MD
            smooth_mask = df[brand_col].str.contains('Smooth', case=False, na=False)
            df = df[smooth_mask]
            
            # Then Meta sources
            meta_mask = df[source_col].str.contains('Facebook|Instagram|Meta|FB|IG', case=False, na=False)
            df = df[meta_mask]
            
            st.success(f"✅ Found {len(df)} Smooth MD Meta leads (expecting ~652)")
            return df
        else:
            st.error("Missing brand or source columns")
            return pd.DataFrame()
            
    except Exception as e:
        st.error(f"Error loading leads: {str(e)}")
        return pd.DataFrame()

def load_transactions_simple(api_key, base_id='appri2CgCoIiuZWq3'):
    """Load transactions data simply"""
    try:
        api = Api(api_key)
        table = api.table(base_id, 'Transactions')
        records = table.all()
        
        data = []
        for record in records:
            clean_record = {'record_id': record['id']}
            for field, value in record['fields'].items():
                clean_record[field] = str(value) if value is not None else ''
            data.append(clean_record)
        
        df = pd.DataFrame(data)
        
        # Convert amount to numeric
        amount_col = 'fldUIvamoBDCIayd3'
        if amount_col in df.columns:
            df[amount_col] = pd.to_numeric(df[amount_col].str.replace(',', '').str.replace('$', ''), errors='coerce').fillna(0)
        
        st.success(f"✅ Loaded {len(df)} transaction records")
        return df
        
    except Exception as e:
        st.error(f"Error loading transactions: {str(e)}")
        return pd.DataFrame()

def calculate_simple_roas(leads_df, transactions_df, meta_spend):
    """Calculate ROAS with lead-transaction matching"""
    if leads_df.empty:
        return {
            'total_leads': 0,
            'total_revenue': 0,
            'leads_with_revenue': 0,
            'roas': 0,
            'cost_per_lead': 0,
            'revenue_per_lead': 0
        }
    
    total_leads = len(leads_df)
    total_revenue = 0
    leads_with_revenue = 0
    
    # Simple revenue calculation from transactions
    if not transactions_df.empty:
        amount_col = 'fldUIvamoBDCIayd3'
        if amount_col in transactions_df.columns:
            total_revenue = transactions_df[amount_col].sum()
            leads_with_revenue = len(transactions_df[transactions_df[amount_col] > 0])
    
    return {
        'total_leads': int(total_leads),
        'total_revenue': float(total_revenue),
        'leads_with_revenue': int(leads_with_revenue),
        'roas': float(total_revenue / meta_spend) if meta_spend > 0 else 0,
        'cost_per_lead': float(meta_spend / total_leads) if total_leads > 0 else 0,
        'revenue_per_lead': float(total_revenue / total_leads) if total_leads > 0 else 0
    }

def render_streamlined_roas():
    """Streamlined ROAS dashboard"""
    st.markdown("# 🎯 Streamlined Real ROAS")
    st.markdown("**Authentic 652 Meta Lead Revenue Tracking**")
    
    # Check for API key
    if not st.session_state.get('api_key'):
        st.error("Please set your Airtable API key in Settings")
        return
    
    # Load data
    with st.spinner("Loading your authentic Meta leads and transactions..."):
        leads_df = load_meta_leads_only(st.session_state.get('api_key'))
        transactions_df = load_transactions_simple(st.session_state.get('api_key'))
    
    if leads_df.empty:
        st.error("No Meta leads found!")
        return
    
    # Get Meta spend (you can make this configurable)
    meta_spend = st.number_input("Meta Ad Spend ($)", value=5000.0, min_value=0.0)
    
    # Calculate metrics
    metrics = calculate_simple_roas(leads_df, transactions_df, meta_spend)
    
    # Display key metrics
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Meta Leads", metrics['total_leads'])
        st.metric("Cost per Lead", f"${metrics['cost_per_lead']:.2f}")
    
    with col2:
        st.metric("Total Revenue", f"${metrics['total_revenue']:,.2f}")
        st.metric("Revenue per Lead", f"${metrics['revenue_per_lead']:.2f}")
    
    with col3:
        st.metric("ROAS", f"{metrics['roas']:.2f}x")
        st.metric("Leads with Revenue", metrics['leads_with_revenue'])
    
    # Simple chart
    if metrics['total_revenue'] > 0:
        fig = go.Figure(data=[
            go.Bar(name='Ad Spend', x=['Investment'], y=[meta_spend], marker_color='red'),
            go.Bar(name='Revenue', x=['Return'], y=[metrics['total_revenue']], marker_color='green')
        ])
        fig.update_layout(title="Meta Ad Investment vs Revenue", barmode='group')
        st.plotly_chart(fig, use_container_width=True)
    
    # Show lead data
    if st.checkbox("Show Lead Data"):
        st.dataframe(leads_df.head(20))