"""
KV Store Optimized Dashboard
Ultra-fast dashboard leveraging Replit's built-in Key-Value Store for instant data access
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import logging
from enhanced_data_connector import EnhancedDataConnector

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Marketing Intelligence Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for professional styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        margin-bottom: 1rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        margin: 0.5rem 0;
    }
    .cache-indicator {
        background: #28a745;
        color: white;
        padding: 0.25rem 0.5rem;
        border-radius: 4px;
        font-size: 0.8rem;
        margin-left: 0.5rem;
    }
    .performance-badge {
        background: #17a2b8;
        color: white;
        padding: 0.2rem 0.4rem;
        border-radius: 3px;
        font-size: 0.75rem;
    }
</style>
""", unsafe_allow_html=True)

@st.cache_data(ttl=300)
def load_dashboard_data(start_date: str, end_date: str):
    """Load dashboard data with Streamlit caching as backup"""
    connector = EnhancedDataConnector()
    
    # Load data using KV Store optimized methods
    transactions_result = connector.load_transactions_optimized(start_date, end_date)
    leads_result = connector.load_leads_optimized(start_date, end_date)
    meta_result = connector.load_meta_insights_optimized(start_date, end_date)
    
    return transactions_result, leads_result, meta_result

def create_performance_overview(transactions_data, leads_data, meta_data):
    """Create performance overview section"""
    
    st.markdown('<div class="main-header">📊 Performance Overview</div>', unsafe_allow_html=True)
    
    # Key metrics row
    col1, col2, col3, col4 = st.columns(4)
    
    total_revenue = transactions_data.get('total_revenue', 0)
    total_spend = meta_data.get('total_spend', 0)
    total_leads = leads_data.get('total_leads', 0)
    roas = (total_revenue / total_spend) if total_spend > 0 else 0
    
    with col1:
        st.metric(
            "Total Revenue", 
            f"${total_revenue:,.2f}",
            delta=f"From {transactions_data.get('total_transactions', 0)} transactions"
        )
    
    with col2:
        st.metric(
            "Ad Spend", 
            f"${total_spend:,.2f}",
            delta=f"{meta_data.get('impressions', 0):,} impressions"
        )
    
    with col3:
        st.metric(
            "ROAS", 
            f"{roas:.2f}x",
            delta="Return on Ad Spend"
        )
    
    with col4:
        st.metric(
            "Total Leads", 
            f"{total_leads:,}",
            delta=f"From Meta campaigns"
        )

def create_revenue_chart(transactions_data):
    """Create revenue trend visualization"""
    
    if not transactions_data.get('success') or not transactions_data.get('transactions'):
        st.warning("No transaction data available for visualization")
        return
    
    # Convert to DataFrame
    df = pd.DataFrame(transactions_data['transactions'])
    df['date'] = pd.to_datetime(df['date'])
    
    # Daily revenue aggregation
    daily_revenue = df.groupby('date')['amount'].sum().reset_index()
    
    # Create line chart
    fig = px.line(
        daily_revenue, 
        x='date', 
        y='amount',
        title='Daily Revenue Trend',
        labels={'amount': 'Revenue ($)', 'date': 'Date'}
    )
    
    fig.update_layout(
        height=400,
        showlegend=False,
        hovermode='x unified'
    )
    
    st.plotly_chart(fig, use_container_width=True)

def create_performance_gauge(value, title, max_value=None):
    """Create performance gauge chart"""
    
    if max_value is None:
        max_value = value * 1.5 if value > 0 else 100
    
    fig = go.Figure(go.Indicator(
        mode = "gauge+number+delta",
        value = value,
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': title},
        gauge = {
            'axis': {'range': [None, max_value]},
            'bar': {'color': "darkblue"},
            'steps': [
                {'range': [0, max_value*0.5], 'color': "lightgray"},
                {'range': [max_value*0.5, max_value*0.8], 'color': "gray"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': max_value*0.9
            }
        }
    ))
    
    fig.update_layout(height=300)
    return fig

def display_cache_performance(connector):
    """Display cache performance metrics"""
    
    st.markdown("### ⚡ Performance Optimization")
    
    cache_stats = connector.get_cache_stats()
    
    if cache_stats.get('enabled'):
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric(
                "Transactions Cached", 
                cache_stats.get('transactions_cached_entries', 0),
                help="Number of cached transaction datasets"
            )
        
        with col2:
            st.metric(
                "Leads Cached", 
                cache_stats.get('leads_cached_entries', 0),
                help="Number of cached lead datasets"
            )
        
        with col3:
            st.metric(
                "Meta Insights Cached", 
                cache_stats.get('meta_cached_entries', 0),
                help="Number of cached Meta API responses"
            )
        
        # Cache management buttons
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("🔄 Refresh Transactions"):
                connector.invalidate_cache('transactions')
                st.success("Transaction cache cleared")
                st.rerun()
        
        with col2:
            if st.button("🔄 Refresh Leads"):
                connector.invalidate_cache('leads')
                st.success("Lead cache cleared")
                st.rerun()
        
        with col3:
            if st.button("🧹 Cleanup Expired"):
                cleaned = connector.cleanup_expired_cache()
                st.success(f"Cleaned {cleaned} expired entries")
                st.rerun()
    else:
        st.info("Cache system not available - using standard data loading")

def create_meta_insights_dashboard(meta_data):
    """Create Meta insights visualization"""
    
    if not meta_data.get('success'):
        st.warning("Meta insights data not available")
        return
    
    st.markdown("### 📈 Meta Campaign Performance")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # CTR Gauge
        ctr = meta_data.get('ctr', 0)
        ctr_fig = create_performance_gauge(ctr, "Click-Through Rate (%)", 10)
        st.plotly_chart(ctr_fig, use_container_width=True)
    
    with col2:
        # CPM Gauge  
        cpm = meta_data.get('cpm', 0)
        cpm_fig = create_performance_gauge(cpm, "Cost Per Mille ($)", 50)
        st.plotly_chart(cpm_fig, use_container_width=True)
    
    # Additional metrics
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Total Clicks", f"{meta_data.get('clicks', 0):,}")
    
    with col2:
        st.metric("Reach", f"{meta_data.get('reach', 0):,}")
    
    with col3:
        st.metric("Frequency", f"{meta_data.get('frequency', 0):.2f}")

def main():
    """Main dashboard application"""
    
    st.markdown('<div class="main-header">🚀 Marketing Intelligence Dashboard</div>', unsafe_allow_html=True)
    st.markdown("**Powered by Replit Key-Value Store for instant data access**")
    
    # Sidebar controls
    st.sidebar.markdown("## 📅 Date Range Selection")
    
    # Date range picker
    col1, col2 = st.sidebar.columns(2)
    with col1:
        start_date = st.date_input(
            "Start Date",
            value=datetime.now() - timedelta(days=30),
            max_value=datetime.now()
        )
    
    with col2:
        end_date = st.date_input(
            "End Date",
            value=datetime.now(),
            max_value=datetime.now()
        )
    
    # Convert to strings
    start_date_str = start_date.strftime('%Y-%m-%d')
    end_date_str = end_date.strftime('%Y-%m-%d')
    
    # Data loading with performance timing
    with st.spinner("Loading optimized data..."):
        start_time = datetime.now()
        
        try:
            transactions_data, leads_data, meta_data = load_dashboard_data(
                start_date_str, end_date_str
            )
            
            load_time = (datetime.now() - start_time).total_seconds()
            
            # Performance indicator
            source_indicator = ""
            if transactions_data.get('source') == 'kv_cache':
                source_indicator = '<span class="cache-indicator">⚡ KV Cache Hit</span>'
            elif transactions_data.get('source') == 'airtable_api':
                source_indicator = '<span class="performance-badge">🔄 Fresh Data</span>'
            
            st.markdown(
                f'<div style="text-align: right; margin-bottom: 1rem;">'
                f'Load Time: {load_time:.2f}s {source_indicator}</div>',
                unsafe_allow_html=True
            )
            
        except Exception as e:
            st.error(f"Data loading error: {e}")
            logger.error(f"Dashboard data loading error: {e}")
            return
    
    # Create dashboard sections
    create_performance_overview(transactions_data, leads_data, meta_data)
    
    st.markdown("---")
    
    # Revenue visualization
    st.markdown("### 💰 Revenue Analysis")
    create_revenue_chart(transactions_data)
    
    st.markdown("---")
    
    # Meta insights
    create_meta_insights_dashboard(meta_data)
    
    st.markdown("---")
    
    # Cache performance section
    connector = EnhancedDataConnector()
    display_cache_performance(connector)
    
    # Data quality indicators
    st.sidebar.markdown("## 📊 Data Quality")
    
    # Transaction data quality
    if transactions_data.get('success'):
        st.sidebar.success(f"✅ Transactions: {transactions_data.get('total_transactions', 0)}")
    else:
        st.sidebar.error("❌ Transaction data unavailable")
    
    # Lead data quality
    if leads_data.get('success'):
        st.sidebar.success(f"✅ Leads: {leads_data.get('total_leads', 0)}")
    else:
        st.sidebar.error("❌ Lead data unavailable")
    
    # Meta data quality
    if meta_data.get('success'):
        st.sidebar.success(f"✅ Meta: ${meta_data.get('total_spend', 0):.2f} spend")
    else:
        st.sidebar.error("❌ Meta data unavailable")
    
    # Footer
    st.markdown("---")
    st.markdown(
        "**Powered by Enhanced Data Connector with KV Store Integration** | "
        "Real-time data validation and intelligent caching for optimal performance"
    )

if __name__ == "__main__":
    main()