"""
Comprehensive Metrics Audit Tool
Validates all calculated metrics for accuracy and alignment with development specifications
"""

import streamlit as st
from unified_production_connector import unified_connector
from advanced_lead_matcher import advanced_lead_matcher
from datetime import datetime, timedelta
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def audit_revenue_calculations():
    """Audit revenue calculation accuracy"""
    
    st.markdown("## Revenue Calculation Audit")
    
    # Load sample data for last 30 days
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    # Get raw data
    transaction_result = unified_connector.load_transactions(start_date, end_date)
    lead_result = unified_connector.load_leads(start_date, end_date)
    
    if not transaction_result.success or not lead_result.success:
        st.error("Failed to load data for audit")
        return
    
    # Process through the system
    meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data)
    matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
        meta_leads, transaction_result.data
    )
    
    # Manual verification
    st.markdown("### Manual Verification")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**System Calculations:**")
        st.metric("Total Meta Leads", len(meta_leads))
        st.metric("Matched Leads", len([l for l in matched_leads if l['matched_transactions']]))
        st.metric("System Revenue", f"${matching_stats.get('total_matched_revenue', 0):,.2f}")
        st.metric("Attribution Rate", f"{matching_stats.get('attribution_rate', 0):.1f}%")
    
    with col2:
        st.markdown("**Manual Verification:**")
        
        # Manual revenue calculation
        manual_revenue = 0
        manual_matched = 0
        
        for lead in matched_leads:
            if lead['matched_transactions']:
                manual_matched += 1
                for tx in lead['matched_transactions']:
                    tx_amount = tx.get('amount', 0)
                    if 500 <= tx_amount <= 50000:  # Same validation as system
                        manual_revenue += tx_amount
        
        manual_attribution = (manual_matched / len(meta_leads) * 100) if meta_leads else 0
        
        st.metric("Manual Matched", manual_matched)
        st.metric("Manual Revenue", f"${manual_revenue:,.2f}")
        st.metric("Manual Attribution", f"{manual_attribution:.1f}%")
        
        # Validation
        revenue_match = abs(manual_revenue - matching_stats.get('total_matched_revenue', 0)) < 1
        attribution_match = abs(manual_attribution - matching_stats.get('attribution_rate', 0)) < 0.1
        
        if revenue_match and attribution_match:
            st.success("✓ Revenue calculations verified")
        else:
            st.error("✗ Revenue calculation mismatch detected")

def audit_roas_calculations():
    """Audit ROAS calculation accuracy"""
    
    st.markdown("## ROAS Calculation Audit")
    
    # Test different ad spend scenarios
    test_scenarios = [
        {"spend": 1000, "revenue": 12570, "expected_roas": 12.57},
        {"spend": 2000, "revenue": 12570, "expected_roas": 6.285},
        {"spend": 5000, "revenue": 12570, "expected_roas": 2.514},
    ]
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("**Scenario**")
    with col2:
        st.markdown("**Calculated ROAS**")
    with col3:
        st.markdown("**Status**")
    
    for i, scenario in enumerate(test_scenarios):
        spend = scenario["spend"]
        revenue = scenario["revenue"]
        expected = scenario["expected_roas"]
        
        # Calculate ROAS using system method
        calculated_roas = revenue / spend if spend > 0 else 0
        
        with col1:
            st.write(f"${spend:,} spend")
            st.write(f"${revenue:,} revenue")
        
        with col2:
            st.write(f"{calculated_roas:.2f}x")
        
        with col3:
            if abs(calculated_roas - expected) < 0.01:
                st.success("✓ Correct")
            else:
                st.error(f"✗ Expected {expected:.2f}x")

def audit_conversion_metrics():
    """Audit conversion rate and funnel calculations"""
    
    st.markdown("## Conversion Metrics Audit")
    
    # Load current data
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    transaction_result = unified_connector.load_transactions(start_date, end_date)
    lead_result = unified_connector.load_leads(start_date, end_date)
    
    if not transaction_result.success or not lead_result.success:
        st.error("Failed to load data for audit")
        return
    
    meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data)
    matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
        meta_leads, transaction_result.data
    )
    
    # Calculate performance metrics
    estimated_spend = len(meta_leads) * 45  # Conservative estimate
    performance_metrics = advanced_lead_matcher.calculate_performance_metrics(
        matched_leads, estimated_spend
    )
    
    # Manual verification of funnel calculations
    total_leads = len(matched_leads)
    booked_leads = len([l for l in matched_leads if l['is_booked']])
    converted_leads = len([l for l in matched_leads if l['is_converted']])
    revenue_leads = len([l for l in matched_leads if l['total_revenue'] > 0])
    
    # Manual rate calculations
    manual_booking_rate = (booked_leads / total_leads * 100) if total_leads > 0 else 0
    manual_conversion_rate = (converted_leads / total_leads * 100) if total_leads > 0 else 0
    manual_revenue_rate = (revenue_leads / total_leads * 100) if total_leads > 0 else 0
    
    # Compare with system calculations
    st.markdown("### Funnel Metrics Verification")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("**System Calculated**")
        st.metric("Booking Rate", f"{performance_metrics.get('booking_rate', 0):.1f}%")
        st.metric("Conversion Rate", f"{performance_metrics.get('conversion_rate', 0):.1f}%")
        st.metric("Revenue Rate", f"{performance_metrics.get('revenue_rate', 0):.1f}%")
    
    with col2:
        st.markdown("**Manual Calculated**")
        st.metric("Booking Rate", f"{manual_booking_rate:.1f}%")
        st.metric("Conversion Rate", f"{manual_conversion_rate:.1f}%")
        st.metric("Revenue Rate", f"{manual_revenue_rate:.1f}%")
    
    with col3:
        st.markdown("**Validation**")
        
        booking_match = abs(performance_metrics.get('booking_rate', 0) - manual_booking_rate) < 0.1
        conversion_match = abs(performance_metrics.get('conversion_rate', 0) - manual_conversion_rate) < 0.1
        revenue_match = abs(performance_metrics.get('revenue_rate', 0) - manual_revenue_rate) < 0.1
        
        if booking_match:
            st.success("✓ Booking Rate")
        else:
            st.error("✗ Booking Rate")
            
        if conversion_match:
            st.success("✓ Conversion Rate")
        else:
            st.error("✗ Conversion Rate")
            
        if revenue_match:
            st.success("✓ Revenue Rate")
        else:
            st.error("✗ Revenue Rate")

def audit_cost_metrics():
    """Audit cost per lead and cost per conversion calculations"""
    
    st.markdown("## Cost Metrics Audit")
    
    # Test scenarios
    scenarios = [
        {"leads": 652, "spend": 29340, "conversions": 4},  # Current data
        {"leads": 100, "spend": 5000, "conversions": 10},  # Test scenario
    ]
    
    for i, scenario in enumerate(scenarios):
        st.markdown(f"### Scenario {i + 1}")
        
        leads = scenario["leads"]
        spend = scenario["spend"]
        conversions = scenario["conversions"]
        
        # Calculate using system formulas
        cost_per_lead = spend / leads if leads > 0 else 0
        cost_per_conversion = spend / conversions if conversions > 0 else 0
        
        # Expected calculations
        expected_cpl = spend / leads if leads > 0 else 0
        expected_cpc = spend / conversions if conversions > 0 else 0
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.write(f"Leads: {leads:,}")
            st.write(f"Spend: ${spend:,}")
            st.write(f"Conversions: {conversions}")
        
        with col2:
            st.write(f"Cost/Lead: ${cost_per_lead:.2f}")
            st.write(f"Cost/Conversion: ${cost_per_conversion:.2f}")
        
        with col3:
            cpl_match = abs(cost_per_lead - expected_cpl) < 0.01
            cpc_match = abs(cost_per_conversion - expected_cpc) < 0.01
            
            if cpl_match:
                st.success("✓ CPL Correct")
            else:
                st.error("✗ CPL Error")
                
            if cpc_match:
                st.success("✓ CPC Correct")
            else:
                st.error("✗ CPC Error")

def audit_data_quality():
    """Audit data quality and matching accuracy"""
    
    st.markdown("## Data Quality Audit")
    
    # Load current data
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    transaction_result = unified_connector.load_transactions(start_date, end_date)
    lead_result = unified_connector.load_leads(start_date, end_date)
    
    if not transaction_result.success or not lead_result.success:
        st.error("Failed to load data for audit")
        return
    
    meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data)
    matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
        meta_leads, transaction_result.data
    )
    
    # Analyze data quality
    leads_with_email = len([l for l in meta_leads if l.get('email')])
    leads_with_phone = len([l for l in meta_leads if l.get('phone')])
    leads_with_both = len([l for l in meta_leads if l.get('email') and l.get('phone')])
    
    st.markdown("### Lead Data Quality")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Total Meta Leads", len(meta_leads))
        st.metric("Leads with Email", leads_with_email)
        email_coverage = (leads_with_email / len(meta_leads) * 100) if meta_leads else 0
        st.metric("Email Coverage", f"{email_coverage:.1f}%")
    
    with col2:
        st.metric("Leads with Phone", leads_with_phone)
        phone_coverage = (leads_with_phone / len(meta_leads) * 100) if meta_leads else 0
        st.metric("Phone Coverage", f"{phone_coverage:.1f}%")
    
    with col3:
        st.metric("Leads with Both", leads_with_both)
        both_coverage = (leads_with_both / len(meta_leads) * 100) if meta_leads else 0
        st.metric("Complete Coverage", f"{both_coverage:.1f}%")
    
    # Matching method breakdown
    st.markdown("### Matching Method Analysis")
    
    method_stats = matching_stats.get('match_methods', {})
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Direct Links", method_stats.get('direct_link_matches', 0))
    with col2:
        st.metric("Email Matches", method_stats.get('email_matches', 0))
    with col3:
        st.metric("Phone Matches", method_stats.get('phone_matches', 0))
    with col4:
        st.metric("Patient ID Matches", method_stats.get('patient_id_matches', 0))

def generate_audit_summary():
    """Generate overall audit summary"""
    
    st.markdown("## Audit Summary")
    
    # Current system metrics
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    transaction_result = unified_connector.load_transactions(start_date, end_date)
    lead_result = unified_connector.load_leads(start_date, end_date)
    
    if not transaction_result.success or not lead_result.success:
        st.error("Failed to generate summary")
        return
    
    meta_leads = advanced_lead_matcher.identify_meta_leads(lead_result.data)
    matched_leads, matching_stats = advanced_lead_matcher.match_transactions_to_leads(
        meta_leads, transaction_result.data
    )
    
    estimated_spend = len(meta_leads) * 45
    performance_metrics = advanced_lead_matcher.calculate_performance_metrics(
        matched_leads, estimated_spend
    )
    
    st.markdown("### Final Validated Metrics")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Meta Leads (Smooth MD)", len(meta_leads))
        st.metric("Attribution Rate", f"{matching_stats.get('attribution_rate', 0):.1f}%")
    
    with col2:
        st.metric("Matched Leads", len([l for l in matched_leads if l['matched_transactions']]))
        st.metric("Total Revenue", f"${matching_stats.get('total_matched_revenue', 0):,.2f}")
    
    with col3:
        st.metric("Estimated Spend", f"${estimated_spend:,.2f}")
        st.metric("ROAS", f"{performance_metrics.get('roas', 0):.2f}x")
    
    with col4:
        st.metric("Cost per Lead", f"${performance_metrics.get('cost_per_lead', 0):.2f}")
        st.metric("Cost per Conversion", f"${performance_metrics.get('cost_per_conversion', 0):,.2f}")
    
    # Validation status
    st.markdown("### Validation Status")
    
    if matching_stats.get('total_matched_revenue', 0) > 0:
        st.success("✓ Revenue calculations validated")
    else:
        st.warning("⚠ No revenue attributed")
    
    if 10 <= matching_stats.get('attribution_rate', 0) <= 60:
        st.success("✓ Attribution rate within reasonable range")
    else:
        st.warning("⚠ Attribution rate outside expected range")
    
    if 1 <= performance_metrics.get('roas', 0) <= 20:
        st.success("✓ ROAS within reasonable range")
    else:
        st.warning("⚠ ROAS outside expected range")

def main():
    """Main audit application"""
    
    st.set_page_config(
        page_title="Metrics Audit",
        page_icon="🔍",
        layout="wide"
    )
    
    st.title("🔍 Comprehensive Metrics Audit")
    st.markdown("**Validating revenue, attribution, and ROAS calculations for accuracy**")
    
    # Run all audits
    audit_revenue_calculations()
    st.markdown("---")
    
    audit_roas_calculations()
    st.markdown("---")
    
    audit_conversion_metrics()
    st.markdown("---")
    
    audit_cost_metrics()
    st.markdown("---")
    
    audit_data_quality()
    st.markdown("---")
    
    generate_audit_summary()

if __name__ == "__main__":
    main()