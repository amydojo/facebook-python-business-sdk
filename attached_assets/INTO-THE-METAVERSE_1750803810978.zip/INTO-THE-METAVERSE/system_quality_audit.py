"""
System Quality Audit & Enhancement Suite
Comprehensive quality testing and robustness enhancement for MetaPulse
"""

import os
import sys
import logging
import traceback
import pandas as pd
import streamlit as st
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import requests
from pyairtable import Api
import plotly.graph_objects as go
import plotly.express as px

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SystemQualityAuditor:
    """Comprehensive system quality auditing and enhancement"""
    
    def __init__(self):
        self.audit_results = {}
        self.recommendations = []
        self.critical_issues = []
        self.warnings = []
        
    def run_comprehensive_audit(self) -> Dict:
        """Execute complete system quality audit"""
        st.title("🔍 System Quality Audit & Enhancement")
        st.markdown("---")
        
        # Initialize audit results
        self.audit_results = {
            'timestamp': datetime.now().isoformat(),
            'environment': self._audit_environment(),
            'dependencies': self._audit_dependencies(),
            'configuration': self._audit_configuration(),
            'data_sources': self._audit_data_sources(),
            'code_quality': self._audit_code_quality(),
            'performance': self._audit_performance(),
            'security': self._audit_security(),
            'ui_ux': self._audit_ui_ux(),
            'recommendations': self.recommendations,
            'critical_issues': self.critical_issues,
            'warnings': self.warnings
        }
        
        # Display audit results
        self._display_audit_dashboard()
        
        return self.audit_results
    
    def _audit_environment(self) -> Dict:
        """Audit environment configuration and variables"""
        st.subheader("🌍 Environment Audit")
        
        env_status = {}
        required_vars = [
            'AIRTABLE_API_KEY',
            'META_ACCESS_TOKEN', 
            'META_AD_ACCOUNT_ID',
            'META_PIXEL_ID'
        ]
        
        for var in required_vars:
            exists = bool(os.getenv(var))
            env_status[var] = {
                'exists': exists,
                'length': len(os.getenv(var, '')) if exists else 0,
                'status': 'configured' if exists else 'missing'
            }
            
            if not exists:
                self.critical_issues.append(f"Missing environment variable: {var}")
        
        # Python environment
        env_status['python_version'] = sys.version
        env_status['platform'] = sys.platform
        
        self._display_env_status(env_status)
        return env_status
    
    def _audit_dependencies(self) -> Dict:
        """Audit installed packages and versions"""
        st.subheader("📦 Dependencies Audit")
        
        critical_packages = [
            'streamlit', 'pandas', 'plotly', 'pyairtable',
            'requests', 'psycopg2-binary'
        ]
        
        dep_status = {}
        for package in critical_packages:
            try:
                module = __import__(package.replace('-', '_'))
                version = getattr(module, '__version__', 'unknown')
                dep_status[package] = {
                    'installed': True,
                    'version': version,
                    'status': 'ok'
                }
            except ImportError:
                dep_status[package] = {
                    'installed': False,
                    'version': None,
                    'status': 'missing'
                }
                self.critical_issues.append(f"Missing package: {package}")
        
        self._display_dependency_status(dep_status)
        return dep_status
    
    def _audit_configuration(self) -> Dict:
        """Audit configuration management"""
        st.subheader("⚙️ Configuration Audit")
        
        config_status = {}
        
        # Check config_manager
        try:
            from config_manager import get_config
            config = get_config()
            config_status['config_manager'] = {
                'status': 'working',
                'has_airtable_config': hasattr(config, 'get_airtable_config'),
                'has_meta_config': hasattr(config, 'get_meta_config'),
                'has_data_filters': hasattr(config, 'get_data_filters')
            }
        except Exception as e:
            config_status['config_manager'] = {
                'status': 'error',
                'error': str(e)
            }
            self.critical_issues.append(f"Config manager error: {e}")
        
        # Check Streamlit config
        streamlit_config_path = '.streamlit/config.toml'
        config_status['streamlit_config'] = {
            'exists': os.path.exists(streamlit_config_path),
            'path': streamlit_config_path
        }
        
        self._display_config_status(config_status)
        return config_status
    
    def _audit_data_sources(self) -> Dict:
        """Audit data source connections and quality"""
        st.subheader("🗄️ Data Sources Audit")
        
        data_status = {}
        
        # Test Airtable connection
        try:
            from reliable_data_connector import ReliableDataConnector
            connector = ReliableDataConnector()
            
            # Test transaction data
            end_date = datetime.now().strftime('%Y-%m-%d')
            start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
            
            trans_result = connector.get_transactions(start_date, end_date)
            data_status['airtable_transactions'] = {
                'connection': 'success' if trans_result.get('success') else 'failed',
                'record_count': trans_result.get('transaction_count', 0),
                'total_revenue': trans_result.get('total_revenue', 0),
                'error': trans_result.get('error')
            }
            
            # Test leads data
            leads_result = connector.get_leads(start_date, end_date)
            data_status['airtable_leads'] = {
                'connection': 'success' if leads_result.get('success') else 'failed',
                'total_leads': leads_result.get('total_leads', 0),
                'booked_leads': leads_result.get('booked_leads', 0),
                'error': leads_result.get('error')
            }
            
            # Test Meta API
            meta_result = connector.get_meta_insights(start_date, end_date)
            data_status['meta_api'] = {
                'connection': 'success' if meta_result.get('success') else 'failed',
                'total_spend': meta_result.get('total_spend', 0),
                'error': meta_result.get('error')
            }
            
        except Exception as e:
            data_status['connector_error'] = {
                'error': str(e),
                'traceback': traceback.format_exc()
            }
            self.critical_issues.append(f"Data connector error: {e}")
        
        self._display_data_status(data_status)
        return data_status
    
    def _audit_code_quality(self) -> Dict:
        """Audit code quality and structure"""
        st.subheader("💻 Code Quality Audit")
        
        code_status = {}
        
        # Check main application file
        main_files = ['app.py', 'reliable_data_connector.py', 'config_manager.py']
        
        for file_path in main_files:
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    content = f.read()
                    
                code_status[file_path] = {
                    'exists': True,
                    'line_count': len(content.split('\n')),
                    'has_docstrings': '"""' in content,
                    'has_error_handling': 'try:' in content and 'except' in content,
                    'has_logging': 'logging' in content or 'logger' in content,
                    'size_kb': round(len(content) / 1024, 2)
                }
            else:
                code_status[file_path] = {'exists': False}
                self.warnings.append(f"Missing file: {file_path}")
        
        # Check for duplicate files (code debt)
        all_files = [f for f in os.listdir('.') if f.endswith('.py')]
        duplicate_patterns = ['app_', 'dashboard_', 'meta_']
        
        for pattern in duplicate_patterns:
            duplicates = [f for f in all_files if f.startswith(pattern)]
            if len(duplicates) > 3:
                self.warnings.append(f"Multiple {pattern} files detected: {len(duplicates)} files")
        
        self._display_code_status(code_status)
        return code_status
    
    def _audit_performance(self) -> Dict:
        """Audit system performance"""
        st.subheader("⚡ Performance Audit")
        
        perf_status = {}
        
        # Check cache directory
        cache_dir = 'data_cache'
        if os.path.exists(cache_dir):
            cache_files = os.listdir(cache_dir)
            total_cache_size = sum(
                os.path.getsize(os.path.join(cache_dir, f)) 
                for f in cache_files
            )
            
            perf_status['cache'] = {
                'exists': True,
                'file_count': len(cache_files),
                'total_size_mb': round(total_cache_size / (1024*1024), 2),
                'status': 'active'
            }
        else:
            perf_status['cache'] = {'exists': False}
            self.warnings.append("No cache directory found")
        
        # Memory usage estimation
        try:
            import psutil
            process = psutil.Process()
            perf_status['memory'] = {
                'rss_mb': round(process.memory_info().rss / (1024*1024), 2),
                'cpu_percent': process.cpu_percent()
            }
        except ImportError:
            perf_status['memory'] = {'unavailable': 'psutil not installed'}
        
        self._display_performance_status(perf_status)
        return perf_status
    
    def _audit_security(self) -> Dict:
        """Audit security configuration"""
        st.subheader("🔒 Security Audit")
        
        security_status = {}
        
        # Check for hardcoded secrets in main files
        sensitive_patterns = ['api_key', 'token', 'password', 'secret']
        main_files = ['app.py', 'reliable_data_connector.py']
        
        for file_path in main_files:
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    content = f.read().lower()
                    
                found_patterns = []
                for pattern in sensitive_patterns:
                    if f'{pattern} =' in content and 'os.getenv' not in content:
                        found_patterns.append(pattern)
                
                security_status[file_path] = {
                    'hardcoded_secrets': found_patterns,
                    'uses_env_vars': 'os.getenv' in content,
                    'status': 'secure' if not found_patterns else 'warning'
                }
                
                if found_patterns:
                    self.warnings.append(f"Potential hardcoded secrets in {file_path}: {found_patterns}")
        
        self._display_security_status(security_status)
        return security_status
    
    def _audit_ui_ux(self) -> Dict:
        """Audit UI/UX implementation"""
        st.subheader("🎨 UI/UX Audit")
        
        ui_status = {}
        
        # Check main app file for UI components
        if os.path.exists('app.py'):
            with open('app.py', 'r') as f:
                content = f.read()
                
            ui_status['app.py'] = {
                'has_styling': 'st.markdown' in content and 'style' in content,
                'has_custom_css': '<style>' in content,
                'has_plotly_charts': 'plotly' in content,
                'has_error_handling': 'st.error' in content,
                'has_success_messages': 'st.success' in content,
                'responsive_design': 'use_container_width=True' in content
            }
        
        # Check for preview files
        preview_files = ['preview.html', 'preview2.html']
        ui_status['preview_files'] = {
            file: os.path.exists(file) for file in preview_files
        }
        
        self._display_ui_status(ui_status)
        return ui_status
    
    def _display_env_status(self, status: Dict):
        """Display environment status"""
        cols = st.columns(2)
        
        with cols[0]:
            st.metric("Environment Variables", 
                     len([v for v in status.values() if isinstance(v, dict) and v.get('exists')]),
                     delta=f"/{len([v for v in status.values() if isinstance(v, dict)])}")
        
        with cols[1]:
            missing_count = len([v for v in status.values() if isinstance(v, dict) and not v.get('exists')])
            st.metric("Missing Variables", missing_count, 
                     delta="Critical" if missing_count > 0 else "OK")
    
    def _display_dependency_status(self, status: Dict):
        """Display dependency status"""
        installed = len([p for p in status.values() if p.get('installed')])
        total = len(status)
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Installed Packages", f"{installed}/{total}")
        with col2:
            st.metric("Package Health", "OK" if installed == total else "Issues")
    
    def _display_config_status(self, status: Dict):
        """Display configuration status"""
        config_ok = status.get('config_manager', {}).get('status') == 'working'
        st.metric("Configuration Status", "Working" if config_ok else "Error")
    
    def _display_data_status(self, status: Dict):
        """Display data source status"""
        connections = []
        if 'airtable_transactions' in status:
            connections.append(status['airtable_transactions'].get('connection') == 'success')
        if 'airtable_leads' in status:
            connections.append(status['airtable_leads'].get('connection') == 'success')
        if 'meta_api' in status:
            connections.append(status['meta_api'].get('connection') == 'success')
        
        success_rate = sum(connections) / len(connections) if connections else 0
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Data Connections", f"{sum(connections)}/{len(connections)}")
        with col2:
            st.metric("Success Rate", f"{success_rate:.1%}")
        with col3:
            if 'airtable_transactions' in status:
                st.metric("Revenue Tracked", f"${status['airtable_transactions'].get('total_revenue', 0):,.0f}")
    
    def _display_code_status(self, status: Dict):
        """Display code quality status"""
        total_files = len([f for f in status.values() if isinstance(f, dict) and f.get('exists')])
        files_with_docs = len([f for f in status.values() if isinstance(f, dict) and f.get('has_docstrings')])
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Core Files", total_files)
        with col2:
            st.metric("Documentation Coverage", f"{files_with_docs}/{total_files}")
    
    def _display_performance_status(self, status: Dict):
        """Display performance status"""
        cache_status = status.get('cache', {})
        if cache_status.get('exists'):
            st.metric("Cache Files", cache_status.get('file_count', 0))
    
    def _display_security_status(self, status: Dict):
        """Display security status"""
        secure_files = len([f for f in status.values() if isinstance(f, dict) and f.get('status') == 'secure'])
        total_files = len([f for f in status.values() if isinstance(f, dict)])
        
        st.metric("Security Score", f"{secure_files}/{total_files}")
    
    def _display_ui_status(self, status: Dict):
        """Display UI/UX status"""
        app_status = status.get('app.py', {})
        ui_features = sum([
            app_status.get('has_styling', False),
            app_status.get('has_custom_css', False),
            app_status.get('has_plotly_charts', False),
            app_status.get('responsive_design', False)
        ])
        
        st.metric("UI Features", f"{ui_features}/4")
    
    def _display_audit_dashboard(self):
        """Display comprehensive audit dashboard"""
        st.markdown("---")
        st.subheader("📊 Audit Summary")
        
        # Summary metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Critical Issues", len(self.critical_issues), 
                     delta="High Priority" if self.critical_issues else "None")
        
        with col2:
            st.metric("Warnings", len(self.warnings),
                     delta="Medium Priority" if self.warnings else "None")
        
        with col3:
            total_issues = len(self.critical_issues) + len(self.warnings)
            st.metric("Total Issues", total_issues)
        
        with col4:
            health_score = max(0, 100 - (len(self.critical_issues) * 20) - (len(self.warnings) * 5))
            st.metric("System Health", f"{health_score}%")
        
        # Issues breakdown
        if self.critical_issues:
            st.error("🚨 Critical Issues")
            for issue in self.critical_issues:
                st.write(f"• {issue}")
        
        if self.warnings:
            st.warning("⚠️ Warnings")
            for warning in self.warnings:
                st.write(f"• {warning}")
        
        # Recommendations
        if not self.critical_issues and not self.warnings:
            st.success("✅ System is healthy and robust!")
        else:
            st.info("💡 Recommendations for enhancement coming next...")

def main():
    """Run the quality audit"""
    st.set_page_config(
        page_title="MetaPulse Quality Audit",
        page_icon="🔍",
        layout="wide"
    )
    
    auditor = SystemQualityAuditor()
    results = auditor.run_comprehensive_audit()
    
    # Export results option
    if st.button("📋 Export Audit Results"):
        import json
        results_json = json.dumps(results, indent=2, default=str)
        st.download_button(
            label="Download Audit Report",
            data=results_json,
            file_name=f"quality_audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            mime="application/json"
        )

if __name__ == "__main__":
    main()