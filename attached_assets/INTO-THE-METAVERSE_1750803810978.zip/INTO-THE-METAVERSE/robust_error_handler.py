"""
Robust Error Handling System
Centralized error management with monitoring and recovery
"""

import logging
import traceback
import time
import functools
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional
import streamlit as st

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ErrorRecoverySystem:
    """Advanced error recovery and monitoring system"""
    
    def __init__(self):
        self.error_history = []
        self.recovery_attempts = {}
        self.circuit_breaker_states = {}
        
    def log_error(self, operation: str, error: Exception, context: Dict = None):
        """Log error with context and recovery tracking"""
        error_entry = {
            'timestamp': datetime.now(),
            'operation': operation,
            'error_type': type(error).__name__,
            'error_message': str(error),
            'context': context or {},
            'traceback': traceback.format_exc()
        }
        
        self.error_history.append(error_entry)
        logger.error(f"Error in {operation}: {error}")
        
        # Track recovery attempts
        if operation not in self.recovery_attempts:
            self.recovery_attempts[operation] = 0
        self.recovery_attempts[operation] += 1
        
    def should_retry(self, operation: str, max_retries: int = 3) -> bool:
        """Determine if operation should be retried"""
        current_attempts = self.recovery_attempts.get(operation, 0)
        return current_attempts < max_retries
        
    def reset_recovery_counter(self, operation: str):
        """Reset recovery counter after successful operation"""
        if operation in self.recovery_attempts:
            del self.recovery_attempts[operation]
            
    def get_error_summary(self) -> Dict:
        """Get summary of recent errors"""
        recent_errors = [
            e for e in self.error_history 
            if (datetime.now() - e['timestamp']).total_seconds() < 3600
        ]
        
        error_counts = {}
        for error in recent_errors:
            error_type = error['error_type']
            error_counts[error_type] = error_counts.get(error_type, 0) + 1
            
        return {
            'total_recent_errors': len(recent_errors),
            'error_types': error_counts,
            'most_recent': recent_errors[-1] if recent_errors else None
        }

# Global error recovery system
error_recovery = ErrorRecoverySystem()

def robust_operation(
    operation_name: str,
    max_retries: int = 3,
    delay: float = 1.0,
    exponential_backoff: bool = True
):
    """Decorator for robust operation execution with retry logic"""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            last_error = None
            
            for attempt in range(max_retries):
                try:
                    result = func(*args, **kwargs)
                    error_recovery.reset_recovery_counter(operation_name)
                    return result
                    
                except Exception as e:
                    last_error = e
                    error_recovery.log_error(
                        operation_name, 
                        e, 
                        {'attempt': attempt + 1, 'max_retries': max_retries}
                    )
                    
                    # Don't retry on final attempt
                    if attempt == max_retries - 1:
                        break
                        
                    # Calculate delay with exponential backoff
                    wait_time = delay * (2 ** attempt) if exponential_backoff else delay
                    logger.warning(f"Retrying {operation_name} in {wait_time}s (attempt {attempt + 1}/{max_retries})")
                    time.sleep(wait_time)
            
            # All retries failed
            logger.error(f"All retries failed for {operation_name}")
            return handle_final_failure(operation_name, last_error)
            
        return wrapper
    return decorator

def handle_final_failure(operation: str, error: Exception) -> Dict:
    """Handle final failure with user-friendly response"""
    error_response = {
        'success': False,
        'error': f"Operation failed: {str(error)}",
        'operation': operation,
        'timestamp': datetime.now().isoformat(),
        'user_message': get_user_friendly_error_message(error)
    }
    
    # Show user-friendly error in Streamlit if available
    try:
        st.error(error_response['user_message'])
    except:
        pass  # Not in Streamlit context
        
    return error_response

def get_user_friendly_error_message(error: Exception) -> str:
    """Convert technical errors to user-friendly messages"""
    error_type = type(error).__name__
    error_message = str(error).lower()
    
    if 'connection' in error_message or 'timeout' in error_message:
        return "Connection issue detected. Please check your internet connection and API credentials."
    elif 'authentication' in error_message or 'unauthorized' in error_message:
        return "Authentication failed. Please check your API keys and permissions."
    elif 'not found' in error_message or '404' in error_message:
        return "Data source not found. Please verify your configuration settings."
    elif 'rate limit' in error_message or '429' in error_message:
        return "Rate limit exceeded. Please wait a moment and try again."
    elif 'permission' in error_message or 'forbidden' in error_message:
        return "Permission denied. Please check your access rights."
    elif error_type == 'KeyError':
        return "Data format issue detected. The expected data structure may have changed."
    elif error_type == 'ValueError':
        return "Data validation error. Please check your input parameters."
    else:
        return f"System error encountered. Please try again or contact support if the issue persists."

def safe_execute(func: Callable, fallback_value: Any = None, *args, **kwargs) -> Any:
    """Safely execute function with fallback value"""
    try:
        return func(*args, **kwargs)
    except Exception as e:
        logger.error(f"Safe execution failed for {func.__name__}: {e}")
        return fallback_value

def validate_data_integrity(data: Any, validation_rules: Dict) -> tuple[bool, List[str]]:
    """Validate data integrity with comprehensive rules"""
    issues = []
    
    if data is None:
        issues.append("Data is None")
        return False, issues
        
    if isinstance(data, dict):
        # Check required keys
        required_keys = validation_rules.get('required_keys', [])
        for key in required_keys:
            if key not in data:
                issues.append(f"Missing required key: {key}")
                
        # Check data types
        type_checks = validation_rules.get('type_checks', {})
        for key, expected_type in type_checks.items():
            if key in data and not isinstance(data[key], expected_type):
                issues.append(f"Invalid type for {key}: expected {expected_type.__name__}")
                
    elif isinstance(data, list):
        # Check minimum length
        min_length = validation_rules.get('min_length', 0)
        if len(data) < min_length:
            issues.append(f"Data length {len(data)} below minimum {min_length}")
            
        # Check item validation
        item_rules = validation_rules.get('item_rules', {})
        if item_rules:
            for i, item in enumerate(data):
                item_valid, item_issues = validate_data_integrity(item, item_rules)
                if not item_valid:
                    issues.extend([f"Item {i}: {issue}" for issue in item_issues])
    
    return len(issues) == 0, issues

class CircuitBreaker:
    """Circuit breaker pattern for API calls"""
    
    def __init__(self, failure_threshold: int = 5, recovery_timeout: int = 60):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failure_count = 0
        self.last_failure_time = None
        self.state = 'CLOSED'  # CLOSED, OPEN, HALF_OPEN
        
    def call(self, func: Callable, *args, **kwargs) -> Any:
        """Execute function with circuit breaker protection"""
        
        if self.state == 'OPEN':
            if self._should_attempt_reset():
                self.state = 'HALF_OPEN'
            else:
                raise Exception("Circuit breaker is OPEN - service unavailable")
                
        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
            
        except Exception as e:
            self._on_failure()
            raise e
            
    def _should_attempt_reset(self) -> bool:
        """Check if enough time has passed to attempt reset"""
        if self.last_failure_time is None:
            return True
        return time.time() - self.last_failure_time >= self.recovery_timeout
        
    def _on_success(self):
        """Handle successful operation"""
        self.failure_count = 0
        self.state = 'CLOSED'
        
    def _on_failure(self):
        """Handle failed operation"""
        self.failure_count += 1
        self.last_failure_time = time.time()
        
        if self.failure_count >= self.failure_threshold:
            self.state = 'OPEN'

# Global circuit breakers for different services
circuit_breakers = {
    'airtable': CircuitBreaker(failure_threshold=3, recovery_timeout=30),
    'meta_api': CircuitBreaker(failure_threshold=3, recovery_timeout=30)
}

def with_circuit_breaker(service_name: str):
    """Decorator to add circuit breaker protection"""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            breaker = circuit_breakers.get(service_name)
            if breaker:
                return breaker.call(func, *args, **kwargs)
            else:
                return func(*args, **kwargs)
        return wrapper
    return decorator