#!/usr/bin/env python3
"""
Test pyairtable API connection
"""

from pyairtable import Api

# API credentials
API_KEY = 'patRpwfhYlGferLE8.17a89cf5c31e4ef29041a67a4b28ca4058bb443779beb0dd4352ad999b186cdd'
BASE_ID = 'appH4MePHS6qLsk5z'

print("Testing pyairtable API connection...")
print(f"API Key: {API_KEY[:20]}...")
print(f"Base ID: {BASE_ID}")

try:
    # Initialize API
    api = Api(API_KEY)
    print("✓ API initialized")
    
    # Get base first, then table
    print("\nGetting base...")
    base = api.base(BASE_ID)
    print("✓ Base object created")
    
    # Test Leads table
    print("\nTesting Leads table...")
    leads_table = base.table('Leads')
    print("✓ Leads table object created")
    
    leads_records = leads_table.all(max_records=3)
    print(f"✓ Loaded {len(leads_records)} lead records")
    
    if leads_records:
        print("Sample lead fields:", list(leads_records[0]['fields'].keys())[:10])
    
    # Test Transactions table
    print("\nTesting Transactions table...")
    tx_table = base.table('Transactions')
    print("✓ Transactions table object created")
    
    tx_records = tx_table.all(max_records=3)
    print(f"✓ Loaded {len(tx_records)} transaction records")
    
    if tx_records:
        print("Sample transaction fields:", list(tx_records[0]['fields'].keys())[:10])
    
    print("\n🎉 API connection successful!")
    
except Exception as e:
    print(f"\n❌ Error: {e}")
    print(f"Exception type: {type(e).__name__}")
    import traceback
    print(f"Full traceback:\n{traceback.format_exc()}")