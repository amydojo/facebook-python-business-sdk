#!/usr/bin/env python3
"""
Test new Airtable API key and discover table structure
"""

import requests
import json
from pyairtable import Api

def test_airtable_connection():
    api_key = "patRpwfhYlGferLE8.17a89cf5c31e4ef29041a67a4b28ca4058bb443779beb0dd4352ad999b186cdd"
    base_id = "appH4MePHS6qLsk5z"
    
    print("Testing Airtable connection with new API key...")
    
    # Test metadata API
    headers = {'Authorization': f'Bearer {api_key}'}
    response = requests.get(f'https://api.airtable.com/v0/meta/bases/{base_id}/tables', headers=headers)
    
    print(f"Metadata API status: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        tables = data.get('tables', [])
        
        print(f"SUCCESS! Found {len(tables)} tables:")
        
        for table in tables:
            table_name = table['name']
            fields = [field['name'] for field in table.get('fields', [])]
            print(f"\nTable: {table_name}")
            print(f"  Fields: {', '.join(fields[:10])}{'...' if len(fields) > 10 else ''}")
        
        # Test data access on first few tables
        print("\nTesting data access...")
        api = Api(api_key)
        
        for table in tables[:3]:  # Test first 3 tables
            table_name = table['name']
            try:
                table_obj = api.table(base_id, table_name)
                records = table_obj.all(max_records=2)
                print(f"✅ {table_name}: {len(records)} records accessible")
                
                if records:
                    sample_fields = list(records[0]['fields'].keys())
                    print(f"   Sample fields: {', '.join(sample_fields[:5])}")
                    
            except Exception as e:
                print(f"❌ {table_name}: Error - {e}")
        
        return True, tables
        
    else:
        print(f"Error: {response.status_code}")
        print(response.text)
        return False, []

if __name__ == "__main__":
    success, tables = test_airtable_connection()
    if success:
        print(f"\n🎉 Connection successful! {len(tables)} tables discovered.")
    else:
        print("❌ Connection failed.")