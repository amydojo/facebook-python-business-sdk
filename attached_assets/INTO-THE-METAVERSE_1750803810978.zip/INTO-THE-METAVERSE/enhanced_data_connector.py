"""
Enhanced Data Connector with Key-Value Store Integration
Ultra-fast data loading with intelligent caching and zero-config database storage
"""

import pandas as pd
import requests
import logging
import time
from datetime import datetime, timedelta
from pyairtable import Api
from typing import Dict, Tuple, List, Optional, Any
from config_manager import get_config

# Key-Value Store integration
try:
    from replit import db
    KV_AVAILABLE = True
except ImportError:
    KV_AVAILABLE = False
    # Fallback for development
    class MockDB:
        def __init__(self):
            self._data = {}
        def __setitem__(self, key, value): self._data[key] = value
        def __getitem__(self, key): return self._data[key]
        def get(self, key, default=None): return self._data.get(key, default)
        def __contains__(self, key): return key in self._data
        def __delitem__(self, key): 
            if key in self._data: del self._data[key]
        def prefix(self, prefix_str): return [k for k in self._data.keys() if k.startswith(prefix_str)]
    db = MockDB()

logger = logging.getLogger(__name__)

class EnhancedDataConnector:
    """Ultra-fast data connector with KV Store caching and intelligent filtering"""
    
    def __init__(self):
        self.config = get_config()
        self.api_key = self.config.get('airtable', {}).get('api_key')
        self.base_id = self.config.get('airtable', {}).get('base_id')
        self.meta_token = self.config.get('meta', {}).get('access_token')
        self.meta_account_id = self.config.get('meta', {}).get('account_id')
        
        # KV Store prefixes for organized data
        self.cache_prefixes = {
            'transactions': 'trans_',
            'leads': 'leads_',
            'meta': 'meta_',
            'analytics': 'analytics_'
        }
        
        # Table mappings
        self.tables = {
            'transactions': 'Social Media',
            'leads': 'Leads'
        }
        
        # Cache TTL settings (in seconds)
        self.cache_ttl = {
            'transactions': 600,  # 10 minutes
            'leads': 600,         # 10 minutes
            'meta_insights': 300, # 5 minutes
            'analytics': 1800     # 30 minutes
        }
        
        logger.info(f"Enhanced Data Connector initialized (KV Store: {'Available' if KV_AVAILABLE else 'Mock'})")
    
    def _generate_cache_key(self, prefix: str, start_date: str, end_date: str, 
                           additional_params: Dict = None) -> str:
        """Generate consistent cache key"""
        key = f"{prefix}{start_date}_{end_date}"
        if additional_params:
            sorted_params = sorted(additional_params.items())
            param_str = "_".join(f"{k}:{v}" for k, v in sorted_params)
            key += f"_{param_str}"
        return key
    
    def _get_cache_entry(self, cache_key: str, ttl_seconds: int) -> Optional[Dict]:
        """Retrieve data from KV Store cache with TTL validation"""
        try:
            if cache_key not in db:
                return None
            
            cache_data = db[cache_key]
            
            # Check if cache entry has proper structure
            if not isinstance(cache_data, dict) or 'timestamp' not in cache_data:
                return None
            
            # Check TTL
            age = time.time() - cache_data['timestamp']
            if age > ttl_seconds:
                # Clean up expired entry
                del db[cache_key]
                return None
            
            logger.debug(f"Cache hit: {cache_key} (age: {age:.1f}s)")
            return cache_data.get('data')
            
        except Exception as e:
            logger.error(f"Cache read error for {cache_key}: {e}")
            return None
    
    def _set_cache_entry(self, cache_key: str, data: Any) -> bool:
        """Store data in KV Store cache with timestamp"""
        try:
            cache_entry = {
                'data': data,
                'timestamp': time.time(),
                'source': 'enhanced_connector'
            }
            db[cache_key] = cache_entry
            logger.debug(f"Cached: {cache_key}")
            return True
            
        except Exception as e:
            logger.error(f"Cache write error for {cache_key}: {e}")
            return False
    
    def load_transactions_optimized(self, start_date: str, end_date: str) -> Dict:
        """Ultra-fast transaction loading with KV Store caching"""
        
        cache_key = self._generate_cache_key(
            self.cache_prefixes['transactions'], start_date, end_date
        )
        
        # Try cache first
        cached_data = self._get_cache_entry(cache_key, self.cache_ttl['transactions'])
        if cached_data:
            return cached_data
        
        # Fetch from API if cache miss
        try:
            if not self.api_key:
                return {'success': False, 'error': 'Airtable API key not configured'}
            
            api = Api(self.api_key)
            table = api.table(self.base_id, self.tables['transactions'])
            all_records = table.all()
            
            logger.info(f"Fetched {len(all_records)} transaction records from Airtable")
            
            # Process and filter transactions
            filtered_transactions = self._process_transactions(all_records, start_date, end_date)
            
            result = {
                'success': True,
                'transactions': filtered_transactions,
                'total_revenue': sum(t.get('amount', 0) for t in filtered_transactions),
                'total_transactions': len(filtered_transactions),
                'date_range': f"{start_date} to {end_date}",
                'source': 'airtable_api'
            }
            
            # Cache successful result
            self._set_cache_entry(cache_key, result)
            
            return result
            
        except Exception as e:
            logger.error(f"Transaction loading error: {e}")
            return {'success': False, 'error': str(e)}
    
    def load_leads_optimized(self, start_date: str, end_date: str) -> Dict:
        """Ultra-fast lead loading with KV Store caching"""
        
        cache_key = self._generate_cache_key(
            self.cache_prefixes['leads'], start_date, end_date
        )
        
        # Try cache first
        cached_data = self._get_cache_entry(cache_key, self.cache_ttl['leads'])
        if cached_data:
            return cached_data
        
        # Fetch from API if cache miss
        try:
            if not self.api_key:
                return {'success': False, 'error': 'Airtable API key not configured'}
            
            api = Api(self.api_key)
            table = api.table(self.base_id, self.tables['leads'])
            all_records = table.all()
            
            logger.info(f"Fetched {len(all_records)} lead records from Airtable")
            
            # Process and filter leads
            filtered_leads = self._process_leads(all_records, start_date, end_date)
            
            result = {
                'success': True,
                'leads': filtered_leads,
                'total_leads': len(filtered_leads),
                'date_range': f"{start_date} to {end_date}",
                'source': 'airtable_api'
            }
            
            # Cache successful result
            self._set_cache_entry(cache_key, result)
            
            return result
            
        except Exception as e:
            logger.error(f"Lead loading error: {e}")
            return {'success': False, 'error': str(e)}
    
    def load_meta_insights_optimized(self, start_date: str, end_date: str) -> Dict:
        """Ultra-fast Meta insights loading with KV Store caching"""
        
        cache_key = self._generate_cache_key(
            self.cache_prefixes['meta'], start_date, end_date
        )
        
        # Try cache first
        cached_data = self._get_cache_entry(cache_key, self.cache_ttl['meta_insights'])
        if cached_data:
            return cached_data
        
        # Fetch from API if cache miss
        try:
            if not (self.meta_token and self.meta_account_id):
                return {'success': False, 'error': 'Meta API credentials not configured'}
            
            # Meta API request
            url = f"https://graph.facebook.com/v18.0/act_{self.meta_account_id}/insights"
            params = {
                'access_token': self.meta_token,
                'fields': 'spend,impressions,clicks,ctr,cpm,reach,frequency',
                'time_range': f'{{"since":"{start_date}","until":"{end_date}"}}',
                'level': 'account'
            }
            
            response = requests.get(url, params=params, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                insights = data.get('data', [])
                
                if insights:
                    insight = insights[0]
                    result = {
                        'success': True,
                        'total_spend': float(insight.get('spend', 0)),
                        'impressions': int(insight.get('impressions', 0)),
                        'clicks': int(insight.get('clicks', 0)),
                        'ctr': float(insight.get('ctr', 0)),
                        'cpm': float(insight.get('cpm', 0)),
                        'reach': int(insight.get('reach', 0)),
                        'frequency': float(insight.get('frequency', 0)),
                        'date_range': f"{start_date} to {end_date}",
                        'source': 'meta_api'
                    }
                else:
                    result = {
                        'success': True,
                        'total_spend': 0,
                        'impressions': 0,
                        'clicks': 0,
                        'date_range': f"{start_date} to {end_date}",
                        'source': 'meta_api'
                    }
                
                # Cache successful result
                self._set_cache_entry(cache_key, result)
                return result
            else:
                return {'success': False, 'error': f'Meta API error: {response.status_code}'}
                
        except Exception as e:
            logger.error(f"Meta insights loading error: {e}")
            return {'success': False, 'error': str(e)}
    
    def _process_transactions(self, records: List[Dict], start_date: str, end_date: str) -> List[Dict]:
        """Process and filter transaction records"""
        
        filtered_transactions = []
        start_dt = datetime.strptime(start_date, '%Y-%m-%d')
        end_dt = datetime.strptime(end_date, '%Y-%m-%d')
        
        for record in records:
            fields = record.get('fields', {})
            
            # Extract brand and source
            brand = self._extract_field(fields, ['Brand', 'brand'])
            source = self._extract_field(fields, ['Source', 'source', 'Lead Source'])
            
            # Filter for Smooth MD Meta transactions
            if brand != 'Smooth MD' or not self._is_meta_source(source):
                continue
            
            # Extract amount
            amount = self._extract_amount(fields)
            if amount <= 0:
                continue
            
            # Extract and validate date
            date_value = self._extract_date(fields)
            if not date_value:
                continue
            
            try:
                if isinstance(date_value, str):
                    trans_dt = datetime.fromisoformat(date_value.replace('Z', '+00:00')).replace(tzinfo=None)
                else:
                    trans_dt = date_value
                
                # Filter by date range
                if not (start_dt <= trans_dt <= end_dt):
                    continue
                    
            except (ValueError, TypeError):
                continue
            
            transaction = {
                'date': trans_dt.strftime('%Y-%m-%d'),
                'amount': amount,
                'brand': brand,
                'source': source,
                'record_id': record.get('id', '')
            }
            
            filtered_transactions.append(transaction)
        
        total_revenue = sum(t['amount'] for t in filtered_transactions)
        logger.info(f"Processed {len(filtered_transactions)} Smooth MD Meta transactions worth ${total_revenue:.2f}")
        
        return filtered_transactions
    
    def _process_leads(self, records: List[Dict], start_date: str, end_date: str) -> List[Dict]:
        """Process and filter lead records"""
        
        filtered_leads = []
        start_dt = datetime.strptime(start_date, '%Y-%m-%d')
        end_dt = datetime.strptime(end_date, '%Y-%m-%d')
        
        for record in records:
            fields = record.get('fields', {})
            
            # Extract brand and source
            brand = self._extract_field(fields, ['Brand', 'brand'])
            source = self._extract_field(fields, ['Source', 'source', 'Lead Source'])
            
            # Filter for Smooth MD Meta leads
            if brand != 'Smooth MD' or not self._is_meta_source(source):
                continue
            
            # Extract and validate date
            date_value = self._extract_date(fields, lead_record=True)
            if not date_value:
                continue
            
            try:
                if isinstance(date_value, str):
                    lead_dt = datetime.fromisoformat(date_value.replace('Z', '+00:00')).replace(tzinfo=None)
                else:
                    lead_dt = date_value
                
                # Filter by date range
                if not (start_dt <= lead_dt <= end_dt):
                    continue
                    
            except (ValueError, TypeError):
                continue
            
            lead = {
                'date': lead_dt.strftime('%Y-%m-%d'),
                'brand': brand,
                'source': source,
                'record_id': record.get('id', '')
            }
            
            filtered_leads.append(lead)
        
        logger.info(f"Processed {len(filtered_leads)} Smooth MD Meta leads")
        return filtered_leads
    
    def _extract_field(self, fields: Dict, possible_keys: List[str]) -> str:
        """Extract field value using multiple possible key names"""
        for key in possible_keys:
            if key in fields and fields[key]:
                return str(fields[key]).strip()
        return ''
    
    def _extract_amount(self, fields: Dict) -> float:
        """Extract amount from transaction fields"""
        amount_keys = ['Amount', 'amount', 'Transaction Amount', 'Total', 'total']
        for key in amount_keys:
            if key in fields and fields[key]:
                try:
                    return float(fields[key])
                except (ValueError, TypeError):
                    continue
        return 0.0
    
    def _extract_date(self, fields: Dict, lead_record: bool = False) -> Optional[datetime]:
        """Extract date from record fields"""
        if lead_record:
            date_keys = ['Inbound', 'Date', 'Created', 'Lead Date']
        else:
            date_keys = ['Date', 'Transaction Date', 'Created', 'Timestamp']
        
        for key in date_keys:
            if key in fields and fields[key]:
                return fields[key]
        return None
    
    def _is_meta_source(self, source: str) -> bool:
        """Check if source indicates Meta/Facebook"""
        if not source:
            return False
        source_lower = source.lower()
        return any(term in source_lower for term in ['meta', 'facebook', 'fb', 'instagram'])
    
    def invalidate_cache(self, data_type: str = None, date_range: str = None) -> int:
        """Invalidate cached data"""
        if not KV_AVAILABLE:
            return 0
        
        evicted_count = 0
        
        try:
            if data_type and date_range:
                # Invalidate specific cache entry
                cache_key = f"{self.cache_prefixes.get(data_type, '')}{date_range}"
                if cache_key in db:
                    del db[cache_key]
                    evicted_count = 1
            elif data_type:
                # Invalidate all entries for data type
                prefix = self.cache_prefixes.get(data_type, '')
                for key in db.prefix(prefix):
                    del db[key]
                    evicted_count += 1
            else:
                # Invalidate all cache entries
                for prefix in self.cache_prefixes.values():
                    for key in db.prefix(prefix):
                        del db[key]
                        evicted_count += 1
            
            logger.info(f"Invalidated {evicted_count} cache entries")
            
        except Exception as e:
            logger.error(f"Cache invalidation error: {e}")
        
        return evicted_count
    
    def get_cache_stats(self) -> Dict:
        """Get comprehensive cache statistics"""
        if not KV_AVAILABLE:
            return {'enabled': False}
        
        try:
            stats = {'enabled': True}
            
            for data_type, prefix in self.cache_prefixes.items():
                cache_keys = [k for k in db.prefix(prefix)]
                stats[f'{data_type}_cached_entries'] = len(cache_keys)
            
            return stats
            
        except Exception as e:
            logger.error(f"Cache stats error: {e}")
            return {'enabled': True, 'error': str(e)}
    
    def cleanup_expired_cache(self) -> int:
        """Remove expired cache entries"""
        if not KV_AVAILABLE:
            return 0
        
        cleaned_count = 0
        current_time = time.time()
        
        try:
            for data_type, prefix in self.cache_prefixes.items():
                ttl = self.cache_ttl.get(data_type, 600)
                
                for cache_key in db.prefix(prefix):
                    try:
                        cache_data = db[cache_key]
                        if isinstance(cache_data, dict) and 'timestamp' in cache_data:
                            age = current_time - cache_data['timestamp']
                            if age > ttl:
                                del db[cache_key]
                                cleaned_count += 1
                    except Exception:
                        # Remove corrupted entries
                        del db[cache_key]
                        cleaned_count += 1
            
            logger.info(f"Cleaned {cleaned_count} expired cache entries")
            
        except Exception as e:
            logger.error(f"Cache cleanup error: {e}")
        
        return cleaned_count

# Export enhanced connector
__all__ = ['EnhancedDataConnector']