import os

# Update environment variables for the current session
os.environ['AIRTABLE_API_KEY'] = 'patRpwfhYlGferLE8.17a89cf5c31e4ef29041a67a4b28ca4058bb443779beb0dd4352ad999b186cdd'
os.environ['AIRTABLE_BASE_ID'] = 'appH4MePHS6qLsk5z'

print("Environment variables updated")
print(f"API Key: {os.environ['AIRTABLE_API_KEY'][:20]}...")
print(f"Base ID: {os.environ['AIRTABLE_BASE_ID']}")