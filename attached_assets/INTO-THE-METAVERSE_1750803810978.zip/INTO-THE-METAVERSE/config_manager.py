"""
Centralized Configuration Manager
Eliminates API key mix-ups and ensures consistent data source connections
"""

import os
import streamlit as st
from typing import Dict, Tuple, Optional

class ConfigManager:
    """Centralized configuration management for all API connections"""
    
    def __init__(self):
        self.config = self._load_configuration()
        self._validate_configuration()
    
    def _load_configuration(self) -> Dict:
        """Load configuration from environment and Streamlit secrets"""
        config = {
            # Airtable Configuration - Updated with user's credentials
            'airtable': {
                'api_key': self._get_secret('AIRTABLE_API_KEY'),
                'base_id': self._get_secret('AIRTABLE_BASE_ID'),
                'tables': {
                    'transactions': 'Social Media',  # Correct table name for transactions
                    'leads': 'Leads'                 # Correct table name for leads
                }
            },
            
            # Meta API Configuration
            'meta': {
                'access_token': self._get_secret('META_ACCESS_TOKEN'),
                'ad_account_id': self._get_secret('META_AD_ACCOUNT_ID'),
                'pixel_id': self._get_secret('META_PIXEL_ID')
            },
            
            # Data Processing Configuration
            'data': {
                'meta_indicators': ['instagram', 'facebook', 'meta', 'fb', 'ig', 'instagram dm'],
                'brand_filters': ['smooth md', 'smooth m.d.', 'smooth m.d', 'smoothmd'],
                'conversion_statuses': ['converted', 'closed', 'sold', 'purchased'],
                'booking_statuses': ['booked', 'scheduled', 'appointment']
            }
        }
        
        return config
    
    def _get_secret(self, key: str) -> Optional[str]:
        """Get secret from Streamlit secrets or environment variables"""
        # Try Streamlit secrets first
        if hasattr(st, 'secrets') and key in st.secrets:
            return st.secrets[key]
        
        # Fallback to environment variables
        return os.environ.get(key)
    
    def _validate_configuration(self) -> None:
        """Validate that all required configurations are present"""
        required_keys = [
            ('airtable', 'api_key'),
            ('airtable', 'base_id'),
            ('meta', 'access_token'),
            ('meta', 'ad_account_id')
        ]
        
        self.validation_status = {}
        
        for section, key in required_keys:
            value = self.config.get(section, {}).get(key)
            is_valid = bool(value and len(str(value)) > 10)
            self.validation_status[f"{section}_{key}"] = is_valid
    
    def get_airtable_config(self) -> Tuple[str, str, Dict[str, str]]:
        """Get Airtable configuration"""
        airtable_config = self.config['airtable']
        return (
            airtable_config['api_key'],
            airtable_config['base_id'],
            airtable_config['tables']
        )
    
    def get_meta_config(self) -> Tuple[str, str, str]:
        """Get Meta API configuration"""
        meta_config = self.config['meta']
        return (
            meta_config['access_token'],
            meta_config['ad_account_id'],
            meta_config['pixel_id']
        )
    
    def get_data_filters(self) -> Dict:
        """Get data processing filters"""
        return self.config['data']
    
    def is_airtable_configured(self) -> bool:
        """Check if Airtable is properly configured"""
        return (
            self.validation_status.get('airtable_api_key', False) and
            self.validation_status.get('airtable_base_id', False)
        )
    
    def is_meta_configured(self) -> bool:
        """Check if Meta API is properly configured"""
        return (
            self.validation_status.get('meta_access_token', False) and
            self.validation_status.get('meta_ad_account_id', False)
        )
    
    def get_status_report(self) -> Dict:
        """Get comprehensive status report"""
        return {
            'airtable_status': 'Configured' if self.is_airtable_configured() else 'Missing credentials',
            'meta_status': 'Configured' if self.is_meta_configured() else 'Missing credentials',
            'base_id': self.config['airtable']['base_id'],
            'tables': self.config['airtable']['tables'],
            'validation_details': self.validation_status
        }
    
    def get(self, section: str, default=None):
        """Get configuration section with dict-like access"""
        return self.config.get(section, default)

# Global configuration instance
_config_manager = None

def get_config() -> ConfigManager:
    """Get global configuration manager instance"""
    global _config_manager
    if _config_manager is None:
        _config_manager = ConfigManager()
    return _config_manager