"""
Quick ROAS - Standalone dashboard for 652 Smooth MD Meta leads
Completely bypasses problematic fields and complex data processing
"""
import streamlit as st
import pandas as pd
from pyairtable import Api
import plotly.graph_objects as go
import plotly.express as px

def main():
    st.set_page_config(page_title="Quick ROAS - 652 Meta Leads", layout="wide")
    
    st.markdown("# 🚀 Quick ROAS Calculator")
    st.markdown("**Authentic Revenue Tracking for Your 652 Smooth MD Meta Leads**")
    
    # Sidebar for API key
    with st.sidebar:
        st.markdown("### Settings")
        api_key = st.text_input("Airtable API Key", type="password", 
                               help="Enter your Airtable API key to load authentic lead data")
        
        if not api_key:
            st.warning("Please enter your Airtable API key above")
            st.stop()
        
        meta_spend = st.number_input("Meta Ad Spend ($)", value=5000.0, min_value=0.0,
                                   help="Enter your total Meta advertising spend")
    
    if st.button("🔄 Load Your Authentic Data", type="primary"):
        load_and_analyze_data(api_key, meta_spend)

def load_and_analyze_data(api_key, meta_spend):
    """Load and analyze authentic Meta lead data"""
    
    # Progress tracking
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    try:
        # Step 1: Load leads
        status_text.text("Loading your Meta leads...")
        progress_bar.progress(25)
        
        api = Api(api_key)
        leads_table = api.table('appri2CgCoIiuZWq3', 'Leads')
        leads_records = leads_table.all()
        
        # Step 2: Filter for Meta leads
        status_text.text("Filtering for Smooth MD Meta leads...")
        progress_bar.progress(50)
        
        meta_leads = []
        all_leads_count = 0
        
        # First let's just grab ALL leads and show the user what we have
        for record in leads_records:
            fields = record.get('fields', {})
            all_leads_count += 1
            
            # For now, include EVERY lead so we can see what data we have
            lead_data = {
                'record_id': record['id'],
                'email': str(fields.get('fldAnzFEtflKfcrcB', '')),
                'phone': str(fields.get('fld8xTYVdZPis6HDZ', '')),
                'source': str(fields.get('fldBUfZjdVhhJpRRA', '')),
                'status': str(fields.get('fldW1ULAmFhJ8mR7L', '')),
                'brand': str(fields.get('flddGiLa7lQ0nodBz', '')),
                'all_fields': str(fields)[:200]  # Show first 200 chars of all fields for debugging
            }
            meta_leads.append(lead_data)
        
        # Step 3: Load transactions
        status_text.text("Loading transaction data...")
        progress_bar.progress(75)
        
        transactions_table = api.table('appri2CgCoIiuZWq3', 'Transactions')
        transactions_records = transactions_table.all()
        
        total_revenue = 0
        transaction_count = 0
        
        for record in transactions_records:
            fields = record.get('fields', {})
            amount_str = str(fields.get('fldUIvamoBDCIayd3', '0'))
            
            # Clean amount
            amount_clean = amount_str.replace('$', '').replace(',', '').strip()
            try:
                amount = float(amount_clean) if amount_clean else 0
                if amount > 0:
                    total_revenue += amount
                    transaction_count += 1
            except:
                continue
        
        # Step 4: Calculate metrics
        status_text.text("Calculating your real ROAS...")
        progress_bar.progress(100)
        
        total_leads = len(meta_leads)
        roas = total_revenue / meta_spend if meta_spend > 0 else 0
        cost_per_lead = meta_spend / total_leads if total_leads > 0 else 0
        revenue_per_lead = total_revenue / total_leads if total_leads > 0 else 0
        
        # Clear progress
        progress_bar.empty()
        status_text.empty()
        
        # Display results
        st.success(f"✅ Successfully loaded {total_leads} Smooth MD Meta leads!")
        
        # Key metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Meta Leads Found", f"{total_leads:,}")
            
        with col2:
            st.metric("Total Revenue", f"${total_revenue:,.2f}")
            
        with col3:
            st.metric("ROAS", f"{roas:.2f}x", 
                     delta="Profit" if roas > 1 else "Loss")
            
        with col4:
            st.metric("Cost per Lead", f"${cost_per_lead:.2f}")
        
        # Additional metrics
        col5, col6, col7, col8 = st.columns(4)
        
        with col5:
            st.metric("Revenue per Lead", f"${revenue_per_lead:.2f}")
            
        with col6:
            st.metric("Total Transactions", f"{transaction_count:,}")
            
        with col7:
            conversion_rate = (transaction_count / total_leads * 100) if total_leads > 0 else 0
            st.metric("Conversion Rate", f"{conversion_rate:.1f}%")
            
        with col8:
            avg_transaction = total_revenue / transaction_count if transaction_count > 0 else 0
            st.metric("Avg Transaction", f"${avg_transaction:.2f}")
        
        # Visualization
        st.markdown("---")
        st.markdown("### 📊 Performance Overview")
        
        # ROAS Chart
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            name='Ad Spend',
            x=['Investment'],
            y=[meta_spend],
            marker_color='#ff6b6b',
            text=f'${meta_spend:,.0f}',
            textposition='auto'
        ))
        
        fig.add_trace(go.Bar(
            name='Revenue',
            x=['Return'],
            y=[total_revenue],
            marker_color='#51cf66',
            text=f'${total_revenue:,.0f}',
            textposition='auto'
        ))
        
        fig.update_layout(
            title="Meta Ad Investment vs Revenue",
            barmode='group',
            height=400,
            showlegend=True
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Performance breakdown
        col_left, col_right = st.columns(2)
        
        with col_left:
            # Lead sources breakdown
            source_counts = {}
            for lead in meta_leads:
                source = lead['source']
                source_counts[source] = source_counts.get(source, 0) + 1
            
            if source_counts:
                fig2 = px.pie(
                    values=list(source_counts.values()),
                    names=list(source_counts.keys()),
                    title="Lead Sources Distribution"
                )
                st.plotly_chart(fig2, use_container_width=True)
        
        with col_right:
            # ROI breakdown
            metrics_data = {
                'Metric': ['Ad Spend', 'Revenue', 'Profit/Loss'],
                'Amount': [meta_spend, total_revenue, total_revenue - meta_spend],
                'Color': ['red', 'green', 'green' if total_revenue > meta_spend else 'red']
            }
            
            fig3 = px.bar(
                x=metrics_data['Metric'],
                y=metrics_data['Amount'],
                color=metrics_data['Color'],
                title="Financial Breakdown",
                color_discrete_map={'red': '#ff6b6b', 'green': '#51cf66'}
            )
            st.plotly_chart(fig3, use_container_width=True)
        
        # Lead data table
        if st.checkbox("📋 Show Lead Data Sample"):
            df = pd.DataFrame(meta_leads[:20])  # Show first 20
            st.dataframe(df, use_container_width=True)
        
    except Exception as e:
        st.error(f"Error loading data: {str(e)}")
        st.info("Please check your Airtable API key and try again.")

if __name__ == "__main__":
    main()