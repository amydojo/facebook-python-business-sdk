"""
Metrics dashboard module for the CAPI Command Center
"""

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from datetime import datetime, timedelta


def safe_metric_value(value):
    """
    Ensures metric values are properly formatted and never None
    """
    if pd.isna(value) or value is None:
        return 0
    try:
        return float(value)
    except (ValueError, TypeError):
        return 0


def create_funnel_chart(data_dict, title="Lead Funnel"):
    """
    Create a funnel chart visualization
    
    Args:
        data_dict (dict): Dictionary of stage names and counts
        title (str): Title for the chart
        
    Returns:
        plotly.graph_objects.Figure: The funnel chart figure
    """
    stages = list(data_dict.keys())
    values = list(data_dict.values())
    
    # Create the funnel chart
    fig = go.Figure(go.Funnel(
        y=stages,
        x=values,
        textinfo="value+percent initial",
        marker={"color": ["#1E88E5", "#42A5F5", "#64B5F6", "#90CAF9", "#BBDEFB"]}
    ))
    
    # Update layout
    fig.update_layout(
        title=title,
        margin=dict(l=20, r=20, t=60, b=20),
        height=400
    )
    
    return fig


def create_revenue_chart(transactions_df, timeframe="all"):
    """
    Create a revenue visualization chart
    
    Args:
        transactions_df (pd.DataFrame): Transactions dataframe
        timeframe (str): Time period to display (all, month, week)
        
    Returns:
        plotly.graph_objects.Figure: The revenue chart figure
    """
    if transactions_df is None or transactions_df.empty:
        # Create empty chart with message
        fig = go.Figure()
        fig.add_annotation(
            text="No transaction data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False
        )
        fig.update_layout(height=400)
        return fig
    
    # Ensure Transaction_Date is datetime
    if 'Transaction_Date' in transactions_df.columns:
        # Clone the dataframe to avoid modifying original
        df = transactions_df.copy()
        
        # Convert Transaction_Date to datetime if it's not already
        if not pd.api.types.is_datetime64_any_dtype(df['Transaction_Date']):
            df['Transaction_Date'] = pd.to_datetime(df['Transaction_Date'], errors='coerce')
            
        # Filter by timeframe
        today = datetime.now()
        if timeframe == "month":
            start_date = today - timedelta(days=30)
            df = df[df['Transaction_Date'] >= start_date]
        elif timeframe == "week":
            start_date = today - timedelta(days=7)
            df = df[df['Transaction_Date'] >= start_date]
            
        # Group by date and sum revenue
        if not df.empty and 'Revenue' in df.columns:
            df['Revenue'] = pd.to_numeric(df['Revenue'], errors='coerce').fillna(0)
            df['Day'] = df['Transaction_Date'].dt.date
            revenue_by_day = df.groupby('Day')['Revenue'].sum().reset_index()
            
            # Create the chart
            fig = px.line(
                revenue_by_day, 
                x='Day', 
                y='Revenue',
                title=f"Revenue Over Time ({timeframe})",
                labels={"Revenue": "Revenue ($)", "Day": "Date"}
            )
            
            # Update layout
            fig.update_layout(
                margin=dict(l=20, r=20, t=60, b=20),
                height=400
            )
            
            return fig
    
    # Fallback empty chart
    fig = go.Figure()
    fig.add_annotation(
        text="No transaction data available for the selected timeframe",
        xref="paper", yref="paper",
        x=0.5, y=0.5,
        showarrow=False
    )
    fig.update_layout(height=400)
    return fig


def create_source_breakdown(leads_df):
    """
    Create a source breakdown pie chart
    
    Args:
        leads_df (pd.DataFrame): Leads dataframe
        
    Returns:
        plotly.graph_objects.Figure: The source breakdown chart
    """
    if leads_df is None or leads_df.empty or 'Source' not in leads_df.columns:
        # Create empty chart with message
        fig = go.Figure()
        fig.add_annotation(
            text="No source data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False
        )
        fig.update_layout(height=400)
        return fig
    
    # Process source data
    # Handle source values that might be lists
    def process_source(source):
        if isinstance(source, list):
            # Take first value if it's a list
            return source[0] if source else "Unknown"
        elif pd.isna(source):
            return "Unknown"
        else:
            return source
    
    # Create a copy and process sources
    df = leads_df.copy()
    df['Processed_Source'] = df['Source'].apply(process_source)
    
    # Group by source and count
    source_counts = df['Processed_Source'].value_counts().reset_index()
    source_counts.columns = ['Source', 'Count']
    
    # Create the pie chart
    fig = px.pie(
        source_counts, 
        names='Source', 
        values='Count',
        title="Lead Sources Breakdown",
        hole=0.4
    )
    
    # Update layout
    fig.update_layout(
        margin=dict(l=20, r=20, t=60, b=20),
        height=400
    )
    
    return fig


def calculate_funnel_metrics(leads_df, metric_type="all"):
    """
    Calculate funnel metrics from leads data
    
    Args:
        leads_df (pd.DataFrame): Leads dataframe
        metric_type (str): Type of metrics to calculate (all, meta)
        
    Returns:
        dict: Dictionary of funnel metrics
    """
    if leads_df is None or leads_df.empty:
        return {
            "Total Leads": 0,
            "Booked": 0,
            "Converted": 0,
            "Abandoned": 0
        }
    
    # Create a copy of the dataframe
    df = leads_df.copy()
    
    # Filter for Meta leads if needed
    if metric_type == "meta":
        # Use globals to get the is_meta_lead function
        is_meta_lead_func = globals().get('is_meta_lead')
        if is_meta_lead_func:
            # Filter for Meta leads
            df = df[df.apply(is_meta_lead_func, axis=1)]
        else:
            # Fallback simple filter if function not available
            df = df[df['Source'].apply(
                lambda x: isinstance(x, str) and any(s in x.lower() for s in 
                                                   ['facebook', 'instagram', 'meta', 'ig ads'])
                if isinstance(x, str) 
                else False
            )]
    
    # Calculate metrics
    total_leads = len(df)
    
    # Use globals to get status functions
    is_booked_func = globals().get('is_booked')
    is_converted_func = globals().get('is_converted')
    is_abandoned_func = globals().get('is_abandoned')
    
    # Calculate based on status functions if available
    if is_booked_func and is_converted_func and is_abandoned_func:
        booked = df.apply(is_booked_func, axis=1).sum()
        converted = df.apply(is_converted_func, axis=1).sum()
        abandoned = df.apply(is_abandoned_func, axis=1).sum()
    else:
        # Fallback calculations based on Status field
        if 'Status' in df.columns:
            # Convert list Status to string for comparison
            df['Status_Str'] = df['Status'].apply(
                lambda x: x[0].lower() if isinstance(x, list) and len(x) > 0 
                else x.lower() if isinstance(x, str) 
                else 'unknown'
            )
            
            booked = df['Status_Str'].apply(
                lambda x: any(s in x for s in ['booked', 'scheduled', 'consult'])
            ).sum()
            
            converted = df['Status_Str'].apply(
                lambda x: any(s in x for s in ['converted', 'purchased', 'closed'])
            ).sum()
            
            abandoned = df['Status_Str'].apply(
                lambda x: any(s in x for s in ['abandoned', 'lost', 'cancelled'])
            ).sum()
        else:
            booked = 0
            converted = 0
            abandoned = 0
    
    return {
        "Total Leads": total_leads,
        "Booked": booked,
        "Converted": converted,
        "Abandoned": abandoned
    }


def calculate_revenue_metrics(transactions_df, timeframe="all"):
    """
    Calculate revenue metrics from transactions data
    
    Args:
        transactions_df (pd.DataFrame): Transactions dataframe
        timeframe (str): Time period to calculate (all, month, week)
        
    Returns:
        dict: Dictionary of revenue metrics
    """
    metrics = {
        "Total Revenue": 0,
        "Average Sale": 0,
        "Transaction Count": 0
    }
    
    if transactions_df is None or transactions_df.empty or 'Revenue' not in transactions_df.columns:
        return metrics
    
    # Create a copy of the dataframe
    df = transactions_df.copy()
    
    # Convert Revenue to numeric
    df['Revenue'] = pd.to_numeric(df['Revenue'], errors='coerce').fillna(0)
    
    # Filter by timeframe if needed
    if timeframe != "all" and 'Transaction_Date' in df.columns:
        # Convert Transaction_Date to datetime if it's not already
        if not pd.api.types.is_datetime64_any_dtype(df['Transaction_Date']):
            df['Transaction_Date'] = pd.to_datetime(df['Transaction_Date'], errors='coerce')
            
        # Filter by timeframe
        today = datetime.now()
        if timeframe == "month":
            start_date = today - timedelta(days=30)
            df = df[df['Transaction_Date'] >= start_date]
        elif timeframe == "week":
            start_date = today - timedelta(days=7)
            df = df[df['Transaction_Date'] >= start_date]
    
    # Calculate metrics
    total_revenue = df['Revenue'].sum()
    transaction_count = len(df)
    avg_sale = total_revenue / transaction_count if transaction_count > 0 else 0
    
    metrics["Total Revenue"] = total_revenue
    metrics["Average Sale"] = avg_sale
    metrics["Transaction Count"] = transaction_count
    
    return metrics