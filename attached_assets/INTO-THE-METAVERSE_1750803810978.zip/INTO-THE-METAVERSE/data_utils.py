"""
Data utility functions for CAPI Command Center
"""
import pandas as pd
import numpy as np
from datetime import datetime

def filter_smooth_md_meta_data(df):
    """
    Filter data to only include Smooth M.D. meta leads
    This is our core filtering function for all metrics
    """
    if df is None or df.empty:
        return pd.DataFrame()
    
    # Create a copy to prevent modifying the original
    filtered_df = df.copy()
    
    # 1. First, filter by Brand
    if 'Brand' in filtered_df.columns:
        # Look for Smooth M.D. variations in the Brand column 
        brand_mask = filtered_df['Brand'].fillna('').astype(str).str.lower().apply(
            lambda x: 'smooth' in x or 'smoothmd' in x
        )
        filtered_df = filtered_df[brand_mask]
        print(f"After Brand filter: {len(filtered_df)} records")
    
    # 2. Then, filter by Meta sources (Facebook/Instagram)
    if not filtered_df.empty:
        meta_terms = ['facebook', 'instagram', 'fb', 'ig', 'meta']
        
        # Try Source column first
        if 'Source' in filtered_df.columns:
            source_mask = filtered_df['Source'].fillna('').astype(str).str.lower().apply(
                lambda x: any(term in x for term in meta_terms)
            )
            result_df = filtered_df[source_mask]
            
            # If we found matches, use those results
            if not result_df.empty:
                filtered_df = result_df
                print(f"Source filter found {len(filtered_df)} Meta records")
        
        # If no matches yet, try Contact Source 
        if filtered_df.empty and 'Contact Source' in df.columns:
            contact_mask = df['Contact Source'].fillna('').astype(str).str.lower().apply(
                lambda x: any(term in x for term in meta_terms)
            )
            filtered_df = df[contact_mask]
            print(f"Contact Source filter found {len(filtered_df)} Meta records")
            
        # If still empty and Lead Source exists, try that
        if filtered_df.empty and 'Lead Source' in df.columns:
            source_mask = df['Lead Source'].fillna('').astype(str).str.lower().apply(
                lambda x: any(term in x for term in meta_terms)
            )
            filtered_df = df[source_mask]
            print(f"Lead Source filter found {len(filtered_df)} Meta records")
    
    return filtered_df

def fix_date_columns(df, target_column='Date'):
    """
    Ensure the DataFrame has a Date column for consistent processing
    Maps from your Airtable schema (Inbound, etc.) to the expected format
    """
    if df is None or df.empty:
        return df
    
    # Copy to prevent modifying original
    df = df.copy()
    
    # If target column already exists, just ensure it's datetime
    if target_column in df.columns:
        df[target_column] = pd.to_datetime(df[target_column], errors='coerce')
        return df
    
    # Priority ordered list of potential date columns from your schema
    date_columns = ['Inbound', 'Created', 'Created Time', 'Transaction Date', 'Consult']
    
    # Try each potential date column
    for date_col in date_columns:
        if date_col in df.columns and pd.notna(df[date_col].iloc[0]) if not df.empty else False:
            try:
                df[target_column] = pd.to_datetime(df[date_col], errors='coerce')
                print(f"Mapped {date_col} to {target_column}")
                return df
            except:
                pass
    
    # If we still don't have a date column, create one with today's date
    if target_column not in df.columns:
        print(f"Warning: No date column found, using current date")
        df[target_column] = datetime.now()
    
    return df

def safe_is_booked(lead_row):
    """
    Enhanced check if lead is booked based on Airtable schema
    Works with either DataFrame row or Series
    """
    try:
        # First, check Consult Status
        if 'Consult Status' in lead_row and pd.notna(lead_row.get('Consult Status')):
            status = str(lead_row['Consult Status']).lower()
            if any(term in status for term in ['booked', 'scheduled', 'confirmed', 'appointment']):
                return True
        
        # Try all variations of booking status fields
        status_fields = [
            'Status', 'Overall Status', 'Lead Status', 'Booking Status', 
            'Appointment Status', 'Client Status'
        ]
        
        for field in status_fields:
            if field in lead_row and pd.notna(lead_row.get(field)):
                status = str(lead_row[field]).lower()
                if any(term in status for term in [
                    'booked', 'scheduled', 'consult', 'appointment', 
                    'follow-up', 'contacted', 'confirmed'
                ]):
                    return True
        
        # Check date fields that would indicate booking
        date_fields = [
            'Consult', 'Consultation Date', 'Appointment Date', 
            'Scheduled Date', 'Follow Up Date'
        ]
        
        for field in date_fields:
            if field in lead_row and pd.notna(lead_row.get(field)):
                return True
        
        # Check for any fields that might indicate booking
        for field, value in lead_row.items():
            if pd.notna(value):
                field_lower = field.lower()
                if ('consult' in field_lower or 'appoint' in field_lower) and not 'status' in field_lower:
                    # If it's a date field or contains meaningful data
                    if value is not None and str(value).strip():
                        return True
                        
        return False
    except Exception as e:
        print(f"Error in safe_is_booked: {e}")
        return False

def safe_is_converted(lead_row):
    """
    Enhanced check if lead has converted based on Airtable schema
    Works with either DataFrame row or Series
    """
    try:
        # Check all potential status fields
        status_fields = [
            'Status', 'Overall Status', 'Lead Status', 'Client Status',
            'Conversion Status', 'Deal Status'
        ]
        
        for field in status_fields:
            if field in lead_row and pd.notna(lead_row.get(field)):
                status = str(lead_row[field]).lower()
                if any(term in status for term in [
                    'closed', 'converted', 'won', 'paid', 'deposit', 
                    'installment', 'customer', 'client', 'complete', 'surgery'
                ]):
                    return True
        
        # Check specific conversion indicators
        conversion_fields = [
            'Closed', 'Closed By', 'Closing Date', 'Deposit Date', 
            'Surgery Date', 'Procedure Date', 'Customer Since',
            'Deposit Amount', 'Payment Date', 'Transactions',
            'Transaction ID', 'Sale Amount', 'Revenue', 'Payment'
        ]
        
        for field in conversion_fields:
            if field in lead_row and pd.notna(lead_row.get(field)):
                return True
                
        # Check for specific pattern fields    
        for field, value in lead_row.items():
            if pd.notna(value):
                field_lower = field.lower()
                
                # Check for revenue or transaction related fields
                if any(term in field_lower for term in ['revenue', 'transaction', 'payment', 'deposit']):
                    if isinstance(value, (int, float)) and value > 0:
                        return True
                    elif isinstance(value, str) and value.strip():
                        # Non-empty string in a transaction field
                        return True
                    elif isinstance(value, list) and len(value) > 0:
                        # Non-empty list (like related records)
                        return True
        
        # Check if we have date fields related to closing
        date_fields = ['Closed Date', 'Closing Date', 'Sale Date', 'Customer Since']
        for field in date_fields:
            if field in lead_row and pd.notna(lead_row.get(field)):
                return True
        
        return False
    except Exception as e:
        print(f"Error in safe_is_converted: {e}")
        return False

def calculate_metrics(leads_df):
    """Calculate core metrics for dashboard"""
    metrics = {
        'leads_count': 0,
        'booked_count': 0,
        'converted_count': 0,
        'booking_rate': 0,
        'conversion_rate': 0
    }
    
    if leads_df is None or leads_df.empty:
        return metrics
    
    # Count all leads (already filtered to Smooth MD Meta)
    metrics['leads_count'] = len(leads_df)
    
    # Count booked and converted leads
    booked_count = sum(safe_is_booked(row) for _, row in leads_df.iterrows())
    converted_count = sum(safe_is_converted(row) for _, row in leads_df.iterrows())
    
    # Update metrics
    metrics['booked_count'] = booked_count
    metrics['converted_count'] = converted_count
    
    # Calculate rates (avoiding division by zero)
    if metrics['leads_count'] > 0:
        metrics['booking_rate'] = (booked_count / metrics['leads_count']) * 100
        metrics['conversion_rate'] = (converted_count / metrics['leads_count']) * 100
    
    return metrics