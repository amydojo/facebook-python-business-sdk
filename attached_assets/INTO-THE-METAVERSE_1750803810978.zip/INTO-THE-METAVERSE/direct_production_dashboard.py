"""
Direct Production Meta Marketing Dashboard
Bypasses connector issues with direct Airtable API calls
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import logging
import os
import requests
from pyairtable import Api

# Feature flag for attribution functionality - Enable by default for demonstration
ENABLE_ATTRIBUTION = os.getenv("ENABLE_ATTRIBUTION", "true").lower() == "true"

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Conditional attribution imports with global variable setup
AttributionModels = None
build_journeys = None
calculate_attribution_roas = None

if ENABLE_ATTRIBUTION:
    try:
        from attribution import AttributionModels, build_journeys, calculate_attribution_roas
        logger.info("Attribution module loaded successfully")
    except ImportError as e:
        logger.error(f"Failed to import attribution module: {e}")
        ENABLE_ATTRIBUTION = False

# Configure APIs
API_KEY = 'patRpwfhYlGferLE8.17a89cf5c31e4ef29041a67a4b28ca4058bb443779beb0dd4352ad999b186cdd'
BASE_ID = 'appH4MePHS6qLsk5z'

# Meta API Configuration
META_ACCESS_TOKEN = os.getenv('META_ACCESS_TOKEN')
META_AD_ACCOUNT_ID = os.getenv('META_AD_ACCOUNT_ID')

# Page configuration
st.set_page_config(page_title="Meta Marketing Dashboard",
                   page_icon="📊",
                   layout="wide",
                   initial_sidebar_state="expanded")

# Professional styling
st.markdown("""
<style>
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1.5rem;
        border-radius: 10px;
        margin: 0.5rem 0;
        text-align: center;
    }
    .metric-value {
        font-size: 2rem;
        font-weight: bold;
    }
    .metric-label {
        font-size: 0.9rem;
        opacity: 0.9;
    }
    .status-good {
        background: #28a745;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        margin: 0.2rem;
    }
    .status-warning {
        background: #ffc107;
        color: #212529;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        margin: 0.2rem;
    }
    .status-error {
        background: #dc3545;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        margin: 0.2rem;
    }
</style>
""", unsafe_allow_html=True)

@st.cache_data(ttl=600)  # Cache for 10 minutes  
def get_meta_ad_spend(start_date, end_date):
    """Fetch actual ad spend from Meta API for Smooth MD campaigns"""
    if not META_ACCESS_TOKEN or not META_AD_ACCOUNT_ID:
        return None, "Meta API credentials not configured"
    
    try:
        # Format dates for Meta API
        start_date_formatted = datetime.strptime(start_date, '%Y-%m-%d').strftime('%Y-%m-%d')
        end_date_formatted = datetime.strptime(end_date, '%Y-%m-%d').strftime('%Y-%m-%d')
        
        # Meta API endpoint for ad account insights
        url = f"https://graph.facebook.com/v18.0/act_{META_AD_ACCOUNT_ID}/insights"
        
        params = {
            'access_token': META_ACCESS_TOKEN,
            'time_range': f'{{"since":"{start_date_formatted}","until":"{end_date_formatted}"}}',
            'fields': 'spend,campaign_name,impressions,clicks,ctr,cpm',
            'level': 'campaign',
            'limit': 200
        }
        
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        data = response.json()
        
        if 'data' not in data:
            return None, f"No data field in API response: {data}"
        
        all_campaigns = data['data']
        
        # Debug info - track all campaigns and filtering
        debug_info = {
            'total_campaigns_found': len(all_campaigns),
            'all_campaign_names': [c.get('campaign_name', 'Unknown') for c in all_campaigns],
            'total_unfiltered_spend': sum(float(c.get('spend', 0)) for c in all_campaigns)
        }
        
        # Include ALL campaigns for Smooth MD (excluding only Dr. Vigor)
        smooth_campaigns = []
        total_spend = 0
        
        for campaign in all_campaigns:
            campaign_name = campaign.get('campaign_name', '').lower()
            spend = float(campaign.get('spend', 0))
            
            # Exclude only Dr. Vigor campaigns, include everything else
            is_dr_vigor = False
            vigor_indicators = ['vigor', 'dr vigor', 'dr. vigor', 'drvigour', 'dr vigour']
            
            for indicator in vigor_indicators:
                if indicator in campaign_name:
                    is_dr_vigor = True
                    break
            
            # Include all campaigns except Dr. Vigor
            if not is_dr_vigor:
                smooth_campaigns.append(campaign)
                total_spend += spend
        
        # Get detailed ad set and ad data for included campaigns
        adset_data = []
        ad_data = []
        
        if smooth_campaigns:
            # Get ad sets for each campaign
            for campaign in smooth_campaigns:
                campaign_id = campaign.get('campaign_id')
                if campaign_id:
                    try:
                        # Fetch ad sets
                        adset_url = f"https://graph.facebook.com/v18.0/{campaign_id}/adsets"
                        adset_params = {
                            'access_token': META_ACCESS_TOKEN,
                            'fields': 'name,campaign_id,status,daily_budget,lifetime_budget,targeting',
                            'limit': 50
                        }
                        adset_response = requests.get(adset_url, params=adset_params)
                        if adset_response.status_code == 200:
                            adset_result = adset_response.json()
                            for adset in adset_result.get('data', []):
                                adset['campaign_name'] = campaign.get('campaign_name')
                                adset_data.append(adset)
                                
                                # Get ads for each ad set
                                adset_id = adset.get('id')
                                if adset_id:
                                    ad_url = f"https://graph.facebook.com/v18.0/{adset_id}/ads"
                                    ad_params = {
                                        'access_token': META_ACCESS_TOKEN,
                                        'fields': 'name,adset_id,status,creative',
                                        'limit': 50
                                    }
                                    ad_response = requests.get(ad_url, params=ad_params)
                                    if ad_response.status_code == 200:
                                        ad_result = ad_response.json()
                                        for ad in ad_result.get('data', []):
                                            ad['campaign_name'] = campaign.get('campaign_name')
                                            ad['adset_name'] = adset.get('name')
                                            ad_data.append(ad)
                    except:
                        continue
        
        # Get insights for ad sets and ads
        adset_insights = []
        ad_insights = []
        
        if adset_data:
            try:
                adset_insights_url = f"https://graph.facebook.com/v18.0/act_{META_AD_ACCOUNT_ID}/insights"
                adset_insights_params = {
                    'access_token': META_ACCESS_TOKEN,
                    'time_range': f'{{"since":"{start_date_formatted}","until":"{end_date_formatted}"}}',
                    'fields': 'adset_name,adset_id,spend,impressions,clicks,ctr,cpm,cpp,reach,frequency,cost_per_conversion,conversions',
                    'level': 'adset',
                    'limit': 200
                }
                adset_insights_response = requests.get(adset_insights_url, params=adset_insights_params)
                if adset_insights_response.status_code == 200:
                    adset_insights = adset_insights_response.json().get('data', [])
            except:
                pass
        
        if ad_data:
            try:
                ad_insights_url = f"https://graph.facebook.com/v18.0/act_{META_AD_ACCOUNT_ID}/insights"
                ad_insights_params = {
                    'access_token': META_ACCESS_TOKEN,
                    'time_range': f'{{"since":"{start_date_formatted}","until":"{end_date_formatted}"}}',
                    'fields': 'ad_name,ad_id,spend,impressions,clicks,ctr,cpm,cpp,reach,frequency,cost_per_conversion,conversions',
                    'level': 'ad',
                    'limit': 200
                }
                ad_insights_response = requests.get(ad_insights_url, params=ad_insights_params)
                if ad_insights_response.status_code == 200:
                    ad_insights = ad_insights_response.json().get('data', [])
            except:
                pass

        return {
            'total_spend': total_spend,
            'campaigns': smooth_campaigns,
            'campaign_count': len(smooth_campaigns),
            'adsets': adset_data,
            'ads': ad_data,
            'adset_insights': adset_insights,
            'ad_insights': ad_insights,
            'debug_info': debug_info,
            'api_response_sample': all_campaigns[:3] if all_campaigns else []
        }, None
        
    except requests.exceptions.RequestException as e:
        return None, f"Meta API request failed: {str(e)}"
    except Exception as e:
        return None, f"Error fetching Meta ad spend: {str(e)}"

@st.cache_data(ttl=600)  # Cache for 10 minutes
def load_and_filter_airtable_data(table_name, start_date, end_date):
    """Load and filter data from Airtable with date range filtering"""
    try:
        # Initialize API using correct base -> table pattern
        api = Api(API_KEY)
        base = api.base(BASE_ID)
        table = base.table(table_name)
        
        # Load all records with optimized batch processing
        all_records = table.all()
        
        # Convert to list of dicts and apply date filtering
        filtered_data = []
        start_dt = datetime.strptime(start_date, '%Y-%m-%d')
        end_dt = datetime.strptime(end_date, '%Y-%m-%d')
        
        date_field_options = {
            'Leads': ['Inbound', 'Created Time', 'Date'],
            'Transactions': ['Date', 'Created Time', 'Initial Purchase Month']
        }
        
        date_fields = date_field_options.get(table_name, ['Date', 'Created Time'])
        
        for record in all_records:
            row = {'record_id': record['id']}
            row.update(record['fields'])
            
            # Apply date filtering
            record_date = None
            for date_field in date_fields:
                if date_field in row and row[date_field]:
                    try:
                        date_str = str(row[date_field])
                        if 'T' in date_str:
                            record_date = datetime.fromisoformat(date_str.split('T')[0])
                        elif '-' in date_str:
                            record_date = datetime.strptime(date_str, '%Y-%m-%d')
                        elif '/' in date_str:
                            record_date = datetime.strptime(date_str, '%m/%d/%Y')
                        break
                    except:
                        continue
            
            # Include record if it falls within date range or if no date found (to be safe)
            if record_date is None or (start_dt <= record_date <= end_dt):
                filtered_data.append(row)
        
        return True, filtered_data, len(all_records), len(filtered_data)
        
    except Exception as e:
        st.error(f"Error loading {table_name}: {str(e)}")
        return False, [], 0, 0

# Removed old filter_date_range function - now handled in load_and_filter_airtable_data

def identify_meta_leads(leads_data):
    """Identify Meta/Facebook leads"""
    meta_leads = []
    
    for lead in leads_data:
        # Check Contact Source field (the actual field name from API test)
        source_fields = ['Contact Source', 'Source', 'Lead Source', 'UTM Source', 'Campaign Source']
        is_meta = False
        
        for field in source_fields:
            if field in lead and lead[field]:
                source = str(lead[field]).lower()
                if any(term in source for term in ['facebook', 'meta', 'fb', 'instagram']):
                    is_meta = True
                    break
        
        if is_meta:
            meta_leads.append(lead)
    
    return meta_leads

def filter_smooth_md_leads(meta_leads):
    """Filter to only Smooth MD leads (exclude Dr. Vigor)"""
    smooth_leads = []
    
    for lead in meta_leads:
        # Check brand/company fields
        brand_fields = ['Brand', 'Company', 'Business', 'Account']
        is_smooth_md = False
        
        for field in brand_fields:
            if field in lead and lead[field]:
                brand = str(lead[field]).lower()
                if 'smooth' in brand and 'vigor' not in brand:
                    is_smooth_md = True
                    break
        
        if is_smooth_md:
            smooth_leads.append(lead)
    
    return smooth_leads

def filter_smooth_md_transactions(transactions):
    """Filter transactions to only include Smooth MD transactions"""
    smooth_transactions = []
    
    for tx in transactions:
        # Check Brand (from ID) field to exclude Dr. Vigor
        brand_field = tx.get('Brand (from ID)', [])
        if isinstance(brand_field, list) and brand_field:
            brand = str(brand_field[0]).lower()
        else:
            brand = str(brand_field).lower() if brand_field else ""
        
        # Also check Calculation field as backup
        calculation_field = tx.get('Calculation', '')
        calculation = str(calculation_field).lower() if calculation_field else ""
        
        # Only include if it's Smooth MD (not Dr. Vigor)
        if ('smooth' in brand and 'vigor' not in brand) or ('smooth' in calculation and 'vigor' not in calculation):
            smooth_transactions.append(tx)
        elif 'vigor' not in brand and 'vigor' not in calculation:
            # If no clear brand indicator, assume it's Smooth MD unless explicitly Dr. Vigor
            smooth_transactions.append(tx)
    
    return smooth_transactions

def match_transactions_to_leads(leads, transactions):
    """Match transactions to leads using hybrid approach for maximum accuracy"""
    matched_leads = []
    total_revenue = 0
    matched_count = 0
    
    # First filter transactions to only Smooth MD
    smooth_transactions = filter_smooth_md_transactions(transactions)
    
    # Create multiple lookup strategies
    # Strategy 1: Record ID lookup
    record_id_lookup = {}
    for tx in smooth_transactions:
        if 'ID' in tx and tx['ID']:
            lead_ids = tx['ID'] if isinstance(tx['ID'], list) else [tx['ID']]
            for lead_id in lead_ids:
                lead_record_id = str(lead_id).strip()
                if lead_record_id not in record_id_lookup:
                    record_id_lookup[lead_record_id] = []
                record_id_lookup[lead_record_id].append(tx)
    
    # Strategy 2: Email lookup
    email_lookup = {}
    for tx in smooth_transactions:
        tx_emails = tx.get('Email', [])
        if isinstance(tx_emails, list):
            for email in tx_emails:
                if email:
                    clean_email = str(email).strip().lower()
                    if clean_email not in email_lookup:
                        email_lookup[clean_email] = []
                    email_lookup[clean_email].append(tx)
    
    # Strategy 3: Phone lookup (last 10 digits)
    phone_lookup = {}
    for tx in smooth_transactions:
        tx_phones = tx.get('Phone number', [])
        if isinstance(tx_phones, list):
            for phone in tx_phones:
                if phone:
                    clean_phone = ''.join(filter(str.isdigit, str(phone)))
                    if len(clean_phone) >= 10:
                        phone_key = clean_phone[-10:]
                        if phone_key not in phone_lookup:
                            phone_lookup[phone_key] = []
                        phone_lookup[phone_key].append(tx)
    
    # Match leads using hybrid approach
    for lead in leads:
        lead_copy = lead.copy()
        lead_copy['matched_transactions'] = []
        lead_copy['total_revenue'] = 0
        matched_txs = []
        
        # Method 1: Record ID matching (primary)
        lead_record_id = lead.get('record_id', '')
        if lead_record_id in record_id_lookup:
            matched_txs.extend(record_id_lookup[lead_record_id])
        
        # Method 2: Email matching (fallback)
        if not matched_txs and 'Email' in lead and lead['Email']:
            lead_email = str(lead['Email']).strip().lower()
            if lead_email in email_lookup:
                matched_txs.extend(email_lookup[lead_email])
        
        # Method 3: Phone matching (fallback)
        if not matched_txs and 'Phone' in lead and lead['Phone']:
            lead_phone = ''.join(filter(str.isdigit, str(lead['Phone'])))
            if len(lead_phone) >= 10:
                phone_key = lead_phone[-10:]
                if phone_key in phone_lookup:
                    matched_txs.extend(phone_lookup[phone_key])
        
        # Remove duplicates and calculate revenue
        if matched_txs:
            # Remove duplicate transactions
            unique_txs = []
            seen_ids = set()
            for tx in matched_txs:
                tx_id = tx.get('record_id', '')
                if tx_id not in seen_ids:
                    unique_txs.append(tx)
                    seen_ids.add(tx_id)
            
            lead_copy['matched_transactions'] = unique_txs
            matched_count += 1
            
            # Calculate revenue
            for tx in unique_txs:
                if 'Amount' in tx and tx['Amount']:
                    try:
                        amount = float(tx['Amount'])
                        lead_copy['total_revenue'] += amount
                        total_revenue += amount
                    except:
                        continue
        
        matched_leads.append(lead_copy)
    
    return matched_leads, {
        'total_matched_revenue': total_revenue,
        'matched_leads_count': matched_count,
        'total_leads': len(leads),
        'smooth_transactions_count': len(smooth_transactions),
        'total_transactions': len(transactions),
        'record_id_matches': len(record_id_lookup),
        'email_matches': len(email_lookup),
        'phone_matches': len(phone_lookup)
    }

def main():
    # Mobile-optimized CSS
    st.markdown("""
    <style>
    /* Mobile date picker optimization */
    .stDateInput > div > div > input {
        font-size: 16px !important;
        padding: 12px !important;
        border-radius: 8px !important;
        border: 2px solid #e0e0e0 !important;
        background-color: white !important;
    }
    
    /* Mobile button optimization */
    .stButton > button {
        width: 100% !important;
        padding: 12px 8px !important;
        font-size: 14px !important;
        border-radius: 8px !important;
        margin: 2px 0 !important;
        touch-action: manipulation !important;
    }
    
    /* Prevent zoom on mobile inputs */
    input, select, textarea {
        font-size: 16px !important;
    }
    
    /* Better touch targets */
    .stButton button:hover {
        transform: scale(1.02) !important;
        transition: transform 0.1s !important;
    }
    
    /* Date range summary styling */
    .date-summary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 15px;
        border-radius: 10px;
        text-align: center;
        margin: 10px 0;
        font-weight: bold;
    }
    
    /* Mobile responsive columns */
    @media (max-width: 768px) {
        .stColumns {
            flex-direction: column !important;
        }
        
        .stColumn {
            width: 100% !important;
            margin-bottom: 10px !important;
        }
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.title("🎯 Meta Marketing Dashboard")
    st.markdown("**Production Dashboard with Direct Airtable Connection**")
    
    # Initialize session state for date range
    if 'date_range_start' not in st.session_state:
        st.session_state.date_range_start = datetime.now().date() - timedelta(days=30)
    if 'date_range_end' not in st.session_state:
        st.session_state.date_range_end = datetime.now().date()
    
    # Mobile-optimized date range selector
    st.header("📅 Select Date Range")
    
    # Quick select buttons for mobile with session state
    st.write("**Quick Select:**")
    
    # Mobile stacked layout for better touch
    col1, col2 = st.columns(2)
    with col1:
        if st.button("📅 Last 7 Days", use_container_width=True, key="7days"):
            st.session_state.date_range_start = datetime.now().date() - timedelta(days=7)
            st.session_state.date_range_end = datetime.now().date()
            st.rerun()
        
        if st.button("📅 Last 30 Days", use_container_width=True, key="30days"):
            st.session_state.date_range_start = datetime.now().date() - timedelta(days=30)
            st.session_state.date_range_end = datetime.now().date()
            st.rerun()
        
        if st.button("📅 Last 90 Days", use_container_width=True, key="90days"):
            st.session_state.date_range_start = datetime.now().date() - timedelta(days=90)
            st.session_state.date_range_end = datetime.now().date()
            st.rerun()
    
    with col2:
        if st.button("📅 Last 14 Days", use_container_width=True, key="14days"):
            st.session_state.date_range_start = datetime.now().date() - timedelta(days=14)
            st.session_state.date_range_end = datetime.now().date()
            st.rerun()
        
        if st.button("📅 Last 60 Days", use_container_width=True, key="60days"):
            st.session_state.date_range_start = datetime.now().date() - timedelta(days=60)
            st.session_state.date_range_end = datetime.now().date()
            st.rerun()
        
        if st.button("📅 This Month", use_container_width=True, key="thismonth"):
            today = datetime.now().date()
            st.session_state.date_range_start = today.replace(day=1)
            st.session_state.date_range_end = today
            st.rerun()
    
    st.divider()
    
    # Custom date selection with improved mobile interface
    st.write("**Custom Range:**")
    col1, col2 = st.columns(2)
    
    with col1:
        selected_start = st.date_input(
            "Start Date",
            value=st.session_state.date_range_start,
            max_value=datetime.now().date(),
            help="Touch to select start date",
            key="start_date_input"
        )
    
    with col2:
        selected_end = st.date_input(
            "End Date", 
            value=st.session_state.date_range_end,
            max_value=datetime.now().date(),
            help="Touch to select end date",
            key="end_date_input"
        )
    
    # Update session state when dates change
    if selected_start != st.session_state.date_range_start:
        st.session_state.date_range_start = selected_start
    if selected_end != st.session_state.date_range_end:
        st.session_state.date_range_end = selected_end
    
    # Validation
    if selected_start > selected_end:
        st.error("⚠️ Start date must be before end date")
        st.stop()
    
    # Enhanced date range summary with styling
    days_selected = (selected_end - selected_start).days + 1
    st.markdown(f"""
    <div class="date-summary">
        📊 Selected Period: {days_selected} days<br>
        📅 {selected_start.strftime('%b %d, %Y')} → {selected_end.strftime('%b %d, %Y')}
    </div>
    """, unsafe_allow_html=True)
    
    start_str = selected_start.strftime('%Y-%m-%d')
    end_str = selected_end.strftime('%Y-%m-%d')
    
    # Load data
    st.header("📊 Data Loading Status")
    
    with st.spinner("Loading data and fetching Meta ad spend..."):
        # Load and filter leads
        leads_success, leads_data, total_leads, filtered_leads = load_and_filter_airtable_data('Leads', start_str, end_str)
        
        # Load and filter transactions  
        tx_success, tx_data, total_tx, filtered_tx = load_and_filter_airtable_data('Transactions', start_str, end_str)
        
        # Fetch actual Meta ad spend
        meta_spend_data, meta_error = get_meta_ad_spend(start_str, end_str)
    
    # Display load status with date filtering info and Meta spend
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if leads_success:
            st.markdown(f'<div class="status-good">✅ Leads: {len(leads_data)} in range</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="status-error">❌ Leads: Failed to load</div>', unsafe_allow_html=True)
    
    with col2:
        if tx_success:
            st.markdown(f'<div class="status-good">✅ Transactions: {len(tx_data)} in range</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="status-error">❌ Transactions: Failed to load</div>', unsafe_allow_html=True)
    
    with col3:
        if meta_spend_data:
            st.markdown(f'<div class="status-good">✅ Meta Spend: ${meta_spend_data["total_spend"]:.0f}</div>', unsafe_allow_html=True)
        elif meta_error:
            st.markdown(f'<div class="status-error">⚠️ Meta API: {meta_error[:30]}...</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="status-error">❌ Meta API: No data</div>', unsafe_allow_html=True)
    
    # Meta API Date Range Validation
    if meta_spend_data:
        st.info(f"📅 Meta API Data Range: {start_str} to {end_str} | Found: ${meta_spend_data['total_spend']:.2f} spend")
        
        # Show date range validation for campaigns
        if meta_spend_data.get('api_response_sample'):
            sample_campaign = meta_spend_data['api_response_sample'][0] if meta_spend_data['api_response_sample'] else {}
            if 'date_start' in sample_campaign and 'date_stop' in sample_campaign:
                st.success(f"✅ Date filtering confirmed: Campaign data from {sample_campaign['date_start']} to {sample_campaign['date_stop']}")
    
    # Debug Meta API response for troubleshooting
    if meta_error:
        st.error(f"Meta API Error: {meta_error}")
    elif meta_spend_data and meta_spend_data['total_spend'] == 0:
        st.warning("Meta API connected but found $0 spend in selected date range. Debug info:")
        
        debug_info = meta_spend_data.get('debug_info', {})
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Total Campaigns Found", debug_info.get('total_campaigns_found', 0))
        
        with col2:
            st.metric("Unfiltered Total Spend", f"${debug_info.get('total_unfiltered_spend', 0):.2f}")
        
        with col3:
            st.metric("Filtered Campaigns", meta_spend_data.get('campaign_count', 0))
        
        with st.expander("All Campaign Names Found"):
            campaign_names = debug_info.get('all_campaign_names', [])
            if campaign_names:
                for name in campaign_names:
                    st.write(f"- {name}")
            else:
                st.write("No campaigns found in the API response")
        
        with st.expander("Raw API Sample"):
            st.json(meta_spend_data.get('api_response_sample', []))
    
    if not leads_success or not tx_success:
        st.error("Cannot proceed without both Leads and Transactions data")
        return
    
    st.info(f"Date Range: {start_str} to {end_str}")
    
    # Process data pipeline
    # Step 1: Identify Meta leads
    meta_leads = identify_meta_leads(leads_data)
    
    # Step 2: Filter to Smooth MD only
    smooth_meta_leads = filter_smooth_md_leads(meta_leads)
    
    # Step 3: Match transactions to leads
    matched_leads, matching_stats = match_transactions_to_leads(smooth_meta_leads, tx_data)
    
    # Calculate comprehensive KPIs
    total_revenue = matching_stats['total_matched_revenue']
    total_leads = len(smooth_meta_leads)
    converted_leads = matching_stats['matched_leads_count']
    
    # Use actual Meta ad spend or fallback to estimation
    if meta_spend_data and meta_spend_data['total_spend'] > 0:
        actual_spend = meta_spend_data['total_spend']
        spend_source = "Meta API"
    else:
        # Fallback estimation if Meta API fails
        estimated_daily_spend = 500
        days_in_range = (datetime.strptime(end_str, '%Y-%m-%d') - datetime.strptime(start_str, '%Y-%m-%d')).days + 1
        actual_spend = estimated_daily_spend * days_in_range
        spend_source = "Estimated"
    
    # Calculate KPIs using actual spend
    conversion_rate = (converted_leads / total_leads * 100) if total_leads > 0 else 0
    avg_revenue_per_lead = total_revenue / total_leads if total_leads > 0 else 0
    avg_revenue_per_conversion = total_revenue / converted_leads if converted_leads > 0 else 0
    roas = total_revenue / actual_spend if actual_spend > 0 else 0
    roi = ((total_revenue - actual_spend) / actual_spend * 100) if actual_spend > 0 else 0
    cost_per_lead = actual_spend / total_leads if total_leads > 0 else 0
    cost_per_acquisition = actual_spend / converted_leads if converted_leads > 0 else 0
    
    # Display comprehensive KPIs
    st.header("🎯 Marketing Performance KPIs")
    
    # Row 1: Core Metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{total_leads}</div>
            <div class="metric-label">Total Leads</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{converted_leads}</div>
            <div class="metric-label">Conversions</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">${total_revenue:,.0f}</div>
            <div class="metric-label">Total Revenue</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{conversion_rate:.1f}%</div>
            <div class="metric-label">Conversion Rate</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Row 2: Financial KPIs
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        roas_color = "color: #28a745;" if roas >= 4.0 else "color: #ffc107;" if roas >= 2.0 else "color: #dc3545;"
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value" style="{roas_color}">{roas:.1f}x</div>
            <div class="metric-label">ROAS</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        roi_color = "color: #28a745;" if roi >= 200 else "color: #ffc107;" if roi >= 100 else "color: #dc3545;"
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value" style="{roi_color}">{roi:.0f}%</div>
            <div class="metric-label">ROI</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">${cost_per_lead:.0f}</div>
            <div class="metric-label">Cost Per Lead</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">${cost_per_acquisition:.0f}</div>
            <div class="metric-label">Cost Per Acquisition</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Row 3: Revenue Metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">${avg_revenue_per_lead:.0f}</div>
            <div class="metric-label">Avg Revenue/Lead</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">${avg_revenue_per_conversion:.0f}</div>
            <div class="metric-label">Avg Revenue/Conversion</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">${actual_spend:,.0f}</div>
            <div class="metric-label">{spend_source} Ad Spend</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        profit = total_revenue - actual_spend
        profit_color = "color: #28a745;" if profit > 0 else "color: #dc3545;"
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value" style="{profit_color}">${profit:,.0f}</div>
            <div class="metric-label">Profit</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Revenue breakdown chart
    if matching_stats['total_matched_revenue'] > 0:
        st.header("💰 Revenue Analysis")
        
        # Create revenue by lead chart
        lead_revenues = []
        for lead in matched_leads:
            if lead['total_revenue'] > 0:
                lead_name = lead.get('Name', lead.get('Contact', f"Lead {lead.get('record_id', 'Unknown')}"))
                lead_revenues.append({
                    'Lead': lead_name[:50],  # Truncate long names
                    'Revenue': lead['total_revenue'],
                    'Transactions': len(lead['matched_transactions'])
                })
        
        if lead_revenues:
            df_revenue = pd.DataFrame(lead_revenues)
            df_revenue = df_revenue.sort_values('Revenue', ascending=False).head(20)
            
            fig = px.bar(df_revenue, x='Lead', y='Revenue', 
                        title='Top 20 Leads by Revenue',
                        color='Revenue',
                        color_continuous_scale='viridis')
            fig.update_layout(xaxis_tickangle=45)
            st.plotly_chart(fig, use_container_width=True)
            
            # Revenue distribution analysis
            st.subheader("Revenue Distribution")
            col1, col2 = st.columns(2)
            
            with col1:
                # Revenue ranges
                revenue_ranges = {
                    '$0-$1,000': 0,
                    '$1,000-$5,000': 0,
                    '$5,000-$10,000': 0,
                    '$10,000+': 0
                }
                
                for revenue in df_revenue['Revenue']:
                    if revenue < 1000:
                        revenue_ranges['$0-$1,000'] += 1
                    elif revenue < 5000:
                        revenue_ranges['$1,000-$5,000'] += 1
                    elif revenue < 10000:
                        revenue_ranges['$5,000-$10,000'] += 1
                    else:
                        revenue_ranges['$10,000+'] += 1
                
                fig_pie = px.pie(values=list(revenue_ranges.values()), 
                               names=list(revenue_ranges.keys()),
                               title='Revenue Range Distribution')
                st.plotly_chart(fig_pie, use_container_width=True)
            
            with col2:
                st.metric("Highest Revenue Lead", f"${df_revenue['Revenue'].max():,.0f}")
                st.metric("Average Revenue per Conversion", f"${df_revenue['Revenue'].mean():,.0f}")
                st.metric("Median Revenue", f"${df_revenue['Revenue'].median():,.0f}")
    
    # Performance benchmarks and insights
    st.header("📊 Performance Benchmarks")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("ROAS Performance")
        if roas >= 4.0:
            st.success(f"Excellent ROAS: {roas:.1f}x (Target: 4.0x+)")
        elif roas >= 2.0:
            st.warning(f"Good ROAS: {roas:.1f}x (Target: 4.0x+)")
        else:
            st.error(f"Below Target ROAS: {roas:.1f}x (Target: 4.0x+)")
        
        st.info(f"For every $1 spent, you generate ${roas:.2f} in revenue")
    
    with col2:
        st.subheader("Conversion Rate")
        if conversion_rate >= 15:
            st.success(f"Excellent: {conversion_rate:.1f}% (Industry avg: 10-15%)")
        elif conversion_rate >= 10:
            st.warning(f"Good: {conversion_rate:.1f}% (Industry avg: 10-15%)")
        else:
            st.error(f"Below Average: {conversion_rate:.1f}% (Industry avg: 10-15%)")
        
        st.info(f"{converted_leads} of {total_leads} leads converted")
    
    # Campaign optimization insights
    st.header("💡 Optimization Insights")
    
    insights = []
    
    if roas < 2.0:
        insights.append("🔴 **Critical**: ROAS below 2x - Review targeting and ad creative")
    elif roas < 4.0:
        insights.append("🟡 **Optimize**: ROAS can be improved - Test new audiences or creatives")
    else:
        insights.append("🟢 **Excellent**: Strong ROAS - Consider scaling successful campaigns")
    
    if conversion_rate < 10:
        insights.append("🔴 **Improve**: Low conversion rate - Review landing pages and lead forms")
    elif conversion_rate < 15:
        insights.append("🟡 **Good**: Solid conversion rate - Test funnel optimizations")
    else:
        insights.append("🟢 **Excellent**: High conversion rate - Scale winning elements")
    
    if cost_per_acquisition > 200:
        insights.append("🟡 **Monitor**: High CPA - Optimize for lower acquisition costs")
    
    if avg_revenue_per_conversion > 5000:
        insights.append("🟢 **Strength**: High-value conversions - Focus on similar audience segments")
    
    for insight in insights:
        st.markdown(insight)
    
    # Comprehensive Meta Analysis with Ad Set & Creative Breakdown
    if meta_spend_data and meta_spend_data['campaigns']:
        st.header("📱 Comprehensive Meta Campaign Analysis")
        
        # Load detailed ad performance data
        detailed_performance = {'adsets': [], 'ads': []}
        try:
            from unified_production_connector import UnifiedProductionConnector
            connector = UnifiedProductionConnector()
            
            # Get detailed ad set and creative data using the selected date range
            # Use the same date range as the main dashboard
            if 'selected_start_date' in st.session_state and 'selected_end_date' in st.session_state:
                start_str = st.session_state.selected_start_date.strftime('%Y-%m-%d')
                end_str = st.session_state.selected_end_date.strftime('%Y-%m-%d')
            else:
                # Fallback to last 7 days
                current_end = datetime.now()
                current_start = current_end - timedelta(days=7)
                start_str = current_start.strftime('%Y-%m-%d')
                end_str = current_end.strftime('%Y-%m-%d')
                
            detailed_performance = connector.get_detailed_ad_performance(start_str, end_str)
        except Exception as e:
            st.warning(f"Unable to load detailed ad performance: {str(e)}")
            
            # Campaign Level Analysis
            st.subheader("🎯 Campaign Performance")
            campaign_df = pd.DataFrame(meta_spend_data['campaigns'])
            if not campaign_df.empty:
                campaign_df['spend'] = campaign_df['spend'].astype(float)
                campaign_df['impressions'] = campaign_df['impressions'].astype(int)
                campaign_df['clicks'] = campaign_df['clicks'].astype(int)
                campaign_df['ctr'] = campaign_df['ctr'].astype(float)
                campaign_df['cpm'] = campaign_df['cpm'].astype(float)
                campaign_df = campaign_df.sort_values('spend', ascending=False)
                
                # Display campaign metrics
                st.dataframe(campaign_df[['campaign_name', 'spend', 'impressions', 'clicks', 'ctr', 'cpm']], use_container_width=True)
                
                # Ad Set Level Analysis
                if detailed_performance.get('adsets'):
                    st.subheader("🎨 Ad Set Performance Breakdown")
                    adset_df = pd.DataFrame(detailed_performance['adsets'])
                    if not adset_df.empty:
                        # Calculate performance metrics for each ad set
                        adset_df['spend'] = pd.to_numeric(adset_df['spend'], errors='coerce').fillna(0)
                        adset_df['impressions'] = pd.to_numeric(adset_df['impressions'], errors='coerce').fillna(0)
                        adset_df['clicks'] = pd.to_numeric(adset_df['clicks'], errors='coerce').fillna(0)
                        adset_df['ctr'] = pd.to_numeric(adset_df['ctr'], errors='coerce').fillna(0)
                        adset_df['cpc'] = pd.to_numeric(adset_df.get('cpc', 0), errors='coerce').fillna(0)
                        
                        # Sort by spend
                        adset_df = adset_df.sort_values('spend', ascending=False)
                        
                        # Display top performing ad sets
                        st.write("**Top Ad Sets by Spend:**")
                        display_cols = ['adset_name', 'campaign_name', 'spend', 'impressions', 'clicks', 'ctr', 'cpc']
                        available_cols = [col for col in display_cols if col in adset_df.columns]
                        st.dataframe(adset_df[available_cols].head(10), use_container_width=True)
                        
                        # Ad set performance insights
                        col1, col2 = st.columns(2)
                        with col1:
                            if len(adset_df) > 0:
                                top_adset = adset_df.iloc[0]
                                st.metric("Top Ad Set", top_adset.get('adset_name', 'Unknown'), f"${top_adset.get('spend', 0):.2f}")
                                st.metric("Best CTR Ad Set", 
                                         adset_df.loc[adset_df['ctr'].idxmax(), 'adset_name'] if len(adset_df) > 0 else 'N/A',
                                         f"{adset_df['ctr'].max():.2f}%" if len(adset_df) > 0 else "0%")
                        
                        with col2:
                            avg_ctr = adset_df['ctr'].mean()
                            st.metric("Average Ad Set CTR", f"{avg_ctr:.2f}%")
                            total_adsets = len(adset_df)
                            st.metric("Total Active Ad Sets", total_adsets)
                
                # Individual Ad Creative Analysis
                if detailed_performance.get('ads'):
                    st.subheader("🎭 Individual Ad Creative Performance")
                    ads_df = pd.DataFrame(detailed_performance['ads'])
                    if not ads_df.empty:
                        # Calculate performance metrics for each ad
                        ads_df['spend'] = pd.to_numeric(ads_df['spend'], errors='coerce').fillna(0)
                        ads_df['impressions'] = pd.to_numeric(ads_df['impressions'], errors='coerce').fillna(0)
                        ads_df['clicks'] = pd.to_numeric(ads_df['clicks'], errors='coerce').fillna(0)
                        ads_df['ctr'] = pd.to_numeric(ads_df['ctr'], errors='coerce').fillna(0)
                        ads_df['cpc'] = pd.to_numeric(ads_df.get('cpc', 0), errors='coerce').fillna(0)
                        
                        # Calculate creative performance score
                        ads_df['performance_score'] = (
                            (ads_df['ctr'] * 0.4) +  # CTR weight
                            ((1 / (ads_df['cpc'] + 0.01)) * 0.3) +  # CPC efficiency weight
                            (ads_df['impressions'] / ads_df['impressions'].max() * 0.3)  # Volume weight
                        ) * 100
                        
                        # Sort by performance score
                        ads_df = ads_df.sort_values('performance_score', ascending=False)
                        
                        # Display top performing ads
                        st.write("**Top Individual Ad Creatives by Performance Score:**")
                        display_cols = ['ad_name', 'adset_name', 'spend', 'impressions', 'clicks', 'ctr', 'cpc', 'performance_score']
                        available_cols = [col for col in display_cols if col in ads_df.columns]
                        
                        # Format the dataframe for display
                        display_df = ads_df[available_cols].head(15).copy()
                        if 'performance_score' in display_df.columns:
                            display_df['performance_score'] = display_df['performance_score'].round(1)
                        if 'spend' in display_df.columns:
                            display_df['spend'] = display_df['spend'].round(2)
                        if 'ctr' in display_df.columns:
                            display_df['ctr'] = display_df['ctr'].round(3)
                        if 'cpc' in display_df.columns:
                            display_df['cpc'] = display_df['cpc'].round(2)
                        
                        st.dataframe(display_df, use_container_width=True)
                        
                        # Creative performance insights
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            if len(ads_df) > 0:
                                best_ad = ads_df.iloc[0]
                                st.metric("Best Performing Ad", 
                                         best_ad.get('ad_name', 'Unknown')[:30] + "..." if len(str(best_ad.get('ad_name', ''))) > 30 else best_ad.get('ad_name', 'Unknown'),
                                         f"Score: {best_ad.get('performance_score', 0):.1f}")
                        
                        with col2:
                            if len(ads_df) > 0:
                                best_ctr_ad = ads_df.loc[ads_df['ctr'].idxmax()]
                                st.metric("Highest CTR Ad", 
                                         best_ctr_ad.get('ad_name', 'Unknown')[:30] + "..." if len(str(best_ctr_ad.get('ad_name', ''))) > 30 else best_ctr_ad.get('ad_name', 'Unknown'),
                                         f"{best_ctr_ad.get('ctr', 0):.2f}%")
                        
                        with col3:
                            total_ads = len(ads_df)
                            avg_creative_performance = ads_df['performance_score'].mean()
                            st.metric("Total Active Ads", total_ads)
                            st.metric("Avg Performance Score", f"{avg_creative_performance:.1f}")
                        
                        # Creative optimization recommendations
                        st.subheader("🎯 Creative Optimization Recommendations")
                        
                        # Identify underperforming ads
                        low_performers = ads_df[ads_df['performance_score'] < ads_df['performance_score'].quantile(0.3)]
                        high_performers = ads_df[ads_df['performance_score'] > ads_df['performance_score'].quantile(0.7)]
                        
                        col1, col2 = st.columns(2)
                        with col1:
                            st.write("**🔴 Underperforming Ads (Bottom 30%):**")
                            if len(low_performers) > 0:
                                for _, ad in low_performers.head(5).iterrows():
                                    st.warning(f"**{ad.get('ad_name', 'Unknown')[:40]}** - Score: {ad.get('performance_score', 0):.1f} | CTR: {ad.get('ctr', 0):.2f}%")
                            else:
                                st.success("No significantly underperforming ads found")
                        
                        with col2:
                            st.write("**🟢 Top Performing Ads (Top 30%):**")
                            if len(high_performers) > 0:
                                for _, ad in high_performers.head(5).iterrows():
                                    st.success(f"**{ad.get('ad_name', 'Unknown')[:40]}** - Score: {ad.get('performance_score', 0):.1f} | CTR: {ad.get('ctr', 0):.2f}%")
                            else:
                                st.info("Performance data still being analyzed")
            
            # Campaign performance insights
            col1, col2, col3 = st.columns(3)
            with col1:
                best_ctr_campaign = campaign_df.loc[campaign_df['ctr'].idxmax(), 'campaign_name'] if not campaign_df.empty else "N/A"
                st.metric("Best CTR Campaign", best_ctr_campaign)
            with col2:
                lowest_cpm_campaign = campaign_df.loc[campaign_df['cpm'].idxmin(), 'campaign_name'] if not campaign_df.empty else "N/A"
                st.metric("Lowest CPM Campaign", lowest_cpm_campaign)
            with col3:
                highest_spend_campaign = campaign_df.loc[campaign_df['spend'].idxmax(), 'campaign_name'] if not campaign_df.empty else "N/A"
                st.metric("Highest Spend Campaign", highest_spend_campaign)
        
        # Ad Set Level Analysis
        if meta_spend_data.get('adset_insights'):
            st.subheader("📊 Ad Set Performance Analysis")
            adset_insights_df = pd.DataFrame(meta_spend_data['adset_insights'])
            
            if not adset_insights_df.empty:
                # Convert numeric columns
                numeric_cols = ['spend', 'impressions', 'clicks', 'ctr', 'cpm', 'reach', 'frequency']
                for col in numeric_cols:
                    if col in adset_insights_df.columns:
                        adset_insights_df[col] = pd.to_numeric(adset_insights_df[col], errors='coerce').fillna(0)
                
                adset_insights_df = adset_insights_df.sort_values('spend', ascending=False)
                
                # Display top performing ad sets
                st.write("**Top Ad Sets by Spend:**")
                display_cols = ['adset_name', 'spend', 'impressions', 'clicks', 'ctr', 'cpm']
                available_cols = [col for col in display_cols if col in adset_insights_df.columns]
                st.dataframe(adset_insights_df[available_cols].head(10), use_container_width=True)
                
                # Ad set performance metrics
                if len(adset_insights_df) > 1:
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        avg_ctr = adset_insights_df['ctr'].mean() if 'ctr' in adset_insights_df.columns else 0
                        st.metric("Avg Ad Set CTR", f"{avg_ctr:.2f}%")
                    
                    with col2:
                        avg_cpm = adset_insights_df['cpm'].mean() if 'cpm' in adset_insights_df.columns else 0
                        st.metric("Avg Ad Set CPM", f"${avg_cpm:.2f}")
                    
                    with col3:
                        total_adset_reach = adset_insights_df['reach'].sum() if 'reach' in adset_insights_df.columns else 0
                        st.metric("Total Reach", f"{total_adset_reach:,.0f}")
                    
                    with col4:
                        avg_frequency = adset_insights_df['frequency'].mean() if 'frequency' in adset_insights_df.columns else 0
                        st.metric("Avg Frequency", f"{avg_frequency:.1f}")
                
                # Advanced Ad Set Analysis
                if 'ctr' in adset_insights_df.columns and 'cpm' in adset_insights_df.columns:
                    st.write("**Ad Set Performance Breakdown:**")
                    
                    # Create comprehensive metrics
                    adset_insights_df['efficiency_score'] = (adset_insights_df['ctr'] / adset_insights_df['cpm'].replace(0, 1)) * 100
                    adset_insights_df['cost_per_click'] = adset_insights_df['spend'] / adset_insights_df['clicks'].replace(0, 1)
                    adset_insights_df['impression_share'] = (adset_insights_df['impressions'] / adset_insights_df['impressions'].sum()) * 100
                    
                    # Performance categorization
                    adset_insights_df['performance_tier'] = pd.cut(
                        adset_insights_df['efficiency_score'], 
                        bins=[0, 10, 25, 50, 100], 
                        labels=['Needs Optimization', 'Below Average', 'Good', 'Excellent']
                    )
                    
                    # Display detailed breakdown
                    detailed_metrics = adset_insights_df[['adset_name', 'spend', 'impressions', 'clicks', 'ctr', 'cpm', 'cost_per_click', 'efficiency_score', 'performance_tier']].copy()
                    detailed_metrics['spend'] = detailed_metrics['spend'].round(2)
                    detailed_metrics['cost_per_click'] = detailed_metrics['cost_per_click'].round(2)
                    detailed_metrics['efficiency_score'] = detailed_metrics['efficiency_score'].round(1)
                    
                    st.dataframe(detailed_metrics, use_container_width=True)
                    
                    # Performance distribution chart
                    fig_adset = px.scatter(
                        adset_insights_df, 
                        x='cpm', 
                        y='ctr',
                        size='spend',
                        color='performance_tier',
                        hover_data=['adset_name', 'clicks', 'impressions'],
                        title='Ad Set Performance: CTR vs CPM (Bubble size = Spend)',
                        labels={'cpm': 'Cost Per Mille ($)', 'ctr': 'Click-Through Rate (%)'}
                    )
                    fig_adset.update_layout(height=400)
                    st.plotly_chart(fig_adset, use_container_width=True)
        
        # Ad Creative Level Analysis  
        if meta_spend_data.get('ad_insights'):
            st.subheader("🎨 Ad Creative Performance Analysis")
            ad_insights_df = pd.DataFrame(meta_spend_data['ad_insights'])
            
            if not ad_insights_df.empty:
                # Convert numeric columns
                numeric_cols = ['spend', 'impressions', 'clicks', 'ctr', 'cpm', 'reach', 'frequency']
                for col in numeric_cols:
                    if col in ad_insights_df.columns:
                        ad_insights_df[col] = pd.to_numeric(ad_insights_df[col], errors='coerce').fillna(0)
                
                ad_insights_df = ad_insights_df.sort_values('spend', ascending=False)
                
                # Display top performing ads
                st.write("**Top Ads by Spend:**")
                display_cols = ['ad_name', 'spend', 'impressions', 'clicks', 'ctr', 'cpm']
                available_cols = [col for col in display_cols if col in ad_insights_df.columns]
                st.dataframe(ad_insights_df[available_cols].head(15), use_container_width=True)
                
                # Creative performance insights
                if len(ad_insights_df) > 1:
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        best_performing_ad = ad_insights_df.loc[ad_insights_df['ctr'].idxmax(), 'ad_name'] if 'ctr' in ad_insights_df.columns else "N/A"
                        st.metric("Best CTR Creative", best_performing_ad[:30] + "..." if len(str(best_performing_ad)) > 30 else str(best_performing_ad))
                    
                    with col2:
                        most_efficient_ad = ad_insights_df.loc[ad_insights_df['cpm'].idxmin(), 'ad_name'] if 'cpm' in ad_insights_df.columns else "N/A"
                        st.metric("Most Efficient Creative", str(most_efficient_ad)[:30] + "..." if len(str(most_efficient_ad)) > 30 else str(most_efficient_ad))
                    
                    with col3:
                        total_ad_count = len(ad_insights_df)
                        st.metric("Total Active Creatives", f"{total_ad_count}")
                
                # Advanced Creative Analysis
                if 'ctr' in ad_insights_df.columns and 'spend' in ad_insights_df.columns:
                    st.write("**Individual Creative Performance Analysis:**")
                    
                    # Calculate advanced creative metrics with safe operations
                    try:
                        if 'spend' in ad_insights_df.columns and 'clicks' in ad_insights_df.columns:
                            ad_insights_df['cost_per_click'] = ad_insights_df['spend'] / ad_insights_df['clicks'].replace(0, 1)
                        if 'clicks' in ad_insights_df.columns and 'impressions' in ad_insights_df.columns:
                            ad_insights_df['engagement_rate'] = (ad_insights_df['clicks'] / ad_insights_df['impressions'].replace(0, 1)) * 100
                        if 'ctr' in ad_insights_df.columns and 'cpm' in ad_insights_df.columns:
                            ad_insights_df['creative_efficiency'] = (ad_insights_df['ctr'] / ad_insights_df['cpm'].replace(0, 1)) * 100
                    except Exception:
                        # Skip advanced metrics if calculation fails
                        pass
                    
                    # Creative performance scoring with safe column access
                    try:
                        ctr_score = ad_insights_df.get('ctr', 0) * 0.4 if 'ctr' in ad_insights_df.columns else 0
                        engagement_score = ad_insights_df.get('engagement_rate', 0) * 0.3 if 'engagement_rate' in ad_insights_df.columns else 0
                        efficiency_score = ad_insights_df.get('creative_efficiency', 0) * 0.3 if 'creative_efficiency' in ad_insights_df.columns else 0
                        
                        ad_insights_df['creative_score'] = ctr_score + engagement_score + efficiency_score
                    except Exception:
                        # Set default creative score if calculation fails
                        ad_insights_df['creative_score'] = 0
                    
                    # Performance tiers for creatives
                    ad_insights_df['creative_tier'] = pd.cut(
                        ad_insights_df['creative_score'], 
                        bins=[0, 5, 15, 30, 100], 
                        labels=['Low Performer', 'Average', 'High Performer', 'Top Performer']
                    )
                    
                    # Detailed creative breakdown
                    available_columns = [col for col in ['ad_name', 'spend', 'impressions', 'clicks', 'ctr', 'cpm', 'cost_per_click', 'creative_score', 'creative_tier'] if col in ad_insights_df.columns]
                    creative_metrics = ad_insights_df[available_columns].copy()
                    
                    # Sort by creative score if column exists
                    if 'creative_score' in creative_metrics.columns:
                        try:
                            creative_metrics = creative_metrics.sort_values('creative_score', ascending=False)
                        except Exception:
                            pass  # Continue without sorting if it fails
                    # Safe rounding for columns that exist
                    if 'spend' in creative_metrics.columns:
                        creative_metrics['spend'] = creative_metrics['spend'].round(2)
                    if 'cost_per_click' in creative_metrics.columns:
                        creative_metrics['cost_per_click'] = creative_metrics['cost_per_click'].round(2)
                    if 'creative_score' in creative_metrics.columns:
                        creative_metrics['creative_score'] = creative_metrics['creative_score'].round(1)
                    
                    st.dataframe(creative_metrics.head(20), use_container_width=True)
                    
                    # Creative performance visualization
                    fig_creative = px.scatter(
                        ad_insights_df, 
                        x='spend', 
                        y='ctr',
                        size='impressions',
                        color='creative_tier',
                        hover_data=['ad_name', 'clicks', 'creative_score'],
                        title='Creative Performance: CTR vs Spend (Bubble size = Impressions)',
                        labels={'spend': 'Ad Spend ($)', 'ctr': 'Click-Through Rate (%)'}
                    )
                    fig_creative.update_layout(height=400)
                    st.plotly_chart(fig_creative, use_container_width=True)
                    
                    # Creative optimization insights
                    col1, col2 = st.columns(2)
                    with col1:
                        top_performers = ad_insights_df[ad_insights_df['creative_tier'] == 'Top Performer']
                        if not top_performers.empty:
                            st.success(f"🎯 Top Performers: {len(top_performers)} creatives")
                            st.write("**Scale these creatives:**")
                            for _, creative in top_performers.head(3).iterrows():
                                st.write(f"• {creative['ad_name'][:40]}... (Score: {creative['creative_score']:.1f})")
                    
                    with col2:
                        low_performers = ad_insights_df[ad_insights_df['creative_tier'] == 'Low Performer']
                        if not low_performers.empty:
                            st.warning(f"⚠️ Low Performers: {len(low_performers)} creatives")
                            st.write("**Consider pausing:**")
                            for _, creative in low_performers.head(3).iterrows():
                                st.write(f"• {creative['ad_name'][:40]}... (Score: {creative['creative_score']:.1f})")
        
        # Performance Summary and Recommendations
        st.subheader("💡 Meta Performance Insights & Recommendations")
        
        insights = []
        
        if not campaign_df.empty:
            # Campaign level insights
            avg_campaign_ctr = campaign_df['ctr'].mean()
            if avg_campaign_ctr < 1.0:
                insights.append("🟡 **Campaign CTR**: Below 1% - Consider testing new audiences or creative approaches")
            elif avg_campaign_ctr > 2.0:
                insights.append("🟢 **Campaign CTR**: Above 2% - Excellent engagement, consider scaling")
            
            avg_campaign_cpm = campaign_df['cpm'].mean()
            if avg_campaign_cpm > 20:
                insights.append("🔴 **High CPM**: Above $20 - Review targeting to reduce costs")
            elif avg_campaign_cpm < 10:
                insights.append("🟢 **Low CPM**: Below $10 - Efficient reach, good targeting")
        
        # Ad set insights
        if meta_spend_data.get('adset_insights') and len(meta_spend_data['adset_insights']) > 0:
            adset_count = len(meta_spend_data['adset_insights'])
            if adset_count < 3:
                insights.append("🟡 **Ad Set Diversity**: Consider testing more ad sets for better optimization")
            elif adset_count > 10:
                insights.append("🟡 **Ad Set Management**: Many ad sets may dilute budget - consider consolidating top performers")
        
        # Creative insights  
        if meta_spend_data.get('ad_insights') and len(meta_spend_data['ad_insights']) > 0:
            creative_count = len(meta_spend_data['ad_insights'])
            if creative_count < 5:
                insights.append("🟡 **Creative Testing**: Add more creative variations for better performance")
            elif creative_count > 20:
                insights.append("🟡 **Creative Optimization**: Focus budget on top 5-10 performing creatives")
        
        if insights:
            for insight in insights:
                st.markdown(insight)
        else:
            st.info("Comprehensive analysis complete. All metrics are within optimal ranges.")
    
    # Date Range Testing for Meta API
    st.header("🔍 Meta API Date Range Testing")
    with st.expander("Test Different Date Ranges"):
        st.write("Test Meta API data retrieval across different time periods:")
        
        col1, col2 = st.columns(2)
        with col1:
            test_periods = [
                ("Last 7 days", 7),
                ("Last 14 days", 14), 
                ("Last 30 days", 30),
                ("Last 60 days", 60),
                ("Last 90 days", 90)
            ]
            
            if st.button("Test Multiple Date Ranges"):
                results = []
                for period_name, days in test_periods:
                    test_start = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
                    test_end = datetime.now().strftime('%Y-%m-%d')
                    
                    test_data, test_error = get_meta_ad_spend(test_start, test_end)
                    
                    if test_data:
                        results.append({
                            'Period': period_name,
                            'Date Range': f"{test_start} to {test_end}",
                            'Spend': f"${test_data['total_spend']:.2f}",
                            'Campaigns': test_data['campaign_count'],
                            'Status': 'Success'
                        })
                    else:
                        results.append({
                            'Period': period_name,
                            'Date Range': f"{test_start} to {test_end}",
                            'Spend': '$0.00',
                            'Campaigns': 0,
                            'Status': f'Error: {test_error}' if test_error else 'No data'
                        })
                
                if results:
                    results_df = pd.DataFrame(results)
                    st.dataframe(results_df, use_container_width=True)
                    
                    # Show spend trend
                    spend_values = [float(r['Spend'].replace('$', '').replace(',', '')) for r in results]
                    if any(s > 0 for s in spend_values):
                        fig = px.bar(results_df, x='Period', y=[float(s.replace('$', '').replace(',', '')) for s in results_df['Spend']], 
                                   title='Meta Ad Spend by Time Period')
                        fig.update_layout(yaxis_title='Spend ($)')
                        st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.write("**Current Selection Validation:**")
            if meta_spend_data:
                st.success(f"Selected Range: {start_str} to {end_str}")
                st.metric("Meta Spend Found", f"${meta_spend_data['total_spend']:.2f}")
                st.metric("Campaigns Found", meta_spend_data['campaign_count'])
                
                if meta_spend_data.get('api_response_sample'):
                    sample = meta_spend_data['api_response_sample'][0]
                    if 'date_start' in sample and 'date_stop' in sample:
                        st.info(f"API returned data for: {sample['date_start']} to {sample['date_stop']}")
            else:
                st.error("No Meta data for current selection")
    
    # Comprehensive Lead Conversion Funnel
    st.header("🔄 Lead Conversion Funnel Analysis")
    
    # Initialize default values to prevent unbound variable errors
    inbound_leads = 0
    scheduled_leads = 0
    consulted_leads = 0
    converted_leads = 0
    crosssell_leads = 0
    filtered_transactions = pd.DataFrame()
    
    # Ensure we have valid data for funnel analysis
    try:
        if (leads_success and len(smooth_meta_leads) > 0) or (tx_success and len(tx_data) > 0):
            # Convert to DataFrame if it's a list
            if isinstance(smooth_meta_leads, list):
                filtered_leads = pd.DataFrame(smooth_meta_leads)
            else:
                filtered_leads = smooth_meta_leads.copy()
            
            total_leads = len(filtered_leads)
            
            # Stage 1: Inbound Leads
            inbound_leads = total_leads
            
            # Stage 2: Scheduled/Booked (based on Overall Status)
            scheduled_leads = 0
            try:
                if isinstance(filtered_leads, pd.DataFrame) and 'Overall Status' in filtered_leads.columns:
                    scheduled_leads = len(filtered_leads[filtered_leads['Overall Status'].isin([
                        'Booked', 'Scheduled', 'Appointment Set', 'Consultation Scheduled'
                    ])])
            except Exception:
                scheduled_leads = 0
            
            # Stage 3: Consulted (had consultation)
            consulted_leads = 0
            try:
                if isinstance(filtered_leads, pd.DataFrame) and 'Overall Status' in filtered_leads.columns:
                    consulted_leads = len(filtered_leads[filtered_leads['Overall Status'].isin([
                        'Consulted', 'Consultation Complete', 'Post-Consultation', 'Treatment Discussed'
                    ])])
            except Exception:
                consulted_leads = 0
            
            # Stage 4: Converted (made first purchase)
            converted_leads = 0
            try:
                if isinstance(filtered_leads, pd.DataFrame) and 'Overall Status' in filtered_leads.columns:
                    converted_leads = len(filtered_leads[filtered_leads['Overall Status'].isin([
                        'Converted', 'Patient', 'Treatment Started', 'Active Patient'
                    ])])
            except Exception:
                converted_leads = 0
        
            # Stage 5: Cross-sell (multiple services or return visits)
            crosssell_leads = 0
            returning_customers = 0
            
            # Get transactions for the matched leads
            filtered_transactions = tx_data
            # Ensure matched_leads is a DataFrame
            if isinstance(matched_leads, list):
                matched_leads_df = pd.DataFrame(matched_leads) if matched_leads else pd.DataFrame()
            elif isinstance(matched_leads, pd.DataFrame):
                matched_leads_df = matched_leads
            else:
                matched_leads_df = pd.DataFrame()
            
            if not matched_leads_df.empty:
                # Filter transactions to only those matching our leads
                try:
                    matched_lead_ids = list(matched_leads_df.index) if hasattr(matched_leads_df, 'index') else []
                    if matched_lead_ids and hasattr(filtered_transactions, 'columns') and 'lead_id' in filtered_transactions.columns:
                        filtered_transactions = filtered_transactions[filtered_transactions['lead_id'].isin(matched_lead_ids)]
                except Exception as e:
                    logger.warning(f"Could not filter transactions by lead IDs: {e}")
                    # Continue with all transactions
            
            # Ensure filtered_transactions is a DataFrame
            if isinstance(filtered_transactions, list):
                filtered_transactions = pd.DataFrame(filtered_transactions) if filtered_transactions else pd.DataFrame()
            elif not isinstance(filtered_transactions, pd.DataFrame):
                filtered_transactions = pd.DataFrame()
            
            if not filtered_transactions.empty:
                # Count leads with multiple transactions (cross-sell/returning)
                if 'lead_id' in filtered_transactions.columns:
                    lead_transaction_counts = filtered_transactions.groupby('lead_id').size()
                    crosssell_leads = len(lead_transaction_counts[lead_transaction_counts > 1])
                    
                    # Identify returning customers (transactions spread over time)
                    if 'Date' in filtered_transactions.columns:
                        transaction_dates = filtered_transactions.groupby('lead_id')['Date'].nunique()
                        returning_customers = len(transaction_dates[transaction_dates > 1])
                    else:
                        returning_customers = 0
                else:
                    crosssell_leads = 0
                    returning_customers = 0
        
        # Create funnel visualization
        funnel_data = {
            'Stage': [
                '1. Inbound Leads',
                '2. Scheduled/Booked', 
                '3. Consulted',
                '4. Converted',
                '5. Cross-sell/Return'
            ],
            'Count': [inbound_leads, scheduled_leads, consulted_leads, converted_leads, crosssell_leads],
            'Percentage': [100, 0, 0, 0, 0]
        }
        
        # Calculate conversion rates
        if inbound_leads > 0:
            funnel_data['Percentage'][1] = (scheduled_leads / inbound_leads) * 100
            funnel_data['Percentage'][2] = (consulted_leads / inbound_leads) * 100
            funnel_data['Percentage'][3] = (converted_leads / inbound_leads) * 100
            funnel_data['Percentage'][4] = (crosssell_leads / inbound_leads) * 100
        
        funnel_df = pd.DataFrame(funnel_data)
        
        # Display funnel metrics
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            st.metric("📥 Inbound Leads", f"{inbound_leads:,}", help="Total leads in selected period")
        
        with col2:
            booking_rate = (scheduled_leads / inbound_leads * 100) if inbound_leads > 0 else 0
            st.metric("📅 Scheduled", f"{scheduled_leads:,}", f"{booking_rate:.1f}%")
        
        with col3:
            consultation_rate = (consulted_leads / inbound_leads * 100) if inbound_leads > 0 else 0
            st.metric("🗣️ Consulted", f"{consulted_leads:,}", f"{consultation_rate:.1f}%")
        
        with col4:
            conversion_rate = (converted_leads / inbound_leads * 100) if inbound_leads > 0 else 0
            st.metric("💰 Converted", f"{converted_leads:,}", f"{conversion_rate:.1f}%")
        
        with col5:
            crosssell_rate = (crosssell_leads / inbound_leads * 100) if inbound_leads > 0 else 0
            st.metric("🔄 Cross-sell", f"{crosssell_leads:,}", f"{crosssell_rate:.1f}%")
        
        # Funnel visualization
        fig_funnel = px.funnel(
            funnel_df, 
            x='Count', 
            y='Stage',
            title='Lead Conversion Funnel',
            text='Count',
            color_discrete_sequence=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
        )
        
        fig_funnel.update_traces(
            texttemplate='%{text}<br>(%{x})', 
            textposition='inside'
        )
        fig_funnel.update_layout(height=400)
        st.plotly_chart(fig_funnel, use_container_width=True)
        
        # Detailed funnel analysis
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("🎯 Conversion Rate Analysis")
            
            conversion_metrics = [
                ("Lead to Booking", booking_rate, "📅"),
                ("Lead to Consultation", consultation_rate, "🗣️"),
                ("Lead to Conversion", conversion_rate, "💰"),
                ("Lead to Cross-sell", crosssell_rate, "🔄")
            ]
            
            for metric_name, rate, icon in conversion_metrics:
                if rate >= 20:
                    color = "🟢"
                elif rate >= 10:
                    color = "🟡"
                else:
                    color = "🔴"
                
                st.write(f"{color} {icon} {metric_name}: {rate:.1f}%")
        
        with col2:
            st.subheader("💡 Funnel Optimization Insights")
            
            insights = []
            
            if booking_rate < 15:
                insights.append("🔴 Low booking rate - improve lead qualification and follow-up speed")
            elif booking_rate > 25:
                insights.append("🟢 Strong booking rate - excellent lead engagement")
            
            if consultation_rate < 10:
                insights.append("🔴 Low consultation rate - review scheduling process and no-show rates")
            elif consultation_rate > 20:
                insights.append("🟢 High consultation rate - effective consultation scheduling")
            
            if conversion_rate < 8:
                insights.append("🔴 Low conversion rate - enhance consultation quality and follow-up")
            elif conversion_rate > 15:
                insights.append("🟢 Strong conversion rate - effective sales process")
            
            if crosssell_rate < 5:
                insights.append("🟡 Cross-sell opportunity - implement retention and upselling strategies")
            elif crosssell_rate > 10:
                insights.append("🟢 Excellent cross-selling - strong customer lifetime value")
            
            if not insights:
                insights.append("🟢 All funnel metrics are within healthy ranges")
            
            for insight in insights:
                st.markdown(insight)
        
        # Customer lifecycle analysis with error handling
        try:
            if filtered_transactions is not None and not filtered_transactions.empty and 'Amount' in filtered_transactions.columns:
                st.subheader("📊 Customer Lifecycle Metrics")
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    avg_transaction_value = filtered_transactions['Amount'].mean()
                    st.metric("Avg Transaction Value", f"${avg_transaction_value:,.0f}")
                
                with col2:
                    total_revenue = filtered_transactions['Amount'].sum()
                    revenue_per_lead = total_revenue / inbound_leads if inbound_leads > 0 else 0
                    st.metric("Revenue per Lead", f"${revenue_per_lead:,.0f}")
                
                with col3:
                    if crosssell_leads > 0:
                        repeat_customer_rate = (crosssell_leads / converted_leads * 100) if converted_leads > 0 else 0
                        st.metric("Repeat Customer Rate", f"{repeat_customer_rate:.1f}%")
                    else:
                        st.metric("Repeat Customer Rate", "0%")
            else:
                st.info("Transaction data not available for lifecycle analysis")
        except Exception as e:
            st.warning(f"Unable to calculate lifecycle metrics: {str(e)}")
        
    except Exception as e:
        st.error(f"Error in funnel analysis: {str(e)}")
        # Set default values to prevent further errors
        inbound_leads = 0
        scheduled_leads = 0
        consulted_leads = 0
        converted_leads = 0
        crosssell_leads = 0
    
    else:
        st.warning("Lead and transaction data required for funnel analysis")
    
    # Revenue Attribution Analysis (Feature-Flagged)
    if ENABLE_ATTRIBUTION:
        st.header("🎯 Revenue Attribution Analysis")
        st.info("Advanced multi-touch attribution using real customer journey data")
        
        try:
            # Check if we have sufficient data for attribution
            if leads_success and tx_success and len(smooth_meta_leads) > 0:
                # Prepare merged dataset for journey building
                if isinstance(matched_leads, pd.DataFrame):
                    merged_df = matched_leads.copy()
                elif isinstance(matched_leads, list) and len(matched_leads) > 0:
                    merged_df = pd.DataFrame(matched_leads)
                else:
                    merged_df = pd.DataFrame()
                
                if not merged_df.empty:
                    # Add required columns for attribution
                    if 'lead_id' not in merged_df.columns:
                        merged_df['lead_id'] = merged_df.index
                    
                    # Attribution model selection
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        attribution_model = st.selectbox(
                            "Attribution Model:",
                            ["first_touch", "last_touch", "linear", "position_based", "time_decay", "markov_chain"],
                            help="Select how to attribute revenue across touchpoints"
                        )
                    
                    with col2:
                        first_weight = 0.4
                        last_weight = 0.4
                        half_life_days = 7
                        
                        if attribution_model == "position_based":
                            first_weight = st.slider("First Touch Weight", 0.1, 0.7, 0.4, 0.1)
                            last_weight = st.slider("Last Touch Weight", 0.1, 0.7, 0.4, 0.1)
                        elif attribution_model == "time_decay":
                            half_life_days = st.slider("Half-life (days)", 1, 30, 7)
                    
                    # Build simplified attribution analysis
                    try:
                        if not merged_df.empty:
                            # Create simplified attribution analysis with available data
                            st.success(f"Analyzing attribution for {len(merged_df)} conversions")
                            
                            # Calculate basic attribution metrics without complex module
                            # Handle potential list data types safely
                            if 'total_revenue' in merged_df.columns:
                                revenue_series = merged_df['total_revenue']
                                # Convert any list values to their first element or 0
                                revenue_values = []
                                for val in revenue_series:
                                    if isinstance(val, list):
                                        revenue_values.append(val[0] if len(val) > 0 else 0)
                                    elif pd.isna(val):
                                        revenue_values.append(0)
                                    else:
                                        revenue_values.append(float(val) if val else 0)
                                total_revenue = sum(revenue_values)
                                conversion_count = sum(1 for val in revenue_values if val > 0)
                            else:
                                total_revenue = 0
                                conversion_count = 0
                            
                            if actual_spend > 0 and total_revenue > 0:
                                attribution_roas = total_revenue / actual_spend
                                
                                st.subheader("📊 Attribution Results")
                                
                                # Display attribution metrics
                                col1, col2, col3, col4 = st.columns(4)
                                
                                with col1:
                                    st.metric("Total Revenue", f"${total_revenue:,.0f}")
                                
                                with col2:
                                    st.metric("Conversions", f"{conversion_count:,}")
                                
                                with col3:
                                    st.metric("Attribution ROAS", f"{attribution_roas:.2f}x")
                                
                                with col4:
                                    avg_revenue = total_revenue / conversion_count if conversion_count > 0 else 0
                                    st.metric("Avg Revenue/Conversion", f"${avg_revenue:,.0f}")
                                
                                # Attribution model comparison
                                st.subheader("🎯 Attribution Model Insights")
                                
                                attribution_models = {
                                    "Single-Touch (Meta)": {
                                        "description": "100% credit to Meta advertising",
                                        "revenue": total_revenue,
                                        "roas": attribution_roas,
                                        "confidence": "High - Direct attribution"
                                    },
                                    "Multi-Touch Estimate": {
                                        "description": "Estimated multi-channel contribution", 
                                        "revenue": total_revenue * 0.7,  # Conservative estimate
                                        "roas": attribution_roas * 0.7,
                                        "confidence": "Medium - Conservative estimate"
                                    }
                                }
                                
                                for model_name, metrics in attribution_models.items():
                                    with st.expander(f"🔍 {model_name}"):
                                        col1, col2, col3 = st.columns(3)
                                        
                                        with col1:
                                            st.metric("Attributed Revenue", f"${metrics['revenue']:,.0f}")
                                        
                                        with col2:
                                            st.metric("ROAS", f"{metrics['roas']:.2f}x")
                                        
                                        with col3:
                                            st.metric("Confidence", metrics['confidence'])
                                        
                                        st.write(f"**Model:** {metrics['description']}")
                                
                                # Revenue distribution analysis
                                if 'Service' in merged_df.columns:
                                    st.subheader("💰 Revenue Attribution by Service")
                                    
                                    # Create a clean DataFrame for service analysis
                                    service_analysis_data = []
                                    for idx, row in merged_df.iterrows():
                                        service = row.get('Service', 'Unknown')
                                        if isinstance(service, list):
                                            service = service[0] if len(service) > 0 else 'Unknown'
                                        
                                        # Get revenue value safely
                                        revenue_val = row.get('total_revenue', 0)
                                        if isinstance(revenue_val, list):
                                            revenue = revenue_val[0] if len(revenue_val) > 0 else 0
                                        elif pd.isna(revenue_val):
                                            revenue = 0
                                        else:
                                            revenue = float(revenue_val) if revenue_val else 0
                                        
                                        service_analysis_data.append({
                                            'Service': str(service),
                                            'Revenue': float(revenue)
                                        })
                                    
                                    service_df = pd.DataFrame(service_analysis_data)
                                    
                                    if not service_df.empty:
                                        service_revenue = service_df.groupby('Service')['Revenue'].agg(['sum', 'count', 'mean']).fillna(0)
                                        service_revenue.columns = ['Total Revenue', 'Conversions', 'Avg Revenue']
                                        service_revenue = service_revenue.sort_values('Total Revenue', ascending=False)
                                        
                                        # Calculate ROAS by service
                                        service_spend = actual_spend / len(service_revenue) if len(service_revenue) > 0 else 0
                                        service_revenue['ROAS'] = service_revenue['Total Revenue'] / service_spend if service_spend > 0 else 0
                                        
                                        st.dataframe(service_revenue.round(2), use_container_width=True)
                                    else:
                                        st.info("No service data available for breakdown")
                                
                            else:
                                st.warning("Insufficient data for attribution analysis. Need both revenue and spend data.")
                        else:
                            st.warning("No conversion data available for attribution analysis")
                    
                    except Exception as e:
                        st.error(f"Attribution analysis error: {str(e)}")
                        logger.error(f"Attribution analysis error: {e}")
                
                else:
                    st.info("💡 **Attribution Analysis Guide**\n\nAttribution models help understand how different marketing touchpoints contribute to conversions:\n\n- **First Touch**: 100% credit to the first interaction\n- **Last Touch**: 100% credit to the final interaction before conversion\n- **Linear**: Equal credit distributed across all touchpoints\n- **Position-Based (U-Shaped)**: Higher weight to first and last touches, remainder split among middle\n- **Time Decay**: More recent touchpoints receive higher credit\n- **Markov Chain**: Data-driven model using transition probabilities\n\n**Configuration:**\n- Set `ENABLE_ATTRIBUTION=true` in environment to activate\n- Use `FORCE_MARKOV=true` to force full Markov computation on large datasets\n- Ensure Meta API credentials are configured for spend data")
            else:
                st.warning("Insufficient data for attribution analysis - need both leads and transactions")
                
        except Exception as e:
            logger.error(f"Attribution analysis error: {e}")
            st.error(f"Attribution feature encountered an error: {str(e)}")
    else:
        # Attribution disabled - show activation instructions
        if st.checkbox("🎯 Enable Revenue Attribution (Advanced)", help="Requires ENABLE_ATTRIBUTION=true in environment"):
            st.info("""
            **Revenue Attribution is currently disabled.**
            
            To enable advanced multi-touch attribution analysis:
            1. Set environment variable: `ENABLE_ATTRIBUTION=true`
            2. Restart the dashboard
            3. Ensure you have lead and transaction data with proper timestamps and channel information
            
            Attribution will provide insights into which touchpoints drive conversions across the customer journey.
            """)
    
    # Allow manual spend override if needed
    st.header("⚙️ Spend Override")
    with st.expander("Manually Adjust Ad Spend (if needed)"):
        if spend_source == "Meta API":
            st.success(f"Using actual Meta API spend: ${actual_spend:,.0f}")
        else:
            st.warning(f"Using estimated spend: ${actual_spend:,.0f}")
        
        manual_spend = st.number_input(
            "Override ad spend for this period:",
            min_value=0.0,
            value=float(actual_spend),
            step=100.0,
            help="Override with manual spend amount if Meta API data is incorrect"
        )
        
        if manual_spend != actual_spend:
            # Recalculate with manual spend
            manual_roas = total_revenue / manual_spend if manual_spend > 0 else 0
            manual_roi = ((total_revenue - manual_spend) / manual_spend * 100) if manual_spend > 0 else 0
            manual_cpl = manual_spend / total_leads if total_leads > 0 else 0
            manual_cpa = manual_spend / converted_leads if converted_leads > 0 else 0
            manual_profit = total_revenue - manual_spend
            
            st.success("Updated Metrics with Manual Spend:")
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                roas_change = manual_roas - roas
                st.metric("ROAS", f"{manual_roas:.1f}x", f"{roas_change:+.1f}x")
            
            with col2:
                roi_change = manual_roi - roi
                st.metric("ROI", f"{manual_roi:.0f}%", f"{roi_change:+.0f}%")
            
            with col3:
                cpl_change = manual_cpl - cost_per_lead
                st.metric("Cost/Lead", f"${manual_cpl:.0f}", f"${cpl_change:+.0f}")
            
            with col4:
                profit_change = manual_profit - profit
                st.metric("Profit", f"${manual_profit:,.0f}", f"${profit_change:+,.0f}")
    
    # Optional debug section (collapsed by default)
    with st.expander("🔧 Technical Details"):
        st.write(f"**Processing Summary:**")
        st.write(f"- Date Range: {start_str} to {end_str}")
        st.write(f"- Total Leads in Database: {total_leads:,}")
        st.write(f"- Leads in Date Range: {len(leads_data):,}")
        st.write(f"- Meta Leads Found: {len(meta_leads):,}")
        st.write(f"- Smooth MD Meta Leads: {len(smooth_meta_leads):,}")
        st.write(f"- Total Transactions in Database: {total_tx:,}")
        st.write(f"- Transactions in Date Range: {len(tx_data):,}")
        st.write(f"- Ad Spend Source: {spend_source}")
        if meta_spend_data:
            st.write(f"- Meta API Status: Connected ({meta_spend_data.get('campaign_count', 0)} campaigns)")
        else:
            st.write(f"- Meta API Status: {meta_error if meta_error else 'No data'}")
        
        if matching_stats.get('smooth_transactions_count'):
            st.write(f"- Smooth MD Transactions: {matching_stats['smooth_transactions_count']:,}")
        
        st.write("**Matching Performance:**")
        st.json(matching_stats)

if __name__ == "__main__":
    main()