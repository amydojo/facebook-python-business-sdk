"""
Comprehensive Meta Marketing Dashboard
Integrates live Meta API data with Airtable lead funnel and conversion tracking
Complete attribution from ad spend to actual revenue
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import os
import requests
from datetime import datetime, timedelta
from pyairtable import Api
import numpy as np

# Configure page
st.set_page_config(
    page_title="Comprehensive Meta Dashboard", 
    page_icon="🚀",
    layout="wide"
)

def get_meta_advertising_data(start_date: str, end_date: str):
    """Get Meta advertising data from API"""
    try:
        access_token = os.getenv('META_ACCESS_TOKEN')
        ad_account_id = os.getenv('META_AD_ACCOUNT_ID')
        
        if not access_token or not ad_account_id:
            return None
        
        if not ad_account_id.startswith('act_'):
            ad_account_id = f"act_{ad_account_id}"
            
        url = f"https://graph.facebook.com/v18.0/{ad_account_id}/insights"
        params = {
            'access_token': access_token,
            'time_range': f'{{"since":"{start_date}","until":"{end_date}"}}',
            'fields': 'campaign_name,spend,impressions,clicks,ctr,cpm,reach,frequency,actions',
            'level': 'campaign',
            'limit': 100
        }
        
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            campaigns = data.get('data', [])
            if campaigns:
                return {
                    'success': True,
                    'campaigns': campaigns,
                    'total_spend': sum(float(c.get('spend', 0)) for c in campaigns),
                    'total_impressions': sum(int(c.get('impressions', 0)) for c in campaigns),
                    'total_clicks': sum(int(c.get('clicks', 0)) for c in campaigns)
                }
        return None
            
    except Exception as e:
        st.error(f"Meta API Error: {str(e)}")
        return None

def get_detailed_ad_performance(start_date: str, end_date: str):
    """Get detailed ad set and individual ad performance"""
    try:
        access_token = os.getenv('META_ACCESS_TOKEN')
        ad_account_id = os.getenv('META_AD_ACCOUNT_ID')
        
        if not access_token or not ad_account_id:
            return {'success': False, 'adsets': [], 'ads': []}
        
        if not ad_account_id.startswith('act_'):
            ad_account_id = f"act_{ad_account_id}"
            
        detailed_performance = {
            'success': True,
            'adsets': [],
            'ads': []
        }
        
        # Get ad set level data
        url = f"https://graph.facebook.com/v18.0/{ad_account_id}/insights"
        params = {
            'access_token': access_token,
            'time_range': f'{{"since":"{start_date}","until":"{end_date}"}}',
            'fields': 'campaign_name,adset_name,spend,impressions,clicks,ctr,cpc,cpm',
            'level': 'adset',
            'limit': 100
        }
        
        response = requests.get(url, params=params)
        if response.status_code == 200:
            data = response.json()
            detailed_performance['adsets'] = data.get('data', [])
        
        # Get individual ad level data
        params['level'] = 'ad'
        params['fields'] = 'campaign_name,adset_name,ad_name,spend,impressions,clicks,ctr,cpc,cpm'
        params['limit'] = 200
        
        response = requests.get(url, params=params)
        if response.status_code == 200:
            data = response.json()
            detailed_performance['ads'] = data.get('data', [])
        
        return detailed_performance
        
    except Exception as e:
        st.error(f"Detailed performance error: {e}")
        return {'success': False, 'adsets': [], 'ads': []}

def load_airtable_leads():
    """Load lead data from Airtable"""
    try:
        api_key = os.getenv('AIRTABLE_API_KEY')
        base_id = os.getenv('AIRTABLE_BASE_ID')
        
        if not api_key or not base_id:
            st.warning("Airtable credentials not found")
            return pd.DataFrame()
        
        api = Api(api_key)
        table = api.table(base_id, 'Leads')
        
        records = table.all()
        
        leads_data = []
        for record in records:
            fields = record['fields']
            leads_data.append({
                'id': record['id'],
                'name': fields.get('Name', ''),
                'phone': fields.get('Phone', ''),
                'email': fields.get('Email', ''),
                'source': fields.get('Source', ''),
                'brand': fields.get('Brand', ''),
                'inbound_date': fields.get('Inbound', ''),
                'overall_status': fields.get('Overall Status', ''),
                'booking_status': fields.get('Booking Status', ''),
                'show_status': fields.get('Show Status', ''),
                'consult_status': fields.get('Consult Status', ''),
                'close_status': fields.get('Close Status', '')
            })
        
        df = pd.DataFrame(leads_data)
        
        # Filter for Meta/Facebook leads
        if not df.empty:
            meta_leads = df[df['source'].isin(['Meta', 'Facebook', 'Instagram', 'meta', 'facebook'])].copy()
            return meta_leads
        
        return df
        
    except Exception as e:
        st.error(f"Airtable leads error: {e}")
        return pd.DataFrame()

def load_airtable_transactions():
    """Load transaction/revenue data from Airtable"""
    try:
        api_key = os.getenv('AIRTABLE_API_KEY')
        base_id = os.getenv('AIRTABLE_BASE_ID')
        
        if not api_key or not base_id:
            return pd.DataFrame()
        
        api = Api(api_key)
        
        # Try different table names for transactions
        table_names = ['Transactions', 'Social Media', 'Revenue', 'Sales']
        
        for table_name in table_names:
            try:
                table = api.table(base_id, table_name)
                records = table.all()
                
                transactions_data = []
                for record in records:
                    fields = record['fields']
                    transactions_data.append({
                        'id': record['id'],
                        'customer_name': fields.get('Customer Name', fields.get('Name', '')),
                        'phone': fields.get('Phone', ''),
                        'email': fields.get('Email', ''),
                        'service': fields.get('Service', fields.get('Treatment', '')),
                        'amount': fields.get('Amount', fields.get('Revenue', fields.get('Total', 0))),
                        'date': fields.get('Date', fields.get('Transaction Date', '')),
                        'status': fields.get('Status', 'Completed'),
                        'source': fields.get('Source', 'Meta')
                    })
                
                df = pd.DataFrame(transactions_data)
                if not df.empty:
                    return df
                    
            except Exception:
                continue
        
        return pd.DataFrame()
        
    except Exception as e:
        st.error(f"Airtable transactions error: {e}")
        return pd.DataFrame()

def calculate_funnel_metrics(leads_df):
    """Calculate lead funnel conversion metrics"""
    if leads_df.empty:
        return {}
    
    total_leads = len(leads_df)
    
    # Count leads at each funnel stage
    booked_leads = len(leads_df[leads_df['booking_status'].isin(['Booked', 'Confirmed', 'Scheduled'])])
    showed_leads = len(leads_df[leads_df['show_status'].isin(['Showed', 'Completed', 'Attended'])])
    consulted_leads = len(leads_df[leads_df['consult_status'].isin(['Consulted', 'Completed', 'Done'])])
    closed_leads = len(leads_df[leads_df['close_status'].isin(['Closed', 'Won', 'Converted', 'Paid'])])
    
    # Calculate conversion rates
    booking_rate = (booked_leads / total_leads * 100) if total_leads > 0 else 0
    show_rate = (showed_leads / booked_leads * 100) if booked_leads > 0 else 0
    consult_rate = (consulted_leads / showed_leads * 100) if showed_leads > 0 else 0
    close_rate = (closed_leads / consulted_leads * 100) if consulted_leads > 0 else 0
    
    return {
        'total_leads': total_leads,
        'booked_leads': booked_leads,
        'showed_leads': showed_leads,
        'consulted_leads': consulted_leads,
        'closed_leads': closed_leads,
        'booking_rate': booking_rate,
        'show_rate': show_rate,
        'consult_rate': consult_rate,
        'close_rate': close_rate,
        'overall_conversion_rate': (closed_leads / total_leads * 100) if total_leads > 0 else 0
    }

def match_leads_to_revenue(leads_df, transactions_df):
    """Match leads to actual revenue transactions"""
    if leads_df.empty or transactions_df.empty:
        return leads_df, 0
    
    # Match by phone number (primary) and email (secondary)
    leads_with_revenue = leads_df.copy()
    leads_with_revenue['revenue'] = 0
    leads_with_revenue['transaction_count'] = 0
    
    total_attributed_revenue = 0
    
    for idx, lead in leads_df.iterrows():
        lead_phone = str(lead.get('phone', '')).strip()
        lead_email = str(lead.get('email', '')).strip().lower()
        
        # Find matching transactions
        phone_matches = transactions_df[transactions_df['phone'].astype(str).str.strip() == lead_phone] if lead_phone else pd.DataFrame()
        email_matches = transactions_df[transactions_df['email'].astype(str).str.strip().str.lower() == lead_email] if lead_email else pd.DataFrame()
        
        # Combine matches
        all_matches = pd.concat([phone_matches, email_matches]).drop_duplicates()
        
        if not all_matches.empty:
            revenue = all_matches['amount'].astype(float).sum()
            leads_with_revenue.at[idx, 'revenue'] = revenue
            leads_with_revenue.at[idx, 'transaction_count'] = len(all_matches)
            total_attributed_revenue += revenue
    
    return leads_with_revenue, total_attributed_revenue

def calculate_roas_metrics(meta_data, attributed_revenue, total_conversions):
    """Calculate comprehensive ROAS and efficiency metrics"""
    if not meta_data or meta_data.get('total_spend', 0) == 0:
        return {}
    
    total_spend = meta_data['total_spend']
    total_clicks = meta_data['total_clicks']
    total_impressions = meta_data['total_impressions']
    
    roas = (attributed_revenue / total_spend) if total_spend > 0 else 0
    cost_per_conversion = (total_spend / total_conversions) if total_conversions > 0 else 0
    conversion_rate = (total_conversions / total_clicks * 100) if total_clicks > 0 else 0
    
    return {
        'roas': roas,
        'cost_per_conversion': cost_per_conversion,
        'conversion_rate': conversion_rate,
        'revenue_per_click': (attributed_revenue / total_clicks) if total_clicks > 0 else 0,
        'revenue_per_impression': (attributed_revenue / total_impressions * 1000) if total_impressions > 0 else 0
    }

def create_funnel_visualization(funnel_metrics):
    """Create conversion funnel chart"""
    if not funnel_metrics:
        return None
    
    stages = ['Leads', 'Booked', 'Showed', 'Consulted', 'Closed']
    values = [
        funnel_metrics['total_leads'],
        funnel_metrics['booked_leads'],
        funnel_metrics['showed_leads'],
        funnel_metrics['consulted_leads'],
        funnel_metrics['closed_leads']
    ]
    
    fig = go.Figure(go.Funnel(
        y=stages,
        x=values,
        textposition="inside",
        textinfo="value+percent initial",
        opacity=0.8,
        marker={
            "color": ["#3366cc", "#dc3912", "#ff9900", "#109618", "#990099"],
            "line": {"width": 2, "color": "white"}
        }
    ))
    
    fig.update_layout(
        title="Meta Lead Conversion Funnel",
        height=400,
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font=dict(color='white')
    )
    
    return fig

def create_roas_gauge(roas_value):
    """Create ROAS gauge chart"""
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=roas_value,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': "ROAS", 'font': {'color': 'white'}},
        delta={'reference': 3.0, 'increasing': {'color': '#00ff00'}, 'decreasing': {'color': '#ff0000'}},
        gauge={
            'axis': {'range': [None, 10], 'tickcolor': 'white'},
            'bar': {'color': '#00ff88'},
            'steps': [
                {'range': [0, 2], 'color': '#ff4444'},
                {'range': [2, 4], 'color': '#ffaa00'},
                {'range': [4, 10], 'color': '#00ff44'}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 3.0
            }
        }
    ))
    
    fig.update_layout(
        height=300,
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font=dict(color='white')
    )
    
    return fig

def main():
    st.title("🚀 Comprehensive Meta Marketing Dashboard")
    st.markdown("**Complete Attribution: Ad Spend → Leads → Revenue**")
    
    # Date range selection
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Start Date", datetime.now().date() - timedelta(days=7))
    with col2:
        end_date = st.date_input("End Date", datetime.now().date())
    
    start_str = start_date.strftime('%Y-%m-%d')
    end_str = end_date.strftime('%Y-%m-%d')
    
    # Load all data sources
    with st.spinner("Loading comprehensive data..."):
        meta_data = get_meta_advertising_data(start_str, end_str)
        detailed_performance = get_detailed_ad_performance(start_str, end_str)
        leads_df = load_airtable_leads()
        transactions_df = load_airtable_transactions()
    
    # Attribution Analysis
    st.header("📊 Complete Attribution Analysis")
    
    if meta_data:
        # Match leads to revenue
        leads_with_revenue, attributed_revenue = match_leads_to_revenue(leads_df, transactions_df)
        funnel_metrics = calculate_funnel_metrics(leads_df)
        roas_metrics = calculate_roas_metrics(meta_data, attributed_revenue, funnel_metrics.get('closed_leads', 0))
        
        # Key Metrics Row
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Ad Spend", f"${meta_data['total_spend']:,.2f}")
        with col2:
            st.metric("Attributed Revenue", f"${attributed_revenue:,.2f}")
        with col3:
            st.metric("ROAS", f"{roas_metrics.get('roas', 0):.2f}x")
        with col4:
            st.metric("Net Profit", f"${attributed_revenue - meta_data['total_spend']:,.2f}")
        
        # Detailed Performance Row
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Leads", f"{funnel_metrics.get('total_leads', 0):,}")
        with col2:
            st.metric("Conversions", f"{funnel_metrics.get('closed_leads', 0):,}")
        with col3:
            st.metric("Conversion Rate", f"{funnel_metrics.get('overall_conversion_rate', 0):.1f}%")
        with col4:
            st.metric("Cost per Conversion", f"${roas_metrics.get('cost_per_conversion', 0):,.2f}")
        
        # Visualizations
        col1, col2 = st.columns(2)
        
        with col1:
            if funnel_metrics:
                funnel_fig = create_funnel_visualization(funnel_metrics)
                if funnel_fig:
                    st.plotly_chart(funnel_fig, use_container_width=True)
        
        with col2:
            roas_fig = create_roas_gauge(roas_metrics.get('roas', 0))
            st.plotly_chart(roas_fig, use_container_width=True)
        
        # Campaign Performance Breakdown
        st.header("📱 Live Campaign Performance")
        
        campaign_data = []
        for campaign in meta_data['campaigns']:
            campaign_data.append({
                "Campaign": campaign.get('campaign_name', 'Unknown'),
                "Spend": f"${float(campaign.get('spend', 0)):,.2f}",
                "Impressions": f"{int(campaign.get('impressions', 0)):,}",
                "Clicks": f"{int(campaign.get('clicks', 0)):,}",
                "CTR": f"{float(campaign.get('ctr', 0)):.2f}%",
                "CPM": f"${float(campaign.get('cpm', 0)):,.2f}"
            })
        
        if campaign_data:
            st.dataframe(pd.DataFrame(campaign_data), use_container_width=True)
        
        # Ad Set Performance
        if detailed_performance.get('adsets'):
            st.header("🎯 Ad Set Performance Breakdown")
            
            adset_data = []
            for adset in detailed_performance['adsets'][:10]:  # Top 10
                adset_data.append({
                    "Ad Set": adset.get('adset_name', 'Unknown'),
                    "Campaign": adset.get('campaign_name', 'Unknown'),
                    "Spend": f"${float(adset.get('spend', 0)):,.2f}",
                    "Impressions": f"{int(adset.get('impressions', 0)):,}",
                    "Clicks": f"{int(adset.get('clicks', 0)):,}",
                    "CTR": f"{float(adset.get('ctr', 0)):.2f}%",
                    "CPC": f"${float(adset.get('cpc', 0)):,.2f}"
                })
            
            st.dataframe(pd.DataFrame(adset_data), use_container_width=True)
        
        # Revenue Attribution Details
        if not leads_with_revenue.empty:
            st.header("💰 Revenue Attribution Details")
            
            revenue_leads = leads_with_revenue[leads_with_revenue['revenue'] > 0].copy()
            if not revenue_leads.empty:
                revenue_summary = []
                for _, lead in revenue_leads.iterrows():
                    revenue_summary.append({
                        "Lead Name": lead.get('name', 'Unknown'),
                        "Phone": lead.get('phone', 'N/A'),
                        "Revenue": f"${lead.get('revenue', 0):,.2f}",
                        "Transactions": int(lead.get('transaction_count', 0)),
                        "Status": lead.get('overall_status', 'Unknown')
                    })
                
                st.dataframe(pd.DataFrame(revenue_summary), use_container_width=True)
                
                st.success(f"Successfully attributed ${attributed_revenue:,.2f} in revenue to {len(revenue_leads)} Meta leads")
            else:
                st.info("No revenue attribution matches found. Check lead/transaction data alignment.")
    
    else:
        st.error("Meta API connection failed. Please check your credentials.")
        
        # Show demo data structure
        st.info("Demo mode - showing data structure with sample values")
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Ad Spend", "$2,450.50")
        with col2:
            st.metric("Attributed Revenue", "$12,500.00")
        with col3:
            st.metric("ROAS", "5.10x")
        with col4:
            st.metric("Net Profit", "$10,049.50")

if __name__ == "__main__":
    main()