"""
Enhanced lead transaction matching for Ad Command Center
"""

import pandas as pd
import numpy as np

def get_lead_transactions_enhanced(leads_df, transactions_df):
    """
    Match leads with their corresponding transactions with robust error handling
    
    Args:
        leads_df (pd.DataFrame): DataFrame containing lead data
        transactions_df (pd.DataFrame): DataFrame containing transaction data
        
    Returns:
        pd.DataFrame: Leads DataFrame with transaction data added
    """
    if transactions_df is None or transactions_df.empty or leads_df is None or leads_df.empty:
        print("Missing transaction or lead data for accurate ROI calculation")
        return leads_df
    
    # Debug information
    print(f"Transactions table columns: {transactions_df.columns.tolist()}")
    print(f"Leads table columns: {leads_df.columns.tolist()}")
    
    # Create a copy of leads_df to add transaction data
    enriched_leads = leads_df.copy()
    
    # Add columns for transaction data
    enriched_leads['transaction_count'] = 0
    enriched_leads['transaction_total'] = 0.0
    
    # Find an amount field in the transactions
    amount_field = None
    for field in ['Amount', 'Revenue', 'Payment', 'Value', 'Price', 'Total']:
        if field in transactions_df.columns:
            amount_field = field
            print(f"Using amount field: {field}")
            break
    
    if not amount_field:
        print("Could not find amount field in transactions")
        return leads_df
    
    # Create a clean version of the transactions with standardized numeric amounts
    tx_df = transactions_df.copy()
    
    # Convert amount to numeric safely handling strings
    try:
        tx_df['clean_amount'] = tx_df[amount_field].apply(
            lambda x: pd.to_numeric(
                str(x).replace('$', '').replace(',', '') if isinstance(x, str) else x,
                errors='coerce'
            )
        ).fillna(0.0)
    except Exception as e:
        print(f"Error cleaning amount field: {e}")
        tx_df['clean_amount'] = 0.0
    
    # Set up mappings for fields
    email_fields = ['Email', 'email', 'email_address', 'Email Address']
    phone_fields = ['Phone', 'phone', 'Phone number', 'phone_number', 'Phone Number']
    
    # Create a simple matching function to avoid array truth comparison issues
    def is_match(lead_value, tx_value):
        """Safe matching function that avoids array truth value ambiguity"""
        if pd.isna(lead_value) or pd.isna(tx_value):
            return False
            
        try:
            # Convert both to strings for comparison
            lead_str = str(lead_value).strip().lower()
            tx_str = str(tx_value).strip().lower()
            
            # Check if lead ID is contained within the transaction field
            return lead_str in tx_str
        except Exception as e:
            print(f"Error in matching: {e}")
            return False
    
    # Track matching stats
    matched_count = 0
    
    # Process each lead individually
    for idx, lead in enriched_leads.iterrows():
        lead_id = lead.get('id')
        if not lead_id:
            continue
        
        # Find matching transactions
        matches = []
        
        for tx_idx, tx in tx_df.iterrows():
            # Try to match by ID first in any field
            found_match = False
            
            # Check certain fields that might contain lead references
            for field in tx.index:
                # Skip non-relevant fields or empty values
                if field in ['clean_amount'] or pd.isna(tx[field]):
                    continue
                
                # Use the safe matching function
                if is_match(lead_id, tx[field]):
                    found_match = True
                    break
            
            # Try matching by email if ID match failed
            if not found_match:
                for lead_email_field in email_fields:
                    if lead_email_field in lead and pd.notna(lead[lead_email_field]):
                        lead_email = lead[lead_email_field]
                        
                        for tx_email_field in email_fields:
                            if tx_email_field in tx and pd.notna(tx[tx_email_field]):
                                if is_match(lead_email, tx[tx_email_field]):
                                    found_match = True
                                    break
                    
                    if found_match:
                        break
            
            # Try matching by phone if email match failed
            if not found_match:
                for lead_phone_field in phone_fields:
                    if lead_phone_field in lead and pd.notna(lead[lead_phone_field]):
                        # Clean phone numbers to just digits
                        lead_phone = ''.join(c for c in str(lead[lead_phone_field]) if c.isdigit())
                        
                        for tx_phone_field in phone_fields:
                            if tx_phone_field in tx and pd.notna(tx[tx_phone_field]):
                                tx_phone = ''.join(c for c in str(tx[tx_phone_field]) if c.isdigit())
                                
                                # Only match if we have substantial digit matches (avoid matching partial numbers)
                                if lead_phone and tx_phone and lead_phone[-10:] == tx_phone[-10:]:
                                    found_match = True
                                    break
                    
                    if found_match:
                        break
            
            # If we found a match, add transaction to matches
            if found_match:
                matches.append(tx)
        
        # Process matches for this lead
        if matches:
            matched_count += len(matches)
            total_amount = sum(match['clean_amount'] for match in matches)
            
            # Update lead with transaction data
            enriched_leads.at[idx, 'transaction_count'] = len(matches)
            enriched_leads.at[idx, 'transaction_total'] = total_amount
    
    # Debug results
    print(f"Matched {matched_count} transactions to leads")
    print(f"Found transactions for {(enriched_leads['transaction_count'] > 0).sum()} leads")
    print(f"Total matched transaction value: ${enriched_leads['transaction_total'].sum():.2f}")
    
    return enriched_leads