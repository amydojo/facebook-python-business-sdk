"""
Revenue Attribution Module for Smooth MD Meta Marketing
Implements multi-touch attribution models following best practices from:
- https://developers.facebook.com/docs/marketing-apis/
- https://www.attributionapp.com/blog/revenue-attribution/
- https://airtable.com/developers/web/api/introduction
"""

import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import os

logger = logging.getLogger(__name__)

class AttributionModels:
    """
    Multi-touch attribution models for revenue attribution analysis
    Uses concepts per https://www.attributionapp.com/blog/revenue-attribution/
    """
    
    @staticmethod
    def first_touch(journeys_df: pd.DataFrame) -> pd.DataFrame:
        """
        First-touch attribution: 100% credit to initial interaction
        
        Args:
            journeys_df: DataFrame with columns ['conversion_id', 'channel_sequence', 'revenue_amount']
            
        Returns:
            DataFrame with columns ['conversion_id', 'channel', 'credit_fraction']
        """
        expected_cols = {"conversion_id", "channel_sequence", "revenue_amount"}
        missing = expected_cols - set(journeys_df.columns)
        if missing:
            raise ValueError(f"first_touch: missing columns {missing}")
            
        if journeys_df.empty:
            logger.warning("first_touch: no journeys provided")
            return pd.DataFrame(columns=["conversion_id", "channel", "credit_fraction"])
        
        result_data = []
        for _, row in journeys_df.iterrows():
            if row['channel_sequence'] and len(row['channel_sequence']) > 0:
                first_channel = row['channel_sequence'][0]
                result_data.append({
                    'conversion_id': row['conversion_id'],
                    'channel': first_channel,
                    'credit_fraction': 1.0
                })
            else:
                logger.warning(f"Empty channel sequence for conversion {row['conversion_id']}")
        
        return pd.DataFrame(result_data)
    
    @staticmethod
    def last_touch(journeys_df: pd.DataFrame) -> pd.DataFrame:
        """
        Last-touch attribution: 100% credit to final interaction
        """
        expected_cols = {"conversion_id", "channel_sequence", "revenue_amount"}
        missing = expected_cols - set(journeys_df.columns)
        if missing:
            raise ValueError(f"last_touch: missing columns {missing}")
            
        if journeys_df.empty:
            logger.warning("last_touch: no journeys provided")
            return pd.DataFrame(columns=["conversion_id", "channel", "credit_fraction"])
        
        result_data = []
        for _, row in journeys_df.iterrows():
            if row['channel_sequence'] and len(row['channel_sequence']) > 0:
                last_channel = row['channel_sequence'][-1]
                result_data.append({
                    'conversion_id': row['conversion_id'],
                    'channel': last_channel,
                    'credit_fraction': 1.0
                })
            else:
                logger.warning(f"Empty channel sequence for conversion {row['conversion_id']}")
        
        return pd.DataFrame(result_data)
    
    @staticmethod
    def linear_attribution(journeys_df: pd.DataFrame) -> pd.DataFrame:
        """
        Linear attribution: Equal credit to each touchpoint
        """
        expected_cols = {"conversion_id", "channel_sequence", "revenue_amount"}
        missing = expected_cols - set(journeys_df.columns)
        if missing:
            raise ValueError(f"linear_attribution: missing columns {missing}")
            
        if journeys_df.empty:
            logger.warning("linear_attribution: no journeys provided")
            return pd.DataFrame(columns=["conversion_id", "channel", "credit_fraction"])
        
        result_data = []
        for _, row in journeys_df.iterrows():
            if row['channel_sequence'] and len(row['channel_sequence']) > 0:
                num_channels = len(row['channel_sequence'])
                credit_per_channel = 1.0 / num_channels
                
                for channel in row['channel_sequence']:
                    result_data.append({
                        'conversion_id': row['conversion_id'],
                        'channel': channel,
                        'credit_fraction': credit_per_channel
                    })
            else:
                logger.warning(f"Empty channel sequence for conversion {row['conversion_id']}")
        
        return pd.DataFrame(result_data)
    
    @staticmethod
    def position_based(journeys_df: pd.DataFrame, first_weight: float = 0.4, last_weight: float = 0.4) -> pd.DataFrame:
        """
        Position-based (U-shaped) attribution
        
        Args:
            journeys_df: Journey data
            first_weight: Weight for first touchpoint (default 40%)
            last_weight: Weight for last touchpoint (default 40%)
        """
        expected_cols = {"conversion_id", "channel_sequence", "revenue_amount"}
        missing = expected_cols - set(journeys_df.columns)
        if missing:
            raise ValueError(f"position_based: missing columns {missing}")
            
        if journeys_df.empty:
            logger.warning("position_based: no journeys provided")
            return pd.DataFrame(columns=["conversion_id", "channel", "credit_fraction"])
        
        middle_weight = 1.0 - first_weight - last_weight
        result_data = []
        
        for _, row in journeys_df.iterrows():
            if not row['channel_sequence'] or len(row['channel_sequence']) == 0:
                logger.warning(f"Empty channel sequence for conversion {row['conversion_id']}")
                continue
                
            channels = row['channel_sequence']
            num_channels = len(channels)
            
            if num_channels == 1:
                # Single touchpoint gets 100%
                result_data.append({
                    'conversion_id': row['conversion_id'],
                    'channel': channels[0],
                    'credit_fraction': 1.0
                })
            elif num_channels == 2:
                # Split between first and last
                result_data.extend([
                    {
                        'conversion_id': row['conversion_id'],
                        'channel': channels[0],
                        'credit_fraction': first_weight + middle_weight / 2
                    },
                    {
                        'conversion_id': row['conversion_id'],
                        'channel': channels[1],
                        'credit_fraction': last_weight + middle_weight / 2
                    }
                ])
            else:
                # First touchpoint
                result_data.append({
                    'conversion_id': row['conversion_id'],
                    'channel': channels[0],
                    'credit_fraction': first_weight
                })
                
                # Middle touchpoints
                middle_channels = channels[1:-1]
                if middle_channels:
                    credit_per_middle = middle_weight / len(middle_channels)
                    for channel in middle_channels:
                        result_data.append({
                            'conversion_id': row['conversion_id'],
                            'channel': channel,
                            'credit_fraction': credit_per_middle
                        })
                
                # Last touchpoint
                result_data.append({
                    'conversion_id': row['conversion_id'],
                    'channel': channels[-1],
                    'credit_fraction': last_weight
                })
        
        return pd.DataFrame(result_data)
    
    @staticmethod
    def time_decay(journeys_df: pd.DataFrame, half_life_days: int = 7) -> pd.DataFrame:
        """
        Time-decay attribution: More recent touchpoints get higher weight
        
        Args:
            journeys_df: Journey data with timestamp information
            half_life_days: Days for weight to decay by 50%
        """
        expected_cols = {"conversion_id", "channel_sequence", "revenue_amount"}
        missing = expected_cols - set(journeys_df.columns)
        if missing:
            raise ValueError(f"time_decay: missing columns {missing}")
            
        if journeys_df.empty:
            logger.warning("time_decay: no journeys provided")
            return pd.DataFrame(columns=["conversion_id", "channel", "credit_fraction"])
        
        # For simplification, assume equal time intervals between touchpoints
        # In production, this would use actual timestamps
        decay_factor = 0.5 ** (1.0 / half_life_days)
        result_data = []
        
        for _, row in journeys_df.iterrows():
            if not row['channel_sequence'] or len(row['channel_sequence']) == 0:
                logger.warning(f"Empty channel sequence for conversion {row['conversion_id']}")
                continue
                
            channels = row['channel_sequence']
            num_channels = len(channels)
            
            # Calculate weights (most recent = highest weight)
            weights = []
            for i in range(num_channels):
                days_before_conversion = num_channels - 1 - i
                weight = decay_factor ** days_before_conversion
                weights.append(weight)
            
            # Normalize weights to sum to 1
            total_weight = sum(weights)
            normalized_weights = [w / total_weight for w in weights]
            
            for i, channel in enumerate(channels):
                result_data.append({
                    'conversion_id': row['conversion_id'],
                    'channel': channel,
                    'credit_fraction': normalized_weights[i]
                })
        
        return pd.DataFrame(result_data)
    
    @staticmethod
    def markov_chain_attribution(journeys_df: pd.DataFrame) -> pd.DataFrame:
        """
        Markov chain attribution with removal effect analysis
        Builds transition matrix, computes removal-effect per channel
        Cache or sample for performance per https://www.attributionapp.com/blog/revenue-attribution/
        """
        expected_cols = {"conversion_id", "channel_sequence", "revenue_amount"}
        missing = expected_cols - set(journeys_df.columns)
        if missing:
            raise ValueError(f"markov_chain_attribution: missing columns {missing}")
            
        if journeys_df.empty:
            logger.warning("markov_chain_attribution: no journeys provided")
            return pd.DataFrame(columns=["conversion_id", "channel", "credit_fraction"])
        
        # Sample large datasets for performance unless forced
        max_journeys = 10000
        force_full = os.getenv("FORCE_MARKOV", "false").lower() == "true"
        
        if len(journeys_df) > max_journeys and not force_full:
            logger.info(f"Sampling {max_journeys} journeys for Markov due to large dataset")
            journeys_sample = journeys_df.sample(n=max_journeys, random_state=42)
        else:
            journeys_sample = journeys_df
        
        # Build transition matrix
        transitions = {}
        all_channels = set()
        
        for _, row in journeys_sample.iterrows():
            if not row['channel_sequence'] or len(row['channel_sequence']) == 0:
                continue
                
            channels = ['start'] + row['channel_sequence'] + ['conversion']
            all_channels.update(row['channel_sequence'])
            
            for i in range(len(channels) - 1):
                from_state = channels[i]
                to_state = channels[i + 1]
                
                if from_state not in transitions:
                    transitions[from_state] = {}
                if to_state not in transitions[from_state]:
                    transitions[from_state][to_state] = 0
                
                transitions[from_state][to_state] += 1
        
        # Calculate removal effect for each channel
        # Simplified implementation - in production would use proper Markov chain analysis
        channel_credits = {}
        total_conversions = len(journeys_sample)
        
        for channel in all_channels:
            # Count conversions that include this channel
            channel_conversions = 0
            for _, row in journeys_sample.iterrows():
                if channel in row['channel_sequence']:
                    channel_conversions += 1
            
            # Simple removal effect approximation
            removal_effect = channel_conversions / total_conversions if total_conversions > 0 else 0
            channel_credits[channel] = removal_effect
        
        # Normalize credits
        total_credit = sum(channel_credits.values())
        if total_credit > 0:
            for channel in channel_credits:
                channel_credits[channel] = channel_credits[channel] / total_credit
        
        # Apply credits to all conversions
        result_data = []
        for _, row in journeys_df.iterrows():
            if not row['channel_sequence'] or len(row['channel_sequence']) == 0:
                continue
                
            journey_channels = set(row['channel_sequence'])
            journey_total_credit = sum(channel_credits.get(ch, 0) for ch in journey_channels)
            
            if journey_total_credit > 0:
                for channel in journey_channels:
                    credit = channel_credits.get(channel, 0) / journey_total_credit
                    result_data.append({
                        'conversion_id': row['conversion_id'],
                        'channel': channel,
                        'credit_fraction': credit
                    })
        
        return pd.DataFrame(result_data)


def build_journeys(merged_df: pd.DataFrame) -> pd.DataFrame:
    """
    Build customer journeys from merged lead and transaction data
    
    Args:
        merged_df: DataFrame with lead and transaction data
        
    Returns:
        DataFrame with columns ['conversion_id', 'channel_sequence', 'revenue_amount']
    """
    expected_cols = {"lead_id", "timestamp", "channel", "revenue_amount"}
    available_cols = set(merged_df.columns)
    
    # Handle variations in column names
    timestamp_col = None
    for col in ['timestamp', 'Inbound', 'Date', 'created_time']:
        if col in available_cols:
            timestamp_col = col
            break
    
    channel_col = None
    for col in ['channel', 'Source', 'utm_source', 'lead_source']:
        if col in available_cols:
            channel_col = col
            break
    
    revenue_col = None
    for col in ['revenue_amount', 'Amount', 'transaction_amount', 'revenue']:
        if col in available_cols:
            revenue_col = col
            break
    
    if not timestamp_col or not channel_col:
        logger.error(f"build_journeys: missing required columns. Available: {available_cols}")
        return pd.DataFrame(columns=['conversion_id', 'channel_sequence', 'revenue_amount'])
    
    logger.info(f"Using columns - timestamp: {timestamp_col}, channel: {channel_col}, revenue: {revenue_col}")
    
    # Normalize channel names
    def normalize_channel(channel_raw):
        if pd.isna(channel_raw):
            return "unknown"
        
        channel_str = str(channel_raw).lower()
        
        # Map Meta/Facebook channels
        if any(term in channel_str for term in ['facebook', 'meta', 'fb']):
            return "meta_facebook"
        elif 'instagram' in channel_str:
            return "meta_instagram"
        elif 'google' in channel_str:
            return "google_ads"
        elif 'linkedin' in channel_str:
            return "linkedin"
        elif 'email' in channel_str:
            return "email"
        elif 'organic' in channel_str:
            return "organic_search"
        elif 'direct' in channel_str:
            return "direct"
        else:
            return f"other_{channel_str[:20]}"  # Truncate long channel names
    
    # Process journeys
    result_data = []
    
    # Group by lead_id and process each lead's journey
    for lead_id, lead_group in merged_df.groupby('lead_id'):
        # Sort by timestamp
        try:
            lead_group = lead_group.sort_values(timestamp_col)
        except Exception as e:
            logger.warning(f"Could not sort by timestamp for lead {lead_id}: {e}")
            continue
        
        # Extract channel sequence
        channels = []
        total_revenue = 0
        
        for _, row in lead_group.iterrows():
            channel = normalize_channel(row[channel_col])
            if channel not in channels:  # Avoid duplicate consecutive channels
                channels.append(channel)
            
            # Sum revenue for this lead
            if revenue_col and not pd.isna(row.get(revenue_col, 0)):
                total_revenue += float(row[revenue_col])
        
        # Only include leads with transactions (revenue > 0)
        if total_revenue > 0 and channels:
            result_data.append({
                'conversion_id': f"lead_{lead_id}",
                'channel_sequence': channels,
                'revenue_amount': total_revenue
            })
        elif not channels:
            logger.warning(f"No valid channels found for lead {lead_id}")
    
    logger.info(f"Built {len(result_data)} customer journeys with total revenue")
    
    return pd.DataFrame(result_data)


def calculate_attribution_roas(credit_df: pd.DataFrame, journeys_df: pd.DataFrame, spend_df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate ROAS and other metrics by channel using attribution results
    
    Args:
        credit_df: Attribution credit results
        journeys_df: Journey data with revenue
        spend_df: Spend data by channel
        
    Returns:
        DataFrame with channel performance metrics
    """
    if credit_df.empty or journeys_df.empty:
        logger.warning("Empty attribution or journey data")
        return pd.DataFrame(columns=['channel', 'attributed_revenue', 'spend', 'roas', 'cost_per_revenue'])
    
    # Merge credit with revenue
    try:
        merged_credit = credit_df.merge(
            journeys_df[['conversion_id', 'revenue_amount']], 
            on='conversion_id', 
            how='left'
        )
        
        # Handle missing revenue amounts
        merged_credit['revenue_amount'] = merged_credit['revenue_amount'].fillna(0)
        
        # Calculate weighted revenue by channel
        merged_credit['weighted_revenue'] = (
            merged_credit['credit_fraction'] * merged_credit['revenue_amount']
        )
        
        channel_revenue = (
            merged_credit.groupby('channel')['weighted_revenue']
            .sum()
            .reset_index()
            .rename(columns={'weighted_revenue': 'attributed_revenue'})
        )
        
        # Merge with spend data
        result_df = channel_revenue.merge(spend_df, on='channel', how='left')
        result_df['spend'] = result_df['spend'].fillna(0)
        
        # Calculate metrics
        result_df['roas'] = result_df.apply(
            lambda r: (r['attributed_revenue'] / r['spend']) if r['spend'] > 0 else None, 
            axis=1
        )
        
        result_df['cost_per_revenue'] = result_df.apply(
            lambda r: (r['spend'] / r['attributed_revenue']) if r['attributed_revenue'] > 0 else None, 
            axis=1
        )
        
        # Log channels missing spend data
        missing_spend = result_df[result_df['spend'] == 0]['channel'].tolist()
        if missing_spend:
            logger.warning(f"Channels missing spend data: {missing_spend}")
        
        return result_df.sort_values('attributed_revenue', ascending=False)
        
    except Exception as e:
        logger.error(f"Error calculating attribution ROAS: {e}")
        return pd.DataFrame(columns=['channel', 'attributed_revenue', 'spend', 'roas', 'cost_per_revenue'])