"""
Debug Meta API Connection and Ad Spend
Test the Meta API connection and troubleshoot ad spend retrieval
"""

import streamlit as st
import requests
import os
import json
from datetime import datetime, timedelta

# Meta API Configuration
META_ACCESS_TOKEN = os.getenv('META_ACCESS_TOKEN')
META_AD_ACCOUNT_ID = os.getenv('META_AD_ACCOUNT_ID')

st.title("🔍 Meta API Debugging Tool")
st.write("Testing Meta API connection and ad spend retrieval")

# Check environment variables
st.header("1. Environment Variables Check")
col1, col2 = st.columns(2)

with col1:
    if META_ACCESS_TOKEN:
        st.success(f"✅ META_ACCESS_TOKEN: Present ({META_ACCESS_TOKEN[:20]}...)")
    else:
        st.error("❌ META_ACCESS_TOKEN: Missing")

with col2:
    if META_AD_ACCOUNT_ID:
        st.success(f"✅ META_AD_ACCOUNT_ID: {META_AD_ACCOUNT_ID}")
    else:
        st.error("❌ META_AD_ACCOUNT_ID: Missing")

if not META_ACCESS_TOKEN or not META_AD_ACCOUNT_ID:
    st.stop()

# Date range for testing
st.header("2. Date Range Selection")
col1, col2 = st.columns(2)
with col1:
    start_date = st.date_input("Start Date", datetime.now().date() - timedelta(days=30))
with col2:
    end_date = st.date_input("End Date", datetime.now().date())

start_str = start_date.strftime('%Y-%m-%d')
end_str = end_date.strftime('%Y-%m-%d')

# Test basic API connection
st.header("3. Basic API Connection Test")

def test_api_connection():
    """Test basic API connection"""
    try:
        url = f"https://graph.facebook.com/v18.0/act_{META_AD_ACCOUNT_ID}"
        params = {
            'access_token': META_ACCESS_TOKEN,
            'fields': 'name,account_status,currency'
        }
        
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        return True, response.json()
    except Exception as e:
        return False, str(e)

if st.button("Test API Connection"):
    success, result = test_api_connection()
    
    if success:
        st.success("✅ API Connection Successful")
        st.json(result)
    else:
        st.error(f"❌ API Connection Failed: {result}")

# Test insights endpoint
st.header("4. Insights Endpoint Test")

def test_insights_endpoint():
    """Test insights endpoint with different parameters"""
    tests = []
    
    # Test 1: Basic insights
    try:
        url = f"https://graph.facebook.com/v18.0/act_{META_AD_ACCOUNT_ID}/insights"
        params = {
            'access_token': META_ACCESS_TOKEN,
            'time_range': f'{{"since":"{start_str}","until":"{end_str}"}}',
            'fields': 'spend,impressions,clicks',
            'limit': 10
        }
        
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        
        tests.append({
            'test': 'Basic Insights',
            'status': 'success',
            'data': data,
            'url': url,
            'params': params
        })
    except Exception as e:
        tests.append({
            'test': 'Basic Insights',
            'status': 'error',
            'error': str(e),
            'url': url,
            'params': params
        })
    
    # Test 2: Campaign level insights
    try:
        url = f"https://graph.facebook.com/v18.0/act_{META_AD_ACCOUNT_ID}/insights"
        params = {
            'access_token': META_ACCESS_TOKEN,
            'time_range': f'{{"since":"{start_str}","until":"{end_str}"}}',
            'fields': 'campaign_name,spend,impressions,clicks,ctr,cpm',
            'level': 'campaign',
            'limit': 50
        }
        
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        
        tests.append({
            'test': 'Campaign Level Insights',
            'status': 'success',
            'data': data,
            'url': url,
            'params': params
        })
    except Exception as e:
        tests.append({
            'test': 'Campaign Level Insights',
            'status': 'error',
            'error': str(e),
            'url': url,
            'params': params
        })
    
    return tests

if st.button("Test Insights Endpoint"):
    tests = test_insights_endpoint()
    
    for test in tests:
        st.subheader(f"Test: {test['test']}")
        
        if test['status'] == 'success':
            st.success("✅ Success")
            data = test['data']
            
            if 'data' in data:
                st.write(f"Found {len(data['data'])} records")
                
                total_spend = 0
                for record in data['data']:
                    spend = float(record.get('spend', 0))
                    total_spend += spend
                
                st.metric("Total Spend Found", f"${total_spend:.2f}")
                
                if data['data']:
                    st.write("Sample records:")
                    st.json(data['data'][:3])
                else:
                    st.warning("No data records found in response")
            else:
                st.warning("No 'data' field in response")
                st.json(data)
        else:
            st.error(f"❌ Error: {test['error']}")
        
        with st.expander("Request Details"):
            st.write("URL:", test['url'])
            st.write("Parameters:")
            st.json(test['params'])

# Test different time ranges
st.header("5. Time Range Tests")

def test_different_time_ranges():
    """Test different time ranges to see when data exists"""
    ranges = [
        ("Last 7 days", 7),
        ("Last 30 days", 30),
        ("Last 60 days", 60),
        ("Last 90 days", 90)
    ]
    
    results = []
    
    for name, days in ranges:
        try:
            test_start = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
            test_end = datetime.now().strftime('%Y-%m-%d')
            
            url = f"https://graph.facebook.com/v18.0/act_{META_AD_ACCOUNT_ID}/insights"
            params = {
                'access_token': META_ACCESS_TOKEN,
                'time_range': f'{{"since":"{test_start}","until":"{test_end}"}}',
                'fields': 'spend,campaign_name',
                'level': 'campaign',
                'limit': 100
            }
            
            response = requests.get(url, params=params)
            response.raise_for_status()
            data = response.json()
            
            total_spend = 0
            campaign_count = 0
            smooth_campaigns = 0
            
            if 'data' in data:
                for record in data['data']:
                    spend = float(record.get('spend', 0))
                    campaign_name = record.get('campaign_name', '').lower()
                    
                    total_spend += spend
                    campaign_count += 1
                    
                    if any(keyword in campaign_name for keyword in ['smooth', 'md', 'smoothmd']) and \
                       not any(keyword in campaign_name for keyword in ['vigor', 'dr vigor', 'dr. vigor']):
                        smooth_campaigns += 1
            
            results.append({
                'range': name,
                'period': f"{test_start} to {test_end}",
                'total_spend': total_spend,
                'campaign_count': campaign_count,
                'smooth_campaigns': smooth_campaigns,
                'status': 'success'
            })
            
        except Exception as e:
            results.append({
                'range': name,
                'period': f"{test_start} to {test_end}",
                'error': str(e),
                'status': 'error'
            })
    
    return results

if st.button("Test Different Time Ranges"):
    results = test_different_time_ranges()
    
    for result in results:
        if result['status'] == 'success':
            st.write(f"**{result['range']}** ({result['period']})")
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Total Spend", f"${result['total_spend']:.2f}")
            with col2:
                st.metric("Total Campaigns", result['campaign_count'])
            with col3:
                st.metric("Smooth MD Campaigns", result['smooth_campaigns'])
        else:
            st.error(f"**{result['range']}**: {result['error']}")

# Manual API call tester
st.header("6. Manual API Call Tester")

st.write("Test custom API calls with your own parameters:")

custom_fields = st.text_input("Fields to request", "spend,campaign_name,impressions,clicks")
custom_level = st.selectbox("Level", ["account", "campaign", "adset", "ad"])
custom_limit = st.number_input("Limit", min_value=1, max_value=1000, value=50)

if st.button("Test Custom API Call"):
    try:
        url = f"https://graph.facebook.com/v18.0/act_{META_AD_ACCOUNT_ID}/insights"
        params = {
            'access_token': META_ACCESS_TOKEN,
            'time_range': f'{{"since":"{start_str}","until":"{end_str}"}}',
            'fields': custom_fields,
            'level': custom_level,
            'limit': custom_limit
        }
        
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        
        st.success("✅ Custom API Call Successful")
        st.json(data)
        
        if 'data' in data and data['data']:
            total_spend = sum(float(record.get('spend', 0)) for record in data['data'])
            st.metric("Total Spend from Custom Call", f"${total_spend:.2f}")
            
    except Exception as e:
        st.error(f"❌ Custom API Call Failed: {str(e)}")