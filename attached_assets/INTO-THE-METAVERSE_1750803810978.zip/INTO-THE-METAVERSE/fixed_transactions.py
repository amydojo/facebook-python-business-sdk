"""
Fixed transaction to lead matching for ad performance tracking
"""
import pandas as pd
import numpy as np

def match_lead_transactions(leads_df, transactions_df):
    """
    Match leads with their corresponding transactions using a safe method
    that avoids array truth value errors
    
    Args:
        leads_df (pd.DataFrame): DataFrame containing lead data
        transactions_df (pd.DataFrame): DataFrame containing transaction data
        
    Returns:
        pd.DataFrame: Leads DataFrame with transaction data added
    """
    if transactions_df is None or transactions_df.empty or leads_df is None or leads_df.empty:
        print("Missing transaction or lead data for accurate ROI calculation")
        return leads_df
    
    # Create a copy of leads_df to add transaction data
    enriched_leads = leads_df.copy()
    
    # Add columns for transaction data
    enriched_leads['transaction_count'] = 0
    enriched_leads['transaction_total'] = 0.0
    
    # Find an amount field in the transactions
    amount_field = None
    for field in ['Amount', 'Revenue', 'Payment', 'Value', 'Price', 'Total']:
        if field in transactions_df.columns:
            amount_field = field
            print(f"Using amount field: {field}")
            break
    
    if not amount_field:
        print("Could not find amount field in transactions")
        return leads_df
    
    # Create a clean version of the transactions with standardized numeric amounts
    tx_df = transactions_df.copy()
    
    # Convert amount to numeric safely handling string formatting
    try:
        tx_df['clean_amount'] = tx_df[amount_field].apply(
            lambda x: pd.to_numeric(
                str(x).replace('$', '').replace(',', '') if isinstance(x, str) else x,
                errors='coerce'
            )
        ).fillna(0.0)
    except Exception as e:
        print(f"Error cleaning amount field: {e}")
        tx_df['clean_amount'] = 0.0
    
    # Identify fields that might contain identifiers
    email_fields = ['Email', 'email', 'email_address', 'Email Address']
    phone_fields = ['Phone', 'phone', 'Phone number', 'phone_number', 'Phone Number']
    lead_id_fields = ['id', 'ID', 'recID']
    tx_id_fields = ['Lead ID', 'Lead_ID', 'Original Location Interest (from Lead ID)']
    
    # Track matching stats
    matched_count = 0
    matched_leads = set()
    
    # Process each lead individually to find matching transactions
    for idx, lead in enriched_leads.iterrows():
        # Get lead identifiers
        lead_id = None
        lead_email = None
        lead_phone = None
        
        # Extract lead ID
        for id_field in lead_id_fields:
            if id_field in lead and pd.notna(lead[id_field]):
                lead_id = str(lead[id_field])
                break
                
        # Extract lead email
        for email_field in email_fields:
            if email_field in lead and pd.notna(lead[email_field]):
                lead_email = str(lead[email_field]).lower().strip()
                break
                
        # Extract lead phone
        for phone_field in phone_fields:
            if phone_field in lead and pd.notna(lead[phone_field]):
                # Clean phone to digits only
                lead_phone = ''.join(c for c in str(lead[phone_field]) if c.isdigit())
                if len(lead_phone) >= 10:  # Ensure it's a valid phone
                    break
                else:
                    lead_phone = None
        
        # Skip leads with no identifiable info
        if not lead_id and not lead_email and not lead_phone:
            continue
            
        # Find matching transactions for this lead
        lead_matches = []
        
        # Check each transaction for a match with this lead
        for _, tx in tx_df.iterrows():
            match_found = False
            
            # Try ID-based matching first
            if lead_id:
                # First check common fields that might link to lead ID
                for field in tx_id_fields:
                    if field in tx and pd.notna(tx[field]):
                        tx_val = str(tx[field])
                        if lead_id in tx_val:
                            match_found = True
                            break
                
                # If still not found, try any field that might contain the ID
                if not match_found:
                    for field in tx.index:
                        # Skip non-string fields
                        if field == 'clean_amount' or not pd.notna(tx[field]):
                            continue
                            
                        # Try to convert to string and check if lead ID is contained
                        try:
                            if isinstance(tx[field], str) and lead_id in tx[field]:
                                match_found = True
                                break
                        except:
                            continue
            
            # Try email matching if no ID match
            if not match_found and lead_email:
                for tx_email_field in email_fields:
                    if tx_email_field in tx and pd.notna(tx[tx_email_field]):
                        tx_email = str(tx[tx_email_field]).lower().strip()
                        if lead_email == tx_email:
                            match_found = True
                            break
            
            # Try phone matching if no ID or email match
            if not match_found and lead_phone:
                for tx_phone_field in phone_fields:
                    if tx_phone_field in tx and pd.notna(tx[tx_phone_field]):
                        tx_phone = ''.join(c for c in str(tx[tx_phone_field]) if c.isdigit())
                        # Match either entire phone or last 10 digits
                        if (lead_phone == tx_phone or 
                            (len(lead_phone) >= 10 and len(tx_phone) >= 10 and
                             lead_phone[-10:] == tx_phone[-10:])):
                            match_found = True
                            break
            
            # If we found a match by any method, add this transaction
            if match_found:
                lead_matches.append(tx)
                matched_leads.add(idx)
        
        # Process all matches for this lead
        if lead_matches:
            matched_count += len(lead_matches)
            transaction_count = len(lead_matches)
            total_amount = sum(tx['clean_amount'] for tx in lead_matches)
            
            # Update lead with transaction data
            enriched_leads.at[idx, 'transaction_count'] = transaction_count
            enriched_leads.at[idx, 'transaction_total'] = total_amount
    
    # Debug results
    print(f"Matched {matched_count} transactions to {len(matched_leads)} leads")
    print(f"Total matched transaction value: ${enriched_leads['transaction_total'].sum():.2f}")
    
    return enriched_leads