
"""
Reliable Airtable Client
A simplified, robust implementation focused on reliable connections
"""
import os
import json
import time
import streamlit as st
import pandas as pd
from pyairtable import Api
from typing import Dict, List, Optional, Union, Any
import traceback

class ReliableAirtableClient:
    def __init__(self, api_key: str = None, base_id: str = None, table_name: str = None):
        """Initialize with credentials or load from session/file"""
        # Try to get credentials in this order: 
        # 1. Passed parameters
        # 2. Session state
        # 3. Credentials file
        self.api_key = api_key or st.session_state.get('api_key')
        self.base_id = base_id or st.session_state.get('base_id', 'appri2CgCoIiuZWq3')
        self.table_name = table_name or st.session_state.get('leads_table_name', 'Leads')
        
        # If still no API key, try to load from credentials file
        if not self.api_key and os.path.exists('.credentials.json'):
            try:
                with open('.credentials.json', 'r') as f:
                    credentials = json.load(f)
                    self.api_key = credentials.get('api_key')
                    self.base_id = credentials.get('base_id', self.base_id)
                    self.table_name = credentials.get('leads_table_name', self.table_name)
            except Exception as e:
                st.error(f"Failed to load credentials from file: {str(e)}")
        
        # Initialize the API connection
        self._initialize_api()
        
        # Track connection status
        self.connected = False
        
    def _initialize_api(self):
        """Initialize the Airtable API connection with error handling"""
        try:
            if not self.api_key:
                st.warning("No API key provided. Please set your Airtable API key.")
                self.api = None
                self.table = None
                return
                
            self.api = Api(self.api_key)
            self.table = self.api.table(self.base_id, self.table_name)
        except Exception as e:
            st.error(f"Failed to initialize Airtable API: {str(e)}")
            self.api = None
            self.table = None
    
    def test_connection(self) -> bool:
        """Test the connection to Airtable with a simple query"""
        if not self.api or not self.table:
            st.error("Airtable API not initialized. Check your credentials.")
            return False
            
        try:
            # Attempt to fetch a single record
            records = self.table.all(max_records=1)
            self.connected = True
            return True
        except Exception as e:
            error_msg = str(e)
            self.connected = False
            
            if "401" in error_msg:
                st.error("❌ Authentication failed: Invalid API key")
            elif "404" in error_msg:
                st.error("❌ Not found: Check your base ID and table name")
            else:
                st.error(f"❌ Connection error: {error_msg}")
                
            return False
    
    def get_records(self, max_records: int = None, 
                   fields: List[str] = None, 
                   filter_by_formula: str = None,
                   retry_count: int = 3) -> List[Dict]:
        """
        Get records from Airtable with built-in retry logic
        """
        if not self.api or not self.table:
            st.error("Airtable API not initialized. Check your credentials.")
            return []
            
        attempt = 0
        while attempt < retry_count:
            try:
                params = {}
                if max_records:
                    params['max_records'] = max_records
                if fields:
                    params['fields'] = fields
                if filter_by_formula:
                    params['filter_by_formula'] = filter_by_formula
                    
                records = self.table.all(**params)
                self.connected = True
                return records
                
            except Exception as e:
                attempt += 1
                error_msg = str(e)
                
                if "429" in error_msg:  # Rate limit error
                    st.warning(f"Rate limit hit, retrying in {attempt} seconds...")
                    time.sleep(attempt)  # Exponential backoff
                elif attempt >= retry_count:
                    self.connected = False
                    st.error(f"Failed to get records after {retry_count} attempts: {error_msg}")
                    return []
                else:
                    time.sleep(1)  # Brief pause before retry
        
        return []
    
    def get_dataframe(self, max_records: int = None, 
                     fields: List[str] = None, 
                     filter_by_formula: str = None) -> pd.DataFrame:
        """
        Get records as a pandas DataFrame with error handling
        """
        records = self.get_records(max_records, fields, filter_by_formula)
        
        if not records:
            return pd.DataFrame()
            
        try:
            # Extract fields from records
            data = [record['fields'] for record in records]
            # Also include record ID
            for i, record in enumerate(records):
                data[i]['record_id'] = record['id']
                
            return pd.DataFrame(data)
        except Exception as e:
            st.error(f"Error converting records to DataFrame: {str(e)}")
            return pd.DataFrame()
    
    def create_record(self, fields: Dict) -> Dict:
        """Create a new record in Airtable"""
        if not self.api or not self.table:
            st.error("Airtable API not initialized. Check your credentials.")
            return {}
            
        try:
            record = self.table.create(fields)
            return record
        except Exception as e:
            st.error(f"Failed to create record: {str(e)}")
            return {}
    
    def update_record(self, record_id: str, fields: Dict) -> Dict:
        """Update an existing record in Airtable"""
        if not self.api or not self.table:
            st.error("Airtable API not initialized. Check your credentials.")
            return {}
            
        try:
            record = self.table.update(record_id, fields)
            return record
        except Exception as e:
            st.error(f"Failed to update record: {str(e)}")
            return {}
    
    def save_credentials_to_file(self) -> bool:
        """Save credentials to a local file for persistence"""
        if not self.api_key:
            st.error("No API key to save")
            return False
            
        try:
            credentials = {
                "api_key": self.api_key,
                "base_id": self.base_id,
                "leads_table_name": self.table_name
            }
            
            with open('.credentials.json', 'w') as f:
                json.dump(credentials, f)
                
            return True
        except Exception as e:
            st.error(f"Failed to save credentials: {str(e)}")
            return False

# Simple test function to demonstrate usage
def test_reliable_airtable():
    st.title("Reliable Airtable Client Test")
    
    with st.sidebar:
        st.header("Connection Settings")
        api_key = st.text_input("Airtable API Key", type="password")
        base_id = st.text_input("Base ID", value="appri2CgCoIiuZWq3")
        table_name = st.text_input("Table Name", value="Leads")
        
        if st.button("Save Settings"):
            st.session_state.api_key = api_key
            st.session_state.base_id = base_id
            st.session_state.leads_table_name = table_name
            st.success("Settings saved to session!")
    
    # Initialize client
    client = ReliableAirtableClient()
    
    # Test connection button
    if st.button("Test Connection"):
        with st.spinner("Testing connection..."):
            if client.test_connection():
                st.success("✅ Connection successful!")
                # Show a sample record if available
                records = client.get_records(max_records=1)
                if records:
                    st.write("Sample record fields:", list(records[0]['fields'].keys()))
            else:
                st.error("❌ Connection failed")
    
    # Get records as DataFrame
    if st.button("Get Records as DataFrame"):
        with st.spinner("Fetching records..."):
            df = client.get_dataframe(max_records=10)
            if not df.empty:
                st.success(f"Retrieved {len(df)} records")
                st.dataframe(df)
            else:
                st.warning("No records found or error occurred")
    
    # Save credentials
    if st.button("Save Credentials to File"):
        if client.save_credentials_to_file():
            st.success("Credentials saved successfully!")
        else:
            st.error("Failed to save credentials")

if __name__ == "__main__":
    test_reliable_airtable()
