"""
Enhanced Error Recovery System
Iron-proof error handling with comprehensive recovery mechanisms
"""

import logging
import traceback
import time
import functools
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, TypeVar, Union
import streamlit as st

# Configure logging with rotation
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s',
    handlers=[
        logging.FileHandler('system_errors.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

T = TypeVar('T')

class EnhancedErrorRecovery:
    """Advanced error recovery with circuit breakers and fallbacks"""
    
    def __init__(self):
        self.error_counts: Dict[str, int] = {}
        self.circuit_states: Dict[str, str] = {}  # CLOSED, OPEN, HALF_OPEN
        self.last_failures: Dict[str, datetime] = {}
        self.recovery_strategies: Dict[str, Callable] = {}
    
    def register_recovery_strategy(self, operation: str, strategy: Callable) -> None:
        """Register a recovery strategy for specific operations"""
        self.recovery_strategies[operation] = strategy
    
    def circuit_breaker(self, operation: str, failure_threshold: int = 5, recovery_timeout: int = 60):
        """Circuit breaker decorator"""
        def decorator(func: Callable[..., T]) -> Callable[..., Optional[T]]:
            @functools.wraps(func)
            def wrapper(*args, **kwargs) -> Optional[T]:
                # Check circuit state
                if self._is_circuit_open(operation, recovery_timeout):
                    logger.warning(f"Circuit breaker OPEN for {operation}")
                    return self._execute_fallback(operation, *args, **kwargs)
                
                try:
                    result = func(*args, **kwargs)
                    self._on_success(operation)
                    return result
                
                except Exception as e:
                    self._on_failure(operation, e, failure_threshold)
                    return self._execute_fallback(operation, *args, **kwargs)
            
            return wrapper
        return decorator
    
    def _is_circuit_open(self, operation: str, timeout: int) -> bool:
        """Check if circuit breaker is open"""
        if operation not in self.circuit_states:
            return False
        
        if self.circuit_states[operation] == 'OPEN':
            if operation in self.last_failures:
                time_since_failure = (datetime.now() - self.last_failures[operation]).seconds
                if time_since_failure >= timeout:
                    self.circuit_states[operation] = 'HALF_OPEN'
                    return False
            return True
        
        return False
    
    def _on_success(self, operation: str) -> None:
        """Handle successful operation"""
        self.error_counts[operation] = 0
        self.circuit_states[operation] = 'CLOSED'
    
    def _on_failure(self, operation: str, error: Exception, threshold: int) -> None:
        """Handle failed operation"""
        self.error_counts[operation] = self.error_counts.get(operation, 0) + 1
        self.last_failures[operation] = datetime.now()
        
        logger.error(f"Operation {operation} failed: {error}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        
        if self.error_counts[operation] >= threshold:
            self.circuit_states[operation] = 'OPEN'
            logger.error(f"Circuit breaker OPEN for {operation} after {threshold} failures")
    
    def _execute_fallback(self, operation: str, *args, **kwargs) -> Optional[Any]:
        """Execute fallback strategy"""
        if operation in self.recovery_strategies:
            try:
                return self.recovery_strategies[operation](*args, **kwargs)
            except Exception as e:
                logger.error(f"Fallback strategy failed for {operation}: {e}")
        
        return None

# Global recovery system
recovery_system = EnhancedErrorRecovery()

def robust_operation(
    operation_name: str,
    max_retries: int = 3,
    backoff_factor: float = 2.0,
    fallback_value: Any = None
):
    """Comprehensive robust operation decorator"""
    def decorator(func: Callable[..., T]) -> Callable[..., Union[T, Any]]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Union[T, Any]:
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                
                except Exception as e:
                    last_exception = e
                    wait_time = backoff_factor ** attempt
                    
                    logger.warning(
                        f"Attempt {attempt + 1}/{max_retries} failed for {operation_name}: {e}"
                    )
                    
                    if attempt < max_retries - 1:
                        time.sleep(wait_time)
            
            # All retries failed
            logger.error(f"All retries failed for {operation_name}: {last_exception}")
            
            # Try to show user-friendly error
            try:
                st.error(f"Operation temporarily unavailable: {operation_name}")
            except:
                pass
            
            return fallback_value
        
        return wrapper
    return decorator

def safe_execution(default_return: Any = None):
    """Safe execution wrapper with comprehensive error handling"""
    def decorator(func: Callable[..., T]) -> Callable[..., Union[T, Any]]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Union[T, Any]:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.error(f"Safe execution failed for {func.__name__}: {e}")
                logger.error(f"Traceback: {traceback.format_exc()}")
                return default_return
        return wrapper
    return decorator
