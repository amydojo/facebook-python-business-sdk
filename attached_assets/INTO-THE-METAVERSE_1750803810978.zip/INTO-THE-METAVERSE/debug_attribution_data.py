#!/usr/bin/env python3
"""
Attribution Data Diagnostic
Analyzes the exact data structure to fix revenue attribution
"""

import streamlit as st
import os
from datetime import datetime, timedelta
from pyairtable import Api

def analyze_attribution_data():
    """Analyze leads and transactions data to debug attribution"""
    
    st.title("🔍 Attribution Data Analysis")
    
    # Get credentials
    api_key = os.getenv('AIRTABLE_API_KEY')
    base_id = os.getenv('AIRTABLE_BASE_ID')
    
    if not api_key or not base_id:
        st.error("Missing Airtable credentials")
        return
    
    try:
        api = Api(api_key)
        
        # Date range
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=30)
        
        st.subheader("📊 Data Analysis Report")
        
        # Load leads with detailed analysis
        st.write("### Meta Leads Analysis")
        leads_table = api.table(base_id, 'Leads')
        
        # Get all Meta leads without filtering first
        formula = "OR({Contact Source}='Facebook AD', {Contact Source}='Instagram AD', {Contact Source}='Facebook AD Sign Up')"
        leads_records = leads_table.all(formula=formula, max_records=50)
        
        st.write(f"Found {len(leads_records)} Meta leads")
        
        # Analyze lead data structure
        if leads_records:
            sample_lead = leads_records[0]['fields']
            st.write("**Sample Lead Fields:**")
            for field, value in sample_lead.items():
                st.write(f"- {field}: {type(value).__name__} = {str(value)[:100]}")
        
        # Process leads for analysis
        processed_leads = []
        for record in leads_records:
            fields = record.get('fields', {})
            lead = {
                'id': record['id'],
                'lead_id': fields.get('ID', ''),
                'phone': str(fields.get('Phone', '')).strip(),
                'email': str(fields.get('Email', '')).strip().lower(),
                'contact_source': fields.get('Contact Source', ''),
                'overall_status': fields.get('Overall Status', ''),
                'patient_name': fields.get('Patient', ''),  # Check if name field exists
            }
            processed_leads.append(lead)
        
        # Display lead summary
        st.write("### Lead Summary by Status")
        status_counts = {}
        for lead in processed_leads:
            status = lead.get('overall_status', 'Unknown')
            status_counts[status] = status_counts.get(status, 0) + 1
        
        for status, count in status_counts.items():
            st.write(f"- {status}: {count}")
        
        # Load transactions
        st.write("### Transactions Analysis")
        transactions_table = api.table(base_id, 'Transactions')
        trans_records = transactions_table.all(max_records=50, sort=["-Date"])
        
        st.write(f"Found {len(trans_records)} transactions")
        
        # Analyze transaction structure
        if trans_records:
            sample_trans = trans_records[0]['fields']
            st.write("**Sample Transaction Fields:**")
            for field, value in sample_trans.items():
                st.write(f"- {field}: {type(value).__name__} = {str(value)[:100]}")
        
        # Process transactions
        processed_transactions = []
        total_revenue = 0
        for record in trans_records:
            fields = record.get('fields', {})
            amount = 0
            if 'Amount' in fields and fields['Amount']:
                try:
                    amount = float(fields['Amount'])
                    total_revenue += amount
                except:
                    pass
            
            trans = {
                'id': record['id'],
                'patient': str(fields.get('Patient', '')).strip(),
                'date': fields.get('Date', ''),
                'amount': amount,
            }
            processed_transactions.append(trans)
        
        st.write(f"**Total Revenue:** ${total_revenue:,.2f}")
        
        # Test matching logic
        st.write("### Matching Analysis")
        
        matches_found = 0
        match_details = []
        
        for lead in processed_leads[:10]:  # Test first 10 leads
            lead_phone = lead['phone'].replace('(', '').replace(')', '').replace('-', '').replace(' ', '')
            lead_email = lead['email']
            
            for trans in processed_transactions:
                patient_name = trans['patient'].lower()
                
                # Test phone matching
                phone_match = False
                if lead_phone and len(lead_phone) >= 10:
                    if lead_phone[-10:] in patient_name.replace('(', '').replace(')', '').replace('-', '').replace(' ', ''):
                        phone_match = True
                
                # Test email matching
                email_match = False
                if lead_email and '@' in lead_email:
                    email_prefix = lead_email.split('@')[0]
                    if len(email_prefix) >= 3 and email_prefix in patient_name:
                        email_match = True
                
                if phone_match or email_match:
                    matches_found += 1
                    match_details.append({
                        'lead_id': lead['lead_id'],
                        'lead_phone': lead_phone,
                        'lead_email': lead_email,
                        'patient': trans['patient'],
                        'amount': trans['amount'],
                        'phone_match': phone_match,
                        'email_match': email_match
                    })
        
        st.write(f"**Direct Matches Found:** {matches_found}")
        
        # Show match details
        if match_details:
            st.write("**Match Details:**")
            for match in match_details[:5]:
                st.write(f"- Lead {match['lead_id']} → Patient {match['patient']} (${match['amount']})")
                st.write(f"  Phone: {match['lead_phone'][:10]}... → Phone Match: {match['phone_match']}")
                st.write(f"  Email: {match['lead_email'][:20]}... → Email Match: {match['email_match']}")
        
        # Revenue distribution analysis
        st.write("### Revenue Distribution Issue")
        if matches_found == 0:
            st.warning("No direct matches found - this explains why all leads get equal revenue")
            st.write("Revenue is being distributed proportionally among all leads")
            
            # Calculate what each lead would get
            num_leads = len(processed_leads)
            if num_leads > 0:
                revenue_per_lead = total_revenue / num_leads
                st.write(f"Each lead gets: ${revenue_per_lead:.2f}")
        else:
            st.success(f"Found {matches_found} direct matches")
        
        # Sample data for debugging
        st.write("### Sample Data for Debugging")
        
        st.write("**First 3 Leads:**")
        for i, lead in enumerate(processed_leads[:3]):
            st.write(f"Lead {i+1}:")
            st.write(f"  ID: {lead['lead_id']}")
            st.write(f"  Phone: {lead['phone']}")
            st.write(f"  Email: {lead['email']}")
            st.write(f"  Status: {lead['overall_status']}")
        
        st.write("**First 3 Transactions:**")
        for i, trans in enumerate(processed_transactions[:3]):
            st.write(f"Transaction {i+1}:")
            st.write(f"  Patient: {trans['patient']}")
            st.write(f"  Amount: ${trans['amount']}")
            st.write(f"  Date: {trans['date']}")
        
    except Exception as e:
        st.error(f"Analysis error: {str(e)}")

if __name__ == "__main__":
    analyze_attribution_data()