"""
ROI and Conversions tab for the Ad Command Center
"""
import os
import json
import streamlit as st
import pandas as pd
import numpy as np
import requests
from datetime import datetime, timedelta
import plotly.graph_objects as go

def render_roi_tab():
    """Render the ROI & Conversions tab content"""
    st.markdown('<p class="section-title">ROI & ROAS Analysis</p>', unsafe_allow_html=True)
    
    # ROI Calculator settings
    with st.expander("ROI Calculation Settings"):
        col1, col2 = st.columns(2)
        
        with col1:
            avg_transaction = st.number_input("Average Transaction Value ($):", min_value=0, value=2500, step=100)
            booking_multiplier = st.number_input("Booking Value Multiplier (%):", min_value=0, max_value=100, value=20, step=5) / 100
        
        with col2:
            lead_value = st.number_input("Lead Value ($):", min_value=0, value=50, step=10)
            booked_to_close = st.slider("Booking to Closed Rate (%):", min_value=0, max_value=100, value=65, step=5) / 100
    
    # Direct Meta API connection for campaign data
    with st.spinner("Getting latest Meta campaign data..."):
        try:
            meta_access_token = os.environ.get("META_ACCESS_TOKEN")
            meta_ad_account_id = os.environ.get("META_AD_ACCOUNT_ID", "860378271946500")
            
            if not meta_ad_account_id.startswith('act_'):
                meta_ad_account_id = f"act_{meta_ad_account_id}"
            
            # Get campaigns
            campaigns_url = f"https://graph.facebook.com/v22.0/{meta_ad_account_id}/campaigns"
            campaigns_params = {
                "access_token": meta_access_token,
                "fields": "name,status,objective,created_time,start_time,stop_time,daily_budget,lifetime_budget,id",
                "limit": 50
            }
            
            # Get insights
            insights_url = f"https://graph.facebook.com/v22.0/{meta_ad_account_id}/insights"
            today = datetime.now()
            start_date = today - timedelta(days=90)
            date_range = {
                "since": start_date.strftime("%Y-%m-%d"),
                "until": today.strftime("%Y-%m-%d")
            }
            
            insights_params = {
                "access_token": meta_access_token,
                "level": "campaign",
                "time_range": json.dumps(date_range),
                "fields": "campaign_id,campaign_name,spend,impressions,clicks,cpm,cpc,ctr"
            }
            
            # API requests
            response = requests.get(campaigns_url, params=campaigns_params)
            campaigns = []
            if response.status_code == 200:
                result = response.json()
                if "data" in result:
                    campaigns = result["data"]
                    
            insights_response = requests.get(insights_url, params=insights_params)
            insights = []
            if insights_response.status_code == 200:
                insights_result = insights_response.json()
                if "data" in insights_result:
                    insights = insights_result["data"]
            
            # Process campaign data
            campaign_data = []
            
            # Map campaign spend
            campaign_spend = {}
            for insight in insights:
                if "campaign_name" in insight and "spend" in insight:
                    name = insight["campaign_name"]
                    if name not in campaign_spend:
                        campaign_spend[name] = 0
                    campaign_spend[name] += float(insight["spend"])
            
            # Get total leads
            total_leads = len(st.session_state.leads_df) if hasattr(st.session_state, 'leads_df') and st.session_state.leads_df is not None else 0
            
            # Create ROAS data
            for campaign in campaigns:
                if "name" in campaign:
                    name = campaign["name"]
                    status = campaign.get("status", "UNKNOWN")
                    
                    # Get spend
                    spend = campaign_spend.get(name, 0)
                    
                    # Estimate leads
                    total_spend = sum(campaign_spend.values()) if campaign_spend else 1
                    campaign_weight = spend / total_spend if total_spend > 0 else 0
                    estimated_leads = total_leads * campaign_weight
                    
                    # Estimate conversions
                    estimated_conversions = estimated_leads * 0.15
                    
                    # Calculate revenue
                    estimated_revenue = estimated_conversions * avg_transaction
                    
                    # Calculate ROAS
                    roas = estimated_revenue / spend if spend > 0 else 0
                    
                    campaign_data.append({
                        "Campaign": name,
                        "Status": status,
                        "Spend": spend,
                        "Estimated Revenue": estimated_revenue,
                        "ROAS": roas,
                        "Leads": estimated_leads,
                        "Estimated Conversions": estimated_conversions
                    })
            
            # Display campaign metrics
            if campaign_data:
                # Create campaign metrics table
                st.markdown("### Campaign Performance Metrics")
                
                # Create DataFrame
                campaign_df = pd.DataFrame(campaign_data)
                
                # Format for display
                display_df = campaign_df.copy()
                display_df["Spend"] = display_df["Spend"].apply(lambda x: f"${x:.2f}")
                display_df["Estimated Revenue"] = display_df["Estimated Revenue"].apply(lambda x: f"${x:.2f}")
                display_df["ROAS"] = display_df["ROAS"].apply(lambda x: f"{x:.2f}x")
                display_df["Leads"] = display_df["Leads"].apply(lambda x: f"{x:.1f}")
                display_df["Estimated Conversions"] = display_df["Estimated Conversions"].apply(lambda x: f"{x:.1f}")
                
                # Display table
                st.dataframe(
                    display_df,
                    column_config={
                        "Campaign": st.column_config.TextColumn("Campaign"),
                        "Status": st.column_config.TextColumn("Status"),
                        "Spend": st.column_config.TextColumn("Spend"),
                        "Estimated Revenue": st.column_config.TextColumn("Est. Revenue"),
                        "ROAS": st.column_config.TextColumn("ROAS"),
                        "Leads": st.column_config.TextColumn("Leads"),
                        "Estimated Conversions": st.column_config.TextColumn("Est. Conversions")
                    },
                    use_container_width=True
                )
                
                # Create ROAS chart
                fig = go.Figure()
                
                # Add spend bars
                fig.add_trace(go.Bar(
                    x=campaign_df["Campaign"],
                    y=campaign_df["Spend"],
                    name="Ad Spend",
                    marker_color="rgba(58, 71, 80, 0.6)"
                ))
                
                # Add revenue bars
                fig.add_trace(go.Bar(
                    x=campaign_df["Campaign"],
                    y=campaign_df["Estimated Revenue"],
                    name="Estimated Revenue",
                    marker_color="rgba(16, 185, 129, 0.6)"
                ))
                
                # Add ROAS line
                fig.add_trace(go.Scatter(
                    x=campaign_df["Campaign"],
                    y=campaign_df["ROAS"],
                    name="ROAS",
                    mode="lines+markers",
                    marker=dict(size=8, color="#1E3A8A"),
                    line=dict(width=2, color="#1E3A8A"),
                    yaxis="y2"
                ))
                
                # Update layout
                fig.update_layout(
                    title="Campaign Performance: Spend vs Estimated Revenue & ROAS",
                    xaxis=dict(
                        title="Campaign",
                        tickangle=45,
                        tickfont=dict(size=10)
                    ),
                    yaxis=dict(title="Amount ($)"),
                    yaxis2=dict(
                        title="ROAS (x)",
                        overlaying="y",
                        side="right",
                        rangemode="tozero"
                    ),
                    barmode="group",
                    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                    height=500,
                    margin=dict(l=20, r=20, t=60, b=120),
                    plot_bgcolor="rgba(0,0,0,0)"
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Campaign opportunities
                st.markdown("### Campaign Optimization Opportunities")
                
                # Calculate opportunities
                opportunities = []
                for campaign in campaign_data:
                    name = campaign["Campaign"]
                    roas = campaign["ROAS"] if isinstance(campaign["ROAS"], float) else 0
                    status = campaign["Status"]
                    spend = campaign["Spend"] if isinstance(campaign["Spend"], float) else 0
                    
                    if roas < 1 and status == "ACTIVE" and spend > 100:
                        opportunities.append({
                            "Campaign": name,
                            "Opportunity": "Consider pausing this underperforming campaign (ROAS < 1)",
                            "Priority": "High",
                            "Expected Impact": "Reduce wasted ad spend"
                        })
                    elif roas > 3:
                        opportunities.append({
                            "Campaign": name,
                            "Opportunity": "Consider increasing budget for this high-performing campaign",
                            "Priority": "Medium",
                            "Expected Impact": "Increase lead volume while maintaining ROAS"
                        })
                
                if opportunities:
                    opportunities_df = pd.DataFrame(opportunities)
                    st.dataframe(
                        opportunities_df,
                        column_config={
                            "Campaign": st.column_config.TextColumn("Campaign"),
                            "Opportunity": st.column_config.TextColumn("Opportunity"),
                            "Priority": st.column_config.TextColumn("Priority"),
                            "Expected Impact": st.column_config.TextColumn("Expected Impact")
                        },
                        use_container_width=True
                    )
                else:
                    st.info("No specific optimization opportunities identified at this time.")
            else:
                st.warning("No campaign data found. Please check your Meta API credentials.")
        
        except Exception as e:
            st.error(f"Error retrieving Meta campaign data: {str(e)}")
            st.info("Try refreshing the data with the button below to use your new Meta API token.")
    
    # Add refresh button
    col1, col2 = st.columns([3, 1])
    with col2:
        if st.button("🔄 Refresh Meta Data", use_container_width=True):
            st.session_state.force_refresh = True
            st.rerun()
    
    # ROI attribution
    st.markdown('<p class="section-title">Revenue Attribution</p>', unsafe_allow_html=True)
    
    # Calculate metrics
    total_leads = len(st.session_state.leads_df) if hasattr(st.session_state, 'leads_df') and st.session_state.leads_df is not None else 0
    
    # Check for transactions
    transactions_available = (
        hasattr(st.session_state, 'transactions_df') and 
        st.session_state.transactions_df is not None and 
        not st.session_state.transactions_df.empty
    )
    
    # Get status counts
    if hasattr(st.session_state, 'leads_df') and st.session_state.leads_df is not None and 'Overall Status' in st.session_state.leads_df.columns:
        booked_count = sum(st.session_state.leads_df['Overall Status'].apply(lambda x: 'booked' in str(x).lower() if pd.notna(x) else False))
        converted_count = sum(st.session_state.leads_df['Overall Status'].apply(lambda x: any(s in str(x).lower() for s in ['closed', 'deposit paid', 'installment plan', 'screening closed']) if pd.notna(x) else False))
    else:
        booked_count = int(total_leads * 0.3)  # Fallback
        converted_count = int(total_leads * 0.15)  # Fallback
    
    # Get spend
    campaign_spend = 0
    if hasattr(st.session_state, 'campaign_insights') and st.session_state.campaign_insights:
        for insight in st.session_state.campaign_insights:
            if 'spend' in insight:
                campaign_spend += float(insight['spend'])
    
    # Calculate additional metrics
    lead_cost = campaign_spend / total_leads if total_leads > 0 else 0
    booking_cost = campaign_spend / booked_count if booked_count > 0 else 0
    conversion_cost = campaign_spend / converted_count if converted_count > 0 else 0
    
    # Average transaction values
    avg_transaction_value = avg_transaction  # From user input
    booking_value = avg_transaction_value * booking_multiplier
    lead_value_calculated = lead_value  # From user input
    
    # Total values
    total_lead_value = total_leads * lead_value_calculated
    total_booking_value = booked_count * booking_value
    total_conversion_value = converted_count * avg_transaction_value
    
    # ROI calculations
    lead_roi = (total_lead_value - campaign_spend) / campaign_spend if campaign_spend > 0 else 0
    booking_roi = (total_booking_value - campaign_spend) / campaign_spend if campaign_spend > 0 else 0
    conversion_roi = (total_conversion_value - campaign_spend) / campaign_spend if campaign_spend > 0 else 0
    
    # Display metrics grid
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Lead Acquisition</div>
            <div class="metric-value">{total_leads:,}</div>
            <div class="metric-subtitle">Total Meta Leads</div>
            <hr style="margin: 10px 0; opacity: 0.2;">
            <div class="metric-row">
                <div class="metric-label">Cost Per Lead:</div>
                <div class="metric-value-small">${lead_cost:.2f}</div>
            </div>
            <div class="metric-row">
                <div class="metric-label">Lead Value:</div>
                <div class="metric-value-small">${lead_value_calculated:.2f}</div>
            </div>
            <div class="metric-row">
                <div class="metric-label">Lead ROI:</div>
                <div class="metric-value-small">{lead_roi:.1%}</div>
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Consultation Booking</div>
            <div class="metric-value">{booked_count:,}</div>
            <div class="metric-subtitle">Total Booked Leads</div>
            <hr style="margin: 10px 0; opacity: 0.2;">
            <div class="metric-row">
                <div class="metric-label">Cost Per Booking:</div>
                <div class="metric-value-small">${booking_cost:.2f}</div>
            </div>
            <div class="metric-row">
                <div class="metric-label">Booking Value:</div>
                <div class="metric-value-small">${booking_value:.2f}</div>
            </div>
            <div class="metric-row">
                <div class="metric-label">Booking ROI:</div>
                <div class="metric-value-small">{booking_roi:.1%}</div>
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">Customer Conversion</div>
            <div class="metric-value">{converted_count:,}</div>
            <div class="metric-subtitle">Total Conversions</div>
            <hr style="margin: 10px 0; opacity: 0.2;">
            <div class="metric-row">
                <div class="metric-label">Cost Per Acquisition:</div>
                <div class="metric-value-small">${conversion_cost:.2f}</div>
            </div>
            <div class="metric-row">
                <div class="metric-label">Average Transaction:</div>
                <div class="metric-value-small">${avg_transaction_value:,.2f}</div>
            </div>
            <div class="metric-row">
                <div class="metric-label">Conversion ROI:</div>
                <div class="metric-value-small">{conversion_roi:.1%}</div>
            </div>
        </div>
        """, unsafe_allow_html=True)