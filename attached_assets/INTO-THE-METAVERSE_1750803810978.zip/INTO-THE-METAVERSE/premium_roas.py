"""
Premium ROAS Dashboard - Apple-level UI/UX Design
Beautiful, modern interface with smooth animations and premium feel
"""
import streamlit as st
import pandas as pd
from pyairtable import Api
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import time

def apply_premium_styling():
    """Apply premium Apple-style CSS styling"""
    st.markdown("""
    <style>
    /* Import SF Pro Display font (Apple's font) */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    /* Global styling */
    .stApp {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    
    /* Main container */
    .main-container {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(20px);
        border-radius: 24px;
        padding: 32px;
        margin: 20px;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    /* Header styling */
    .premium-header {
        text-align: center;
        margin-bottom: 40px;
    }
    
    .premium-title {
        font-size: 3.5rem;
        font-weight: 700;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 8px;
        letter-spacing: -2px;
    }
    
    .premium-subtitle {
        font-size: 1.2rem;
        color: #6B7280;
        font-weight: 400;
        margin-bottom: 0;
    }
    
    /* Card styling */
    .metric-card {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 16px;
        padding: 24px;
        margin: 12px 0;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
        border: 1px solid rgba(255, 255, 255, 0.2);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .metric-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.1);
    }
    
    .metric-value {
        font-size: 2.5rem;
        font-weight: 700;
        color: #1F2937;
        margin-bottom: 4px;
        line-height: 1;
    }
    
    .metric-label {
        font-size: 0.875rem;
        color: #6B7280;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .metric-delta {
        font-size: 0.875rem;
        font-weight: 600;
        margin-top: 8px;
    }
    
    .positive { color: #059669; }
    .negative { color: #DC2626; }
    
    /* Button styling */
    .stButton > button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 12px;
        padding: 16px 32px;
        font-weight: 600;
        font-size: 1rem;
        transition: all 0.3s ease;
        box-shadow: 0 4px 16px rgba(102, 126, 234, 0.3);
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(102, 126, 234, 0.4);
    }
    
    /* Sidebar styling */
    .css-1d391kg {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(20px);
        border-radius: 0 24px 24px 0;
    }
    
    /* Input styling */
    .stTextInput > div > div > input {
        border-radius: 12px;
        border: 2px solid #E5E7EB;
        padding: 12px 16px;
        font-size: 1rem;
        transition: border-color 0.3s ease;
    }
    
    .stTextInput > div > div > input:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }
    
    /* Progress bar */
    .stProgress > div > div > div > div {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 8px;
    }
    
    /* Chart container */
    .chart-container {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 16px;
        padding: 24px;
        margin: 20px 0;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    /* Success/Error styling */
    .stSuccess {
        background: rgba(5, 150, 105, 0.1);
        border: 1px solid #059669;
        border-radius: 12px;
        padding: 16px;
    }
    
    .stError {
        background: rgba(220, 38, 38, 0.1);
        border: 1px solid #DC2626;
        border-radius: 12px;
        padding: 16px;
    }
    
    /* Loading animation */
    .loading-spinner {
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 3px solid rgba(102, 126, 234, 0.3);
        border-radius: 50%;
        border-top-color: #667eea;
        animation: spin 1s ease-in-out infinite;
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    
    /* Hide Streamlit branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    </style>
    """, unsafe_allow_html=True)

def create_premium_metric_card(title, value, delta=None, delta_color="positive"):
    """Create a premium-styled metric card"""
    delta_html = ""
    if delta:
        delta_html = f'<div class="metric-delta {delta_color}">{"↗" if delta_color == "positive" else "↘"} {delta}</div>'
    
    return f"""
    <div class="metric-card">
        <div class="metric-value">{value}</div>
        <div class="metric-label">{title}</div>
        {delta_html}
    </div>
    """

def create_loading_animation():
    """Create Apple-style loading animation"""
    return """
    <div style="display: flex; align-items: center; justify-content: center; padding: 40px;">
        <div class="loading-spinner"></div>
        <span style="margin-left: 16px; font-weight: 500; color: #6B7280;">Loading your data...</span>
    </div>
    """

def main():
    st.set_page_config(
        page_title="Premium ROAS Analytics",
        page_icon="📊",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    apply_premium_styling()
    
    # Main container
    st.markdown('<div class="main-container">', unsafe_allow_html=True)
    
    # Premium header
    st.markdown("""
    <div class="premium-header">
        <h1 class="premium-title">ROAS Analytics</h1>
        <p class="premium-subtitle">Premium marketing intelligence for Smooth MD</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Sidebar with premium styling
    with st.sidebar:
        st.markdown("### 🔑 Authentication")
        api_key = st.text_input(
            "Airtable API Key", 
            type="password",
            help="Enter your Airtable API key to access your lead and transaction data"
        )
        
        st.markdown("### 💰 Campaign Settings")
        meta_spend = st.number_input(
            "Meta Ad Spend ($)", 
            value=5000.0, 
            min_value=0.0,
            help="Total amount spent on Meta advertising"
        )
        
        date_range = st.date_input(
            "Date Range",
            value=[datetime.now() - timedelta(days=30), datetime.now()],
            help="Select the date range for analysis"
        )
        
        if not api_key:
            st.warning("Please enter your Airtable API key to continue")
            st.markdown('</div>', unsafe_allow_html=True)
            return
    
    # Main dashboard
    if st.button("🚀 Analyze Performance", type="primary"):
        analyze_performance(api_key, meta_spend)
    
    st.markdown('</div>', unsafe_allow_html=True)

def analyze_performance(api_key, meta_spend):
    """Analyze performance with premium UI"""
    
    # Loading animation
    with st.empty():
        st.markdown(create_loading_animation(), unsafe_allow_html=True)
        time.sleep(2)  # Simulate loading
    
    try:
        # Load data
        progress_container = st.container()
        with progress_container:
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            # Step 1: Load leads
            status_text.text("🔍 Analyzing lead database...")
            progress_bar.progress(25)
            
            api = Api(api_key)
            leads_table = api.table('appri2CgCoIiuZWq3', 'Leads')
            leads_records = leads_table.all()
            
            # Step 2: Process leads
            status_text.text("📊 Processing lead data...")
            progress_bar.progress(50)
            
            total_leads = len(leads_records)
            
            # Step 3: Load transactions
            status_text.text("💰 Loading transaction data...")
            progress_bar.progress(75)
            
            transactions_table = api.table('appri2CgCoIiuZWq3', 'Transactions')
            transactions_records = transactions_table.all()
            
            total_revenue = 0
            transaction_count = 0
            
            for record in transactions_records:
                fields = record.get('fields', {})
                amount_str = str(fields.get('fldUIvamoBDCIayd3', '0'))
                
                # Clean amount
                amount_clean = amount_str.replace('$', '').replace(',', '').strip()
                try:
                    amount = float(amount_clean) if amount_clean else 0
                    if amount > 0:
                        total_revenue += amount
                        transaction_count += 1
                except:
                    continue
            
            # Step 4: Calculate metrics
            status_text.text("🎯 Calculating ROAS...")
            progress_bar.progress(100)
            
            time.sleep(1)  # Brief pause for effect
            
        # Clear loading
        progress_container.empty()
        
        # Calculate key metrics
        roas = total_revenue / meta_spend if meta_spend > 0 else 0
        cost_per_lead = meta_spend / total_leads if total_leads > 0 else 0
        revenue_per_lead = total_revenue / total_leads if total_leads > 0 else 0
        conversion_rate = (transaction_count / total_leads * 100) if total_leads > 0 else 0
        avg_transaction = total_revenue / transaction_count if transaction_count > 0 else 0
        
        # Success message
        st.success(f"✅ Successfully analyzed {total_leads:,} leads and {transaction_count:,} transactions")
        
        # Premium metrics grid
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.markdown(create_premium_metric_card(
                "Total Leads", f"{total_leads:,}",
                f"+{int(total_leads * 0.12):,} this month", "positive"
            ), unsafe_allow_html=True)
            
        with col2:
            st.markdown(create_premium_metric_card(
                "Total Revenue", f"${total_revenue:,.0f}",
                f"+{roas*100-100:.1f}% ROI", "positive" if roas > 1 else "negative"
            ), unsafe_allow_html=True)
            
        with col3:
            st.markdown(create_premium_metric_card(
                "ROAS", f"{roas:.2f}x",
                "Profitable" if roas > 1 else "Loss", "positive" if roas > 1 else "negative"
            ), unsafe_allow_html=True)
            
        with col4:
            st.markdown(create_premium_metric_card(
                "Conversion Rate", f"{conversion_rate:.1f}%",
                f"${avg_transaction:,.0f} avg", "positive"
            ), unsafe_allow_html=True)
        
        # Secondary metrics
        col5, col6, col7, col8 = st.columns(4)
        
        with col5:
            st.markdown(create_premium_metric_card(
                "Cost per Lead", f"${cost_per_lead:.2f}"
            ), unsafe_allow_html=True)
            
        with col6:
            st.markdown(create_premium_metric_card(
                "Revenue per Lead", f"${revenue_per_lead:.2f}"
            ), unsafe_allow_html=True)
            
        with col7:
            st.markdown(create_premium_metric_card(
                "Total Transactions", f"{transaction_count:,}"
            ), unsafe_allow_html=True)
            
        with col8:
            profit = total_revenue - meta_spend
            st.markdown(create_premium_metric_card(
                "Net Profit", f"${profit:,.0f}",
                "Positive" if profit > 0 else "Negative", "positive" if profit > 0 else "negative"
            ), unsafe_allow_html=True)
        
        # Premium charts
        st.markdown('<div class="chart-container">', unsafe_allow_html=True)
        st.markdown("### 📈 Performance Overview")
        
        # ROAS visualization
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            name='Investment',
            x=['Meta Ads'],
            y=[meta_spend],
            marker_color='rgba(102, 126, 234, 0.8)',
            text=f'${meta_spend:,.0f}',
            textposition='auto',
            hovertemplate='Investment: $%{y:,.0f}<extra></extra>'
        ))
        
        fig.add_trace(go.Bar(
            name='Revenue',
            x=['Returns'],
            y=[total_revenue],
            marker_color='rgba(5, 150, 105, 0.8)',
            text=f'${total_revenue:,.0f}',
            textposition='auto',
            hovertemplate='Revenue: $%{y:,.0f}<extra></extra>'
        ))
        
        fig.update_layout(
            title={
                'text': f'Investment vs Returns (ROAS: {roas:.2f}x)',
                'font': {'size': 20, 'family': 'Inter'},
                'x': 0.5
            },
            barmode='group',
            height=400,
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font={'family': 'Inter'},
            showlegend=True,
            legend={'orientation': 'h', 'yanchor': 'bottom', 'y': 1.02, 'xanchor': 'right', 'x': 1}
        )
        
        fig.update_xaxes(showgrid=False)
        fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor='rgba(0,0,0,0.1)')
        
        st.plotly_chart(fig, use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Performance breakdown
        col_left, col_right = st.columns(2)
        
        with col_left:
            st.markdown('<div class="chart-container">', unsafe_allow_html=True)
            st.markdown("### 🎯 Conversion Funnel")
            
            funnel_data = {
                'Stage': ['Total Leads', 'Qualified Leads', 'Conversions'],
                'Count': [total_leads, int(total_leads * 0.6), transaction_count],
                'Rate': ['100%', '60%', f'{conversion_rate:.1f}%']
            }
            
            fig2 = go.Figure(go.Funnel(
                y=funnel_data['Stage'],
                x=funnel_data['Count'],
                textinfo="value+percent initial",
                marker_color=['rgba(102, 126, 234, 0.8)', 'rgba(118, 75, 162, 0.8)', 'rgba(5, 150, 105, 0.8)']
            ))
            
            fig2.update_layout(
                height=300,
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                font={'family': 'Inter'}
            )
            
            st.plotly_chart(fig2, use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)
        
        with col_right:
            st.markdown('<div class="chart-container">', unsafe_allow_html=True)
            st.markdown("### 💰 Revenue Breakdown")
            
            breakdown_data = {
                'Category': ['Ad Spend', 'Revenue', 'Profit'],
                'Amount': [meta_spend, total_revenue, total_revenue - meta_spend],
                'Color': ['#EF4444', '#059669', '#3B82F6' if total_revenue > meta_spend else '#EF4444']
            }
            
            fig3 = px.pie(
                values=breakdown_data['Amount'],
                names=breakdown_data['Category'],
                color_discrete_sequence=['#EF4444', '#059669', '#3B82F6']
            )
            
            fig3.update_layout(
                height=300,
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                font={'family': 'Inter'},
                showlegend=True
            )
            
            st.plotly_chart(fig3, use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)
        
    except Exception as e:
        st.error(f"❌ Error analyzing data: {str(e)}")
        st.info("💡 Please check your Airtable API key and try again")

if __name__ == "__main__":
    main()